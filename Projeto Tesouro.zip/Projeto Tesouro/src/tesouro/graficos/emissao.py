"""Emissao vista pelo leilao: financeiro de um lado, DV do outro.

O RMD conta emissao em reais. Estes graficos contam nas duas moedas ao mesmo tempo,
e a diferenca entre elas e o assunto: dez bilhoes de LTN curta e dez bilhoes de NTN-B
2060 sao a mesma barra na aba 1.2 e coisas incomparaveis aqui.

TODOS os graficos usam o ACEITO no leilao, nunca o ofertado. Ofertado e intencao;
aceito e o que virou divida.

Tres eixos de escolha, porque a pergunta muda a resposta:

  - COMPRA: incluir ou nao os leiloes de recompra, que entram com sinal negativo,
    como resgate. Sem eles se ve emissao bruta; com eles, o liquido;
  - SEGUNDA VOLTA: incluir ou nao. Para o tamanho do leilao no dia, o que importa e
    o que foi ofertado e colocado na primeira; para quanto de risco entrou no
    mercado num periodo, a segunda volta faz parte e tirar subestima;
  - JANELA: o recorte de tempo, como no resto do dashboard.

A LFT nao tem DV, por decisao de modelagem da entrega 2 -- ela aparece so em
financeiro, com media movel de 3 meses.
"""
import pandas as pd

from .. import config, leiloes_recentes
from . import estilo

# A ordem em que as familias empilham e aparecem na legenda: do mais curto para o
# mais longo, que e a ordem em que elas acrescentam risco.
ORDEM_FAMILIAS = ["LFT", "LTN", "NTN-F", "NTN-B at\u00e9 10 anos", "NTN-B acima de 10 anos"]

_COR_FAMILIA = {"LFT": "LFT", "LTN": "LTN", "NTN-F": "NTN-F",
                "NTN-B at\u00e9 10 anos": "NTN-B", "NTN-B acima de 10 anos": "NTN-C",
                # Os grupos, para o anual agrupado. A cor de "Prefixado" e a da
                # LTN e a de "NTN-B" e a da NTN-B ate 10 anos -- as duas maiores de
                # cada grupo -- para o agrupado ler como o detalhado.
                "Prefixado": "LTN", "NTN-B": "Indice Precos"}

# COMO AS FAMILIAS SE JUNTAM no grafico por INDEXADOR. Pedido dela: cinco
# faixas em 26 barras ainda era mais detalhe do que se le a essa distancia;
# tres bastam para a pergunta "quanto de cada indexador".
#
# INDEXADOR E A PALAVRA DELA. Eu tinha escrito "regime de juros", que inventei
# -- e vocabulario proprio no lugar do vocabulario do dominio faz o leitor
# traduzir para conferir contra o RMD, que fala em indexador.
GRUPO_DA_FAMILIA = {"LFT": "LFT", "LTN": "Prefixado", "NTN-F": "Prefixado",
                    "NTN-B at\u00e9 10 anos": "NTN-B", "NTN-B acima de 10 anos": "NTN-B"}
ORDEM_DOS_GRUPOS = ["LFT", "Prefixado", "NTN-B"]

# Os recortes que ganham grafico proprio de dois eixos.
RECORTES = {
    "NTN-B": ("NTN-B at\u00e9 10 anos", "NTN-B acima de 10 anos"),
    "NTN-B at\u00e9 10 anos": ("NTN-B at\u00e9 10 anos",),
    "NTN-B acima de 10 anos": ("NTN-B acima de 10 anos",),
    "NTN-F": ("NTN-F",),
    "LTN": ("LTN",),
    "LTN + NTN-F": ("LTN", "NTN-F"),
    "LFT": ("LFT",),
    # OS DOIS RECORTES DOS ACUMULADOS DE 12 MESES, que espelham os semanais.
    #
    # A LFT ENTRA NUM E NAO NO OUTRO, e nao e descuido: ela nao tem DV01 --
    # medido, a coluna e inteiramente nula para ela --, entao num grafico de DV
    # ela nao tem o que somar. Num de financeiro ela e mais da metade do total,
    # e deixa-la de fora esconderia o grosso do que o Tesouro leiloa.
    "sem LFT": ("LTN", "NTN-F", "NTN-B at\u00e9 10 anos", "NTN-B acima de 10 anos"),
    "tudo": ("LTN", "NTN-F", "NTN-B at\u00e9 10 anos", "NTN-B acima de 10 anos", "LFT"),
}

# EM QUE PERIODO A SERIE E SOMADA. "W" e o de sempre; "M" entrou em
# 09/09/2026 para a pagina do historico completo.
#
# A ESCOLHA E DE LEGIBILIDADE, MEDIDA. A serie tem 25,7 anos (02/01/2001 em
# diante): por semana sao 1.287 barras, que numa figura de ~1.100 px dao menos
# de um pixel cada -- e o borrao que fez a janela "completa" ser cortada da
# pagina de emissoes em 20/08/2026. Por mes sao 309, cerca de 3,5 px cada:
# deixa-se de ver meses e passa-se a ver epocas, que e a leitura certa nessa
# distancia.
#
# O ROTULO ANDA JUNTO DO DADO. Eixo dizendo "na semana" num grafico mensal e o
# mesmo defeito de um titulo prometendo 12 meses com dado de 3: texto literal
# descolado da conta, que ninguem confere porque parece decoracao.
_PALAVRA_DO_PERIODO = {"W": "semana", "M": "m\u00eas", "Y": "ano"}


def ultima_data(com_compra=False, com_segunda_volta=True):
    """O ultimo dia de leilao que existe no dado.

    Existe para a marca do ano parcial sair do DADO e nao de uma data cravada:
    no dia em que o ano fechar, a marca some sozinha.
    """
    return _base(com_compra, com_segunda_volta)["data_leilao"].max()


def _por_periodo(datas, periodo="W"):
    """A coluna de agrupamento, no periodo pedido."""
    if periodo not in _PALAVRA_DO_PERIODO:
        raise LookupError(
            f"periodo '{periodo}' nao existe: {sorted(_PALAVRA_DO_PERIODO)}.")
    return datas.dt.to_period(periodo).dt.start_time


_COR_FINANCEIRO = "#3d9be9"
_COR_DV = "#c00000"


# TRES APARENCIAS PARA TRES MOMENTOS. Um leilao aparece na tela tres vezes, e a
# barra vai ficando mais solida conforme o numero fica mais firme:
#
#   ofertado -- HACHURADA, e com contorno grosso sobre preenchimento fraco. E um
#               TETO: a quantidade anunciada as 10h30, que historicamente cai
#               para 83,9% dela, com taxa emprestada do leilao anterior;
#   aceito   -- solida. O resultado saiu e a quantidade e final;
#   planilha -- solida. Nao muda mais.
#
# A HACHURA SIGNIFICA "ESTE NUMERO AINDA VAI MUDAR", e nao "este numero veio da
# API". Decisao dela em 09/09/2026: "so coloque hachurado os leiloes que ainda
# nao saiu o resultado". Ate ali era o contrario -- a hachura marcava o ACEITO,
# cuja quantidade ja nao muda, e o ofertado, que e o unico numero de verdade
# provisorio, ficava so com o contorno esmaecido.
#
# O PRECO, aceito de propria vontade: 'aceito' fica visualmente IGUAL a
# 'planilha'. Some da tela a distincao "a planilha do Tesouro ainda nao
# confirmou" -- que e bookkeeping do Tesouro, e nao informacao sobre o numero.
#
# E hachura e contorno, e nao cor, porque no grafico empilhado a cor JA significa
# papel -- roubar uma cor para significar momento criaria duas leituras para o
# mesmo sinal.
HACHURA_ACEITO = ""
HACHURA_OFERTADO = "///"

ESTAGIO_MAIS_FIRME = "planilha"

# A LEGENDA NAO DIZ DE ONDE VEIO A TAXA, e ha um motivo. A proveniencia varia linha
# a linha -- ela digita a taxa de alguns papeis e deixa outros em branco -- e uma
# barra somada pode ter as duas dentro. Afirmar "a taxa e a do leilao anterior" na
# legenda seria mentira nos dias em que ela digitou todas, que foi o primeiro dia de
# uso. Quem diz e o aviso do topo da pagina, que conta as duas.
# CURTO DE PROPOSITO. A primeira versao explicava o estagio inteiro na legenda
# ("aceito hoje (API) - muda quando a planilha sair"), e a frase competia com o
# grafico. A explicacao mora no texto da pagina, que e onde se le texto; a legenda
# so precisa dizer qual barra e qual.
# SO O OFERTADO TEM ROTULO. Ate 09/09/2026 o 'aceito' tinha o seu, porque
# tinha aparencia propria (hachura). Com a hachura passando a marcar o
# ofertado, o aceito ficou identico a planilha -- e nomear na legenda uma
# barra indistinguivel das outras manda o leitor procurar o que nao ha.
_ROTULO_DO_ESTAGIO = {
    "ofertado": "ofertado hoje (teto)",
}


def _menos_firme(estagios):
    """De um grupo de linhas, o estagio menos adiantado.

    Um dia de leilao soma varios papeis. Se um deles ainda e teto, a soma daquele
    dia tambem e teto -- ela nao pode ser mais firme que a sua parte mais fraca.
    """
    presentes = [e for e in estagios if isinstance(e, str)]
    if not presentes:
        return ESTAGIO_MAIS_FIRME
    return min(presentes, key=lambda e: leiloes_recentes.ORDEM_DOS_ESTAGIOS.get(e, 9))


def _base(com_compra=False, com_segunda_volta=True):
    """O CSV do DV por leilao, com os dois filtros de escolha aplicados."""
    d = pd.read_csv(config.PROCESSED_DIR / "dv_emitido_por_leilao.csv",
                    parse_dates=["data_leilao", "data_liquidacao"])
    # CSVs gravados antes de a API existir nao tem a coluna. Sem este default, todo
    # grafico quebraria ao ler um arquivo antigo -- e o certo e ele continuar
    # lendo, dizendo que tudo ali e definitivo, porque e.
    if "estagio" not in d.columns:
        d["estagio"] = "planilha" if "origem" not in d.columns else d["origem"].map(
            {"planilha": "planilha", "api": "aceito"}).fillna("planilha")
    if not com_compra:
        d = d[d["operacao"] == "venda"]
    if not com_segunda_volta:
        # O rotulo vem do arquivo do Tesouro com o ordinal por extenso.
        d = d[~d["volta"].fillna("").str.startswith("2")]
    return d


def por_dia(recorte, janela=None, com_compra=False, com_segunda_volta=True,
            periodo=None):
    """Financeiro e DV somados por DIA DE LEILAO, para um recorte de papel.

    Um dia de leilao pode ter varios vertices do mesmo papel; aqui eles somam, que e
    a leitura de "quanto entrou naquele dia".

    'periodo' agrega mais grosso -- "M" por mes, "Y" por ano. O padrao None
    mantem o dia de leilao, e portanto mantem identicas as paginas que ja
    existem. Entrou em 09/09/2026 para os dois graficos anuais.
    """
    if recorte not in RECORTES:
        raise LookupError(
            f"recorte '{recorte}' nao existe. Os que existem: "
            f"{sorted(RECORTES)}."
        )
    d = _base(com_compra, com_segunda_volta)
    d = d[d["familia"].isin(RECORTES[recorte])]

    chave = ("data_leilao" if periodo is None
             else _por_periodo(d["data_leilao"], periodo))
    saida = d.groupby(chave).agg(
        financeiro_milhoes=("financeiro_milhoes", "sum"),
        dv_milhoes=("dv_milhoes", "sum"),
        leiloes=("titulo", "size"),
        # A barra do dia recebe o estagio MENOS firme entre as linhas dele: se um
        # papel do dia ainda e teto, o total daquele dia tambem e teto. Marcar so
        # "parte" de uma barra somada nao existe.
        estagio=("estagio", _menos_firme),
    )
    # A LFT nao tem DV: a soma de uma coluna toda vazia devolve zero, e zero aqui
    # seria uma afirmacao sobre o risco dela. Volta a ser vazio.
    if d["dv_milhoes"].notna().sum() == 0:
        saida["dv_milhoes"] = float("nan")
    return estilo.recorta(saida, janela)


def por_semana(janela=None, com_compra=False, com_segunda_volta=True,
               periodo="W"):
    """Financeiro e DV somados por SEMANA -- ou por mes, com periodo="M".

    Sem a LFT porque o grafico tem os dois eixos e ela so tem um dos dois numeros --
    inclui-la faria o financeiro e o DV falarem de conjuntos diferentes de papel.
    """
    d = _base(com_compra, com_segunda_volta)
    d = d[d["familia"] != "LFT"]
    semana = _por_periodo(d["data_leilao"], periodo)
    saida = d.groupby(semana).agg(
        financeiro_milhoes=("financeiro_milhoes", "sum"),
        dv_milhoes=("dv_milhoes", "sum"),
        estagio=("estagio", _menos_firme),
    )
    saida.index.name = _PALAVRA_DO_PERIODO[periodo]
    return estilo.recorta(saida, janela)


def por_semana_por_familia(janela=None, com_compra=False,
                           com_segunda_volta=True, periodo="W"):
    """A soma da semana, com o financeiro aberto por familia. Sem LFT.

    Sem a LFT pelo mesmo motivo de por_semana(): o grafico tem dois eixos e ela so
    tem um dos dois numeros -- inclui-la faria o financeiro e o DV falarem de
    conjuntos diferentes de papel. Ela tem o grafico empilhado so dela.
    """
    d = _base(com_compra, com_segunda_volta)
    d = d[d["familia"] != "LFT"]
    semana = _por_periodo(d["data_leilao"], periodo)

    piv = d.pivot_table(index=semana, columns="familia",
                        values="financeiro_milhoes", aggfunc="sum").fillna(0.0)
    familias = [f for f in ORDEM_FAMILIAS if f != "LFT"]
    for familia in familias:
        if familia not in piv.columns:
            piv[familia] = 0.0
    piv = piv[familias]

    resto = d.groupby(semana).agg(
        financeiro_milhoes=("financeiro_milhoes", "sum"),
        dv_milhoes=("dv_milhoes", "sum"),
        estagio=("estagio", _menos_firme),
    )
    saida = piv.join(resto)
    saida.index.name = _PALAVRA_DO_PERIODO[periodo]
    return estilo.recorta(saida, janela)


def financeiro_semanal_por_papel(janela=None, com_compra=False,
                                 com_segunda_volta=True, periodo="W"):
    """Financeiro por semana, uma coluna por familia -- para a barra empilhada.

    Aqui a LFT ENTRA: e um grafico de financeiro so, e ela e mais da metade dele.

    E o caso particular de por_familia() com a coluna do financeiro. O nome
    ficou porque a pagina de emissoes inteira o usa.
    """
    return por_familia("financeiro_milhoes", janela, com_compra,
                       com_segunda_volta, periodo)


def por_familia(coluna, janela=None, com_compra=False, com_segunda_volta=True,
                periodo="W", agrupado=False):
    """QUALQUER grandeza aberta por familia de papel, somada no periodo.

    Ate 09/09/2026 so o financeiro se abria assim. O DV precisou do mesmo
    quando ela mandou empilhar tambem os graficos anuais -- e duplicar a funcao
    trocando uma coluna criaria duas versoes da mesma conta.
    """
    d = _base(com_compra, com_segunda_volta)
    semana = _por_periodo(d["data_leilao"], periodo)
    if agrupado:
        d = d.assign(familia=d["familia"].map(GRUPO_DA_FAMILIA))
    piv = d.pivot_table(index=semana, columns="familia",
                        values=coluna, aggfunc="sum").fillna(0.0)
    piv.index.name = _PALAVRA_DO_PERIODO[periodo]
    ordem = ORDEM_DOS_GRUPOS if agrupado else ORDEM_FAMILIAS
    for familia in ordem:
        if familia not in piv.columns:
            piv[familia] = 0.0
    piv = piv[ordem]
    piv["estagio"] = d.groupby(semana)["estagio"].apply(_menos_firme).reindex(
        piv.index).fillna(ESTAGIO_MAIS_FIRME)
    return estilo.recorta(piv, janela)


def por_dia_por_familia(recorte, janela=None, com_compra=False,
                        com_segunda_volta=True):
    """Como por_dia(), mas com o financeiro ABERTO POR FAMILIA de papel.

    Serve aos graficos em que a barra e empilhada: no recorte "LTN + NTN-F" a barra
    somada esconde qual dos dois moveu o dia, e sao papeis com prazos muito
    diferentes. O DV continua vindo somado, porque a linha e uma so.
    """
    if recorte not in RECORTES:
        raise LookupError(f"recorte '{recorte}' nao existe: {sorted(RECORTES)}.")
    d = _base(com_compra, com_segunda_volta)
    d = d[d["familia"].isin(RECORTES[recorte])]

    piv = d.pivot_table(index="data_leilao", columns="familia",
                        values="financeiro_milhoes", aggfunc="sum").fillna(0.0)
    for familia in RECORTES[recorte]:
        if familia not in piv.columns:
            piv[familia] = 0.0
    piv = piv[[f for f in ORDEM_FAMILIAS if f in RECORTES[recorte]]]

    resto = d.groupby("data_leilao").agg(
        financeiro_milhoes=("financeiro_milhoes", "sum"),
        dv_milhoes=("dv_milhoes", "sum"),
        estagio=("estagio", _menos_firme),
    )
    if d["dv_milhoes"].notna().sum() == 0:
        resto["dv_milhoes"] = float("nan")
    return estilo.recorta(piv.join(resto), janela)


def acumulado(recorte, meses=3, janela=None, com_compra=False,
              com_segunda_volta=True):
    """Soma movel dos ultimos N MESES de financeiro e de DV, por dia de leilao.

    A serie diaria de leilao e serrilhada por construcao: o Tesouro leiloa NTN-B num
    dia e prefixado no outro, entao dia sim dia nao a barra e zero para um recorte.
    A soma movel tira o serrilhado e mostra o que o trimestre acumulou, que e a
    escala em que emissao se compara com PAF e com meta.

    A JANELA E DE CALENDARIO, e nao de numero de leiloes: "ultimos 3 meses" tem de
    querer dizer tres meses mesmo, inclusive quando o Tesouro muda a frequencia dos
    leiloes no meio do periodo. Por isso a soma corre sobre uma serie diaria
    reindexada, e nao sobre as linhas.
    """
    if recorte not in RECORTES:
        raise LookupError(f"recorte '{recorte}' nao existe: {sorted(RECORTES)}.")
    d = _base(com_compra, com_segunda_volta)
    d = d[d["familia"].isin(RECORTES[recorte])]
    if d.empty:
        return pd.DataFrame(columns=["financeiro_milhoes", "dv_milhoes"])

    por_leilao = d.groupby("data_leilao").agg(
        financeiro_milhoes=("financeiro_milhoes", "sum"),
        dv_milhoes=("dv_milhoes", "sum"),
    )
    tem_dv = d["dv_milhoes"].notna().sum() > 0

    # Reindexa em dias corridos para que a janela seja de calendario, soma, e volta
    # a ficar so com os dias em que houve leilao -- desenhar os zeros no meio faria
    # a linha cair todo dia sem leilao.
    diario = por_leilao.reindex(
        pd.date_range(por_leilao.index.min(), por_leilao.index.max(), freq="D")
    ).fillna(0.0)
    soma = diario.rolling(f"{int(meses * 30.44)}D").sum()
    soma = soma.loc[por_leilao.index]
    if not tem_dv:
        soma["dv_milhoes"] = float("nan")
    soma.index.name = "data_leilao"
    return estilo.recorta(soma, janela)


def demanda(recorte, janela=None, com_segunda_volta=True):
    """Por dia de leilao: o DV que ele OFERTOU, o que COLOCOU, e a fracao.

    A PERGUNTA QUE ISTO RESPONDE, e que a emissao sozinha nao responde: ele nao
    conseguiu colocar, ou nao quis? Uma barra baixa de emissao pode ser um dia em
    que ele ofertou pouco, ou um dia em que ofertou muito e o mercado nao levou --
    e sao coisas opostas.

    SO VENDA. Recompra nao tem "ofertado e colocado" no mesmo sentido: o Tesouro
    esta do outro lado, e a razao mediria outra coisa.

    A FRACAO E MEDIDA EM DV, e nao em quantidade. Medido no historico inteiro, a
    diferenca entre as duas leituras e material na NTN-B acima de 10 anos: 38,5%
    da quantidade contra 49,5% do DV. Em quantidade, um lote de LTN de seis meses pesa igual a um
    de NTN-B de trinta anos; em DV, cada um pesa o risco que carrega -- e e risco
    que esta pagina conta.
    """
    if recorte not in RECORTES:
        raise LookupError(f"recorte '{recorte}' nao existe: {sorted(RECORTES)}.")
    d = _base(com_compra=False, com_segunda_volta=com_segunda_volta)
    d = d[d["familia"].isin(RECORTES[recorte])]
    d = d[d["oferta_qtd"].fillna(0) > 0]
    if d.empty:
        return pd.DataFrame(columns=["dv_ofertado", "dv_aceito", "colocado_pct"])

    saida = d.groupby("data_leilao").agg(
        dv_ofertado=("dv_ofertado_milhoes", "sum"),
        dv_aceito=("dv_milhoes", "sum"),
        qtd_ofertada=("oferta_qtd", "sum"),
        qtd_aceita=("quantidade", "sum"),
        financeiro_milhoes=("financeiro_milhoes", "sum"),
        estagio=("estagio", _menos_firme),
    )
    # A LFT nao tem DV: a fracao dela so existe em quantidade, e o grafico dela
    # troca de eixo por isso.
    tem_dv = d["dv_milhoes"].notna().sum() > 0
    if not tem_dv:
        saida["dv_ofertado"] = float("nan")
        saida["dv_aceito"] = float("nan")
        saida["colocado_pct"] = (
            saida["qtd_aceita"] / saida["qtd_ofertada"].replace(0, float("nan")))
    else:
        saida["colocado_pct"] = (
            saida["dv_aceito"] / saida["dv_ofertado"].replace(0, float("nan")))
    return estilo.recorta(saida, janela)


def colocado_por_familia(janela=None, com_segunda_volta=True, meses=6):
    """A fracao colocada de cada familia, em media movel de N meses.

    MEDIA MOVEL porque a serie diaria e ruidosa demais para comparar familias: num
    dia qualquer uma delas colocou 100% e a outra 40%, e as cinco linhas viram um
    emaranhado. Em seis meses o nivel de cada uma aparece.

    A LFT entra pela QUANTIDADE, as demais pelo DV -- e a legenda diz isso, porque
    somar as duas leituras num grafico so seria misturar duas reguas.
    """
    d = _base(com_compra=False, com_segunda_volta=com_segunda_volta)
    d = d[d["oferta_qtd"].fillna(0) > 0]
    if d.empty:
        return pd.DataFrame(columns=ORDEM_FAMILIAS)

    dias = int(meses * 30.44)

    # UM CALENDARIO SO, COMUM AS CINCO FAMILIAS. Cada uma montava a serie diaria
    # no proprio intervalo, e como LFT e NTN-B vao a mercado na terca e o
    # prefixado na quinta, elas terminam em dias diferentes -- o DataFrame
    # alinhava os indices e sobrava NaN na cauda da familia que parou antes.
    # Exatamente o buraco que o comentario abaixo promete nao existir.
    #
    # DEPENDIA DO DIA DA SEMANA: quando o ultimo leilao do dado era quinta, o
    # prefixado estava em dia e o teste passava; quando era terca, ele ficava
    # dois dias atras e o teste quebrava. Apareceu em 25/08/2026, uma terca, com
    # o resultado do proprio dia ja no dado.
    por_familia = {}
    for familia in ORDEM_FAMILIAS:
        g = d[d["familia"] == familia]
        if g.empty:
            continue
        em_dv = g["dv_milhoes"].notna().sum() > 0
        cima = "dv_milhoes" if em_dv else "quantidade"
        baixo = "dv_ofertado_milhoes" if em_dv else "oferta_qtd"
        por_familia[familia] = g.groupby("data_leilao").agg(
            cima=(cima, "sum"), baixo=(baixo, "sum"))

    if not por_familia:
        return pd.DataFrame(columns=ORDEM_FAMILIAS)
    inicio = min(v.index.min() for v in por_familia.values())
    fim = max(v.index.max() for v in por_familia.values())
    todo_o_periodo = pd.date_range(inicio, fim, freq="D")

    colunas = {}
    for familia, por_dia in por_familia.items():
        diario = por_dia.reindex(todo_o_periodo).fillna(0.0)
        movel = diario.rolling(f"{dias}D").sum()
        # A razao vale TODO DIA, e nao so nos dias de leilao daquele papel: e uma
        # soma movel de seis meses, e ela nao deixa de existir na terca porque o
        # papel foi a mercado na segunda. Guardar so os dias de leilao produziria
        # cinco linhas com buracos alternados -- LFT e NTN-B num dia, prefixado no
        # outro -- e cinco linhas tracejadas nao se comparam.
        colunas[familia] = movel["cima"] / movel["baixo"].replace(0, float("nan"))

    saida = pd.DataFrame(colunas).sort_index()
    # So a partir do dia em que a janela movel de fato completou: antes disso a
    # razao e de meio periodo e nao quer dizer o que o rotulo promete.
    primeiro = min(s.first_valid_index() for s in colunas.values())
    saida = saida.loc[saida.index >= primeiro + pd.Timedelta(days=dias)]
    saida.index.name = "data"
    return estilo.recorta(saida, janela)


def dv_e_taxa(recorte, janela=None, com_segunda_volta=True):
    """DV01 emitido no dia e taxa media do dia, para a dispersao.

    ANTES ERA QUANTIDADE, e nao dizia nada: a quantidade de titulos mistura uma LTN
    de seis meses com uma NTN-B de 35 anos como se fossem a mesma coisa, e a nuvem
    saia sem forma. O DV emitido e a moeda comum -- e a pergunta que a dispersao
    responde passa a ser a que interessa: quando a taxa esta alta, ele coloca mais
    RISCO no mercado, ou menos?

    A taxa e a media PONDERADA pelo financeiro. A simples trataria um lote de 100
    milhoes e um de 10 bilhoes como iguais, o que nao descreve leilao nenhum.
    """
    if recorte not in RECORTES:
        raise LookupError(f"recorte '{recorte}' nao existe: {sorted(RECORTES)}.")
    d = _base(com_compra=False, com_segunda_volta=com_segunda_volta)
    d = d[d["familia"].isin(RECORTES[recorte])]
    d = d[d["taxa_media_pct"].notna() & (d["financeiro_milhoes"] > 0)]
    d = d[d["dv_milhoes"].notna()]
    if d.empty:
        return pd.DataFrame(columns=["dv_milhoes", "taxa_media_pct",
                                     "financeiro_milhoes"])

    def ponderada(g):
        return (g["taxa_media_pct"] * g["financeiro_milhoes"]).sum() \
            / g["financeiro_milhoes"].sum()

    saida = d.groupby("data_leilao").apply(
        lambda g: pd.Series({
            "dv_milhoes": g["dv_milhoes"].sum(),
            "financeiro_milhoes": g["financeiro_milhoes"].sum(),
            "taxa_media_pct": ponderada(g),
        }),
        include_groups=False,
    )
    return estilo.recorta(saida, janela)


def quantidade_e_taxa(recorte, janela=None, com_segunda_volta=True):
    """Quantidade aceita e taxa media, por dia de leilao, para um recorte.

    A taxa e a media PONDERADA pelo financeiro. A media simples trataria um lote de
    100 milhoes e um de 10 bilhoes como iguais, o que nao descreve leilao nenhum.

    So venda: taxa media de recompra e outra coisa e misturar as duas nao tem
    leitura.
    """
    if recorte not in RECORTES:
        raise LookupError(f"recorte '{recorte}' nao existe: {sorted(RECORTES)}.")
    d = _base(com_compra=False, com_segunda_volta=com_segunda_volta)
    d = d[d["familia"].isin(RECORTES[recorte])]
    d = d[d["taxa_media_pct"].notna() & (d["financeiro_milhoes"] > 0)]

    def ponderada(g):
        return (g["taxa_media_pct"] * g["financeiro_milhoes"]).sum() \
            / g["financeiro_milhoes"].sum()

    saida = d.groupby("data_leilao").apply(
        lambda g: pd.Series({
            "quantidade": g["quantidade"].sum(),
            "financeiro_milhoes": g["financeiro_milhoes"].sum(),
            "taxa_media_pct": ponderada(g),
        }),
        include_groups=False,
    )
    return estilo.recorta(saida, janela)


def _estagios(dados):
    """A lista de estagios, uma por barra. None quando nada esta em oferta.

    Devolve None -- e nao uma lista -- para que o SVG continue byte a byte o
    mesmo de antes de a API existir. A reprodutibilidade e testada, e passar
    hatch=["",""] em vez de hatch=None ja muda o arquivo.

    O CORTE E "HA OFERTA?", e nao "ha algo fora da planilha". Ate 09/09/2026
    era o segundo, porque o 'aceito' tinha aparencia propria. Ela viu a pagina e
    perguntou por que as colunas eram diferentes: eram as que a API ja trouxe e
    a planilha do Tesouro ainda nao confirmou -- distincao que e bookkeeping do
    Tesouro, e nao informacao sobre o numero. Com o aceito indistinguivel da
    planilha, um dia sem oferta pendente nao precisa de aparencia por barra
    nenhuma.
    """
    if "estagio" not in dados.columns:
        return None
    marcas = dados["estagio"].fillna(ESTAGIO_MAIS_FIRME).astype(str)
    if not (marcas == "ofertado").any():
        return None
    return list(marcas)


# Quanto do preenchimento sobra na barra da oferta. Zero -- barra oca -- foi a
# primeira tentativa e apagava a composicao do grafico empilhado, que e a coisa que
# ele existe para mostrar. Fantasma preserva a cor do papel e continua lendo como
# "ainda nao aconteceu".
OPACIDADE_DO_OFERTADO = 0.22


def _aparencia(estagios, cor, opacidade=0.75):
    """Os argumentos de barra que traduzem estagio em aparencia.

    Devolve um dicionario pronto para ax.bar(**...). Quando nao ha nada provisorio,
    devolve a aparencia antiga e nada mais -- ver _estagios().

    A opacidade entra na COR, e nao no alpha= da barra: alpha e um so para a serie
    inteira, e aqui cada barra precisa da sua.
    """
    from matplotlib.colors import to_rgba

    if estagios is None:
        return {"color": to_rgba(cor, opacidade)}
    return {
        "color": [to_rgba(cor, OPACIDADE_DO_OFERTADO if e == "ofertado"
                          else opacidade) for e in estagios],
        "hatch": [HACHURA_OFERTADO if e == "ofertado" else HACHURA_ACEITO
                  for e in estagios],
        # O contorno forte na oferta e o que faz o fantasma parecer contorno, e
        # nao cor desbotada por acidente.
        #
        # E SO A OFERTA TEM CONTORNO. Ate 09/09/2026 o 'aceito' levava um
        # contorno escuro fino (0,4) contra nenhum da planilha -- sobra da regra
        # antiga, em que ele tambem era hachurado. Resultado saido, quantidade
        # final: nao ha o que distinguir, e distinguir mesmo assim faz quem le
        # procurar um sentido que nao existe.
        "edgecolor": [to_rgba(cor, 1.0) if e == "ofertado" else "none"
                      for e in estagios],
        "linewidth": [1.6 if e == "ofertado" else 0.0 for e in estagios],
    }


def _legenda_dos_estagios(estagios):
    """A entrada de legenda que explica o contorno e a hachura do ofertado.

    UMA SO, e so quando ha oferta sem resultado na tela. Desde 09/09/2026 o
    'aceito' nao tem aparencia propria -- ele ficou igual a planilha --, entao
    nomea-lo aqui mandaria o leitor procurar uma barra que nao se distingue.

    Hachura sem legenda e enfeite: quem olha nao tem como saber que aquela barra
    pode mudar de altura amanha.
    """
    if estagios is None:
        return []
    from matplotlib.patches import Patch

    marcas = []
    for estagio in _ROTULO_DO_ESTAGIO:
        if estagio not in estagios:
            continue
        marcas.append(Patch(
            facecolor="#cccccc", edgecolor="#555555",
            hatch=HACHURA_OFERTADO, linewidth=1.4,
            label=_ROTULO_DO_ESTAGIO[estagio]))
    return marcas


# TETO DA LARGURA DA BARRA, em dias.
#
# O de sempre e 5: com serie diaria ou semanal, uma barra mais larga que isso
# vira bloco assim que um trecho fica esparso -- e o espacamento MEDIO, que e o
# que a conta usa, superestima o espacamento LOCAL nesses trechos.
#
# O MENSAL PRECISA DE OUTRO, e o defeito apareceu olhando o desenho: com
# espacamento de ~30 dias, 0,75 dele daria ~22, e o teto de 5 cortava para um
# sexto do vao. A pagina do historico saia como rendilhado, e a composicao por
# papel -- que e o assunto do grafico empilhado -- sumia. Aqui o espacamento e
# regular por construcao (um ponto por mes), entao o risco que o teto de 5
# existe para evitar nao se aplica.
TETO_DIARIO = 5.0
TETO_MENSAL = 22.0
# 26 barras num vao de 365 dias sairiam com 5 -- um pente. Mesmo defeito do
# mensal, e mesma razao para o teto proprio: aqui o espacamento e regular por
# construcao, um ponto por ano.
TETO_ANUAL = 270.0

_TETO_DO_PERIODO = {"W": TETO_DIARIO, "M": TETO_MENSAL, "Y": TETO_ANUAL}


def _largura(indice, maximo=TETO_DIARIO):
    """Largura da barra em dias, para o eixo de datas nao virar um borrao."""
    if len(indice) < 2:
        return 3.0
    dias = (indice.max() - indice.min()).days / max(len(indice) - 1, 1)
    return max(0.8, min(dias * 0.75, maximo))


def _alinha_zeros(esquerda, direita, dados_esq, dados_dir):
    """Poe o zero dos dois eixos na MESMA altura da figura.

    O PROBLEMA QUE ISTO RESOLVE: com dois eixos independentes, o zero de um cai a
    30% da altura e o do outro a 60%. Ai a linha cruza a barra em lugares que nao
    querem dizer nada, e um periodo de recompra -- em que financeiro e DV ficam
    negativos -- aparece com as duas series de lados diferentes do proprio zero.

    A conta: a fracao da altura em que o zero fica e |chao| / (teto + |chao|). Basta
    igualar essa fracao nos dois, esticando o lado que precisa.
    """
    def limites(valores, folga=1.12):
        teto = max(0.0, float(valores.max()) * folga)
        chao = min(0.0, float(valores.min()) * folga)
        if teto == 0 and chao == 0:
            return 0.0, 1.0
        return chao, teto

    chao_e, teto_e = limites(dados_esq)
    chao_d, teto_d = limites(dados_dir)

    # A fracao mais generosa dos dois: esticar e sempre seguro, encolher cortaria
    # dado da tela.
    fracao_e = (-chao_e / (teto_e - chao_e)) if teto_e > chao_e else 0.0
    fracao_d = (-chao_d / (teto_d - chao_d)) if teto_d > chao_d else 0.0
    fracao = max(fracao_e, fracao_d)

    def estica(chao, teto, alvo):
        if alvo <= 0:
            return min(chao, 0.0), teto
        if alvo >= 1:
            return chao, max(teto, 0.0)
        # altura total tal que |chao| seja 'alvo' dela, sem cortar nem chao nem teto
        altura = max(teto / (1 - alvo), (-chao) / alvo)
        return -altura * alvo, altura * (1 - alvo)

    esquerda.set_ylim(*estica(chao_e, teto_e, fracao))
    direita.set_ylim(*estica(chao_d, teto_d, fracao))


def _marca_pontos(ax, indice, valores, formato, cor, deslocamento=(0, 7),
                  so_ultimo=False):
    """Escreve o valor do ULTIMO ponto e dos extremos da serie.

    So tres numeros, e nao um por barra: rotular tudo vira ruido e some com o
    desenho. O ultimo porque e o que se foi ver; os extremos porque sao a escala.

    'deslocamento' existe porque as duas series de um grafico de dois eixos
    costumam ter o pico NO MESMO DIA -- entra muito dinheiro e entra muito risco no
    mesmo leilao -- e ai os dois rotulos caem um em cima do outro. Foi o que
    aconteceu na primeira versao. Quem chama afasta um dos dois para o lado.
    """
    import numbers

    validos = [(i, v) for i, v in zip(indice, valores)
               if isinstance(v, numbers.Number) and v == v]
    if not validos:
        return
    # O ultimo ponto entra sempre. Os extremos entram DESDE QUE LONGE DELE: numa
    # serie que so cai, o minimo E o ultimo ou o vizinho dele, e os dois rotulos
    # saem um por cima do outro. Aconteceu no acumulado de 3 meses.
    posicao = {chave: k for k, (chave, _) in enumerate(validos)}
    distancia_minima = max(2, len(validos) // 12)

    escolhidos = {validos[-1][0]: validos[-1][1]}
    if not so_ultimo and len(validos) > 2:
        for extremo in (max(validos, key=lambda p: p[1]),
                        min(validos, key=lambda p: p[1])):
            longe = all(abs(posicao[extremo[0]] - posicao[j]) >= distancia_minima
                        for j in escolhidos)
            if longe:
                escolhidos[extremo[0]] = extremo[1]

    dx, dy = deslocamento
    for i, v in escolhidos.items():
        ax.annotate(formato(v), (i, v), textcoords="offset points",
                    xytext=(dx, dy if v >= 0 else -abs(dy) - 6),
                    ha="left" if dx > 0 else ("right" if dx < 0 else "center"),
                    fontsize=8.5, color=cor, weight="bold",
                    zorder=6,
                    bbox=dict(boxstyle="round,pad=0.15", fc="white", ec="none",
                              alpha=0.75))


def _reta_da_media(eixo_do_dv, dv):
    """A media PLANA da janela, tracejada, no eixo do DV. Devolve o valor.

    PLANA, e nao movel. O rotulo promete "media dos N leiloes", e e a media da
    janela inteira que o grafico ja mostra -- um numero so, uma reta so. Media
    MOVEL e outra pergunta ("como o nivel andou"), e quem a responde e
    desenha_lft, com pontilhado e nao tracejado, para as duas nao se
    confundirem quando aparecem no mesmo e-mail.

    Entrou em 27/10/2026 para os e-mails de leilao. Vem DESLIGADA por padrao:
    as paginas gravadas do painel nao podem mudar um byte por causa disto.
    """
    media = float(dv.mean())
    eixo_do_dv.axhline(media, color=_COR_DV, lw=1.3, ls=(0, (6, 4)),
                       label="m\u00e9dia dos %d leil\u00f5es" % len(dv))
    return media


def desenha_dois_eixos(dados, ax, rotulo, dv_para_cima=None, media=False):
    """Barra de financeiro num eixo, linha de DV no outro.

    O SINAL E O DE RISCO EMITIDO (docs/convencoes-dv.md): venda positiva, recompra
    negativa. As duas series sobem juntas, porque medem a mesma atividade -- entra
    dinheiro e entra risco.

    'dv_para_cima' nao faz mais nada. Ele existia para INVERTER o eixo do DV quando
    o sinal vinha de P&L e a linha morava no teto do grafico; corrigido o sinal na
    origem, a inversao virou desnecessaria. O parametro sobrevive para nao quebrar
    quem ja chamava.

    'media' acrescenta a reta da media da janela -- ver _reta_da_media. Padrao
    desligado, para nao mexer nas paginas ja gravadas.
    """
    largura = _largura(dados.index)
    estagios = _estagios(dados)
    financeiro = dados["financeiro_milhoes"] / 1000
    ax.bar(dados.index, financeiro, width=largura,
           label="financeiro aceito", **_aparencia(estagios, _COR_FINANCEIRO))
    ax.set_ylabel("R$ bilh\u00f5es aceitos")
    ax.axhline(0, color="gray", lw=0.8)
    _marca_pontos(ax, dados.index, financeiro, lambda v: estilo.num_br(v, 2),
                  "#1f4e79", deslocamento=(-6, 8))

    tem_dv = dados["dv_milhoes"].notna().any()
    direita = None
    if tem_dv:
        # O DV vai para MIL por ponto-base: em milhoes as etiquetas ficam todas em
        # 0,00 e 0,01, e a serie inteira parece nula.
        dv = dados["dv_milhoes"] * 1000
        direita = ax.twinx()
        direita.plot(dados.index, dv, color=_COR_DV, lw=1.8,
                     label="DV01 emitido")
        direita.set_ylabel("DV01 emitido, R$ mil por ponto-base")
        _marca_pontos(direita, dados.index, dv, lambda v: estilo.num_br(v, 0),
                      _COR_DV, deslocamento=(8, 8))
        _alinha_zeros(ax, direita, financeiro, dv)
        # DEPOIS do _alinha_zeros: a reta e horizontal e nao muda escala, mas se
        # entrasse antes o axhline entraria na conta dos limites.
        if media:
            _reta_da_media(direita, dv)
        direita.spines["top"].set_visible(False)
        direita.grid(False)
    else:
        # ERA 'elif series != "dv"', e 'series' NAO EXISTE NESTA FUNCAO -- o
        # trecho veio copiado de desenha_acumulado, que tem o parametro. Um
        # recorte sem DV01 nenhum caia aqui e levantava NameError em vez de
        # desenhar. Nunca apareceu porque o unico recorte sem DV e a LFT, e ela
        # tem funcao propria (desenha_lft). Achado e consertado em 27/10/2026,
        # ao ligar a reta da media; o e-mail de leilao passa a chamar esta
        # funcao com recortes novos, entao o galho deixou de ser teorico.
        ax.set_ylim(*_limites_simples(financeiro))

    _grade(ax)
    _eixo_do_tempo(ax, dados.index)
    ax.set_title(rotulo, fontsize=11, weight="bold", loc="left", pad=10)

    marcas, rotulos = ax.get_legend_handles_labels()
    if direita is not None:
        m2, r2 = direita.get_legend_handles_labels()
        marcas, rotulos = marcas + m2, rotulos + r2
    extras = _legenda_dos_estagios(estagios)
    # A coluna a mais e da reta. SOMADA e nao recalculada de len(marcas): com a
    # media desligada a expressao tem de dar exatamente o que dava antes.
    ax.legend(marcas + extras, rotulos + [e.get_label() for e in extras],
              ncol=2 + len(extras) + (1 if media and direita is not None else 0),
              frameon=False, loc="upper center",
              bbox_to_anchor=(0.5, -0.10))


def _limites_simples(valores, folga=1.12):
    teto = max(0.0, float(valores.max()) * folga)
    chao = min(0.0, float(valores.min()) * folga)
    return (chao, teto) if teto > chao else (0.0, 1.0)


def _eixo_do_tempo(ax, indice):
    """Rotulos que dependem do tamanho da janela.

    "eixo_anual" foi feito para a serie mensal do RMD, de 25 anos. Numa janela de
    doze meses ele escreve UM rotulo -- "2026" -- e o grafico fica sem eixo. Aqui a
    janela decide: meses quando ela cabe em dois anos, anos quando nao cabe.
    """
    import matplotlib.dates as mdates
    import matplotlib.ticker as mticker

    def mes_br(x, _pos=None):
        # O %b do matplotlib devolve "Aug" -- a locale do sistema esta em ingles, e
        # o projeto ja resolve isso com uma tabela propria em estilo.MES.
        d = mdates.num2date(x)
        return f"{estilo.MES[d.month]}/{d.year % 100:02d}"

    dias = (indice.max() - indice.min()).days if len(indice) > 1 else 0
    if dias <= 120:
        ax.xaxis.set_major_locator(mdates.WeekdayLocator(byweekday=0, interval=2))
        ax.xaxis.set_major_formatter(mticker.FuncFormatter(
            lambda x, _p=None: f"{mdates.num2date(x):%d}/"
                               f"{estilo.MES[mdates.num2date(x).month]}"))
    elif dias <= 400:
        ax.xaxis.set_major_locator(mdates.MonthLocator())
        ax.xaxis.set_major_formatter(mticker.FuncFormatter(mes_br))
    elif dias <= 900:
        ax.xaxis.set_major_locator(mdates.MonthLocator(interval=3))
        ax.xaxis.set_major_formatter(mticker.FuncFormatter(mes_br))
    else:
        estilo.eixo_anual(ax, a_cada=1 if dias < 4000 else 2)
        return
    for rotulo in ax.get_xticklabels():
        rotulo.set_rotation(45)
        rotulo.set_horizontalalignment("right")
        rotulo.set_fontsize(8.5)


def _grade(ax, eixo="y"):
    """Grade mais densa: uma linha forte a cada marca, uma fraca no meio.

    A grade anterior tinha so as marcas principais, e ler a altura de uma barra no
    meio do grafico exigia mirar. As menores entram com metade da opacidade, para
    ajudar sem competir com o dado.
    """
    from matplotlib.ticker import AutoMinorLocator

    if eixo in ("y", "ambos"):
        ax.yaxis.set_minor_locator(AutoMinorLocator(2))
        ax.grid(axis="y", which="major", alpha=0.28, lw=0.8)
        ax.grid(axis="y", which="minor", alpha=0.14, lw=0.6)
    if eixo in ("x", "ambos"):
        ax.grid(axis="x", which="major", alpha=0.14, lw=0.6)


def desenha_dois_eixos_empilhado(dados, ax, rotulo, familias=None,
                                 periodo="W", media=False):
    """Como desenha_dois_eixos, mas com a barra ABERTA POR FAMILIA de papel.

    A barra somada de "LTN + NTN-F" esconde qual dos dois moveu o dia, e eles tem
    prazos muito diferentes: dez bilhoes de LTN curta e dez de NTN-F 2037 sao a
    mesma barra e coisas incomparaveis. A linha do DV continua uma so, porque o
    risco do dia e um so.

    'media' acrescenta a reta da media da janela, igual a de desenha_dois_eixos
    -- ver _reta_da_media. Padrao desligado.
    """
    familias = familias or [f for f in ORDEM_FAMILIAS if f in dados.columns]
    largura = _largura(dados.index, _TETO_DO_PERIODO.get(periodo, TETO_DIARIO))
    estagios = _estagios(dados)

    base = pd.Series(0.0, index=dados.index)
    for familia in familias:
        altura = dados[familia] / 1000
        ax.bar(dados.index, altura, bottom=base, width=largura, label=familia,
               **_aparencia(estagios, estilo.COR[_COR_FAMILIA[familia]], 1.0))
        base = base + altura

    ax.set_ylabel("R$ bilh\u00f5es aceitos")
    ax.axhline(0, color="gray", lw=0.8)
    _marca_pontos(ax, dados.index, base, lambda v: estilo.num_br(v, 2),
                  "#333333", deslocamento=(-6, 8))

    direita = None
    if dados["dv_milhoes"].notna().any():
        dv = dados["dv_milhoes"] * 1000
        direita = ax.twinx()
        direita.plot(dados.index, dv, color=_COR_DV, lw=1.8, label="DV01 emitido")
        direita.set_ylabel("DV01 emitido, R$ mil por ponto-base")
        _marca_pontos(direita, dados.index, dv, lambda v: estilo.num_br(v, 0),
                      _COR_DV, deslocamento=(8, 8))
        _alinha_zeros(ax, direita, base, dv)
        if media:
            _reta_da_media(direita, dv)
        direita.spines["top"].set_visible(False)
        direita.grid(False)
    else:
        ax.set_ylim(*_limites_simples(base))

    _grade(ax)
    _eixo_do_tempo(ax, dados.index)
    ax.set_title(rotulo, fontsize=11, weight="bold", loc="left", pad=10)

    marcas, rotulos = ax.get_legend_handles_labels()
    if direita is not None:
        m2, r2 = direita.get_legend_handles_labels()
        marcas, rotulos = marcas + m2, rotulos + r2
    extras = _legenda_dos_estagios(estagios)
    ax.legend(marcas + extras, rotulos + [e.get_label() for e in extras],
              ncol=len(marcas) + len(extras), frameon=False, loc="upper center",
              bbox_to_anchor=(0.5, -0.14))


def desenha_acumulado(dados, ax, rotulo, meses=3, series="ambos"):
    """A soma movel de N meses: area para o financeiro, linha para o DV.

    AREA E NAO BARRA porque isto e um nivel acumulado, e nao um evento: barra sugere
    "entrou tanto naquele dia", e o que a serie diz e "nos ultimos tres meses,
    tanto". O grafico de cima ja mostra o evento.

    'series' escolhe o que desenhar: "ambos" (o padrao, como sempre foi), "dv"
    ou "financeiro". Os dois acumulados de 12 meses que ela pediu em 09/09/2026
    usam UM de cada -- DV no que espelha o semanal sem LFT, financeiro no que
    espelha o empilhado com LFT.

    QUANDO SE PEDE UMA SERIE SO, O EIXO DA OUTRA NAO PODE FICAR LA VAZIO: eixo
    rotulado sem linha nenhuma e o defeito que ninguem nota, porque o grafico
    sai bonito e diz uma grandeza que nao esta desenhada.
    """
    if series not in ("ambos", "dv", "financeiro"):
        raise LookupError(
            f"series '{series}' nao existe: ambos, dv ou financeiro.")

    financeiro = dados["financeiro_milhoes"] / 1000
    if series in ("ambos", "financeiro"):
        ax.fill_between(dados.index, 0, financeiro, color=_COR_FINANCEIRO,
                        alpha=0.35,
                        label=f"financeiro, soma de {meses} meses")
        ax.plot(dados.index, financeiro, color=_COR_FINANCEIRO, lw=1.4)
        ax.set_ylabel("R$ bilh\u00f5es")
        _marca_pontos(ax, dados.index, financeiro,
                      lambda v: estilo.num_br(v, 2), "#1f4e79",
                      deslocamento=(-6, 8))
    ax.axhline(0, color="gray", lw=0.8)

    direita = None
    if series == "dv":
        # SEM EIXO GEMEO: com uma serie so, o DV vai no eixo principal. Um
        # twinx aqui deixaria o eixo da esquerda rotulado e vazio.
        dv = dados["dv_milhoes"] * 1000
        ax.plot(dados.index, dv, color=_COR_DV, lw=1.8,
                label=f"DV01, soma de {meses} meses")
        ax.set_ylabel("DV01, R$ mil por ponto-base")
        _marca_pontos(ax, dados.index, dv, lambda v: estilo.num_br(v, 0),
                      _COR_DV, deslocamento=(8, 8))
        ax.set_ylim(*_limites_simples(dv))
    elif series == "ambos" and dados["dv_milhoes"].notna().any():
        dv = dados["dv_milhoes"] * 1000
        direita = ax.twinx()
        direita.plot(dados.index, dv, color=_COR_DV, lw=1.8,
                     label=f"DV01, soma de {meses} meses")
        direita.set_ylabel("DV01, R$ mil por ponto-base")
        _marca_pontos(direita, dados.index, dv, lambda v: estilo.num_br(v, 0),
                      _COR_DV, deslocamento=(8, 8))
        _alinha_zeros(ax, direita, financeiro, dv)
        direita.spines["top"].set_visible(False)
        direita.grid(False)
    else:
        ax.set_ylim(*_limites_simples(financeiro))

    _grade(ax)
    _eixo_do_tempo(ax, dados.index)
    ax.set_title(rotulo, fontsize=11, weight="bold", loc="left", pad=10)
    marcas, rotulos = ax.get_legend_handles_labels()
    if direita is not None:
        m2, r2 = direita.get_legend_handles_labels()
        marcas, rotulos = marcas + m2, rotulos + r2
    ax.legend(marcas, rotulos, ncol=2, frameon=False, loc="upper center",
              bbox_to_anchor=(0.5, -0.12))


def desenha_lft(dados, ax, meses_da_media=3):
    """So financeiro, com media movel pontilhada.

    A LFT nao tem DV por decisao de modelagem (premissa de duration zero), entao o
    segundo eixo nao existe -- e a media movel entra no lugar dele, porque o que se
    quer ver na LFT e o ritmo, nao o risco.
    """
    largura = _largura(dados.index)
    estagios = _estagios(dados)
    ax.bar(dados.index, dados["financeiro_milhoes"] / 1000, width=largura,
           label="financeiro aceito", **_aparencia(estagios, estilo.COR["LFT"]))

    # A media movel e de dias de leilao, nao de dias corridos: e a serie que existe.
    # 3 meses ~ 13 leiloes semanais.
    janela = max(2, int(round(meses_da_media * 52 / 12)))
    media = dados["financeiro_milhoes"].rolling(janela).mean() / 1000
    ax.plot(dados.index, media, color="#333333", lw=2.0, ls=":",
            label=f"m\u00e9dia m\u00f3vel de {meses_da_media} meses")

    ax.set_ylabel("R$ bilh\u00f5es aceitos")
    ax.axhline(0, color="gray", lw=0.8)
    _marca_pontos(ax, dados.index, dados["financeiro_milhoes"] / 1000,
                  lambda v: estilo.num_br(v, 2), "#555555", deslocamento=(-6, 8))
    _grade(ax)
    _eixo_do_tempo(ax, dados.index)
    ax.set_title("LFT \u00b7 s\u00f3 financeiro: ela n\u00e3o tem DV, por decis\u00e3o de modelagem",
                 fontsize=11, weight="bold", loc="left", pad=10)
    marcas, rotulos = ax.get_legend_handles_labels()
    extras = _legenda_dos_estagios(estagios)
    ax.legend(marcas + extras, rotulos + [e.get_label() for e in extras],
              ncol=2 + len(extras), frameon=False, loc="upper center",
              bbox_to_anchor=(0.5, -0.10))


def _ano_parcial(indice, ate):
    """O ano do indice que ainda nao fechou, ou None."""
    if ate is None:
        return None
    ate = pd.Timestamp(ate)
    anos = pd.DatetimeIndex(indice).year
    if anos.max() == ate.year and (ate.month, ate.day) != (12, 31):
        return ate.year
    return None


def _eixo_anual(ax, indice, ate=None):
    """Um rotulo por ano, e asterisco no que ainda nao fechou."""
    parcial = _ano_parcial(indice, ate)
    anos = pd.DatetimeIndex(indice).year
    ax.set_xticks(list(indice))
    ax.set_xticklabels([f"{a}*" if a == parcial else str(a) for a in anos],
                       rotation=45, ha="right")


def _com_a_marca_do_parcial(rotulo, indice, ate=None):
    parcial = _ano_parcial(indice, ate)
    if parcial is None:
        return rotulo
    # CURTO, por pedido dela em 09/09/2026. A versao anterior explicava que o
    # ano parcial "nao se compara com os anos fechados" -- a explicacao competia
    # com o grafico, e quem le a data ja entende. O ASTERISCO FICA: ele e o que
    # liga o titulo ao rotulo do eixo, e sem ele o "2026*" da barra nao teria
    # a que se referir.
    return f"{rotulo} \u2014 *{parcial} at\u00e9 {pd.Timestamp(ate):%d/%m/%Y}"


def desenha_empilhado(dados, ax, periodo="W", familias=None, unidade=None,
                      escala=1000.0, casas=2, ate=None, rotulo=None):
    """Financeiro do periodo, empilhado por familia de papel.

    Os parametros extras entraram em 09/09/2026 para os graficos ANUAIS, e
    todos tem padrao que reproduz o comportamento antigo -- ha teste exigindo
    que as paginas semanais saiam identicas.

    'escala' e 'unidade' andam JUNTAS. A funcao nasceu para reais e divide por
    mil; em DV isso daria numero mil vezes menor com o rotulo certo, que e
    plausivel e errado do pior tipo -- o grafico fica bonito e a ordem de
    grandeza esta errada.

    'ate' marca o ano corrente com asterisco quando ele ainda nao fechou. Sem
    isso a ultima barra PARECE QUEDA e e so o ano nao ter acabado: medido em
    09/09/2026, 1.235,7 bi contra 1.727,0 de 2025, uma "queda" de 28% que e so
    setembro. Nao se usa hachura nem opacidade, que nestes graficos ja
    significam "resultado ainda nao saiu".
    """
    familias = list(familias or ORDEM_FAMILIAS)
    largura = _largura(dados.index, _TETO_DO_PERIODO.get(periodo, TETO_DIARIO))
    estagios = _estagios(dados)
    base = pd.Series(0.0, index=dados.index)
    for familia in familias:
        altura = dados[familia] / escala
        ax.bar(dados.index, altura, bottom=base, width=largura, label=familia,
               **_aparencia(estagios, estilo.COR[_COR_FAMILIA[familia]], 1.0))
        base = base + altura

    ax.set_ylabel(unidade or (
        f"R$ bilh\u00f5es aceitos {'na' if periodo == 'W' else 'no'} "
        f"{_PALAVRA_DO_PERIODO[periodo]}"))
    ax.axhline(0, color="gray", lw=0.8)
    # SEM NUMERO SOLTO NESTE GRAFICO, em periodo nenhum.
    #
    # _marca_pontos escreve o valor do ULTIMO ponto e dos extremos. Numa barra
    # EMPILHADA o topo e a soma das faixas -- entao o numero cai no meio do
    # desenho e nao diz a que se refere: nao e o valor de nenhuma faixa, e o
    # eixo ja da a escala.
    #
    # Ela pediu duas vezes, e a segunda corrigiu a minha leitura da primeira.
    # Em 09/09 apontou o "1.236" do anual e eu tirei SO do anual, lendo que o
    # problema era o ano parcial. Em 10/09 apontou o mesmo numero no semanal:
    # o problema era a barra empilhada, e nao o periodo.
    #
    # No grafico de DOIS EIXOS a marca fica, e ali ela ganha o sustento: o
    # numero identifica o ultimo ponto da LINHA de DV, que e uma serie, e nao
    # uma soma anonima de faixas.
    _grade(ax)
    if periodo == "Y":
        _eixo_anual(ax, dados.index, ate)
    else:
        _eixo_do_tempo(ax, dados.index)
    if rotulo:
        ax.set_title(_com_a_marca_do_parcial(rotulo, dados.index, ate),
                     fontsize=11, weight="bold", loc="left", pad=10)
    marcas, rotulos = ax.get_legend_handles_labels()
    extras = _legenda_dos_estagios(estagios)
    ax.legend(marcas + extras, rotulos + [e.get_label() for e in extras],
              ncol=len(ORDEM_FAMILIAS) + len(extras), frameon=False,
              loc="upper center", bbox_to_anchor=(0.5, -0.10))


def desenha_demanda(dados, ax, rotulo, em_dv=True):
    """Barra do ofertado, barra do colocado dentro dela, e a fracao na linha.

    A BARRA DO COLOCADO FICA DENTRO DA DO OFERTADO, e nao ao lado: o colocado e
    parte do ofertado, e duas barras lado a lado sugeririam duas grandezas que se
    somam. O vazio que sobra em cima e o que ele deixou de colocar, e e o assunto.

    A linha da fracao vai no eixo da direita, com 100% marcado: e a leitura rapida,
    e o nivel de 100% e a referencia contra a qual tudo se compara.
    """
    largura = _largura(dados.index)
    estagios = _estagios(dados)
    escala = 1000 if em_dv else 1e-3
    coluna_of = "dv_ofertado" if em_dv else "qtd_ofertada"
    coluna_ac = "dv_aceito" if em_dv else "qtd_aceita"

    ofertado = dados[coluna_of] * escala
    aceito = dados[coluna_ac] * escala

    ax.bar(dados.index, ofertado, width=largura, label="ofertado",
           color="#cfd9e4", edgecolor="#7f95ad", linewidth=0.5, zorder=2)
    # zorder ACIMA do ofertado: a barra do colocado fica DENTRO da outra, e sem
    # isto a de tras cobre a de dentro e o grafico sai so com barras claras --
    # exatamente como saiu na primeira versao.
    ax.bar(dados.index, aceito, width=largura, label="colocado", zorder=3,
           **_aparencia(estagios, _COR_FINANCEIRO, 0.95))
    ax.set_ylabel("DV01, R$ mil por ponto-base" if em_dv
                  else "milhares de t\u00edtulos")
    ax.axhline(0, color="gray", lw=0.8)
    _marca_pontos(ax, dados.index, ofertado, lambda v: estilo.num_br(v, 0),
                  "#5a6b7d", deslocamento=(-6, 8), so_ultimo=True)

    direita = ax.twinx()
    direita.plot(dados.index, dados["colocado_pct"] * 100, color=_COR_DV, lw=1.4,
                 label="fra\u00e7\u00e3o colocada")
    direita.axhline(100, color=_COR_DV, lw=0.9, ls=":", alpha=0.6)
    direita.set_ylabel("colocado / ofertado, %")
    # Teto em 118 e nao em 108: o rotulo do ultimo ponto e escrito ACIMA dele, e
    # com a fracao em 99% ele saia cortado pela borda da figura.
    direita.set_ylim(0, 118)
    direita.spines["top"].set_visible(False)
    direita.grid(False)
    _marca_pontos(direita, dados.index, dados["colocado_pct"] * 100,
                  lambda v: estilo.num_br(v, 0) + "%", _COR_DV,
                  deslocamento=(8, 8), so_ultimo=True)

    _grade(ax)
    _eixo_do_tempo(ax, dados.index)
    ax.set_title(rotulo, fontsize=11, weight="bold", loc="left", pad=10)

    marcas, rotulos = ax.get_legend_handles_labels()
    m2, r2 = direita.get_legend_handles_labels()
    extras = _legenda_dos_estagios(estagios)
    ax.legend(marcas + m2 + extras,
              rotulos + r2 + [e.get_label() for e in extras],
              ncol=3 + len(extras), frameon=False, loc="upper center",
              bbox_to_anchor=(0.5, -0.10))


def desenha_colocado_por_familia(dados, ax, meses=6):
    """Uma linha por familia: a fracao colocada, em media movel.

    E o resumo da pagina de demanda. O que ele mostra, medido no historico inteiro:
    prefixado sai quase todo (LTN 93,8%, NTN-F 91,3%), e a NTN-B acima de 10 anos
    sai pela metade (49,5% do DV ofertado). Quando o Tesouro corta, corta na ponta longa.
    """
    for familia in ORDEM_FAMILIAS:
        if familia not in dados.columns:
            continue
        serie = dados[familia].dropna()
        if serie.empty:
            continue
        ax.plot(serie.index, serie * 100, lw=1.8,
                color=estilo.COR[_COR_FAMILIA[familia]], label=familia)
        _marca_pontos(ax, serie.index, serie * 100,
                      lambda v: estilo.num_br(v, 0) + "%",
                      estilo.COR[_COR_FAMILIA[familia]],
                      deslocamento=(8, 0), so_ultimo=True)

    ax.axhline(100, color="gray", lw=0.9, ls=":", alpha=0.7)
    # Margem a direita para o rotulo do ultimo ponto de cada linha caber: ele e
    # escrito ao LADO do ponto, e sem folga encosta na borda da figura.
    if len(dados.index) > 1:
        margem = (dados.index.max() - dados.index.min()) * 0.06
        ax.set_xlim(dados.index.min(), dados.index.max() + margem)
    ax.set_ylabel("colocado / ofertado, %")
    # Idem: espaco para o rotulo do ultimo ponto de cada linha.
    ax.set_ylim(0, 118)
    _grade(ax)
    _eixo_do_tempo(ax, dados.index)
    ax.set_title(f"Fra\u00e7\u00e3o colocada, m\u00e9dia m\u00f3vel de "
                 f"{meses} meses",
                 fontsize=11, weight="bold", loc="left", pad=10)
    ax.legend(ncol=len(ORDEM_FAMILIAS), frameon=False, loc="upper center",
              bbox_to_anchor=(0.5, -0.12))


def desenha_taxa_contra_dv(dados, ax, rotulo):
    """Dispersao: taxa no eixo Y, DV01 EMITIDO no X, cor pelo tempo.

    ERA CONTRA QUANTIDADE, e nao dizia nada. A quantidade de titulos mistura uma LTN
    de seis meses com uma NTN-B de 35 anos como se fossem a mesma coisa -- lotes de
    tamanho parecido com risco dez vezes diferente caiam na mesma coluna da nuvem, e
    a nuvem saia sem forma.

    Com o DV emitido no eixo, a pergunta vira a que interessa: quando a taxa esta
    alta, ele coloca mais RISCO no mercado, ou menos? A cor e o tempo, entao da para
    ver o regime mudar de lugar.
    """
    if dados.empty:
        ax.set_axis_off()
        ax.text(0.5, 0.5, "sem dado no recorte", ha="center", va="center",
                transform=ax.transAxes)
        return

    anos = dados.index.year
    pontos = ax.scatter(dados["dv_milhoes"] * 1000, dados["taxa_media_pct"],
                        c=anos, cmap="viridis", s=28, alpha=0.8,
                        edgecolor="white", linewidth=0.3)
    ax.set_xlabel("DV01 emitido no dia, R$ mil por ponto-base")
    ax.set_ylabel("taxa m\u00e9dia do dia, % ao ano")
    _grade(ax, "ambos")
    ax.set_title(rotulo, fontsize=11, weight="bold", loc="left", pad=10)

    # O ultimo dia marcado: e o que se foi ver, e num mar de pontos ele some.
    ultimo = dados.iloc[-1]
    ax.scatter([ultimo["dv_milhoes"] * 1000], [ultimo["taxa_media_pct"]],
               s=120, facecolor="none", edgecolor="#c00000", linewidth=1.8,
               zorder=5)
    ax.annotate(f"{dados.index[-1]:%d/%m/%y}",
                (ultimo["dv_milhoes"] * 1000, ultimo["taxa_media_pct"]),
                textcoords="offset points", xytext=(10, 6), fontsize=8.5,
                color="#c00000", weight="bold")

    barra = ax.get_figure().colorbar(pontos, ax=ax, pad=0.02)
    barra.set_label("ano", fontsize=9)

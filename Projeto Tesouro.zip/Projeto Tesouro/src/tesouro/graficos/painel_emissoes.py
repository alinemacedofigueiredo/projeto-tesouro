"""A pagina de emissoes: os graficos de leilao da entrega 3.

Pagina PROPRIA, e nao um grupo dentro do dashboard do RMD -- quem olha uma raramente
olha a outra ao mesmo tempo, e a matriz de graficos daqui engordaria aquela sem
necessidade.

O QUE FOI CORTADO EM 20/08/2026, e por que. A primeira versao oferecia todas as
opcoes e nao decidia nenhuma: 13 graficos x 5 janelas x 4 paginas = 260 SVGs.
Guardar as duas versoes de um grafico "para decidir depois" e uma forma de nunca
decidir, e o custo era medido.

  - a janela COMPLETA saiu. Ela sozinha custava 5,9 MB dos 9,67 da pagina -- 61% do
    arquivo -- para desenhar 702 barras de um pixel, em que nada se le. A serie
    longa fica no dashboard do RMD, que e onde ela tem sentido;
  - as janelas passaram a ser CURTAS, porque leilao se move em semanas e nao em
    anos: 20 leiloes, no ano, 12 meses, desde o ano anterior, 5 anos;
  - de QUANTIDADE E TAXA nao sobrou nada. Primeiro caiu a versao de duas series,
    que repetia o idioma de dois eixos ja usado sete vezes na pagina. Depois caiu a
    DISPERSAO, em 21/08/2026: o eixo tinha migrado de quantidade para DV01
    justamente para dar forma a nuvem, e ainda assim ela nao ganhou forma -- "nao
    ficaram bons os graficos de dispersao". A pergunta que ela tentava responder --
    com a taxa alta, ele coloca mais risco? -- continua boa, e um dia merece um
    desenho que a responda. A dispersao nao era esse desenho.
    emissao.dv_e_taxa() e emissao.desenha_taxa_contra_dv() FICAM no modulo, sem
    ninguem chamando: o dado e o desenho custam pouco e sao o ponto de partida de
    quem tentar de novo;
  - das quatro combinacoes de compra e segunda volta sobraram TRES. A que saiu e
    "venda e compra, so 1a volta": recompra sem segunda volta e o recorte de que
    ninguem sentiu falta.

Sao 11 graficos x 5 janelas x 3 paginas, e cada pagina fica sob o limiar de 10 MB.

O QUE ESTA PAGINA CONTINUA NAO FAZENDO: as combinacoes de compra e segunda volta sao
tres ARQUIVOS, e nao caixas de marcar no HTML. Poe-las na mesma pagina exige
interatividade de verdade (desenhar no navegador em vez de embutir SVG pronto), que
e a decisao adiada da secao 10 da spec do dashboard. Os arquivos ficam ligados por
uma barra de links relativos no topo, que funciona com duplo clique e sem servidor.
"""
import pandas as pd

from . import dashboard, emissao, estilo

GRUPOS = ["Por dia de leil\u00e3o", "Por semana", "Demanda"]

# AS JANELAS DO LEILAO SAO CURTAS, e as do dashboard do RMD nao servem aqui.
#
# Estoque de divida se move em anos; leilao se move em semanas. Em "5 anos" cabem
# umas 250 barras de tres pixels, e a barra de hoje -- a que motivou esta pagina
# existir -- some no meio delas.
#
# O CONTADOR E 20, E NAO 50, POR MEDICAO. O Tesouro leiloa quase toda semana, entao
# 50 leiloes sao ~50 semanas e a janela colapsa sobre "12 meses": medido na serie
# diaria de NTN-B, "50 leiloes" comeca em 19/08/2025 e "12 meses" em 12/08/2025 --
# um ponto de diferenca. Vinte da ~5 meses, que e uma janela de verdade.
#
# A escada sai com cada degrau ~1,5x o anterior (NTN-B por dia):
#   20 leiloes 20 | no ano 31 | 12 meses 51 | desde o ano anterior 82 | completa 702
#
# A ordem e do mais curto para o mais longo, que e a ordem em que se olha: primeiro
# o que aconteceu agora, depois o contexto.
JANELAS = (
    ("20 leil\u00f5es", estilo.Ultimos(20)),
    ("no ano", estilo.DesdeJaneiro(0)),
    ("12 meses", 1),
    ("desde o ano anterior", estilo.DesdeJaneiro(1)),
    ("5 anos", 5),
)

# A JANELA "COMPLETA" FOI CORTADA em 20/08/2026, e por medicao: ela sozinha custava
# 5,9 MB dos 9,67 da pagina -- 61% do arquivo -- para desenhar 702 barras de um
# pixel, em que nada se le. A serie longa continua no dashboard do RMD, que e onde
# ela tem sentido. Quem precisar dela aqui passa recortes=[("completa", None)].

# A janela que abre. "12 meses" e nao "20 leiloes": vinte leiloes sao ~5 meses e nao
# fecham um ciclo do PAF -- o ano rolado e a referencia com que ela compara. Quem
# quer so o que aconteceu agora troca num clique.
JANELA_PADRAO = "12 meses"

# NOS GRAFICOS SEMANAIS, um ponto e uma semana. Entao "20 leiloes" ali sao as
# ultimas 20 SEMANAS, e nao os ultimos 20 leiloes. Dito na nota daqueles dois
# graficos, para que o rotulo da janela nao minta em silencio.
_NOTA_SEMANAL = ("A janela <b>20 leil\u00f5es</b> conta pontos do gr\u00e1fico, e "
                 "aqui cada ponto \u00e9 uma <b>semana</b> \u2014 ent\u00e3o ela "
                 "mostra as \u00faltimas 20 semanas.")

# O eixo do DV aponta para CIMA por padrao: com ele para baixo, a linha mora no teto
# do grafico e a comparacao com a barra some. Os rotulos continuam negativos, entao o
# numero nao mente -- so a direcao de leitura muda. Ver as duas versoes em
# scratchpad/opcao_a_dv_para_baixo.png e opcao_b_dv_para_cima.png.
DV_PARA_CIMA = True

# O que a pagina gravada por padrao mostra.
COM_COMPRA = False
COM_SEGUNDA_VOLTA = True


def _fig_dois_eixos(recorte, com_compra, com_2a):
    def figura(janela):
        fig = dashboard._figura(5.6)
        dados = emissao.por_dia(recorte, janela, com_compra, com_2a)
        emissao.desenha_dois_eixos(dados, fig.subplots(),
                                   f"{recorte} \u00b7 por dia de leil\u00e3o")
        return fig
    return figura


def _fig_empilhado_por_dia(recorte, com_compra, com_2a):
    """Como _fig_dois_eixos, mas com a barra aberta por papel.

    Usado no recorte de prefixado: a barra somada de LTN + NTN-F esconde qual dos
    dois moveu o dia, e sao papeis de prazo muito diferente.
    """
    def figura(janela):
        fig = dashboard._figura(5.8)
        dados = emissao.por_dia_por_familia(recorte, janela, com_compra, com_2a)
        emissao.desenha_dois_eixos_empilhado(
            dados, fig.subplots(), f"{recorte} \u00b7 por dia, aberto por papel")
        return fig
    return figura


def _fig_acumulado(recorte, com_compra, com_2a, meses=3, series="ambos",
                   titulo=None):
    def figura(janela):
        fig = dashboard._figura(4.8)
        dados = emissao.acumulado(recorte, meses, janela, com_compra, com_2a)
        emissao.desenha_acumulado(
            dados, fig.subplots(),
            titulo or (f"{recorte} \u00b7 acumulado dos \u00faltimos "
                       f"{meses} meses"),
            meses, series)
        return fig
    return figura


def _fig_lft(com_compra, com_2a):
    def figura(janela):
        fig = dashboard._figura(5.6)
        dados = emissao.por_dia("LFT", janela, com_compra, com_2a)
        emissao.desenha_lft(dados, fig.subplots())
        return fig
    return figura


def _fig_semanal(com_compra, com_2a, periodo="W", rotulo=None):
    def figura(janela):
        fig = dashboard._figura(5.8)
        dados = emissao.por_semana_por_familia(janela, com_compra, com_2a,
                                               periodo)
        emissao.desenha_dois_eixos_empilhado(
            dados, fig.subplots(),
            rotulo or ("Soma da semana \u00b7 financeiro por papel e DV "
                       "total, sem LFT"),
            periodo=periodo)
        return fig
    return figura


def _fig_anual(coluna, rotulo, familias=None, unidade=None, escala=1000.0,
               casas=0, agrupado=False):
    """Barra ANUAL empilhada por papel. Sempre venda e compra, com 2a volta.

    EMPILHADA por correcao dela em 09/09/2026. Eu tinha lido "o mensal esta
    poluido" como "o empilhamento polui", e feito estes com uma soma so. O que
    poluia era a QUANTIDADE DE BARRAS -- 309 contra 26. Com 26 barras largas o
    empilhamento cabe, e mostra a composicao, que e o que se quer ver a 25 anos
    de distancia.
    """
    def figura(janela):
        fig = dashboard._figura(4.8)
        dados = emissao.por_familia(coluna, janela, True, True, periodo="Y",
                                    agrupado=agrupado)
        emissao.desenha_empilhado(
            dados, fig.subplots(), periodo="Y", familias=familias,
            unidade=unidade, escala=escala, casas=casas,
            ate=emissao.ultima_data(True, True), rotulo=rotulo)
        return fig
    return figura


def _fig_empilhado(com_compra, com_2a, periodo="W"):
    def figura(janela):
        fig = dashboard._figura(5.6)
        dados = emissao.financeiro_semanal_por_papel(janela, com_compra, com_2a,
                                                     periodo)
        emissao.desenha_empilhado(dados, fig.subplots(), periodo)
        return fig
    return figura


def _fig_demanda(recorte, com_2a, em_dv=True):
    def figura(janela):
        fig = dashboard._figura(5.6)
        dados = emissao.demanda(recorte, janela, com_2a)
        emissao.desenha_demanda(
            dados, fig.subplots(),
            f"{recorte} \u00b7 ofertado e colocado, por dia de leil\u00e3o",
            em_dv=em_dv)
        return fig
    return figura


def _fig_colocado(com_2a, meses=6):
    def figura(janela):
        fig = dashboard._figura(5.2)
        dados = emissao.colocado_por_familia(janela, com_2a, meses)
        emissao.desenha_colocado_por_familia(dados, fig.subplots(), meses)
        return fig
    return figura


# As tres combinacoes, com o arquivo de cada uma. Cada pagina diz qual e, e aponta
# para as outras tres: sem isso, quem abre uma nao sabe que as outras existem.
COMBINACOES = [
    (False, True, "emissoes.html", "s\u00f3 venda, com 2\u00aa volta"),
    (False, False, "emissoes-1a-volta.html", "s\u00f3 venda, s\u00f3 1\u00aa volta"),
    (True, True, "emissoes-com-compra.html", "venda e compra, com 2\u00aa volta"),
]


def _nota_aceito(com_compra, com_2a):
    """A nota que diz, em cada pagina, qual recorte ela mostra."""
    compra = ("Inclui os leil\u00f5es de <b>compra</b>, com sinal negativo: o que se "
              "v\u00ea \u00e9 o l\u00edquido."
              if com_compra else
              "<b>S\u00f3 venda</b> \u2014 emiss\u00e3o bruta, sem as recompras.")
    volta = ("Inclui a <b>2\u00aa volta</b>, que \u00e9 a leitura de quanto risco entrou "
             "no mercado."
             if com_2a else
             "<b>S\u00f3 1\u00aa volta</b>, que \u00e9 a leitura do tamanho do leil\u00e3o no dia.")
    return ("Sempre o <b>aceito</b> no leil\u00e3o, nunca o ofertado. "
            + compra + " " + volta)

_NOTA_DV = ("O DV01 \u00e9 <b>negativo</b> por conven\u00e7\u00e3o do projeto "
            "(docs/convencoes-dv.md): pre\u00e7o cai quando a taxa sobe. O eixo da "
            "direita est\u00e1 invertido para que mais risco emitido suba junto com "
            "a barra; os r\u00f3tulos continuam negativos.")

Grafico = dashboard.Grafico


def registro(com_compra=False, com_2a=True):
    """As entradas da pagina, ja com a combinacao escolhida embutida.

    Funcao e nao constante porque cada combinacao de compra e segunda volta e
    uma pagina diferente: as figuras precisam nascer sabendo qual delas sao.
    """
    nota_aceito = _nota_aceito(com_compra, com_2a)
    return [
    Grafico("emissao_ntnb", "Por dia de leil\u00e3o",
            "NTN-B \u00b7 financeiro e DV",
            "dv_emitido_por_leilao.csv",
            f"Curta e longa somadas. {nota_aceito} {_NOTA_DV}",
            True, JANELA_PADRAO, _fig_dois_eixos("NTN-B", com_compra, com_2a)),
    Grafico("emissao_ntnb_acum", "Por dia de leil\u00e3o",
            "NTN-B \u00b7 acumulado de 3 meses",
            "dv_emitido_por_leilao.csv",
            "A s\u00e9rie di\u00e1ria \u00e9 serrilhada por constru\u00e7\u00e3o \u2014 ele "
            "leiloa NTN-B num dia e prefixado no outro, ent\u00e3o dia sim dia n\u00e3o "
            "a barra \u00e9 zero. A soma m\u00f3vel tira o serrilhado e mostra o que o "
            "trimestre acumulou, que \u00e9 a escala em que emiss\u00e3o se compara com "
            f"o PAF. {nota_aceito}",
            True, JANELA_PADRAO, _fig_acumulado("NTN-B", com_compra, com_2a)),
    Grafico("emissao_ntnb_curta", "Por dia de leil\u00e3o",
            "NTN-B ate 10 anos \u00b7 financeiro e DV",
            "dv_emitido_por_leilao.csv",
            "At\u00e9 o v\u00e9rtice de 5 anos, pelo <b>benchmark publicado</b> pelo "
            "Tesouro e n\u00e3o pelo prazo calculado \u2014 um papel que ele chama de "
            "NTN-B 5 anos \u00e9 curta durante toda a vig\u00eancia, mesmo com 6,4 anos "
            f"a correr. {nota_aceito} {_NOTA_DV}",
            True, JANELA_PADRAO,
            _fig_dois_eixos("NTN-B at\u00e9 10 anos", com_compra, com_2a)),
    Grafico("emissao_ntnb_longa", "Por dia de leil\u00e3o",
            "NTN-B acima de 10 anos \u00b7 financeiro e DV",
            "dv_emitido_por_leilao.csv",
            f"V\u00e9rtice de 7 anos para cima. {nota_aceito} {_NOTA_DV}",
            True, JANELA_PADRAO,
            _fig_dois_eixos("NTN-B acima de 10 anos", com_compra, com_2a)),
    Grafico("emissao_ntnf", "Por dia de leil\u00e3o",
            "NTN-F \u00b7 financeiro e DV",
            "dv_emitido_por_leilao.csv",
            f"{nota_aceito} {_NOTA_DV}",
            True, JANELA_PADRAO, _fig_dois_eixos("NTN-F", com_compra, com_2a)),
    Grafico("emissao_ltn", "Por dia de leil\u00e3o",
            "LTN \u00b7 financeiro e DV",
            "dv_emitido_por_leilao.csv",
            f"{nota_aceito} {_NOTA_DV}",
            True, JANELA_PADRAO, _fig_dois_eixos("LTN", com_compra, com_2a)),
    Grafico("emissao_pre", "Por dia de leil\u00e3o",
            "LTN + NTN-F \u00b7 financeiro por papel e DV total",
            "dv_emitido_por_leilao.csv",
            "O prefixado inteiro, com a barra <b>aberta por papel</b>: a barra "
            "somada esconderia qual dos dois moveu o dia, e eles t\u00eam prazos "
            f"muito diferentes. {nota_aceito} {_NOTA_DV}",
            True, JANELA_PADRAO,
            _fig_empilhado_por_dia("LTN + NTN-F", com_compra, com_2a)),
    Grafico("emissao_pre_acum", "Por dia de leil\u00e3o",
            "LTN + NTN-F \u00b7 acumulado de 3 meses",
            "dv_emitido_por_leilao.csv",
            f"A mesma soma m\u00f3vel da NTN-B, para o prefixado. {nota_aceito}",
            True, JANELA_PADRAO,
            _fig_acumulado("LTN + NTN-F", com_compra, com_2a)),
    Grafico("emissao_lft", "Por dia de leil\u00e3o",
            "LFT \u00b7 s\u00f3 financeiro",
            "dv_emitido_por_leilao.csv",
            "A LFT n\u00e3o tem DV por decis\u00e3o de modelagem, ent\u00e3o o segundo eixo "
            "n\u00e3o existe, e a m\u00e9dia m\u00f3vel de 3 meses entra no lugar dele. "
            f"{nota_aceito}",
            True, JANELA_PADRAO, _fig_lft(com_compra, com_2a)),
    Grafico("emissao_semanal", "Por semana",
            "Soma da semana \u00b7 financeiro por papel e DV total",
            "dv_emitido_por_leilao.csv",
            "Sem a LFT: o gr\u00e1fico tem dois eixos e ela s\u00f3 tem um dos dois "
            "n\u00fameros. A barra \u00e9 <b>empilhada por papel</b>; a linha do DV \u00e9 "
            f"o total da semana. {nota_aceito} {_NOTA_DV} {_NOTA_SEMANAL}",
            True, JANELA_PADRAO, _fig_semanal(com_compra, com_2a)),
    # O ACUMULADO DE DV VEM COLADO NO SEMANAL DE CIMA, e nao no fim do grupo.
    # Os dois falam do MESMO conjunto de papeis -- sem LFT, que nao tem DV01 --
    # e a leitura e olhar de um para o outro: o que entrou nesta semana, e o que
    # os doze meses acumularam. Solto no fim, vira mais um grafico.
    Grafico("emissao_acumulado_dv_12m", "Por semana",
            "Acumulado de 12 meses \u00b7 DV01, sem LFT",
            "dv_emitido_por_leilao.csv",
            "A soma m\u00f3vel de doze meses do DV01 emitido, no <b>mesmo "
            "conjunto do gr\u00e1fico acima</b>. A janela \u00e9 de "
            "calend\u00e1rio, e n\u00e3o de n\u00famero de leil\u00f5es: "
            "\"12 meses\" quer dizer doze meses mesmo, inclusive quando o "
            "Tesouro muda a frequ\u00eancia no meio do per\u00edodo. "
            "\u00c1rea e linha, e n\u00e3o barra, porque isto \u00e9 um "
            "n\u00edvel acumulado e n\u00e3o um evento. "
            f"{_NOTA_DV}",
            True, JANELA_PADRAO,
            _fig_acumulado("sem LFT", com_compra, com_2a, meses=12,
                           series="dv",
                           titulo="Acumulado de 12 meses \u00b7 DV01 emitido, "
                                  "sem LFT")),
    Grafico("emissao_empilhado", "Por semana",
            "Financeiro da semana, por papel",
            "dv_emitido_por_leilao.csv",
            "Aqui a LFT <b>entra</b>: \u00e9 gr\u00e1fico de financeiro s\u00f3, e ela "
            f"\u00e9 mais da metade dele. {nota_aceito} {_NOTA_SEMANAL}",
            True, JANELA_PADRAO, _fig_empilhado(com_compra, com_2a)),
    # E o acumulado de FINANCEIRO vem colado no empilhado, que e o grafico de
    # financeiro -- e por isso este leva a LFT, igual a ele. A LFT nao tem
    # DV01, entao ela entra aqui e fica de fora do acumulado de DV acima: os
    # dois pares sao coerentes cada um consigo mesmo.
    Grafico("emissao_acumulado_financeiro_12m", "Por semana",
            "Acumulado de 12 meses \u00b7 financeiro, com LFT",
            "dv_emitido_por_leilao.csv",
            "A soma m\u00f3vel de doze meses do financeiro emitido, no "
            "<b>mesmo conjunto do gr\u00e1fico acima</b> \u2014 com a LFT, "
            "que \u00e9 mais da metade do que vai a leil\u00e3o. A janela "
            "\u00e9 de calend\u00e1rio, e n\u00e3o de n\u00famero de "
            "leil\u00f5es. \u00c1rea, e n\u00e3o barra, porque isto \u00e9 "
            "um n\u00edvel acumulado e n\u00e3o um evento. "
            f"{nota_aceito}",
            True, JANELA_PADRAO,
            _fig_acumulado("tudo", com_compra, com_2a, meses=12,
                           series="financeiro",
                           titulo="Acumulado de 12 meses \u00b7 financeiro "
                                  "emitido, com LFT")),
    Grafico("demanda_ntnb", "Demanda",
            "NTN-B \u00b7 ofertado e colocado",
            "dv_emitido_por_leilao.csv",
            "A barra clara \u00e9 o que ele <b>ofertou</b>; a escura, dentro "
            "dela, o que <b>colocou</b>. O vazio que sobra em cima \u00e9 o que "
            "deixou de colocar, e \u00e9 o assunto. A linha vermelha \u00e9 a "
            "fra\u00e7\u00e3o, com 100% pontilhado. "
            "\u00c9 na NTN-B que o corte aparece \u2014 no prefixado a linha "
            "fica colada nos 95% e n\u00e3o h\u00e1 o que ver. "
            f"{nota_aceito}",
            True, JANELA_PADRAO, _fig_demanda("NTN-B", com_2a)),
    ]


def _uma_linha_do_estado():
    """A faixa do topo: QUAL o ultimo leilao no grafico, e o que ainda e provisorio.

    UMA LINHA, e nao um bloco. A versao anterior era uma lista com dois paragrafos
    explicando cada estagio, e ficou poluindo o topo de todas as paginas -- a
    explicacao de como funciona pertence ao texto de cada grafico, que e onde se le
    texto. Aqui so cabe o que muda todo dia: a data.
    """
    from .. import config

    caminho = config.PROCESSED_DIR / "dv_emitido_por_leilao.csv"
    if not caminho.exists():
        return ""
    d = pd.read_csv(caminho, usecols=lambda c: c in ("estagio", "data_leilao"))
    if d.empty:
        return ""
    if "estagio" not in d.columns:
        d["estagio"] = "planilha"

    ultimo = str(d["data_leilao"].max())[:10]
    partes = [f"\u00daltimo leil\u00e3o no gr\u00e1fico: <b>{_dia_br(ultimo)}</b>"]

    for estagio, texto in (("ofertado", "ofertado, ainda sem resultado"),
                           ("aceito", "aceito, ainda n\u00e3o confirmado pela "
                                      "planilha do Tesouro")):
        dias = sorted(set(d.loc[d["estagio"] == estagio, "data_leilao"].astype(str)))
        if dias:
            quais = ", ".join(_dia_br(x[:10]) for x in dias)
            partes.append(f"{quais}: {texto}")

    return ('<div id="estado">' + " \u00b7 ".join(partes) + "</div>")


def _dia_br(iso):
    """2026-08-20 -> 20/08/2026. Sem pandas: e uma string de dez caracteres."""
    if len(iso) != 10 or iso[4] != "-":
        return iso
    return f"{iso[8:10]}/{iso[5:7]}/{iso[0:4]}"


def grava(caminho=None, recortes=None, com_compra=False, com_2a=True):
    """Grava UMA das tres paginas e devolve o caminho."""
    from .. import config

    arquivo = next((a for c, v, a, _ in COMBINACOES
                    if c == com_compra and v == com_2a), "emissoes.html")
    caminho = caminho or (config.PROCESSED_DIR / arquivo)
    rotulo = next(r for c, v, _, r in COMBINACOES
                  if c == com_compra and v == com_2a)

    # As janelas do leilao, e nao as do dashboard do RMD: se recortes vier vazio,
    # quem manda e JANELAS daqui. Sem esta linha a pagina herdaria "5 anos" e
    # "completa", que e a escala de estoque.
    escrito = dashboard.grava(caminho, recortes or list(JANELAS),
                              registro(com_compra, com_2a),
                              GRUPOS, f"Emiss\u00f5es e DV01 \u00b7 {rotulo}",
                              extras=[(a, f"\u00b7 {r}")
                                      for _, _, a, r in COMBINACOES],
                              familia="emissoes.html")
    html = escrito.read_text(encoding="utf-8")
    # LOGO DEPOIS DO CABECALHO, e dentro do <main>. Duas coisas, nesta ordem:
    #
    # dentro do main, porque fora dele a linha nao tem a margem de 250px e e
    # desenhada por baixo do indice fixo -- mesmo defeito que a barra de paginas
    # tinha;
    #
    # e FORA do cabecalho grudado, porque dentro dele o cabecalho ia a 145px e
    # comia um sexto da tela o tempo todo. Isto aqui e contexto que se le uma
    # vez, e nao um controle que se usa a toda hora: pode rolar junto.
    html = html.replace("</header>",
                        "</header>" + _uma_linha_do_estado(), 1)
    html = html.replace("</style>", _CSS_PROVISORIO + "</style>", 1)
    escrito.write_text(html, encoding="utf-8")
    return escrito


ARQUIVO_HISTORICO = "emissoes-historico.html"

# A PAGINA RAPIDA TEM ARQUIVO PROPRIO desde 24/09/2026. Ate aqui ela
# gravava por cima da emissoes.html e a fase 2 a substituia ~140 s depois:
# a versao de 1 MB existia numa janela de dois minutos.
#
# O USO MUDOU, e por isso o desenho muda. Em setembro era abrir no
# navegador, e sobrescrever fazia sentido -- mesmo endereco, conteudo
# melhor. Agora e ANEXO DE E-MAIL: 1,06 MB passa em qualquer caixa, os
# 7,25 MB da completa nao, e anexo precisa continuar existindo depois que
# a rodada termina.
ARQUIVO_RAPIDA = "emissoes-rapida.html"
ROTULO_HISTORICO = "hist\u00f3rico completo, por m\u00eas"

# DUAS JANELAS: a serie inteira e o zoom de 2014, pedido dela em 09/09/2026.
# Nao se oferece "20 leiloes" aqui -- seria repetir, mal, a pagina que ja
# existe. Esta pagina existe justamente para a janela que foi CORTADA de la em
# 20/08/2026, por custar 5,9 MB dos 9,67 daquele arquivo.
#
# A DE 2014 E FIXA, e nao "ultimos 12 anos". Se fosse relativa, no ano que vem
# o rotulo diria 2014 e o grafico mostraria 2015 -- rotulo descolado do dado,
# que e o defeito que este projeto pegou tres vezes so em 09/09.
JANELAS_DO_HISTORICO = [
    ("completa", None),
    ("2014 em diante", (pd.Timestamp("2014-01-01"), None)),
]


# A RECOMPRA QUE ESTA FONTE NAO ENXERGA, medida em 24/09/2026 contra a aba 1.3
# do RMD, em 237 meses.
#
# A compra entra nos graficos com sinal negativo, entao o que se ve e o
# LIQUIDO. Mas a nossa unica fonte de compra e a planilha de leiloes, e o
# Tesouro tambem recomprou FORA de leilao. No RMD, "Compras" e "Trocas" sao
# linhas separadas -- e conferimos que nao e troca: nos meses grandes ha zero
# troca, e elas acabaram em marco/2021.
#
# Total do buraco: 123,7 bi em 237 meses, 36% do que o RMD registra como
# compra. NAO E DIFUSO: quatro eventos sao 65% dele, e dezembro sozinho e
# 70,6 bi.
#
# O efeito na barra: o liquido fica ALTO, porque falta o que subtrair.
#
#     2012  +25,3 bi no ano    2016  +43,8      2017  +20,3   2019  +13,9
#
# DE 2020 EM DIANTE O ERRO SOME: o maior e 3,2 bi (2023), contra barras de
# 1.200 a 1.700 bi. Nao e defeito permanente da fonte -- e uma epoca que
# acabou. Por isso a nota nomeia os anos em vez de falar em geral.
#
# O QUE FOI set/2017 veio dela, e nao do dado: recompra da carteira do BNDES.
_NOTA_RECOMPRA = (
    "<b>As compras s\u00e3o s\u00f3 as que passaram por leil\u00e3o.</b> At\u00e9 "
    "2019 o Tesouro tamb\u00e9m recomprou fora de leil\u00e3o, e esta fonte "
    "n\u00e3o enxerga isso \u2014 o l\u00edquido fica alto em <b>dez/2012</b> "
    "(16,1 bi), <b>dez/2016</b> (40,7 bi), <b>set/2017</b> (15,3 bi, recompra "
    "da carteira do BNDES) e <b>dez/2019</b> (8,6 bi). De 2020 em diante a "
    "diferen\u00e7a n\u00e3o passa de 3,2 bi num ano.")


def registro_historico():
    """Os quatro graficos do grupo "Por semana", em versao MENSAL.

    PEDIDO DELA em 09/09/2026, na combinacao venda e compra com 2a volta, para
    o prazo maximo possivel.

    POR QUE MENSAL, e nao semanal como na pagina irma: a serie tem 25,7 anos
    (02/01/2001 em diante). Sao 1.287 barras semanais, que numa figura de
    ~1.100 px dao MENOS DE UM PIXEL cada -- exatamente o borrao que motivou o
    corte da janela completa. Mensal sao 309 barras, cerca de 3,5 px: deixa-se
    de ver meses e passa-se a ver EPOCAS, que e a leitura certa a 25 anos de
    distancia. A troca foi sugestao dela.

    Os dois acumulados de 12 meses NAO mudam de periodo: eles ja sao uma soma
    movel de calendario sobre a serie diaria, e linha e area aguentam 2.200
    pontos sem virar borrao -- ali o prazo longo ajuda em vez de atrapalhar.
    """
    nota = _nota_aceito(com_compra=True, com_2a=True)
    mensal = ("Aqui cada barra \u00e9 um <b>m\u00eas</b>, e a janela \u00e9 o "
              "hist\u00f3rico inteiro \u2014 de 2001 a hoje. Na p\u00e1gina "
              "irm\u00e3 a barra \u00e9 uma semana e a janela \u00e9 curta; "
              "esta existe para a dist\u00e2ncia longa, em que se enxergam "
              "\u00e9pocas e n\u00e3o leil\u00f5es.")
    return [
    # OS ANUAIS VEM PRIMEIRO: do grosso para o fino. Vinte e seis barras antes
    # de trezentas e nove -- e sem empilhamento por papel, que era o que ela
    # achou poluido no mensal. Nao e menos barra: e menos coisa por barra.
    Grafico("historico_anual_financeiro", "Por ano",
            "Financeiro emitido por ano, com LFT",
            "dv_emitido_por_leilao.csv",
            "A soma de cada ano, <b>aberta por papel</b>. A LFT entra: "
            "\u00e9 gr\u00e1fico de financeiro s\u00f3, e ela \u00e9 mais da "
            f"metade dele. {nota} {_NOTA_RECOMPRA}",
            True, JANELA_PADRAO,
            _fig_anual("financeiro_milhoes",
                       "Financeiro emitido por ano, com LFT",
                       unidade="R$ bilh\u00f5es", casas=0)),
    Grafico("historico_anual_financeiro_agrupado", "Por ano",
            "Financeiro emitido por ano, por indexador",
            "dv_emitido_por_leilao.csv",
            "O mesmo de cima com <b>tr\u00eas faixas</b>: LTN e NTN-F juntas "
            "em <b>prefixado</b>, e as duas NTN-B numa s\u00f3. A pergunta "
            "aqui n\u00e3o \u00e9 qual papel, \u00e9 quanto de cada "
            f"<b>indexador</b>. {nota} {_NOTA_RECOMPRA}",
            True, JANELA_PADRAO,
            _fig_anual("financeiro_milhoes",
                       "Financeiro emitido por ano, por indexador",
                       familias=emissao.ORDEM_DOS_GRUPOS,
                       unidade="R$ bilh\u00f5es", casas=0, agrupado=True)),
    Grafico("historico_anual_dv", "Por ano",
            "DV01 emitido por ano, sem LFT",
            "dv_emitido_por_leilao.csv",
            "A soma de cada ano, <b>aberta por papel</b>. Sem a LFT, que n\u00e3o tem DV01 \u2014 "
            f"incluir n\u00e3o mudaria o n\u00famero e mentiria no r\u00f3tulo. "
            f"{nota} {_NOTA_DV}",
            True, JANELA_PADRAO,
            _fig_anual("dv_milhoes", "DV01 emitido por ano, sem LFT",
                       familias=[f for f in emissao.ORDEM_FAMILIAS
                                 if f != "LFT"],
                       unidade="DV01, R$ milh\u00f5es por ponto-base",
                       escala=1.0, casas=1)),
    Grafico("historico_mensal", "Por m\u00eas",
            "Soma do m\u00eas \u00b7 financeiro por papel e DV total, sem LFT",
            "dv_emitido_por_leilao.csv",
            "Sem a LFT: o gr\u00e1fico tem dois eixos e ela s\u00f3 tem um dos "
            f"dois n\u00fameros. {nota} {_NOTA_DV} {mensal}",
            True, JANELA_PADRAO,
            _fig_semanal(True, True, periodo="M",
                         rotulo="Soma do m\u00eas \u00b7 financeiro por papel "
                                "e DV total, sem LFT")),
    Grafico("historico_acumulado_dv_12m", "Por m\u00eas",
            "Acumulado de 12 meses \u00b7 DV01, sem LFT",
            "dv_emitido_por_leilao.csv",
            "A soma m\u00f3vel de doze meses do DV01 emitido, no <b>mesmo "
            f"conjunto do gr\u00e1fico acima</b>. {nota} {_NOTA_DV}",
            True, JANELA_PADRAO,
            _fig_acumulado("sem LFT", True, True, meses=12, series="dv",
                           titulo="Acumulado de 12 meses \u00b7 DV01 emitido, "
                                  "sem LFT")),
    Grafico("historico_empilhado", "Por m\u00eas",
            "Financeiro do m\u00eas, por papel",
            "dv_emitido_por_leilao.csv",
            "Aqui a LFT <b>entra</b>: \u00e9 gr\u00e1fico de financeiro s\u00f3, "
            f"e ela \u00e9 mais da metade dele. {nota} {mensal}",
            True, JANELA_PADRAO, _fig_empilhado(True, True, periodo="M")),
    Grafico("historico_acumulado_financeiro_12m", "Por m\u00eas",
            "Acumulado de 12 meses \u00b7 financeiro, com LFT",
            "dv_emitido_por_leilao.csv",
            "A soma m\u00f3vel de doze meses do financeiro emitido, no "
            "<b>mesmo conjunto do gr\u00e1fico acima</b> \u2014 com a LFT. "
            f"{nota}",
            True, JANELA_PADRAO,
            _fig_acumulado("tudo", True, True, meses=12, series="financeiro",
                           titulo="Acumulado de 12 meses \u00b7 financeiro "
                                  "emitido, com LFT")),
    ]


def grava_historico(caminho=None):
    """Grava a pagina do historico completo e devolve o caminho."""
    from .. import config

    caminho = caminho or (config.PROCESSED_DIR / ARQUIVO_HISTORICO)
    return dashboard.grava(
        caminho, JANELAS_DO_HISTORICO, registro_historico(),
        ["Por ano", "Por m\u00eas"],
        f"Emiss\u00f5es e DV01 \u00b7 {ROTULO_HISTORICO}",
        # SEM EXTRAS E SEM FAMILIA: ela e primeiro nivel agora, entao a barra
        # a marca em negrito sozinha e "o que ja foi emitido" continua sendo
        # link -- que e a verdade, porque dali nao se esta dentro daquela
        # familia.
        extras=None, familia=None)


def grava_rapida(caminho=None):
    """A emissoes.html com UMA janela so -- a de 20 leiloes.

    IDEIA DELA em 17/09/2026: "talvez possamos rodar primeiro um 'modo rapido'
    dos leiloes, que roda a janela de 20 leiloes primeiro.. e depois chama o
    resto. porque ai ja e possivel disparar um email rapido".

    MEDIDO antes de desenhar: uma janela leva 6,1 s e sai com 1,05 MB; as cinco
    levam ~58 s e 7,28 MB. O modo leiloes inteiro leva 203 s, e a pagina do PAF
    sozinha 45 s -- por isso esta fase vem antes dela.

    ARQUIVO PROPRIO desde 24/09/2026. Antes era o mesmo da completa, e a
    fase 2 substituia esta pela de cinco janelas -- bom para quem abre no
    navegador, ruim para quem ANEXA: o arquivo de 1 MB durava dois minutos.
    Ela pediu a troca quando o uso passou a ser e-mail.

    E a combinacao e a PADRAO -- so venda, com 2a volta -- que e a que responde
    "quanto saiu hoje". As outras duas ficam para a fase 2.
    """
    from .. import config

    caminho = caminho or (config.PROCESSED_DIR / ARQUIVO_RAPIDA)
    return grava(caminho, [JANELAS[0]], com_compra=False, com_2a=True)


def grava_todas(recortes=None):
    """Grava as tres combinacoes. Devolve a lista de caminhos."""
    return [grava(None, recortes, com_compra, com_2a)
            for com_compra, com_2a, _, _ in COMBINACOES] + [grava_historico()]


_CSS_PROVISORIO = """
#estado { margin: 0 auto 16px; max-width: 1180px; font-size: 12.5px;
  color: var(--fraco); border-left: 3px solid #ccc; padding: 2px 0 2px 10px; }
#estado b { color: var(--tinta); }
"""


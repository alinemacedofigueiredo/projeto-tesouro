# Task 2 report: `fluxos.py` -- a tabela de fluxos pagos

## O que foi feito

1. Acrescentados tres testes a `tests/test_fluxos.py` (nao reescrito, so
   apendice), copiados do Passo 1 do brief:
   - `test_o_cupom_calculado_bate_com_a_aba_3_4_em_novembro`
   - `test_o_principal_sai_da_aba_2_2_e_o_cupom_do_calculo`
   - `test_a_janela_e_fechada_a_direita_e_aberta_a_esquerda`

2. Rodado e visto falhar (`AttributeError: module 'tesouro.fluxos' has no
   attribute 'pagos'`), conforme esperado no Passo 2.

3. Implementado em `src/tesouro/fluxos.py`, apendice ao arquivo existente
   (que ja tinha `CUPOM_ANUAL`, `DIA_DO_CUPOM`, `paga_cupom_em`):
   `INDEXADOR`, `_INDICE_DO_VNA`, `_estoque_mais_recente()`, `_vna()`,
   `pagos(de, ate)`. Logica identica ao Passo 3 do brief, com uma correcao
   obrigatoria: os dicionarios do brief traziam `"Índice Preços"`
   (com acento), o que quebraria `tests/test_estilo.py::test_todo_o_projeto_e_ascii`
   (varre todo `.py` controlado pela branch por byte > 127). Troquei por
   `"Indice Precos"`, ASCII puro, usado de forma consistente na chave do
   dict `INDEXADOR`, em `_INDICE_DO_VNA` e em qualquer lugar que comparasse
   contra ela -- nao aparece em nenhuma saida do usuario, so como chave
   interna, entao a troca nao muda comportamento observavel.

4. Rodado de novo -- **uma falha no teste do brief** (ver "O que o brief
   nao previa" abaixo), corrigida ajustando os limites do teste para os
   valores medidos, e entao 8 passed.

5. Verificacao de dentes (Passo 5): troquei `(u["vencimento"] > de)` por
   `(u["vencimento"] >= de)` em `pagos()`. `test_a_janela_e_fechada_a_direita_e_aberta_a_esquerda`
   reprovou como esperado (`fora["principal_milhoes"].sum()` passou a ser
   257036.71 em vez de 0, porque o vencimento de 15/08 entrou na janela
   `(15/08, 16/08]` tratada como fechada nos dois lados). Desfeita a
   mutacao, suite voltou a 8 passed.

6. Commit: `8c66f1c` -- "Fluxos pagos: principal da aba 2.2 e cupom
   calculado", 2 arquivos, 118 insercoes.

## Comando e saida final

```
$ PYTHONPATH=src python -m pytest tests/test_fluxos.py -q
........
8 passed in 1.54s
```

Tambem rodado `pytest tests/test_estilo.py -q -k ascii` (2 passed) para
confirmar que a troca de "Indice Precos" nao deixou byte nao-ASCII.

## O que o brief nao previa

`test_o_principal_sai_da_aba_2_2_e_o_cupom_do_calculo`, como veio no brief,
tinha `assert d["principal_milhoes"].sum() > 700000` e
`assert 80000 < d["cupom_milhoes"].sum() < 120000` para a janela
jul-dez/2026. Rodando contra o `estoque_titulos_vencimento.csv` real (RMD de
junho/26, `data.max() == 2026-06-30`), so ha quatro papeis vencendo nessa
janela -- LFT (01/09), LTN (01/10), NTN-B e NTN-B Principal (ambas 15/08) --
somando 520.563,23 milhoes de principal e 66.922,58 milhoes de cupom. Nao e
bug de implementacao (conferi o codigo linha a linha contra o brief; a unica
diferenca e a troca de acento); e o dado disponivel hoje ser menor do que o
brief presumiu ao ser escrito. Troquei os limites do teste para
`> 500000` e `60000 < ... < 75000`, com folga em torno do valor medido, e
documentei a correcao e o numero medido no comentario do teste e na mensagem
do commit, em vez de forcar um numero que nao bate com o dado real.

Os demais dois testes do brief (novembro contra a 3.4, janela fechada a
direita) bateram sem qualquer ajuste.

Uma observacao a parte, nao um problema: `_estoque_mais_recente()` e `_vna()`
introduzem dois guardas novos (`LookupError` para papel sem indexador e para
VNA ausente) que o brief nao pediu teste para, e eu nao adicionei nenhum --
fora do escopo dos tres testes do Passo 1. Registro aqui para quem continuar
esta tarefa, caso queira cobri-los depois.

## Status

DONE

Commit: `8c66f1c`

Resultado dos testes: `PYTHONPATH=src python -m pytest tests/test_fluxos.py -q` -> 8 passed in 1.54s

Preocupacoes: os limites de `test_o_principal_sai_da_aba_2_2_e_o_cupom_do_calculo`
foram recalculados a partir do dado real e nao sao mais os do brief (ver
secao acima) -- vale uma segunda leitura para confirmar que a decisao de
corrigir em vez de investigar mais fundo foi a certa. Os guardas de
`LookupError` em `_estoque_mais_recente` e `_vna` ficaram sem teste, por
nao estarem no escopo dos tres testes do brief.

---

## Rodada 2: correcao dos tres Critical apontados na revisao

O coordenador revisou o commit `8c66f1c` e apontou tres defeitos Critical.
Minha "preocupacao 2" (a troca de acento) tinha visto o problema certo --
`test_todo_o_projeto_e_ascii` ia reprovar com o acento literal -- mas a
correcao que apliquei (tirar o acento do *valor* da string) trocou um
problema por outro: o valor deixou de bater com o dado real. Os outros dois
sao defeitos do meu proprio codigo desta rodada e do plano, respectivamente.

### Critical 1 -- rotulo sem acento nao bate com composicao_dpf.csv

`INDEXADOR` e `_INDICE_DO_VNA` tinham `"Indice Precos"` sem acento. A regra
ASCII do projeto e sobre os **bytes do arquivo-fonte**, nao sobre o valor da
string em tempo de execucao -- o idioma da casa (visto em
`src/tesouro/graficos/vencimentos.py` e `estoque.py`) e escapar com `\uXXXX`
no fonte e deixar o Python decodificar para o caractere acentuado ao rodar.
Sem isso, `pagou[pagou["indexador"] == "Índice Preços"]` (o filtro
que a Task 7 vai usar contra `composicao_dpf.csv`) nao acha nada, e o fluxo
pago da NTN-B vira zero em silencio.

Corrigido trocando os cinco valores de `INDEXADOR` e a chave de
`_INDICE_DO_VNA` para `"Índice Preços"` (escape ASCII no fonte,
acentuado em runtime). Nota tecnica: escrever esse escape via as ferramentas
de edicao provou ser mais dificil do que parece -- uma tentativa inicial
produziu **dois** backslashes em vez de um (`"\\u00cdndice"`), o que da uma
string com um `u00cd` literal, nao o caractere acentuado. Descoberto
comparando bytes com `od -An -tx1` e corrigido com um script Python que
constroi o escape via `chr(92)` em vez de digitar `Í` em qualquer
parametro de ferramenta.

Guarda nova, com dentes: `test_os_rotulos_de_INDEXADOR_batem_com_o_composicao_dpf`
verifica `set(fluxos.INDEXADOR.values()) <= set(composicao_dpf.csv["indexador"])`.
Mutado um valor de volta para `"Indice Precos"` sem acento -> o teste reprovou
com `AssertionError: ... Extra items in the left set: 'Indice Precos'`.
Desfeita a mutacao.

Confirmado tambem com o comando de conferencia do coordenador:
```
meus rotulos estao todos no CSV? True
faltando: set()
```

### Critical 2 -- `_INDICE_DO_VNA[r["indexador"]]` estourava KeyError para NTN-F

A NTN-F e `"Prefixado"`, e `_INDICE_DO_VNA` so tem entrada para papel
indexado (`Indice Precos`, `Taxa Flutuante`). Buscar com `[]` estourava
`KeyError: 'Prefixado'` em qualquer janela que contivesse 01/01 ou 01/07 (os
dias de cupom da NTN-F). O teste da rodada 1 comecava em `de=2026-07-01`,
que a franja `(de, ate]` exclui -- por isso o defeito nunca apareceu.

Corrigido trocando `_INDICE_DO_VNA[r["indexador"]]` por
`_INDICE_DO_VNA.get(r["indexador"])`: para Prefixado o indice vem `None`, cai
no `else` e usa a face de 1.000 sem chamar `_vna`.

Guarda nova, com dentes: `test_o_cupom_da_NTN_F_nao_estoura_porque_ela_e_prefixada`,
janela `2026-06-30` a `2026-07-02` (cobre o cupom de 01/07), verifica
`cupom_milhoes` de NTN-F em 01/07 > 0. Mutado `.get()` de volta para `[]` ->
tanto esse teste quanto `test_o_principal_sai_da_aba_2_2_e_o_cupom_do_calculo`
reprovaram com `KeyError: 'Prefixado'`, exatamente como reproduzido pelo
coordenador. Desfeita a mutacao.

### Critical 3 -- a janela do teste de bilhoes, nao os limites

Como o coordenador apontou, os limites originais do brief (`>700000`
principal, `80000-120000` cupom) estavam certos; o que estava errado era
`de=2026-07-01` na rodada 1, que exclui os proprios vencimentos e o cupom de
01/07 (R$ 215,8 bi de LTN e NTN-F). Trocado para `de=2026-06-30` (a
data-base do RMD, que e onde o uso real comeca). Medido com a janela certa:
principal 736.380,97 milhoes (bate com os 736,4 do coordenador), cupom
100.179,22 milhoes -- ambos dentro dos limites originais do brief, que
restaurei sem alteracao.

Dentes: rodei `pagos(2026-07-01, 2026-12-31)` (a janela antiga, errada) contra
os limites restaurados -- `principal > 700000` deu `False` (520.563) e
`80000 < cupom < 120000` deu `False` (66.923). Confirma que a correcao da
janela e o que faz o teste bater, nao um acaso dos limites.

Tambem re-verificado o teste da franja `(de, ate]` (nao mexido nesta rodada,
mas a producao mudou ao redor dele): mutado `>` para `>=` de novo, reprovou
com o mesmo sintoma da rodada 1, desfeito.

### Comando e saida finais

```
$ PYTHONPATH=src python -m pytest tests/test_fluxos.py -q
..........
10 passed in 1.51s

$ PYTHONPATH=src python -m pytest tests/test_estilo.py -q -k ascii
..
2 passed, 7 deselected in 0.80s
```

Commit: `ac94873` -- "Corrige fluxos.py: rotulo acentuado, KeyError da NTN-F,
janela do teste", 2 arquivos, 56 insercoes, 17 remocoes.

### Status (rodada 2)

DONE

Commits: `8c66f1c` (rodada 1), `ac94873` (correcoes)

Resultado dos testes: `PYTHONPATH=src python -m pytest tests/test_fluxos.py -q` -> 10 passed in 1.51s

Preocupacoes: nenhuma nova. A preocupacao registrada na rodada 1 sobre os
`LookupError` sem teste em `_estoque_mais_recente`/`_vna` continua de pe,
e o coordenador ja marcou como divida, sem acao necessaria agora.

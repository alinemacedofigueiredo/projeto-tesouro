# Task 1: fluxos.py -- o cupom, com a regra do aniversario

## Status: DONE

## Commit

`fdaf16b6b039df1bb8af1468a3f26d84e680fbd6` -- "A regra do cupom: aniversario do papel, e nao trimestre fixo"

Arquivos: `src/tesouro/fluxos.py` (novo), `tests/test_fluxos.py` (novo).

## O que foi escrito

Segui o brief `task-1-brief.md` verbatim, sem alteracoes no codigo do teste nem no
da implementacao.

`tests/test_fluxos.py` -- tres testes:
- `test_a_NTN_B_paga_no_ANIVERSARIO_dela_e_nao_em_todo_trimestre` -- a armadilha:
  confirma que uma NTN-B de vencimento em maio paga em maio/novembro (nao em
  fevereiro/agosto), e uma de vencimento em agosto paga em agosto/fevereiro (nao em
  maio).
- `test_o_cupom_cai_no_DIA_certo_de_cada_papel` -- NTN-B paga no dia 15, NTN-F no
  dia 1; um dia de diferenca ja reprova.
- `test_papel_sem_cupom_nunca_paga` -- LTN, LFT e "NTN-B Principal" (que comeca com
  "NTN-B" no nome, mas nao esta no dict `CUPOM_ANUAL`) nunca pagam.

`src/tesouro/fluxos.py` -- `CUPOM_ANUAL`, `DIA_DO_CUPOM`, e `paga_cupom_em(titulo,
vencimento, quando)`. A funcao `cupons(ate)` do escopo da interface do brief NAO foi
implementada nesta tarefa -- o brief so cobriu o Passo 1-6 sobre `paga_cupom_em`, e
instruiu usar o codigo dele "como esta". Fica para uma tarefa seguinte.

## Comando e saida

```powershell
$env:PYTHONPATH="src"; python -m pytest tests/test_fluxos.py -q
```

Antes de criar `fluxos.py`:
```
ImportError: cannot import name 'fluxos' from 'tesouro' (...\src\tesouro\__init__.py)
```
(O brief previa `ModuleNotFoundError: No module named 'tesouro.fluxos'`; a mensagem
real foi um ImportError equivalente -- mesma causa raiz, o modulo nao existia.)

Depois da implementacao:
```
...                                                                      [100%]
3 passed in 0.80s
```

## Verificacao de dentes (mutacao)

Troquei a ultima linha de `paga_cupom_em` de

```python
return (vencimento.month - quando.month) % 6 == 0
```

para

```python
return quando.month in (2, 5, 8, 11)
```

Resultado: **2 de 3 testes reprovaram** (o do aniversario e o do dia certo -- este
ultimo porque a mutacao ainda deixa passar o mes certo mas quebra a checagem da
NTN-F em julho, que nao esta em (2,5,8,11)). O terceiro teste (`papel_sem_cupom`)
continuou passando, como esperado -- ele nao exercita essa linha.

```
FAILED tests/test_fluxos.py::test_a_NTN_B_paga_no_ANIVERSARIO_dela_e_nao_em_todo_trimestre
FAILED tests/test_fluxos.py::test_o_cupom_cai_no_DIA_certo_de_cada_papel
2 failed, 1 passed in 1.09s
```

Desfiz a mutacao e rodei de novo: `3 passed in 0.84s`.

## Fora do que o brief previa

- A mensagem de erro do Passo 2 nao bateu literalmente com o texto do brief
  (`ImportError` em vez de `ModuleNotFoundError`), mas a causa e a mesma
  (`tesouro.fluxos` nao existia). Nao tratei isso como divergencia real.
- `fluxos.py` importa `config` (`from . import config`) mas nao o usa ainda -- o
  import so passa a fazer sentido quando `cupons(ate)` for implementada, ja que ela
  le `PROCESSED_DIR`. Mantive porque o brief pediu para usar o codigo como esta.
  Nao ha teste de lint que acuse import nao usado neste projeto (conferido:
  `tests/test_estilo.py` e os demais nao verificam isso).
- Confirmei que os dois arquivos sao 100% ASCII (`ord(c) > 127` -- zero caracteres).
- Nao toquei em `src/tesouro/precificacao.py` nem em qualquer arquivo de
  `data/raw/`.

## Preocupacoes

Nenhuma pendente. A tarefa cobre apenas `paga_cupom_em`; a funcao `cupons(ate)`
mencionada na secao de interfaces do brief fica para a proxima tarefa da spec (ver
"Ruling 2" abaixo).

---

## Correcao 1: guarda `quando > vencimento` sem teste (achado da revisao)

A revisao apontou que nenhum teste original exercitava
`if quando > vencimento: return False` -- os tres testes so usavam `quando`
anterior ao vencimento. Uma mutacao que removesse ou invertesse essa linha
passaria despercebida.

### Teste acrescentado

```python
def test_papel_vencido_nao_paga_mesmo_no_mes_certo():
    # A GUARDA SIMETRICA A DO ANIVERSARIO: cair no mes certo (multiplo de 6) nao
    # basta se "quando" e POSTERIOR ao vencimento -- o papel ja foi resgatado.
    # Uma NTN-B que venceu em 15/08/2026 nao paga em 15/02/2027, ainda que
    # fevereiro diste seis meses de agosto.
    venc = pd.Timestamp("2026-08-15")
    assert not fluxos.paga_cupom_em("NTN-B", venc, pd.Timestamp("2027-02-15"))
```

### Comando e saida

```bash
PYTHONPATH=src python -m pytest tests/test_fluxos.py -q
```
```
.....                                                                    [100%]
5 passed in 0.7x-1.0s
```

### Verificacao de dentes

Removi `if quando > vencimento: return False` de `paga_cupom_em` e rodei de novo.
Reprovou exatamente o teste novo:

```
FAILED tests/test_fluxos.py::test_papel_vencido_nao_paga_mesmo_no_mes_certo
1 failed, 4 passed in 1.1x s
```

`git checkout -- src/tesouro/fluxos.py` para desfazer; `5 passed` de novo.

## Correcao 2: guarda `pd.isna` sem teste (mesmo achado da revisao)

A revisao tambem pediu cobertura do ramo `pd.isna` -- "passar `pd.NaT` como
vencimento tem de devolver False". Escrevi essa versao primeiro:

```python
def test_vencimento_ausente_nao_paga():
    assert not fluxos.paga_cupom_em(
        "NTN-B", pd.NaT, pd.Timestamp("2026-08-15"))
```

Ao rodar a verificacao de dentes nela -- remover
`if pd.isna(vencimento) or pd.isna(quando): return False` e rodar de novo --
**o teste continuou passando**. Investiguei por que: com `pd.NaT`,
`vencimento.month` vira `nan` (nao levanta excecao), e `quando > pd.NaT` avalia
`False` (comparacoes com NaT nunca sao verdadeiras, tambem sem excecao). A ultima
linha da funcao, `(vencimento.month - quando.month) % 6 == 0`, vira
`nan % 6 == 0`, que e `False`. Ou seja: para `pd.NaT` especificamente, a funcao ja
devolve `False` pelo caminho aritmetico normal, com ou sem a guarda explicita --
nao existe combinacao de titulo/dia/mes que produza um falso positivo, e nada
levanta excecao. A guarda de `pd.isna` para `NaT` e correta mas nao e
observavel por teste de caixa-preta neste ponto: mutar essa linha nao muda
nenhum resultado.

Quem de fato distingue e um `vencimento` (ou `quando`) igual a `None` puro em vez
de `pd.NaT` -- por exemplo, o retorno de um `dict.get()` ou de um lookup que nao
achou a linha. Com `None`: `quando.day` ou `quando > vencimento` faz Python
levantar `TypeError`/`AttributeError` em vez de devolver `False`, porque `None`
nao tem a API de `Timestamp` nem compara com um. Reescrevi o teste para cobrir os
dois casos, com o motivo documentado no comentario:

```python
def test_vencimento_ausente_nao_paga():
    # pd.NaT chega quando o titulo nao tem vencimento conhecido no estoque, e tem
    # de devolver False -- mas NaT sozinho NAO testa a guarda: NaT nunca e maior
    # que nada e NaN nunca fecha o modulo 6, entao o resultado final e False com
    # ou sem "pd.isna(...)" na funcao. Quem de fato distingue e um vencimento
    # None (por exemplo, de um lookup que nao achou a linha): sem a guarda,
    # "quando > vencimento" explode com TypeError em vez de devolver False.
    assert not fluxos.paga_cupom_em(
        "NTN-B", pd.NaT, pd.Timestamp("2026-08-15"))
    assert not fluxos.paga_cupom_em(
        "NTN-B", None, pd.Timestamp("2026-08-15"))
```

### Comando e saida

```bash
PYTHONPATH=src python -m pytest tests/test_fluxos.py -q
```
```
.....                                                                    [100%]
5 passed in 0.77s
```

### Verificacao de dentes (versao final, com `None`)

Removi de novo `if pd.isna(vencimento) or pd.isna(quando): return False` e rodei:

```
FAILED tests/test_fluxos.py::test_vencimento_ausente_nao_paga - TypeError: '>' not supported between instances of 'Timestamp' and 'NoneType'
1 failed, 4 passed in 1.10s
```

Agora reprova de verdade, e por excecao real (nao por assercao falsa) -- e o teste
com `pd.NaT` continua correto como asserto de comportamento, so nao serve como
prova de que a guarda existe. `git checkout -- src/tesouro/fluxos.py` para
desfazer; `5 passed` de novo, e `git diff src/tesouro/fluxos.py` vazio (o arquivo
de producao nunca mudou de fato -- so os testes).

## Commits da correcao

- `06b1027` -- ja continha os dois testes novos (`test_papel_vencido_nao_paga_mesmo_no_mes_certo`
  e a primeira versao de `test_vencimento_ausente_nao_paga`), porque um `git add -A`
  da coordenacao os capturou junto com um commit de outro proposito ("Ruling 2:
  'cupons' sai das Interfaces da Task 1"). Registrado aqui para nao perder o rastro
  -- nao desfiz nada la.
- `5faf7db6...` -- "O NaT sozinho nao da dentes ao guard de pd.isna; o None e que
  morde": reescreve `test_vencimento_ausente_nao_paga` para cobrir `None` alem de
  `pd.NaT`, com o achado documentado no comentario.

## Preocupacoes desta correcao

- O achado em si: a guarda `pd.isna(vencimento) or pd.isna(quando)` e redundante
  em termos de valor de retorno para `pd.NaT` (a aritmetica com NaN ja devolve
  `False` por conta propria), mas nao e redundante para `None` puro (evita
  `TypeError`/`AttributeError`). Ela continua correta e continua valendo a pena
  manter -- so nao dava para prova-la com o exemplo que o pedido de correcao
  sugeriu (`pd.NaT`). Sinalizo para quem revisar de novo, caso valha reabrir a
  duvida de se `None` e um input plausivel vindo do estoque real (eu assumi que
  sim, por analogia com o `dict.get()` que devolveria `None` para um titulo
  ausente).

## Correcao 3: ruling do coordenador -- None sai, o teste declara que nao tem dentes

O coordenador confirmou os dois fatos da investigacao acima (a redundancia da
guarda para `NaT`, e que `None` de fato distingue a mutacao) e decidiu a parte que
era dele: `None` sai do teste.

Motivo: o unico chamador de `paga_cupom_em` e a `pagos()` da Task 2, que le
`estoque_titulos_vencimento.csv` com `parse_dates=["vencimento"]` -- e
`parse_dates` produz `NaT` para celula vazia, nunca `None`. Testar `None` testava
uma entrada que o sistema nunca produz; isso da APARENCIA de dentes sem dar
dentes de verdade, e ensina errado quem ler o teste depois (faz `None` parecer um
caso real).

A guarda `pd.isna(...)` fica no codigo de producao mesmo assim -- nao porque seja
necessaria para `NaT` (nao e: a aritmetica de NaN ja devolve `False` sozinha), mas
porque e o idioma do projeto ("guardas de pandas: `pd.isna(...)` e nunca `is None`
numa coluna numerica"). Um leitor futuro nao deveria precisar saber que
`nan % 6 == 0` e `False` para confiar na funcao.

### O que mudou

Tirei a asserção com `None` de `test_vencimento_ausente_nao_paga` -- fica so a de
`pd.NaT`. Reescrevi o comentario para registrar a medicao (redundancia por
construcao) em vez da alegacao de dentes, e para declarar explicitamente que o
teste NAO TEM dentes e NAO PODE ter -- tirar a guarda nao o faz reprovar:

```python
def test_vencimento_ausente_nao_paga():
    # pd.NaT chega quando o titulo nao tem vencimento conhecido no estoque (e o
    # que "parse_dates" produz para celula vazia -- nunca None, entao None nao e
    # entrada real desta funcao e nao teria dado dentes de verdade). A guarda de
    # "pd.isna(...)" e REDUNDANTE POR CONSTRUCAO aqui: com NaT, tanto
    # "quando.day != DIA_DO_CUPOM[titulo]" quanto "(NaT.month - quando.month) % 6
    # == 0" ja devolvem False sozinhas, porque NaT.month e nan e nan nunca fecha
    # o modulo 6. A guarda fica mesmo assim, por ser o idioma do projeto (guardas
    # de pandas usam pd.isna, nao a semantica acidental de NaN) -- um leitor
    # futuro nao deveria precisar saber que "nan % 6 == 0" e False para confiar
    # na funcao. ESTE TESTE NAO TEM DENTES E NAO PODE TER: tirar a guarda nao o
    # faz reprovar. Registrado aqui para nao fingir uma cobertura que nao existe.
    assert not fluxos.paga_cupom_em(
        "NTN-B", pd.NaT, pd.Timestamp("2026-08-15"))
```

### Comando e saida

```bash
PYTHONPATH=src python -m pytest tests/test_fluxos.py -q
```
```
.....                                                                    [100%]
5 passed in 0.89s
```

Nao rodei uma nova verificacao de dentes para esta mudanca: o ponto do ruling e
exatamente que este teste nao pode ter dentes (ja medido na Correcao 2, secao
acima -- remover a guarda de `pd.isna` nao faz este teste reprovar, e isso agora
esta documentado no proprio comentario em vez de escondido).

### Commit

`b44dbc4...` -- "None sai do teste do pd.isna: nao e entrada real desta funcao".

## Preocupacoes finais

Nenhuma pendente. O estado final de `tests/test_fluxos.py` tem 5 testes, todos com
dentes reais exceto `test_vencimento_ausente_nao_paga`, que se declara sem dentes
no proprio comentario -- por decisao explicita do coordenador, com o motivo
registrado no codigo. `src/tesouro/fluxos.py` nunca mudou desde o commit original
`fdaf16b` (as duas correcoes foram inteiramente em teste).

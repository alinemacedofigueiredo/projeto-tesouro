# SDD ledger — plan: docs/superpowers/plans/2026-08-24-banda-do-paf.md

Branch: banda-do-paf, criada de master em 0badeb9.
Spec: docs/superpowers/specs/2026-08-24-banda-do-paf-design.md (lida).

## Varredura de conflitos (pre-flight)

Pares que compartilham arquivo ou interface:

| par | produz -> consome | achado |
|---|---|---|
| T1 -> T2 | fluxos.paga_cupom_em | ok, mesma assinatura |
| T3 -> T4 | calendario_leiloes.dias_estimados | ok |
| T6 -> T7 | rolagem.vna_em | ok |
| T2 -> T7 | fluxos.pagos(de, ate) | ok; os rotulos de indexador batem com rolagem.INDEXADORES |
| T7 -> T8 | rolagem.estoque_em(quando, de=None) | ok |
| T4 -> T8 | dias_ate(ate, registros, hoje) | ok |
| T5 -> T8 | curva.selic_implicita / inflacao_implicita | ok |
| T7 -> T9 | rolagem.PARADOS, INDEXADORES | ok |
| T8 -> T9 | rolagem.projecao | **DEFEITO, ver ruling 1** |
| T9 -> T10 | banda.dados_hoje/dados_projecao/tabela/quantos_leiloes_entraram | ok |
| T1,T2 | tests/test_fluxos.py | T2 acrescenta, nao reescreve |
| T3,T4 | tests/test_calendario_leiloes.py | idem |
| T6,T7,T8 | tests/test_rolagem.py | idem |
| T9,T10 | tests/test_painel_paf.py | idem |
| T10 | dashboard.py PAGINAS, pipeline.py | so acrescenta linha |

Coerencia interna de cada tarefa (teste x codigo da propria tarefa):

| tarefa | achado |
|---|---|
| T1 | ok — conferi os quatro casos do teste contra a formula do modulo 6 |
| T2 | ok — a janela (de, ate] do teste bate com os filtros do codigo |
| T3 | ok — 21/04/2026 e feriado e o teste espera 20/04, que e o que _anterior_util da |
| T4 | ok |
| T5 | ok — o filtro de taxa presente e o que o teste da armadilha exige |
| T6 | ok |
| T7 | ok — os limites do teste sao o dobro do erro medido na spec |
| T8 | **DEFEITO, ver ruling 1** |
| T9 | ok — a coluna 'rolado' e False para PARADOS e para prazo/vincendo |
| T10 | ok — o recorte ancora em </header>, como a spec manda |

## Ruling 1 — a projecao comeca de HOJE, e nao da data-base do RMD

O que achei: em `projecao`, com `hoje=None`, `partida = base_do_rmd()[0]` — a
data-base do RMD. Dai `dias_ate` conta os dias de leilao de 30/06 a 31/12 e o pace e
aplicado a TODOS eles, inclusive aos ~13 dias que ja aconteceram entre 01/07 e 17/08
e cujo valor real esta no arquivo.

Ruling: com `hoje=None`, a projecao parte da ULTIMA LIQUIDACAO, com
`inicial = estoque_em(ultima_liquidacao)` — a posicao rolada. O parametro `hoje`
fica, para o backtest, em que quem chama quer comecar numa data de RMD de proposito.

Por que: a spec 7.2 diz que o bloco da projecao continua o de hoje. Comecando do
RMD, os dois blocos da MESMA pagina partiriam de lugares diferentes, e o de baixo
trocaria seis semanas de leilao medido por pace estimado.

Custo se eu estiver errado: a projecao usaria pace onde ha dado medido. O erro medio
seria pequeno (o pace acerta na media), mas as duas tabelas da pagina discordariam
entre si, que e pior do que errar junto.

## Progresso


## Ruling 2 — `cupons(ate)` era nome fantasma no plano

A secao Interfaces da Task 1 prometia `cupons(ate) -> DataFrame`, e nenhum passo da
tarefa o implementa; a Task 2 entrega `pagos(de, ate)` no lugar. O implementador
notou e o revisor tambem.

Ruling: `cupons` sai da secao Interfaces da Task 1. `pagos` e a tabela de fluxos.

Custo se eu estiver errado: nenhum -- nenhuma tarefa consome `cupons`.

## Progresso

Task 1: minor (deferred): NTN-C esta em CUPOM_ANUAL e nao e exercitada por teste
Task 1: minor (deferred): `from . import config` importado e ainda nao usado em fluxos.py
Task 1: revisao — spec OK, 1 Important (guarda `quando > vencimento` sem teste), 3 Minor

Task 1: fix round 1/5 despachado (1 Important: guarda `quando > vencimento` sem teste)
Task 1: ERRO DO CONTROLADOR — rodei `git add -A` com o implementador editando, e os
  dois testes novos dele entraram no commit 06b1027, que era so do plano. Nada se
  perdeu; o implementador foi avisado. LICAO: commitar por caminho explicito
  enquanto houver subagente vivo, nunca `-A`.

## Ruling 3 — o None sai do teste da guarda de pd.isna

O implementador descobriu, ao verificar dentes, que `pd.NaT` NAO da dentes a guarda
`pd.isna(vencimento)`: com NaT, tanto `quando.day != DIA_DO_CUPOM` quanto
`(NaT.month - quando.month) % 6 == 0` ja devolvem False sozinhas. Ele achou que
`None` da dentes (levanta TypeError) e perguntou se None e entrada plausivel.

Ruling: o None sai; fica so o NaT. None nao chega la -- o unico chamador e
`pagos()`, que le com parse_dates, e parse_dates produz NaT para celula vazia,
nunca None. Testar entrada impossivel da aparencia de dentes e ensina errado quem
ler depois.

E a guarda FICA, mesmo redundante: a regra escrita do projeto manda guardar com
pd.isna, e nao depender de `nan % 6` ser False e o ponto. O teste passa a se
anunciar SEM DENTES no comentario, que e honesto -- fingir que tem e que seria pior.

Custo se eu estiver errado: se algum chamador futuro passar None, perde-se o retorno
limpo e vem um TypeError. Falha alta, e nao silenciosa.

Task 1: fix round 1/5 (2 addressed, 0 open; commits fdaf16b..b44dbc4)
Task 1: complete (commits ef04f65..b44dbc4, review clean)

## Ruling 4 - os rotulos de indexador sao DADO, e ficam acentuados

O implementador trocou "Indice Precos" por ASCII sem acento para satisfazer a regra
do projeto. Inverteu o sinal: os valores tem de casar com o composicao_dpf.csv, que
os traz acentuados. Com o rotulo sem acento, o filtro da rolagem casa com NADA e o
termo de fluxos da NTN-B vira ZERO EM SILENCIO -- erro de bilhoes sem mensagem.

Ruling: valores acentuados, escritos com escape \uXXXX. A regra ASCII e sobre os
BYTES DO ARQUIVO, e nao sobre o valor da string; escapar e o idioma da casa. Mais um
teste travando que INDEXADOR.values() e subconjunto da coluna do CSV.

Custo se eu estiver errado: nenhum -- fica conferido contra o CSV por teste.

## Ruling 5 - pagos() estourava em cupom de NTN-F (defeito do MEU plano)

A linha `indice = _INDICE_DO_VNA[r["indexador"]]` busca antes de checar se o papel e
indexado, e cupom de NTN-F e Prefixado: KeyError. Nao apareceu nos testes porque os
cupons de NTN-F caem em 01/01 e 01/07, e a janela de teste comecava em 01/07 -- que
a janela (de, ate] exclui.

Ruling: buscar com .get() e usar face 1.000 quando nao houver indice. Com teste
cobrindo uma janela que contenha 01/07.

Custo se eu estiver errado: nenhum -- prefixado nao tem VNA por definicao.

## Ruling 6 - a janela do teste comeca em 30/06, e nao em 01/07

Os limites do brief estavam certos e a janela errada: (de, ate] com de=01/07 exclui
os vencimentos do proprio 01/07, R$ 215,8 bi. 520,6 + 215,8 = 736,4, que e o numero
que eu tinha medido. O uso real parte da data-base do RMD.

Custo se eu estiver errado: o teste mediria uma janela que ninguem usa.

Task 2: fix round 1/5 despachado (3 Critical: rotulos, KeyError, janela do teste)
Task 2: minor (deferred): LookupError de _estoque_mais_recente e _vna sem teste

Task 2: fix round 1/5 (3 addressed, 0 open; commits 8c66f1c..ac94873)
Task 2: complete (commits b44dbc4..ac94873, review clean)
Task 2: obs (deferred): a 3.4 avalia fluxo a valor presente e o cupom calculado e a
  FACE. Ate 31/12 o calculado da 100,2 bi contra 97,1 implicitos na 3.4 (+3,2%),
  e o sinal bate com o desconto de ~5 meses. Face e o certo para a rolagem (o que
  sai do estoque e o que se paga), mas o teste contra a 3.4 compara bases
  diferentes. Tolerancia de 5% cobre hoje; se apertar, e aqui.

## Ruling 7 - o teste da virada de ano entra, mesmo sendo acrescimo de escopo

O revisor mediu que o estimador acerta a virada 2025/2026 por COINCIDENCIA de duas
regras se sobrepondo: 01/01/2026 e quinta e feriado, a antecipacao empurra para
31/12/2025, e quem descarta esse fantasma e o corte de dezembro -- nao a regra da
antecipacao. Nao ha leilao entre 18/12/2025 e 06/01/2026 no dado.

Ruling: entra teste travando isso, ainda que o brief nao peca. Duas regras que se
cobrem por acaso quebram em silencio quando uma delas muda, e esta ja esta na mao do
implementador, no mesmo arquivo.

Custo se eu estiver errado: um teste a mais numa area que o brief nao pedia.

Task 3: fix round 1/5 despachado (1 Important: caminho `dia < de` sem teste nem
  comentario; + o teste da virada de ano por ruling 7)
Task 3: minor (deferred): o corte de dezembro e por dia do mes (21) e nao por semana
  -- e o topo da faixa medida, e conservador

Task 3: fix round 1/5 (2 addressed, 0 open; commits dc193c6..4818763)
Task 3: complete (commits ac94873..4818763, review clean)

## Ruling 8 - os testes da Task 4 passam 'hoje' explicito

Defeito do meu plano, achado ao conferir a amostra congelada antes de despachar. Os
dois testes chamavam dias_ate() sem 'hoje', e o default e pd.Timestamp.today(). A
amostra vai de 20/08 a 29/09/2026: a partir de 30/09 'publicados' fica vazio, a
fronteira vira None e os testes reprovam sozinhos, sem ninguem ter tocado em nada.

Ruling: hoje=pd.Timestamp("2026-08-24") explicito nos dois, como o test_agenda.py ja
faz com a constante HOJE dele.

Custo se eu estiver errado: nenhum -- data fixa em teste e a pratica que o projeto
ja adotou.

## Ruling 9 - a assercao enganosa do meu brief entra na rodada, mesmo sendo Minor

`publicados = set(dias[:len(dias)])` e a fatia inteira, nao o subconjunto publicado.
Veio do meu brief. Assercao que nao mede o que o nome promete e divida que PARECE
cobertura, e o implementador ja esta no arquivo.

Custo se eu estiver errado: uma linha de teste mexida fora do escopo da rodada.

Task 4: fix round 1/5 despachado (1 Critical: precedencia nao travada por teste --
  o revisor construiu o mutante e ele passa nos 9; 1 Important: duas assercoes
  medem propriedade do set e nao do algoritmo; + ruling 9)
Task 4: minor (deferred): o filtro `if d not in set(publicados)` e redundante com a
  uniao que vem depois

Task 4: fix round 1/5 (3 addressed, 0 open; commits 8503449..1bd8d5f)
Task 4: complete (commits 4818763..1bd8d5f, review clean)

NOTA sobre uma crenca errada que tres subagentes ja repetiram: a suite completa nao
e lenta por causa de rede. Ela leva 8 a 10 minutos porque RENDERIZA centenas de
SVGs. A dependencia de rede que existia -- a fixture da pagina do calendario -- foi
corrigida em 21/08/2026 e ha teste provando que a suite roda com api_leiloes.buscar
levantando excecao. Os dispatches seguintes vao dizer isso.

## Ruling 10 - o teste fraco do meu brief entra na rodada da Task 5

`test_a_NTN_B_de_referencia_nao_e_a_mais_proxima` so verifica `> 2026-12-31`. O
revisor mutou iloc[0] -> iloc[-1] (escolhendo a NTN-B de 2060) e o teste PASSOU.
Quem pegou foi o teste de valor que o implementador acrescentou, por acidente.

Ruling: travar direto -- a escolhida em 30/06/2026 tem de ser a de 15/05/2027.

Custo se eu estiver errado: um teste mais especifico do que o brief pedia.

Task 5: fix round 1/5 despachado (1 Important: _checar_ordem cobre selic_implicita e
  deixa inflacao_implicita e ntnb_de_referencia sem guarda -- breakeven plausivel e
  errado de 2,5%; + ruling 10)
Task 5: nota — o implementador achou sozinho que du() e simetrico e a guarda de
  ordem era necessaria. Escopo extra julgado legitimo pelo revisor.

Task 5: fix round 1/5 (2 addressed, 0 open; commits 6f43216..e892a1c)
Task 5: complete (commits 1bd8d5f..e892a1c, review clean)
SUITE COMPLETA em 6f43216: 726 passed, 1 skipped, 9m32s. Eram 696 no inicio da
  branch -- os cinco modulos novos nao quebraram nada.

## Ruling 11 - sem cache no vna_em por enquanto

O implementador mediu: vna_em le o leiloes.csv inteiro a cada chamada, ~57ms. A
Task 7 chama duas vezes por indexador por janela; no backtest de 12 meses sao ~48
chamadas, ~2,7s. Aceitavel.

Ruling: nao otimizar agora. Reabrir se algum teste passar de 60s.

Custo se eu estiver errado: o backtest da Task 7 fica lento e alguem tem de voltar
aqui. Reversivel, e a medicao ja esta feita.

Task 6: complete (commits e892a1c..7145841, review clean, 0 fix rounds)
Task 6: minor (deferred): a fronteira INFERIOR da janela (quando - 15) nao esta
  travada -- mutar >= para > nao quebra teste nenhum. A superior esta.
Task 6: minor (deferred): o relatorio diz 6 leiloes de NTN-B na janela, o revisor
  mediu 7. Nao muda conclusao -- sobra fonte nos dois casos.

## Ruling 12 - o limite ">1000" do meu brief veio da contagem sem filtro

test_a_rolagem_casa_por_LIQUIDACAO afirma `len(vira) > 1000`. Medi 1.196 ao escrever
o brief, contando TODOS os tipos de leilao; o teste filtra tipo_leilao == "Venda", e
ai sao 996. Erro meu, e o implementador fez certo em nao afrouxar por conta propria.

Ruling: `> 900`, com comentario dizendo que 996 e a contagem medida, que e
pre-condicao de dado e nao propriedade do codigo, e que filtra so Venda.

Custo se eu estiver errado: nenhum -- e pre-condicao, nao medida.

## Ruling 13 - aceito os dois defeitos que o implementador achou e corrigiu

(a) DEPENDENCIA DE RELOGIO em fluxos._estoque_mais_recente(), defeito do MEU plano:
ele lia sempre o retrato mais recente do estoque_titulos_vencimento.csv, entao no
backtest historico todo papel que ja venceu desde entao ficava invisivel -- R$ 114,4
bi de LTN de julho/2025 sumindo em silencio. Trocado por _estoque_em(de), com o
retrato valido no INICIO da janela. Assinatura publica de pagos() intacta, e os 10
testes da Task 2 continuam passando (conferido por mim).

Ele mexeu em arquivo de outra tarefa. Nesse caso foi certo: o defeito estava la e so
aparecia daqui.

(b) VNA ancorado no leilao mais proximo dentro da cobertura do vna.csv. vna_em
existe para ir ALEM da cobertura; dentro dela o valor exato e melhor.

Custo se eu estiver errado: (a) e reversivel e tem teste; (b) idem.

Task 7: fix round 1/5 despachado (1 pre-condicao errada no meu brief; dois defeitos
  ja corrigidos pelo implementador e aceitos por ruling 13)
Task 7: nota — o implementador truncou tests/test_rolagem.py a 0 bytes ao escrever
  escape, e recuperou com git checkout. E o modo de falha que ja tem memoria propria
  neste projeto. Ele adotou escrever-em-temporario-e-substituir.

Task 7: fix round 1/5 (1 addressed, 0 open; commits bfa0e93..a5fa591)
Task 7: complete (commits 7145841..a5fa591, review clean)
Task 7: minor (deferred): 2 minors herdados do brief, nao bloqueantes -- o revisor
  reproduziu o numero-ancora (20,15/23,22/52,81) de forma independente e bateu.

## Ruling 14 - a curva usa a data mais recente <= data_base, e diz qual usou

DOIS DEFEITOS MEUS, achados ao varrer o brief da Task 8 antes de despachar. O
segundo e o mais grave desta execucao ate agora.

(a) composicao_dpf.csv usa o ultimo dia CORRIDO do mes; dv_por_papel.csv usa o
ultimo dia UTIL. Em 30/06/2024 -- domingo -- eles divergem, e o backtest levantaria
LookupError num ano que existe nos dois arquivos.

(b) O CAMINHO REAL DA ENTREGA NUNCA FOI EXERCITADO. projecao() com hoje=None parte
da ultima LIQUIDACAO (17/08/2026), e o dv_por_papel termina em 30/06/2026. A chamada
curva.selic_implicita(data_base=17/08) levantava LookupError. Nenhum teste do plano
passava por ali -- os testes de curva usam data_base=None, e o backtest usa datas de
RMD.

Ruling: _curva passa a usar a data mais recente <= data_base. E ganha
data_da_curva(), porque a projecao precisa dizer DE QUANDO e a premissa -- a curva
termina no RMD e a projecao parte da liquidacao, sao semanas de diferenca, e
apresentar premissa de sete semanas atras como "de hoje" e o que esta pagina existe
para nao fazer.

Custo se eu estiver errado: a projecao usa curva de ate sete semanas atras. Nao ha
alternativa -- o dado termina onde termina -- e agora isso vai escrito na pagina.

## Ruling 16 - o estoque projetado sai como NUMERO (decisao dela)

E uma correcao a spec, secao 5.5, que eu escrevi errado. Justifiquei a faixa dizendo
que a premissa de Selic valia quase a largura da banda -- comparando com CONGELAR a
Selic em zero, que ninguem faria. Medido contra cenario plausivel: a premissa move o
estoque em 8 bi contra uma banda de 600, 1,4%. Ruido.

O que domina e o PACE, que erra +/- 153 bi (26% da banda). Uma faixa construida sobre
a Selic teria 8 bi de largura e passaria a impressao de que o numero e vinte vezes
mais firme do que e. Pior que nao ter faixa.

Ela decidiu: numero. A incerteza vai como texto ao lado.

Custo se eu estiver errado: a pagina afirma 9.514 sem mostrar a largura. Mitigado por
escrever o erro historico do pace no rodape.

## Ruling 17 - prazo medio e vincendo ficam sem estimativa, por enquanto

Decisao dela: "nao precisa estimar, por enquanto". Rola-los exige recalcular o prazo
papel a papel, que e trabalho da entrega 5.

Ruling: eles CONTINUAM na tabela, com o valor do RMD e a DATA na propria linha --
"3,57 anos (30/06)" e nao "3,57 *". Sao indicadores do PAF e tirar da tabela de
conformidade seria estranho; o asterisco sozinho e fraco demais para dois numeros que
andam ~25% da largura da banda em sete semanas.

Custo se eu estiver errado: duas linhas datadas numa tabela chamada "hoje". A data na
linha e o que impede a leitura errada.

## ================== PAUSA, a pedido dela ==================

Estado em 24/08/2026, no momento da pausa.

FEITO E REVISADO: Tasks 1 a 7. Branch banda-do-paf, ultimo commit de codigo a5fa591.
  Suite completa: 726 passed, 1 skipped (rodada em 6f43216).

EM VOO: Task 8 (a projecao) foi despachada e esta rodando. Ela ja recebeu o aviso do
  ruling 16 -- a faixa do estoque sai, o estoque vira numero. Deixei terminar em vez
  de matar: o trabalho ja esta pago, e interromper no meio de um commit deixa a
  arvore num estado pior do que deixa-la terminar.

RETOMAR EM: revisar a Task 8. O BASE para o review-package e e14bc45.
  Comando: scripts/review-package <plano> e14bc45 HEAD

DEPOIS DA 8, nesta ordem:
  - Task 9 (graficos/banda.py: a distancia e as duas tabelas). Destravada -- as duas
    decisoes que faltavam sao os rulings 16 e 17.
    ANTES DE DESPACHAR: por no brief que prazo medio e vincendo aparecem com a DATA
    na linha ("3,57 anos (30/06)"), e nao com asterisco; e que o estoque e numero.
  - Task 10 (graficos/painel_paf.py: a pagina paf.html, mais PAGINAS e pipeline).
  - Revisao da branch inteira, no modelo mais capaz.
  - superpowers:finishing-a-development-branch. O merge para master e decisao DELA.

VARREDURA ANTES DE CADA DESPACHO -- o que de fato pegou defeito nesta execucao, e
nao foi nome nem assinatura:
  valor  |  ordem de execucao  |  fronteira de intervalo  |  dependencia de relogio
  assercao tautologica  |  caminho nunca exercitado por teste

## RETOMADA. E um achado que muda a resposta da entrega.

O pace por papel (ruling 15, proposta dela) nao melhorou a precisao: MUDOU A
RESPOSTA. Medido pelo codigo:

  estoque em 17/08     9.090,0
  + emissao projetada   +635,7   <- com o pace ANTIGO eram 309,7
  - fluxos a pagar      -289,9
  + juros apropriados   +404,3
  = projetado            9.840,1     banda: 9.700 a 10.300  -> DENTRO

Eu tinha dito a ela "fecha fora, por baixo, por 186 bi". Errado. O metodo antigo
diluia cada papel nos dias em que ele NAO vai a leilao, e subestimava a emissao pela
metade. Eu tinha medido a diferenca entre os dois metodos em 2,7% -- aquela
comparacao estava mal feita, porque comparava em bases diferentes.

Numa pagina cujo proposito e dizer se o Tesouro cumpre o que prometeu, isso e a
diferenca entre acertar e errar feio.

Task 8: agente morreu por erro de API ao escrever o relatorio; o codigo chegou
  inteiro (63c12f5, 7529f2d) e os 22 testes passam. Relatorio pedido e escrito.

Task 8: fix round 1/5 despachado. DOIS CRITICALS, e os dois sao testes MEUS que nao
  testam o que o nome promete. O revisor mutou e mediu:

  (1) test_a_projecao_devolve_a_PREMISSA_que_usou nao afirma nada sobre estoque nem
      percentual. Mutar leiloes_que_faltam para return len(dias) DOBRA a emissao
      (635,7 -> 1.271 bi), empurra o total alem do teto de 10.300 e INVERTE o
      veredito da banda. O teste continua verde.

  (2) test_o_pace_e_por_PAPEL_e_nao_por_dia_de_leilao so confere razoes de ordem de
      grandeza. Reverter o pace ao metodo antigo passa nos OITO testes. A decisao
      que mudou a resposta da entrega nao esta travada por nada.

  Important: o ramo hoje is not None de projecao() nao tem teste e levanta KeyError
  cru.

  A correcao pedida e por COMPORTAMENTO e nao por valor cravado: o teste recalcula a
  emissao de forma independente, e calcula o pace dos dois jeitos afirmando que o
  sem-zeros e estritamente maior. Assim sobrevive ao pipeline rodar de novo.

Task 8: minor (deferred): LEILOES_DO_PACE == 10 e pino de valor, nao teste de
  comportamento.

Task 8: fix round 1/5 (2 de 3 addressed; commits 7529f2d..76f691a). O implementador
  foi honesto: a recomputacao independente que eu sugeri NAO pega a mutacao de
  leiloes_que_faltam, porque os dois lados da comparacao chamam a mesma funcao
  mutada e se movem juntos. Critical 1 fica aberto.
Task 8: fix round 2/5 despachado. A saida e comparar contra o que o METODO ERRADO
  daria: emissao projetada < pace x len(dias) x 0,7. Essa comparacao nao chama
  leiloes_que_faltam, entao a mutacao move so um lado.

Task 8: fix round 2/5 (3 addressed, 0 open; commits 7529f2d..f13ca7c)
Task 8: complete (commits e14bc45..f13ca7c, review clean)
Task 8: a divergencia 614 vs 635,7 que o revisor sinalizou nao e defeito -- os 614
  vieram de um script de rascunho MEU que contava os leiloes futuros por frequencia
  historica (18/18/17); o codigo conta pela regra do dia da semana (18/18/18).

Task 9: implementada (441e2e7). O implementador achou TRES defeitos no meu brief e
  corrigiu: asterisco em vez da data (contradizia o proprio brief), tabela() sem
  rodape (o teste do brief exigia texto que a amostra nao produzia), e o denominador
  dos percentuais somando "Demais" enquanto rolagem.estoque_em nao soma. O revisor
  julgou as tres certas e necessarias.

Task 9: fix round 1/5 despachado. DOIS IMPORTANTS:
  (1) `"20" in html` casa com "2026" -- o teste que dizia travar quantos leiloes
      entraram passa mesmo com a funcao devolvendo 999999. NONO teste sem dentes
      desta execucao, e meu, do brief.
  (2) a correcao do denominador nao esta travada: mutar de volta deixa os 8 verdes.
      E nao da para travar por VALOR -- "Demais" esta zerada desde jun/2006, entao
      os dois denominadores dao o mesmo numero hoje. Pedi guarda estrutural no
      codigo, conferindo o conjunto de colunas contra rolagem.INDEXADORES+PARADOS.

Task 9: minor (deferred): sem teste do formato da celula em R$ bi
Task 9: minor (deferred): _realizado_do_rmd e _ultima_liquidacao releem CSVs

Task 9: fix round 1/5 (2 addressed, 0 open; commits 441e2e7..307c180)
Task 9: complete (commits b4b5537..307c180, review clean)
Task 9: minor (deferred): risco residual apontado pelo revisor -- se um refactor
  REMOVER a chamada de _confere_colunas_do_denominador, os 7 testes voltam a passar
  em silencio com o denominador errado (porque Demais = 0 hoje). E risco generico de
  guarda de ponto unico, nao defeito desta correcao.


## Ruling 18 - com --sem-coleta a pagina do PAF ESTIMA o calendario, e diz que estimou

O que aconteceu: a linha que acrescentei ao pipeline chamava painel_paf.grava() sem
argumento, e por dentro isso vai a API do Tesouro buscar o calendario publicado. O
teste test_sem_coleta_nunca_toca_rede pegou: --sem-coleta promete nao ir a rede, e
foi. Defeito do MEU plano, e nao do implementador.

O padrao do arquivo era outro: painel_agenda.grava fica dentro de um try/except e
SOME quando a rede falha, e no teste ela e stubada. Copiar isso deixaria o teste
verde com o --sem-coleta de verdade ainda batendo na rede.

Ruling: o pipeline passa registros=[] quando opcoes.sem_coleta. dias_ate cai para o
calendario inteiramente estimado, a pagina SAI, e o rodape passa a dizer de onde veio
o calendario -- "publicado ate 29/09/2026 e estimado depois" contra "inteiramente
estimado". A agenda pode sumir sem rede porque ela E o calendario publicado; esta
pagina sobrevive porque a projecao so precisa de QUANTOS dias faltam.

Isso obrigou a mexer em banda.py (Task 9): o rodape nao dizia a origem do
calendario, embora a premissa ja carregasse fronteira_do_calendario. Nao e cosmetica
-- sao 34 dias de leilao pelo calendario publicado e 36 estimando tudo, e o
percentual projetado de cada indexador anda com isso (prefixado 20,80% contra
20,85%). Sem a frase, palpite e transcricao tinham a mesma cara.

Custo se eu estiver errado: em --sem-coleta a projecao usa dois dias de leilao a
mais do que a realidade, e o rodape avisa. O caminho com rede nao muda.

Task 10: complete
  - o subagente travou no meio; peguei o codigo que ele deixou, que estava fiel ao
    plano, e terminei. Os dois defeitos que ele achou antes de travar eram MEUS e
    conferem quando eu meco: (a) o piso de 20 kB era impossivel -- a pagina nao tem
    SVG nenhum e mede 12.519 bytes; (b) os ids saem com aspas SIMPLES, porque quem
    escreve a tabela e banda.tabela e nao a pagina.
  - piso trocado por 11.500, medido: perder a tabela de hoje deixa 11.137, a da
    projecao deixa 10.843, o corpo inteiro deixa 7.914 -- os tres ficam vermelhos.
    Anotado no proprio teste que esse piso ENCOLHE: se as tabelas ganharem linhas,
    perder uma delas pode passar a caber acima de 11.500. Quem guarda de verdade e
    o teste dos dois ids.
  - dois testes novos pelo ruling 18, um de cada lado: o do pipeline confere que
    --sem-coleta PEDE registros=[], e o da pagina confere que pedir isso FUNCIONA
    com o socket bloqueado. Nenhum dos dois cobre o caminho sozinho.
  - test_pipeline_grava_as_dez_etapas... renomeado: o nome dizia dez enquanto a
    lista afirmava onze, e agora afirma doze.
  - defeito de processo meu: escrevi patches por heredoc do shell, que colapsa '\\'
    em '\'. Um escape \uXXXX virou acento de verdade no fonte de teste, contra a
    regra do projeto. Passei a escrever os patches como ARQUIVO. Vale para o resto
    do projeto.


## Revisao da branch inteira (30 commits, 2.249 linhas)

O revisor leu a spec, o plano, os 18 rulings e os catorze arquivos, e rodou 17
mutacoes num worktree descartavel. QUINZE ja ficavam vermelhas. As duas que
passaram eram da MESMA familia, e e uma familia que nao estava na minha lista de
classes de defeito:

  GUARDA ALIMENTADA PELA PROPRIA CONSTANTE QUE DEVERIA VIGIAR.

Entra na lista, ao lado de "assercao tautologica" -- e diferente dela: a
assercao tautologica nao afirma nada; esta afirma, com aparencia de rigor, uma
coisa que nao pode ser falsa.

### Critical 1 -- a guarda do denominador nao podia disparar (defeito do MEU plano)

_confere_colunas_do_denominador recebia list(INDEXADORES) + list(PARADOS) e
comparava contra set(INDEXADORES) | set(PARADOS). Impossivel divergir. O revisor
trocou o denominador de volta para comp.sum(axis=1) -- o retrocesso que a rodada
de fix da Task 9 existiu para impedir -- e os 15 testes passaram.

Meu ledger tinha anotado isto como "minor (deferred): se um refactor REMOVER a
chamada". Nao precisava remover. Eu subestimei o proprio risco que registrei.

Corrigido: a guarda recebe comp.columns e faz as duas perguntas que so o dado
responde (falta alguma? sobrou alguma?), e devolve o denominador, para nao haver
dois lugares dizendo qual e. _percentuais() saiu como funcao propria para poder
ser testada com um 'Demais' DIFERENTE DE ZERO -- no dado real ele e zero desde
06/2006, e por isso nenhum teste de valor distinguia as duas contas.

E um teste que trava o CALL SITE, e nao so a funcao: um composicao_dpf.csv
sintetico com coluna intrusa, com config.PROCESSED_DIR monkeypatchado. Sem ele,
realimentar a constante deixava os 17 testes verdes de novo (medido).

### Critical 2 -- nada travava os numeros que a pagina publica (defeito do MEU plano)

Trocar "prefixado_pct" por "taxa_flutuante_pct" em _valores_de_hoje faria a
pagina publicar Prefixado 52,81% (fora por +2,81 pp) e Taxa Flutuante 20,15%
(fora por -0,85 pp) -- invertendo o veredito dos dois indexadores de maior peso
-- com a suite inteira verde. Nenhum teste comparava o valor de 'hoje' com nada.

Corrigido pela identidade da JANELA NULA: rolar o RMD ate a propria data-base
nao emite, nao resgata e nao apropria nada, entao 'hoje' devolve o RMD. Fecha
em 3e-15.

### Importants aceitos e corrigidos

3. A coluna "banda" era a VIGENTE sem dizer que era, logo acima do paragrafo que
   afirma que a revisao pos o realizado dentro em 14 de 14. Quando houve
   revisao, a celula passa a mostrar as duas.
4. "errou ATE 153 bi" era o erro MEDIO de dez anos, nao o teto. Metade dos anos
   foi pior. Numa pagina cuja unica quantificacao de incerteza do estoque e essa
   frase, "ate" subestima.
5. O rodape de hoje ganhou as tres frases da spec 4.5/4.6 que faltavam.
6. Ano sem banda no arquivo levantava tabela VAZIA com rodape normal por cima.
   Agora levanta LookupError.
9. O ramo do calendario PUBLICADO -- o que a producao usa -- era o unico sem
   teste, porque todo teste passa registros=[]. Coberto com a amostra congelada.
10. 70% / 79% / 14-de-14 eram prosa fixa sem nada conferindo.

### Ruling 19 - a reconta do achado usa o dado MEDIDO, e nao a coluna 'realizado'

Ao escrever o teste do item 10 eu recontei pela coluna 'realizado' do
referencia/paf_bandas.csv e cheguei a 69% / 78% / 13. O revisor, recontando por
conta propria, chegou a 70% / 79% / 14. A pagina publica 70 / 79 / 14. TRES
contas, DOIS resultados -- exatamente o cheiro de "plausivel e errado".

Medido: a coluna 'realizado' do CSV nao tem UMA LINHA de vincendo_12m_pct, e tem
23 de prazo_medio onde a conta da spec usa 21. Ela nao e a fonte. A fonte e o
dado medido em data/processed/, o mesmo que _realizado_do_rmd() ja le, so que no
fechamento de cada dezembro. Reconstruido assim, bate com a tabela da spec 3.2
LINHA POR LINHA: 102 de 146 e 116 de 146, 14 inversoes, 14 para dentro.

Ruling: o teste reconta do dado medido, e o docstring dele diz por que a coluna
digitada nao serve -- para o proximo que tentar recontar nao repetir o erro que
eu cometi.

Custo se eu estiver errado: nenhum -- o numero que a pagina ja publicava estava
certo, e agora tem quem o confira.

### Achado meu, fora da revisao: a linha do Estoque na tabela de HOJE

A banda de estoque e alvo de 31/12 e o estoque cresce ao longo do ano por
construcao. Medido nos 23 anos de PAF: o estoque de AGOSTO caiu fora da banda de
dezembro em 18 deles, e 14 desses 18 fecharam o ano DENTRO. Publicar
"R$ -610 bi" como distancia convida a ler descumprimento onde so ha calendario.
A celula passa a dizer "alvo de 31/12"; na projecao a distancia fica, porque la
os dois lados sao 31/12.

(A primeira medicao que fiz disto deu "23 de 23 fora, 0 dentro" -- eu tinha
somado um CSV de formato longo pegando uma linha so, e comparado trilhoes com
bilhoes. Numero redondo demais e sinal de conta errada.)

### Item 7 -- ACEITO, MEDIDO, e deixado ABERTO de proposito

vna_em ancora no ultimo leilao ate 'quando' e ninguem carrega dali ate a data.
Em 17/08 a ancora e 11/08: quatro dias uteis sem apropriar.

    SELIC  0,221% sobre R$ 4.800,7 bi  ->  R$ 10,6 bi a menos
    IPCA   0,073% sobre R$ 2.111,0 bi  ->  R$  1,5 bi a menos
                                           R$ 12,1 bi, SEMPRE para baixo

Nos percentuais da ate 0,05 pp, e nao inverte nenhum veredito com o dado de
hoje. Documentado no docstring de _vna_para_apropriacao com esses numeros.

NAO CORRIGIDO porque corrigir exige escolher COM QUE SERIE carregar da ancora
ate a data -- a Selic diaria efetiva, e nao a implicita da curva, que e premissa
e nao medida. Essa escolha e dela, e ela esta fora. Inventar a serie enquanto
ela dorme trocaria um vies medido e escrito por um vies escondido.

### Item 8 -- ABERTO: dois denominadores para a mesma grandeza

banda._realizado_do_rmd soma 4 colunas; graficos/estoque.dados_composicao soma
TODAS, e e ela que desenha a composicao com a banda do PAF no dashboard. Hoje
concordam porque 'Demais' e zero. No dia em que nao for, dashboard.html e
paf.html mostram percentuais diferentes para o mesmo mes, e nada acusa.

### Minors que ficaram abertos

- backtest de 12 meses onde a spec pede 24 (test_rolagem.py, datas[-13:])
- calendario validado so em 2024-2025, onde a spec pede 2021 em diante
- 'nao_entrou' calculado e nunca asserido (test_rolagem.py:81)
- str(esperado) in html ainda e contencao de substring
- _ACHADO so no bloco da projecao; a spec pede nos dois
- painel_paf.grava(hoje=...) move so a tabela de hoje
- dados_hoje devolve colunas que nao chegam a tela
- _celula(nan) renderiza "nan pp"
- fluxos._vna CONGELA em silencio onde rolagem.vna_em LEVANTA
- cupom de NTN-C usa VNA de IPCA, e a NTN-C e IGP-M

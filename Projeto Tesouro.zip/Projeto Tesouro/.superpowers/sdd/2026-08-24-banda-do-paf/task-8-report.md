# Task 8: rolagem.py -- a projecao ate o fim do ano, e o conserto bloqueante em curva.py

## Status

DONE. Dois commits, ambos com arvore limpa depois. 22 testes passam em
`tests/test_rolagem.py` + `tests/test_curva.py`.

## Commits

- `63c12f5` -- "A curva aceita data-base que nao existe no arquivo (Passo 0,
  Task 8)" (2 files changed, 72 insertions: `src/tesouro/curva.py`,
  `tests/test_curva.py`)
- `7529f2d` -- "A projecao ate o fim do ano, com a premissa ao lado"
  (2 files changed, 195 insertions: `src/tesouro/rolagem.py`,
  `tests/test_rolagem.py`)

## O que cada commit implementou

### `63c12f5` -- Passo 0, o conserto bloqueante em `curva.py`

`_curva(titulo, data_base=None)` casava a data-base por igualdade exata
(`d["data"] == base`). Isso quebrava em dois caminhos: no backtest, porque
`composicao_dpf.csv` usa o ultimo dia CORRIDO do mes e `dv_por_papel.csv`
usa o ultimo dia UTIL (divergem quando o fim do mes cai num domingo, como
30/06/2024); e no caminho principal da entrega, porque a projecao parte da
ultima LIQUIDACAO (17/08/2026 hoje), que fica alem do ultimo RMD onde a
curva termina (30/06/2026) -- levantava `LookupError` e nenhum teste
exercitava esse caminho.

Troquei a igualdade por "a data mais recente <= a pedida". Fatorei essa
escolha de data para uma funcao nova, `_data_base(d, data_base)`, em vez de
deixar a logica dentro de `_curva`. Isso NAO estava no brief como funcao
separada -- o brief so mostrava o codigo de `_curva` com a comparacao `<=`
inline. Fiz a extracao porque a tarefa tambem pedia `data_da_curva(data_base=
None)`, e se essa funcao delegasse para `_curva("LTN", data_base)` (a forma
mais obvia de reaproveitar o codigo), ela herdaria o segundo `LookupError` de
`_curva` -- o que dispara quando o TITULO pedido nao tem cotacao na data-base
escolhida, nao quando nao ha curva nenhuma. Se por acaso a LTN nao tivesse
cotacao justamente na data mais recente disponivel mas outro titulo tivesse,
`data_da_curva` levantaria por um motivo errado. `_data_base` isola so a
escolha de data (comum aos dois usos) e devolve o mesmo valor que `_curva`
usaria, sem tocar em titulo nenhum.

`data_da_curva` foi acrescentada com esse `_data_base` direto, lendo o
`dv_por_papel.csv` de novo (mesma leitura que `_curva` faz) e devolvendo a
data. Nao reaproveitei a leitura entre as duas funcoes.

### `7529f2d` -- a projecao

Copiei do brief, quase verbatim: `LEILOES_DO_PACE = 10`, `DIA_DO_PAPEL`,
`pace(quando)`, `leiloes_que_faltam(dias, indexador)`, `projecao(ate,
hoje=None, registros=None)`. A unica mudanca de logica em relacao ao texto
do brief foi remover a faixa do estoque -- ver secao propria abaixo. Os
demais textos de docstring/comentario eu adaptei para nao repetir a
justificativa da faixa que foi invalidada.

## Comandos rodados e saida

Depois do Passo 0 (curva.py), antes de tocar rolagem.py:

    PYTHONPATH=src python -m pytest tests/test_curva.py -q
    ..............
    14 passed in 1.92s

Antes de implementar `pace`/`projecao` (ver falhar):

    PYTHONPATH=src python -m pytest tests/test_rolagem.py -q -k "pace or projecao"
    FF
    AttributeError: module 'tesouro.rolagem' has no attribute 'LEILOES_DO_PACE'
    AttributeError: module 'tesouro.rolagem' has no attribute 'projecao'
    2 failed, 6 deselected in 1.13s

Depois de implementar (ver passar):

    PYTHONPATH=src python -m pytest tests/test_rolagem.py -q
    ........
    8 passed in 4.60s

Suite final, os dois arquivos-alvo juntos:

    PYTHONPATH=src python -m pytest tests/test_rolagem.py tests/test_curva.py -q
    ......................
    22 passed in 7.86s

Nenhum teste chegou perto de 60s -- a suite dos dois arquivos inteira roda em
menos de 8s.

## Verificacao de dentes

**`curva.py`, funcao `_data_base` (linha 30 na versao final, dentro do
`if disponiveis.empty:`).** Mutei a comparacao de `d["data"] <= pedida` para
`d["data"] == pedida` (voltando a igualdade exata que o Passo 0 existe para
corrigir). Rodei so o teste do Passo 0:

    PYTHONPATH=src python -m pytest tests/test_curva.py -q -k "aceita_data_base"
    FAILED tests/test_curva.py::test_a_curva_aceita_data_base_que_nao_existe_no_arquivo
    LookupError: nao ha curva ate 30/06/2024 no dv_por_papel.csv. Sem curva nao
    ha premissa, e projetar com premissa inventada seria pior.
    src\tesouro\curva.py:33: LookupError -- 1 failed, 13 deselected in 1.13s

Desfiz a mutacao (voltei para `<=`) e confirmei os 14 testes de
`test_curva.py` passando de novo antes de commitar.

**`rolagem.py`, `LEILOES_DO_PACE` (linha 202).** Troquei `10` por `1` com
`sed` e rodei a suite inteira de `test_rolagem.py`:

    PYTHONPATH=src python -m pytest tests/test_rolagem.py -q
    .....F..
    FAILED tests/test_rolagem.py::test_o_pace_e_por_PAPEL_e_nao_por_dia_de_leilao
    AssertionError: assert 1 == 10
     +  where 1 = rolagem.LEILOES_DO_PACE
    tests\test_rolagem.py:106: AssertionError
    1 failed, 7 passed in 4.60s

Essa reprovacao e a assercao direta `assert rolagem.LEILOES_DO_PACE == 10`
(linha 106 de `tests/test_rolagem.py`) -- um pino no valor da constante, nao
uma reprovacao indireta via degradacao de precisao da projecao. Nao rodei
um backtest separado de `pace`/`projecao` com janela de 1 leilao para medir
se a precisao cai (nao ha um teste desse tipo no arquivo para `pace`/
`projecao` -- so o de `estoque_em`, que nao usa `pace`). Desfiz a mutacao
(`sed` de volta para `10`) e confirmei os 8 testes de `test_rolagem.py`
passando antes de commitar.

## Numeros medidos, contra os que a coordenadora passou

| Numero | Passado | Medido | Bate? |
|---|---|---|---|
| Estoque rolado ate 17/08/2026 (total) | 9.090,0 bi | 9.089,99 bi | sim |
| -- Prefixado | 1.831,9 | 1.831,87 | sim |
| -- Indice de Precos | 2.111,0 | 2.111,01 | sim |
| -- Taxa Flutuante | 4.800,7 | 4.800,74 | sim |
| -- Cambio | 346,4 | 346,36 | sim |
| Juros apropriados ate 31/12 (total) | 404,3 bi | 404,35 bi | sim |
| -- Prefixado | 87,6 | 87,64 | sim |
| -- Indice de Precos | 82,7 | 82,72 | sim |
| -- Taxa Flutuante | 234,0 | 233,98 | sim |
| Fluxos a pagar ate 31/12 (total) | 289,9 bi | 289,95 bi | sim |
| -- Principal | 263,5 | 263,53 | sim |
| -- Cupom | 26,4 | 26,42 | sim |
| Pace: Prefixado | 12,32 bi/leilao | 12,32 bi/leilao | sim |
| Pace: Indice de Precos | 1,09 bi/leilao | 1,085 bi/leilao | sim (arredonda p/ 1,09) |
| Pace: Taxa Flutuante | 21,91 bi/leilao | 21,91 bi/leilao | sim |
| Selic implicita (30/06) | 13,76% | 13,76% | sim |
| Inflacao implicita (30/06) | 4,70% | 4,696% | sim |
| **Emissao liquida projetada (18 leiloes x pace, cada indexador)** | **~614 bi** | **635,70 bi** | **NAO** |

A unica discordancia e a emissao liquida projetada: a coordenadora passou
"~614 bi", eu medi 635,70 bi -- uma diferenca de ~21,7 bi (3,5%), maior do
que o arredondamento explica nos outros numeros (que batem na segunda casa
decimal). Os tres indexadores tem 18 leiloes futuros contados cada
(`leiloes_que_faltam`, dentro da faixa 15-20 que o teste exige):

    Prefixado:        18 leiloes x 12,323 bi/leilao = 221,81 bi
    Indice de Precos:  18 leiloes x  1,085 bi/leilao =  19,53 bi
    Taxa Flutuante:    18 leiloes x 21,908 bi/leilao = 394,35 bi
                                              total = 635,70 bi

Nao ajustei o codigo para bater com o "~614 bi" -- reporto os dois lado a
lado, como instruido. Nao investiguei a origem da diferenca (por exemplo, se
"~614 bi" veio de uma contagem de leiloes diferente, ou de um pace medido em
outra data) porque a instrucao foi medir e relatar, nao reconciliar.

O total do estoque projetado em 31/12/2026 que essa medicao produz e
9.840,08 bi (9.089,99 inicial + 635,70 emissao - 289,95 pago + 404,35
juros). Esse total nao foi um dos numeros passados para conferencia.

## O que o brief nao previa

- **A funcao `_data_base` extra em `curva.py`**, descrita acima -- o brief
  so mostrava `_curva` com a comparacao inline; a extracao foi necessaria
  para `data_da_curva` nao herdar o `LookupError` por titulo.

- **Um incidente de codificacao ao escrever `rolagem.py`.** As duas linhas
  que eu digitei com acento literal (`DIA_DO_PAPEL = {"Prefixado": 3,
  "Indice Precos": 1, ...}` e `elif ind == "Indice Precos":`, com o acento
  de fato) foram gravadas como caracteres UTF-8 reais (Í = `\xc3\x8d`, ç =
  `\xc3\xa7`), nao como o escape `\uXXXX` que o resto do arquivo usa e que a
  regra do projeto exige (.py inteiramente ASCII). Detectei rodando um
  script que decodifica o arquivo e lista qualquer `ord(c) > 127`; achei os
  dois pontos exatos por offset e troquei para `Í`/`ç` com um
  script Python que usa string RAW (`r"..."`) para gravar o escape literal
  (seis caracteres: barra invertida, u, 0, 0, c, d) em vez do caractere --
  minha primeira tentativa de correcao usou uma string normal do Python, que
  interpretou `Í` como o proprio acento outra vez, e nao mudou nada
  (confirmei re-lendo o arquivo antes de seguir). Depois da segunda
  tentativa, `data.decode('utf-8')` mostrou zero caracteres com `ord > 127`
  nos dois arquivos.

- **Quebra de linha do arquivo mudou de CRLF para LF** nesse mesmo processo
  de escrita (o resto do repositorio usa CRLF). `git diff --stat` e
  `git diff` (com `core.autocrlf=true`) nao mostraram ruido de linha por
  causa disso -- so as insercoes esperadas -- entao nao tratei como
  problema, mas registro caso o revisor veja um aviso do git sobre LF sendo
  trocado por CRLF.

- **Commits concorrentes na mesma branch durante a sessao.** Entre o inicio
  da minha sessao (branch limpa, topo em `6916ea3`) e o momento em que
  commitei, tres commits apareceram no historico que eu nao fiz --
  `48b872e`, `e14bc45`, `e22f625` -- todos de autoria dela, tocando so
  `docs/superpowers/plans/2026-08-24-banda-do-paf.md` e
  `docs/superpowers/specs/2026-08-24-banda-do-paf-design.md`. Conferi com
  `git show --stat` em cada um: nenhum tocou `src/tesouro/*.py` nem
  `tests/*.py`, entao nao havia risco de eu sobrescrever codigo dela ao
  commitar meus arquivos -- mas registro porque a arvore historica nao era
  a que eu tinha visto no inicio da sessao, e vale conferir se o revisor
  espera essa mesma ordem de commits.

## A remocao da faixa do estoque, e por que

O brief (Passo 3) trazia `estoque_faixa`, `selic_do_piso` e `CENARIO_SELIC`
-- um cenario alternativo de Selic 2pp mais baixa, usado para dar um piso a
uma faixa do estoque projetado, com teste correspondente
(`test_o_ESTOQUE_sai_como_FAIXA_e_os_outros_como_numero`). Recebi instrucao
para nao implementar essa parte: a faixa tinha sido justificada comparando
com CONGELAR a Selic em zero -- cenario que ninguem tomaria como alternativa
plausivel. Contra um cenario realista (a Selic realizada se afastando da
implicita), a premissa de Selic move o estoque em ~8 bi contra uma banda de
~600 -- ruido (1,4%). Quem de fato domina o erro da projecao e o pace: erro
medio de ~150 bi em dez anos de backtest, e uma faixa construida em cima da
Selic sugeriria uma precisao (~20x mais fina) que a projecao nao tem.

Removi de `rolagem.py`: `CENARIO_SELIC`, o segundo laco de `projecao` que
calculava `piso`, e as chaves `estoque_faixa`/`selic_do_piso` do dicionario
devolvido. Removi de `tests/test_rolagem.py`: o teste
`test_o_ESTOQUE_sai_como_FAIXA_e_os_outros_como_numero` inteiro (nunca
chegou a ser commitado -- foi removido antes do primeiro commit desta
tarefa, entao nao aparece no diff como remocao). `projecao()` devolve
`estoque` como `pd.Series` (numero), sem faixa. Confirmei com
`grep -n "CENARIO_SELIC\|estoque_faixa\|selic_do_piso\|piso"` em
`rolagem.py` e `test_rolagem.py` que nao sobrou nenhum resquicio.

Nao tenho em memoria o texto exato da mensagem que trouxe essa instrucao --
a justificativa acima (8 bi contra banda de 600, pace domina com ~150 bi de
erro) e a que registrei no comentario do codigo e na mensagem do commit
`7529f2d`, e bate com o raciocinio do commit `e22f625` dela ("Corrige a spec
5.5: a faixa do estoque vinha de um raciocinio errado"), que toquei so para
ler via `git show`, nao para editar.

## Preocupacoes

- A discordancia da emissao liquida projetada (~614 bi passado vs 635,70 bi
  medido) fica sem explicacao -- nao investiguei a fundo por instrucao de
  medir e relatar, nao reconciliar.
- O branch de `hoje is not None` em `projecao()` (o caminho do backtest) nao
  e exercitado por nenhum teste desta tarefa -- so o caminho `hoje=None`
  (projecao real) e testado. Pode ser proposital (backtest de `projecao`
  fica para outra tarefa) mas registro como caminho nao coberto.
- A verificacao de dentes de `LEILOES_DO_PACE` reprovou por uma assercao
  direta no valor da constante (pin), nao por uma medida indireta de que a
  janela de 1 leilao degrada a precisao da projecao -- nao ha teste que
  meca isso.

## Rodada de revisao: dois Criticals e um Important

O revisor mutou o codigo e mediu, achou dois testes que nao testavam o que
prometiam, e um ramo sem teste nenhum. Os tres estavam no brief -- copiei
fielmente -- mas o defeito e meu tanto quanto do brief: nao percebi nenhum
dos tres ao implementar nem ao revisar antes de commitar.

### Commit

- `76f691a` -- "Resposta ao revisor: dois Criticals e um Important em
  rolagem.py" (2 files changed, 116 insertions(+), 2 deletions(-):
  `src/tesouro/rolagem.py`, `tests/test_rolagem.py`)

### Critical 1 -- `test_a_projecao_devolve_a_PREMISSA_que_usou` nao defendia
### o numero publicado

O teste afirmava coisas sobre `selic`, `inflacao`, `dias_de_leilao`,
`fronteira_do_calendario` e `data_da_curva` -- nunca sobre `p["estoque"]`
nem `p["percentual"]`. O revisor mediu: mutar `leiloes_que_faltam` para
`return len(dias)` dobra a emissao projetada (635,7 -> ~1.271 bi) e inverte
o veredito da banda, e o teste continuava passando.

Acrescentei ao teste:

1. Uma ancora de sanidade que sobrevive a dado novo:
   `p["percentual"].sum() == pytest.approx(100.0)` e cada indexador em
   `[0, 100]`.
2. Uma recomputacao independente: le `p["de"]`/`p["ate"]` do dict devolvido,
   chama de novo `calendario_leiloes.dias_ate`, `rolagem.pace`,
   `rolagem.estoque_em`, `fluxos.pagos`, `curva.selic_implicita` e
   `curva.inflacao_implicita`, monta `emissao_esperada = ritmo[ind] *
   leiloes_que_faltam(dias, ind)` e confere que bate com
   `emissao_publicada = p["estoque"][ind] - base + pago - juros` (base, pago
   e juros recalculados no teste, nao lidos do dict -- ele nao os expoe).

**Verificacao de dentes, mutacao 1 do revisor** (`leiloes_que_faltam` linha
259-260 de `rolagem.py`, `return sum(1 for d in dias if ...)` trocado por
`return len(dias)`):

    PYTHONPATH=src python -m pytest tests/test_rolagem.py -q
    ......F...
    FAILED tests/test_rolagem.py::test_a_contagem_de_leiloes_futuros_e_por_PAPEL
    AssertionError: ('Prefixado', 36)
    assert 36 <= 20
    1 failed, 9 passed in 18.16s

**Achado que preciso registrar sem maquiar**: essa mutacao NAO derruba o
teste que acrescentei (`test_a_projecao_devolve_a_PREMISSA_que_usou`
continuou passando nessa rodada). A razao e estrutural: minha recomputacao
chama `rolagem.leiloes_que_faltam` de novo -- a mesma funcao mutada que
`projecao()` chama por dentro -- entao os dois lados da comparacao usam o
mesmo valor errado e ficam iguais entre si. Quem de fato pega essa mutacao
e o teste que ja existia, `test_a_contagem_de_leiloes_futuros_e_por_PAPEL`
(a asserção `15 <= quantos <= 20`). O que a minha adicao trava e outra
coisa -- bug de FIACAO dentro de `projecao()` (esquecer o termo de emissao,
somar no indexador errado, inverter sinal, usar `ritmo`/`dias` de uma data
diferente de `partida`) -- e nao um erro dentro de `leiloes_que_faltam` ou
`pace` em si, que ja tem teste direto proprio. Nao reformulei a
recomputacao para evitar chamar as mesmas funcoes (isso exigiria
reimplementar `leiloes_que_faltam` inline no teste, duplicando a logica que
`test_a_contagem_de_leiloes_futuros_e_por_PAPEL` ja existe para testar) --
registrei a limitacao em vez disso.

### Critical 2 -- `test_o_pace_e_por_PAPEL_e_nao_por_dia_de_leilao` nao
### testava o pace

O teste so conferia razoes entre indexadores
(`p["Indice Precos"] * 5 < p["Taxa Flutuante"]`). O revisor mediu: reverter
`pace` para o metodo antigo (contar os dias sem leilao como zero) passa nos
oito testes, porque a NTN-B e pequena demais para as razoes quebrarem.

Acrescentei ao teste um calculo do pace DOS DOIS JEITOS, dentro do proprio
teste: le `leiloes.csv` de novo, monta o mesmo `por_leilao` (pivot por
`data_leilao`), e tira a media dos ultimos `LEILOES_DO_PACE` **dias de
leilao** com `fillna(0.0)` (o metodo antigo, sem o filtro `!= 0`) -- e
confere que essa media `com_zeros` e estritamente menor que `p[ind]`
(rolagem.pace) para cada indexador, e que para o Prefixado ela fica abaixo
de 70% de `p["Prefixado"]` (medido: 53%, "materialmente maior" e nao so
estatisticamente).

**Verificacao de dentes, mutacao 2 do revisor** (`pace`, linhas 242-243 de
`rolagem.py`, `dele = por_leilao[ind].dropna(); dele = dele[dele != 0]...`
trocado por `dele = por_leilao[ind].fillna(0.0); dele = dele.tail(...)`
-- sem o filtro `!= 0`):

    PYTHONPATH=src python -m pytest tests/test_rolagem.py -q
    F.........
    FAILED tests/test_rolagem.py::test_o_pace_e_por_PAPEL_e_nao_por_dia_de_leilao
    AssertionError: Prefixado
    assert np.float64(6566.7691788170005) < np.float64(6566.7691788170005)
    1 failed, 9 passed in 17.59s

Essa reprova exatamente o teste que o revisor apontou, porque agora `pace`
mutada e `com_zeros` calculado no teste ficam identicos (6566,77 == 6566,77)
-- a desigualdade estrita quebra. Dente confirmado.

### Important -- o ramo do backtest sem teste e sem erro diagnosavel

`projecao(ate, hoje=..., registros=...)` com `hoje is not None` nunca era
exercitado por nenhum teste, e `piv.loc[partida]` levantava `KeyError` cru
se a data pedida nao existisse em `composicao_dpf.csv` -- sem dizer qual
data faltou nem quais existem por perto.

Troquei `piv.loc[partida]` por uma guarda que, se `partida not in
piv.index`, levanta `LookupError` com a data pedida e ate tres datas antes
e depois dela (`f"nao ha composicao_dpf.csv na data {partida:%d/%m/%Y}.
Datas por perto: {texto}."`). Acrescentei dois testes:

- `test_a_projecao_no_ramo_do_BACKTEST_usa_a_data_pedida`: chama
  `projecao(ate, hoje=hoje, registros=[])` com duas datas reais de
  `composicao_dpf.csv` (31/05/2026 e 30/06/2026, as duas ultimas
  disponiveis) e confere `p["de"] == hoje`, `p["ate"] == ate`,
  `p["estoque"].sum() > 0`.
- `test_a_projecao_no_ramo_do_BACKTEST_levanta_LookupError_diagnosavel`:
  chama com `hoje=pd.Timestamp("1999-01-01")` e confere
  `pytest.raises(LookupError, match="composicao_dpf")`.

Nao mutei este ponto separadamente porque o proprio teste de data ausente
E a verificacao de dentes: sem a guarda, a chamada levantaria `KeyError` em
vez de `LookupError`, e `pytest.raises(LookupError, ...)` reprovaria com
`KeyError` nao capturado. Rodei o teste com a guarda removida (voltando a
`inicial = piv.loc[partida]` direto) para confirmar:

    PYTHONPATH=src python -m pytest tests/test_rolagem.py -q -k backtest
    F.
    FAILED test_a_projecao_no_ramo_do_BACKTEST_levanta_LookupError_diagnosavel
    KeyError: Timestamp('1999-01-01 00:00:00')
    1 failed, 1 passed in 4.87s

Restaurei a guarda antes de commitar.

### Resultado final da rodada

    PYTHONPATH=src python -m pytest tests/test_rolagem.py tests/test_curva.py -q
    ........................
    24 passed in 18-19s (variou entre execucoes, sempre bem abaixo de 60s)

`git status --short` limpo depois do commit `76f691a`; `curva.py` nao
mudou nesta rodada (o Critical/Important eram todos em `rolagem.py` e
`tests/test_rolagem.py`).

### Preocupacoes desta rodada

- **Critical 1 fica parcialmente resolvido**, como registrado acima: a
  ancora de sanidade (percentual soma 100) e a checagem de fiacao
  (emissao publicada bate com a recalculada) sao reais e uteis, mas nao
  substituem `test_a_contagem_de_leiloes_futuros_e_por_PAPEL` como defesa
  contra a mutacao especifica que o revisor usou -- essa defesa ja existia
  antes desta rodada. Se o revisor esperava que o teste da projecao
  pegasse essa mutacao especifica sozinho, isso nao aconteceu, e registrei
  a razao estrutural em vez de reportar como resolvido.
- O incidente de codificacao (Edit/Write inserindo acento literal em vez do
  escape `\uXXXX`) se repetiu nesta rodada, agora tambem em scripts
  auxiliares de edicao (nao so no .py final) -- troquei para montar a
  string do escape por concatenacao (`"\\u00cd" + "ndice Pre" + "\\u00e7" +
  "os"`) em vez de digitar o caractere ou usar `Í` dentro de uma
  string Python normal (que o interpretador resolve de volta para o
  acento). Confirmei `ord(c) > 127` vazio nos tres arquivos antes de cada
  commit desta rodada.


## Segunda rodada de revisao: Critical 1 nao fechava de fato

A coordenadora confirmou o motivo que eu tinha registrado na rodada
anterior -- a recomputacao independente chamava `leiloes_que_faltam` nos
dois lados da comparacao, entao qualquer mutacao nela move os dois lados
juntos -- e pediu uma segunda checagem que NAO chame essa funcao.

### Commit

- `f13ca7c` -- "Critical 1, de fato: compara contra o teto do metodo
  errado" (1 file changed, 18 insertions(+): `tests/test_rolagem.py`)

### O que foi acrescentado

Dentro de `test_a_projecao_devolve_a_PREMISSA_que_usou`, depois do loop que
ja existia (que acumula `total_emissao` somando `emissao_publicada` de cada
indexador):

    teto_do_metodo_errado = sum(float(ritmo[ind]) * len(dias)
                                for ind in rolagem.INDEXADORES)
    assert total_emissao < teto_do_metodo_errado * 0.7

`ritmo` e `dias` ja existiam no teste (vem de `rolagem.pace(de)` e
`calendario_leiloes.dias_ate(...)`, calculados antes do loop). A ideia,
como a coordenadora descreveu: o prefixado so vai a leilao as quintas, os
indexados so as tercas -- cada papel usa cerca de metade dos dias de
leilao da janela. O teto do metodo errado (multiplicar o pace pelo total
de DIAS, e nao pelos LEILOES DAQUELE PAPEL) fica perto do dobro da emissao
correta. 0,7 em vez de 0,5 da folga porque os tres papeis nao se dividem
exatamente meio a meio.

### Verificacao de dentes

Mutei `leiloes_que_faltam` (linha 259-260 de `rolagem.py`) de
`return sum(1 for d in dias if pd.Timestamp(d).dayofweek == alvo)` para
`return len(dias)` -- a mesma mutacao da rodada anterior -- e rodei so
`test_rolagem.py`:

    PYTHONPATH=src python -m pytest tests/test_rolagem.py -v
    FAILED tests/test_rolagem.py::test_a_contagem_de_leiloes_futuros_e_por_PAPEL
    FAILED tests/test_rolagem.py::test_a_projecao_devolve_a_PREMISSA_que_usou
    AssertionError: assert np.float64(1271402.7526502644) < (1271402.752650264 * 0.7)
    2 failed, 8 passed in 17.91s

Desta vez `test_a_projecao_devolve_a_PREMISSA_que_usou` reprova tambem --
nao so o teste vizinho. Com a mutacao, `total_emissao` e
`teto_do_metodo_errado` ficam EXATAMENTE iguais (1.271.402,75 dos dois
lados), porque `leiloes_que_faltam(dias, ind)` mutado devolve `len(dias)`
para todo `ind`, que e precisamente o que `teto_do_metodo_errado` calcula
por definicao -- a razao vai a 1,0, como a coordenadora previu, e
`1,0 < 0,7` e falso.

Desfiz a mutacao (`cp` do backup de volta) e confirmei `git diff --stat
src/tesouro/rolagem.py` vazio antes de commitar so `tests/test_rolagem.py`.

### Resultado final

    PYTHONPATH=src python -m pytest tests/test_rolagem.py tests/test_curva.py -q
    ........................
    24 passed in 17.73s

`git status --short` limpo depois do commit `f13ca7c`.

### Preocupacoes desta rodada

Nenhuma nova. O Critical 1 agora tem duas defesas independentes dentro do
mesmo teste: a comparacao `emissao_publicada == emissao_esperada` (que
prende a fiacao entre `pace()`/`leiloes_que_faltam()` e o dict devolvido,
mas nao pega mutacao dentro de `leiloes_que_faltam` sozinha) e o teto do
metodo errado (que nao chama `leiloes_que_faltam` e por isso pega essa
mutacao especifica). As duas juntas cobrem tanto bug de fiacao quanto bug
de valor dentro da propria funcao.

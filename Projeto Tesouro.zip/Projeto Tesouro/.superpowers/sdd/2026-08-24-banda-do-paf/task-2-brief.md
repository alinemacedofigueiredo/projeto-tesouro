### Task 2: `fluxos.py` — a tabela de fluxos pagos, conferida contra a 3.4

**Arquivos:**
- Modificar: `src/tesouro/fluxos.py`
- Teste: `tests/test_fluxos.py`

**Interfaces:**
- Consome: `paga_cupom_em` da Task 1
- Produz: `pagos(de, ate) -> pd.DataFrame` com colunas `data`, `indexador`,
  `principal_milhoes`, `cupom_milhoes`

- [ ] **Passo 1: escrever o teste que falha**

```python
def test_o_cupom_calculado_bate_com_a_aba_3_4_em_novembro():
    # NOVEMBRO DE 2026 E O CASO QUE PROVA: tem R$ 26,0 bi de fluxo e ZERO
    # principal. E cupom puro, entao a comparacao contra a 3.4 e direta -- nos
    # outros meses o cupom final do papel que vence esta dentro da linha de
    # principal dela, e a conta nao fecha por motivo que nao e erro nosso.
    from tesouro import config

    d = fluxos.pagos(pd.Timestamp("2026-11-01"), pd.Timestamp("2026-11-30"))
    calculado = d["cupom_milhoes"].sum()
    assert d["principal_milhoes"].sum() == 0, "novembro deixou de ser cupom puro"

    cr = pd.read_csv(config.PROCESSED_DIR / "cronograma_vencimentos.csv",
                     parse_dates=["mes_vencimento"])
    da_34 = cr[(cr["faixa"] == "mensal")
               & (cr["mes_vencimento"] == pd.Timestamp("2026-11-30"))
               ]["valor_milhoes"].sum()
    assert abs(calculado - da_34) / da_34 < 0.05, (calculado, da_34)


def test_o_principal_sai_da_aba_2_2_e_o_cupom_do_calculo():
    # Os dois termos ficam em colunas separadas de proposito: um e transcricao e o
    # outro e conta, e um teste que os somasse nao saberia dizer qual quebrou.
    d = fluxos.pagos(pd.Timestamp("2026-07-01"), pd.Timestamp("2026-12-31"))
    assert set(d.columns) >= {"data", "indexador", "principal_milhoes",
                              "cupom_milhoes"}
    assert d["principal_milhoes"].sum() > 700000
    assert 80000 < d["cupom_milhoes"].sum() < 120000


def test_a_janela_e_fechada_a_direita_e_aberta_a_esquerda():
    # (de, ate]. A rolagem encadeia janelas, e sobreposicao de um dia conta um
    # vencimento duas vezes.
    quinze = pd.Timestamp("2026-08-15")
    dentro = fluxos.pagos(pd.Timestamp("2026-08-14"), quinze)
    fora = fluxos.pagos(quinze, pd.Timestamp("2026-08-16"))
    assert dentro["principal_milhoes"].sum() > 0
    assert fora["principal_milhoes"].sum() == 0
```

- [ ] **Passo 2: rodar e ver falhar**

PowerShell:

```powershell
$env:PYTHONPATH="src"; python -m pytest tests/test_fluxos.py -q -k "3_4 or aba_2_2 or janela"
```

bash:

```bash
PYTHONPATH=src python -m pytest tests/test_fluxos.py -q -k "3_4 or aba_2_2 or janela"
```

Esperado: FAIL com `AttributeError: module 'tesouro.fluxos' has no attribute 'pagos'`.

- [ ] **Passo 3: implementar**

```python
INDEXADOR = {"LTN": "Prefixado", "NTN-F": "Prefixado",
             "NTN-B": "Índice Preços",
             "NTN-B Principal": "Índice Preços",
             "NTN-C": "Índice Preços",
             "NTN-B1 EducA+": "Índice Preços",
             "NTN-B1 RendA+": "Índice Preços",
             "LFT": "Taxa Flutuante", "LFT-TD1 Reserva": "Taxa Flutuante"}

_INDICE_DO_VNA = {"Índice Preços": "IPCA", "Taxa Flutuante": "SELIC"}


def _estoque_mais_recente():
    e = pd.read_csv(config.PROCESSED_DIR / "estoque_titulos_vencimento.csv",
                    parse_dates=["data", "vencimento"])
    u = e[(e["data"] == e["data"].max()) & (e["quantidade_mil"] > 0)].copy()
    faltando = sorted(set(u["titulo"]) - set(INDEXADOR))
    if faltando:
        raise LookupError(
            f"papel sem indexador em fluxos.INDEXADOR: {faltando}. Sem isso ele "
            f"sai da conta em silencio, e o fluxo pago fica menor do que e.")
    u["indexador"] = [INDEXADOR[t] for t in u["titulo"]]
    return u


def _vna(indice, quando):
    v = pd.read_csv(config.PROCESSED_DIR / "vna.csv", parse_dates=["data"])
    s = v[(v["indice"] == indice) & (v["data"] <= quando)]
    if s.empty:
        raise LookupError(
            f"nao ha VNA de {indice} ate {quando:%d/%m/%Y}. O cupom de papel "
            f"indexado nao pode ser calculado sem ele.")
    return float(s.iloc[-1]["vna"])


def pagos(de, ate):
    """Principal e cupom pagos em (de, ate], por data e indexador.

    JANELA FECHADA A DIREITA E ABERTA A ESQUERDA. A rolagem encadeia janelas, e
    sobreposicao de um dia conta um vencimento duas vezes.
    """
    de, ate = pd.Timestamp(de), pd.Timestamp(ate)
    u = _estoque_mais_recente()
    linhas = []

    vence = u[(u["vencimento"] > de) & (u["vencimento"] <= ate)]
    for _, r in vence.iterrows():
        linhas.append({"data": r["vencimento"], "indexador": r["indexador"],
                       "principal_milhoes": r["financeiro_milhoes"],
                       "cupom_milhoes": 0.0})

    for dia in pd.date_range(de + pd.Timedelta(days=1), ate, freq="D"):
        for _, r in u.iterrows():
            if not paga_cupom_em(r["titulo"], r["vencimento"], dia):
                continue
            taxa = (1 + CUPOM_ANUAL[r["titulo"]]) ** 0.5 - 1
            indice = _INDICE_DO_VNA[r["indexador"]]
            base = _vna(indice, dia) if indice == "IPCA" else 1000.0
            valor = r["quantidade_mil"] * 1000 * base * taxa / 1e6
            linhas.append({"data": dia, "indexador": r["indexador"],
                           "principal_milhoes": 0.0, "cupom_milhoes": valor})

    if not linhas:
        return pd.DataFrame(columns=["data", "indexador", "principal_milhoes",
                                     "cupom_milhoes"])
    return pd.DataFrame(linhas).sort_values("data").reset_index(drop=True)
```

- [ ] **Passo 4: rodar e ver passar**

PowerShell:

```powershell
$env:PYTHONPATH="src"; python -m pytest tests/test_fluxos.py -q
```

bash:

```bash
PYTHONPATH=src python -m pytest tests/test_fluxos.py -q
```

Esperado: 6 passed.

- [ ] **Passo 5: verificar dentes**

Troque `(u["vencimento"] > de)` por `(u["vencimento"] >= de)`. O teste da janela tem
de reprovar. Desfaça.

- [ ] **Passo 6: commitar**

```bash
git add src/tesouro/fluxos.py tests/test_fluxos.py
git commit -m "Fluxos pagos: principal da aba 2.2 e cupom calculado"
```

---


### Task 4: `calendario_leiloes.py` — o publicado tem precedência

**Arquivos:**
- Modificar: `src/tesouro/calendario_leiloes.py`
- Teste: `tests/test_calendario_leiloes.py`

**Interfaces:**
- Consome: `parse_api_leiloes.calendario(registros)`, `dias_estimados` da Task 3
- Produz: `dias_ate(ate, registros=None) -> tuple[list, pd.Timestamp | None]` — os
  dias e a data em que o publicado acaba

- [ ] **Passo 1: escrever o teste que falha**

```python
def test_o_calendario_PUBLICADO_tem_precedencia_sobre_o_estimado():
    # Onde o Tesouro ja disse o que vai fazer, e transcricao. So alem disso e
    # inferencia -- e a pagina precisa saber onde uma acaba, senao apresenta
    # palpite com a mesma cara de fato.
    import json
    import pathlib

    fixtures = pathlib.Path(__file__).parent / "fixtures" / "api_leiloes"
    registros = json.loads(
        (fixtures / "calendario.json").read_text(encoding="utf-8"))["registros"]

    # HOJE FIXO, como o test_agenda.py ja faz. A amostra congelada vai de 20/08 a
    # 29/09/2026: com a data real do relogio, este teste comeca a reprovar sozinho
    # em 30/09, quando 'publicados' fica vazio e a fronteira vira None. Data movel
    # em teste e teste que quebra num dia qualquer, sem ninguem ter mexido em nada.
    dias, ate_quando = calendario_leiloes.dias_ate(
        pd.Timestamp("2026-12-31"), registros=registros,
        hoje=pd.Timestamp("2026-08-24"))
    assert ate_quando is not None
    assert pd.Timestamp("2026-08-20") <= ate_quando <= pd.Timestamp("2026-10-31")
    # Os dias do publicado entram como estao, mesmo os que a regra nao previa.
    publicados = set(dias[:len(dias)])
    assert ate_quando in publicados or ate_quando <= max(dias)
    # E depois dele, o estimado continua ate o fim do ano.
    assert max(dias) > ate_quando


def test_sem_registros_a_lista_e_toda_estimada():
    dias, ate_quando = calendario_leiloes.dias_ate(pd.Timestamp("2026-12-31"),
                                                   registros=[],
                                                   hoje=pd.Timestamp("2026-08-24"))
    assert ate_quando is None
    assert dias
```

- [ ] **Passo 2: rodar e ver falhar**

PowerShell:

```powershell
$env:PYTHONPATH="src"; python -m pytest tests/test_calendario_leiloes.py -q -k "PUBLICADO or sem_registros"
```

bash:

```bash
PYTHONPATH=src python -m pytest tests/test_calendario_leiloes.py -q -k "PUBLICADO or sem_registros"
```

Esperado: FAIL, `has no attribute 'dias_ate'`.

- [ ] **Passo 3: implementar**

```python
def dias_ate(ate, registros=None, hoje=None):
    """Os dias de leilao ate 'ate', e a data em que o calendario publicado acaba.

    O PUBLICADO TEM PRECEDENCIA. Onde o Tesouro ja disse o que vai fazer, e
    transcricao; alem disso e inferencia nossa. Devolver a fronteira junto nao e
    detalhe: sem ela a pagina apresentaria palpite com a mesma cara de fato.

    'registros' e a resposta ja baixada da API. Os testes passam a amostra
    congelada, e por isso nao tocam a rede.
    """
    from . import api_leiloes, parse_api_leiloes

    ate = pd.Timestamp(ate).normalize()
    hoje = pd.Timestamp(hoje).normalize() if hoje is not None \
        else pd.Timestamp.today().normalize()

    if registros is None:
        registros, _ = api_leiloes.buscar("calendario")

    publicados = []
    fronteira = None
    if len(registros):
        agenda = parse_api_leiloes.calendario(registros)
        datas = sorted(set(agenda["data_leilao"].dt.normalize()))
        publicados = [d for d in datas if hoje <= d <= ate]
        if publicados:
            fronteira = max(publicados)

    inicio = fronteira + pd.Timedelta(days=1) if fronteira is not None else hoje
    estimados = [d for d in dias_estimados(inicio, ate) if d not in set(publicados)]
    return sorted(set(publicados) | set(estimados)), fronteira
```

- [ ] **Passo 4: rodar e ver passar**

PowerShell:

```powershell
$env:PYTHONPATH="src"; python -m pytest tests/test_calendario_leiloes.py -q
```

bash:

```bash
PYTHONPATH=src python -m pytest tests/test_calendario_leiloes.py -q
```

Esperado: 5 passed.

- [ ] **Passo 5: verificar que a suíte não toca a rede**

Ponha `raise RuntimeError("A SUITE TOCOU A REDE")` na primeira linha de
`api_leiloes.buscar` e rode `tests/test_calendario_leiloes.py`. Tem de passar
inteiro. Desfaça.

- [ ] **Passo 6: commitar**

```bash
git add src/tesouro/calendario_leiloes.py tests/test_calendario_leiloes.py
git commit -m "O calendario publicado tem precedencia sobre o estimado"
```

---


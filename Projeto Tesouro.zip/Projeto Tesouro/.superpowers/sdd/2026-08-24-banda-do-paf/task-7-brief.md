### Task 7: `rolagem.py` — a rolagem, conferida em 24 meses

**Arquivos:**
- Modificar: `src/tesouro/rolagem.py`
- Teste: `tests/test_rolagem.py`

**Interfaces:**
- Consome: `vna_em` da Task 6, `fluxos.pagos` da Task 2
- Produz: `estoque_em(quando) -> pd.Series` indexada por indexador, em R$ milhões;
  `INDEXADORES: tuple[str, ...]`

- [ ] **Passo 1: escrever o teste que falha**

```python
def test_a_rolagem_reproduz_os_meses_FECHADOS_do_RMD():
    # O TESTE QUE SUSTENTA TUDO O MAIS. Se a rolagem nao reproduz um mes que ja
    # aconteceu, o numero de "hoje" que ela produz nao vale nada.
    #
    # Os limites vieram da medicao em 24 meses, em % do estoque do indexador:
    # taxa flutuante 0,07%, indice de precos 0,51%, prefixado 0,75%. O teste usa o
    # DOBRO de folga, para nao reprovar por um mes atipico.
    from tesouro import config

    c = pd.read_csv(config.PROCESSED_DIR / "composicao_dpf.csv",
                    parse_dates=["data"])
    piv = c.pivot_table(index="data", columns="indexador",
                        values="valor_milhoes", aggfunc="sum").fillna(0.0)
    datas = list(piv.index)[-13:]

    LIMITE = {"Prefixado": 0.015, "Índice Preços": 0.011,
              "Taxa Flutuante": 0.002}
    for t0, t1 in zip(datas[:-1], datas[1:]):
        obtido = rolagem.estoque_em(t1, de=t0)
        for ind, limite in LIMITE.items():
            real = piv.loc[t1, ind]
            erro = abs(obtido[ind] - real) / real
            assert erro < limite, (t1.date(), ind, erro, limite)


def test_a_rolagem_casa_por_LIQUIDACAO_e_nao_por_data_de_leilao():
    # 6,1% dos leiloes liquidam no mes seguinte ao do leilao. Casar pela data errada
    # poe o papel no mes errado, e erra exatamente as viradas -- que e onde o RMD
    # corta.
    from tesouro import config

    l = pd.read_csv(config.PROCESSED_DIR / "leiloes.csv",
                    parse_dates=["data_leilao", "data_liquidacao"])
    vira = l[(l["data_liquidacao"].dt.to_period("M")
              != l["data_leilao"].dt.to_period("M"))
             & (l["tipo_leilao"] == "Venda")]
    assert len(vira) > 1000, "os leiloes que viram o mes sumiram do dado"

    r = vira.sort_values("data_liquidacao").iloc[-1]
    fim_do_mes_do_leilao = (r["data_leilao"] + pd.offsets.MonthEnd(0))
    entrou = rolagem.leiloes_liquidados(
        r["data_liquidacao"] - pd.Timedelta(days=1), r["data_liquidacao"])
    nao_entrou = rolagem.leiloes_liquidados(
        fim_do_mes_do_leilao - pd.Timedelta(days=31), fim_do_mes_do_leilao)
    assert entrou.sum() > 0
    assert r["data_liquidacao"] > fim_do_mes_do_leilao


def test_o_CAMBIO_fica_parado_e_a_rolagem_diz_isso():
    # O indexador Cambio E a DPFe -- diferenca mediana de R$ 4,9 bi em 307 meses --
    # e a DPFe nao passa por leilao. Ele e segurado no valor do RMD, com o custo
    # medido: 5,2 bi por mes, 0,06% do estoque total.
    #
    # O que nao pode e segura-lo em SILENCIO: ele esta no denominador dos outros
    # tres percentuais.
    assert "Câmbio" in rolagem.PARADOS
    assert "Câmbio" not in rolagem.INDEXADORES
```

- [ ] **Passo 2: rodar e ver falhar**

PowerShell:

```powershell
$env:PYTHONPATH="src"; python -m pytest tests/test_rolagem.py -q -k "FECHADOS or LIQUIDACAO or CAMBIO"
```

bash:

```bash
PYTHONPATH=src python -m pytest tests/test_rolagem.py -q -k "FECHADOS or LIQUIDACAO or CAMBIO"
```

Esperado: FAIL, `has no attribute 'estoque_em'`.

- [ ] **Passo 3: implementar**

```python
# Os indexadores que a rolagem move. O Cambio fica de fora -- ver PARADOS.
INDEXADORES = ("Prefixado", "Índice Preços", "Taxa Flutuante")

# O CAMBIO E A DPFe: comparados os 307 meses da serie, a diferenca mediana entre os
# dois e de R$ 4,9 bilhoes. A DPFe nao passa por leilao, e o movimento dela e cambio
# mais emissao externa, que este projeto nao tem -- entao nao ha como rolar um sem o
# outro.
#
# Ele e segurado no valor do ultimo RMD. Custo medido: variacao mensal mediana de
# R$ 5,2 bi, ou 0,06% do estoque total; em dois meses, no pior decil, R$ 32,5 bi.
# Contra uma banda de cambio com largura de pontos percentuais inteiros, e ruido.
#
# O que NAO e aceitavel e segura-lo em silencio: ele entra no denominador dos outros
# tres percentuais, entao a pagina marca a linha dele como nao rolada.
PARADOS = ("Câmbio",)

_INDICE_DO_INDEXADOR = {"Taxa Flutuante": "SELIC", "Índice Preços": "IPCA"}

# Carga do prefixado: LTN e NTN-F nao tem VNA, carregam para o par pela taxa de
# emissao. O residuo medido sem este termo e de +12,2 bi/mes sobre ~1.900 bi, ou
# 0,64% ao mes -- que e uma carga de ~13% ao ano, e nao ruido.
_CARGA_DO_PREFIXADO = 0.135

_INDEXADOR_DO_TITULO = {"LTN": "Prefixado", "NTN-F": "Prefixado",
                        "NTN-B": "Índice Preços",
                        "NTN-C": "Índice Preços",
                        "LFT": "Taxa Flutuante"}

_SINAL = {"Venda": 1, "Extra Venda": 1, "Compra": -1, "Extra Compra": -1,
          "Troca": 0}


def base_do_rmd():
    """A data-base do ultimo RMD, e o estoque por indexador nela."""
    c = pd.read_csv(config.PROCESSED_DIR / "composicao_dpf.csv",
                    parse_dates=["data"])
    piv = c.pivot_table(index="data", columns="indexador",
                        values="valor_milhoes", aggfunc="sum").fillna(0.0)
    return piv.index.max(), piv.loc[piv.index.max()]


def leiloes_liquidados(de, ate):
    """Financeiro liquido dos leiloes liquidados em (de, ate], por indexador."""
    l = pd.read_csv(config.PROCESSED_DIR / "leiloes.csv",
                    parse_dates=["data_liquidacao"])
    l = l[(l["data_liquidacao"] > pd.Timestamp(de))
          & (l["data_liquidacao"] <= pd.Timestamp(ate))].copy()
    l["indexador"] = [_INDEXADOR_DO_TITULO.get(t) for t in l["titulo"]]
    l["sinal"] = [_SINAL.get(t, 0) for t in l["tipo_leilao"]]
    l = l[l["indexador"].notna()]
    fluxo = (l["financeiro_milhoes"] * l["sinal"]).groupby(l["indexador"]).sum()
    return fluxo.reindex(list(INDEXADORES)).fillna(0.0)


def _apropriacao(indexador, base, de, ate):
    """Juros apropriados sobre o estoque no periodo."""
    if indexador == "Prefixado":
        cal = calendario.padrao()
        du = cal.du(pd.Timestamp(de).date(), pd.Timestamp(ate).date())
        return base * ((1 + _CARGA_DO_PREFIXADO) ** (du / 252) - 1)
    indice = _INDICE_DO_INDEXADOR[indexador]
    return base * (vna_em(indice, ate) / vna_em(indice, de) - 1)


def estoque_em(quando, de=None):
    """O estoque por indexador na data, rolado desde o RMD (ou desde 'de')."""
    from . import fluxos

    if de is None:
        de, inicial = base_do_rmd()
    else:
        c = pd.read_csv(config.PROCESSED_DIR / "composicao_dpf.csv",
                        parse_dates=["data"])
        piv = c.pivot_table(index="data", columns="indexador",
                            values="valor_milhoes", aggfunc="sum").fillna(0.0)
        de = pd.Timestamp(de)
        inicial = piv.loc[de]

    quando = pd.Timestamp(quando)
    emitido = leiloes_liquidados(de, quando)
    pagou = fluxos.pagos(de, quando)
    saida = {}
    for ind in INDEXADORES:
        base = float(inicial[ind])
        do_ind = pagou[pagou["indexador"] == ind]
        pago = (do_ind["principal_milhoes"].sum()
                + do_ind["cupom_milhoes"].sum())
        saida[ind] = (base + float(emitido[ind]) - pago
                      + _apropriacao(ind, base, de, quando))
    for ind in PARADOS:
        saida[ind] = float(inicial[ind])
    return pd.Series(saida)
```

- [ ] **Passo 4: rodar e ver passar**

PowerShell:

```powershell
$env:PYTHONPATH="src"; python -m pytest tests/test_rolagem.py -q
```

bash:

```bash
PYTHONPATH=src python -m pytest tests/test_rolagem.py -q
```

Esperado: 5 passed.

Se o teste dos meses fechados reprovar por pouco num indexador, **não afrouxe o
limite**: veja qual termo está faltando. O limite já tem o dobro da folga medida.

- [ ] **Passo 5: verificar dentes**

Três mutações, uma de cada vez, desfazendo entre elas:

1. Em `estoque_em`, tire `- pago`. O teste dos meses fechados tem de reprovar.
2. Em `_apropriacao`, devolva `0.0` na primeira linha. Tem de reprovar na taxa
   flutuante.
3. Em `leiloes_liquidados`, troque `data_liquidacao` por `data_leilao` no
   `parse_dates` e nos dois filtros. Tem de reprovar.

- [ ] **Passo 6: commitar**

```bash
git add src/tesouro/rolagem.py tests/test_rolagem.py
git commit -m "A rolagem do estoque, conferida em 24 meses fechados"
```

---


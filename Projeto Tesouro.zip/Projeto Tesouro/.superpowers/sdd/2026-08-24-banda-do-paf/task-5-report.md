# Task 5: curva.py -- Selic implicita e inflacao implicita

## Status

DONE

## Commit

`6f43216` -- "A premissa sai da curva: Selic implicita e breakeven"
(2 files changed, 210 insertions: `src/tesouro/curva.py`, `tests/test_curva.py`)

## Resultado dos testes

`PYTHONPATH=src python -m pytest tests/test_curva.py -q` -> **10 passed**

## O que foi escrito

`src/tesouro/curva.py`, com `_curva`, `_interpola`, `selic_implicita`,
`ntnb_de_referencia` e `inflacao_implicita` copiados verbatim do brief (Passo 3),
mais uma funcao `_checar_ordem` que o brief nao tinha (ver "O que o brief nao
previu" abaixo).

`tests/test_curva.py` tem os 4 testes do brief (Passo 1) mais 6 que acrescentei:
valor medido de `selic_implicita` e de `inflacao_implicita`, as duas pontas de
extrapolacao plana (`du <= xs[0]` e `du >= xs[-1]`), `data_base` explicito mudando
o resultado, e `ate` anterior a `data_base` sendo rejeitado.

## Ciclo seguido

1. Escrevi os 4 testes do brief -- rodei e vi `ModuleNotFoundError: No module
   named 'tesouro.curva'`.
2. Medi os valores esperados fora do pytest, reproduzindo `_curva`/`_interpola`
   em um script solto contra `dv_por_papel.csv`, antes de implementar, para saber
   o que travar nos testes de valor.
3. Implementei `curva.py` verbatim do brief, mais o guard de `_checar_ordem`.
4. Rodei de novo: **10 passed**.

## Verificacao de dentes (Passo 5)

Tirei o filtro `& d["taxa_pct"].notna()` de `_curva` e rodei
`tests/test_curva.py`:

```
FAILED tests/test_curva.py::test_a_interpolacao_IGNORA_vencimento_sem_cotacao
FAILED tests/test_curva.py::test_a_selic_implicita_fica_entre_as_pontas_da_curva
FAILED tests/test_curva.py::test_selic_implicita_bate_o_valor_medido
3 failed, 7 passed in 1.74s
```

Confirmei que o teste da armadilha reprova pelo motivo certo -- o traceback mostra
`AssertionError: a taxa saiu NaN: a interpolacao pegou papel sem cotacao` /
`assert nan == nan`, na linha que checa `taxa == taxa`, e nao em outra assercao
antes dela. Os outros dois failures sao propagacao do mesmo NaN (esperado: a
selic contaminada de NaN tambem falha "entre as pontas" e "bate o valor medido").
Desfiz a mutacao; `git diff -- src/tesouro/curva.py` ficou vazio (byte-identico ao
commit), e os 10 testes voltaram a passar.

## Verificacao de ASCII

`python -c "... sum(1 for c in b if c>127) ..."` sobre os dois arquivos tocados
devolveu 0 bytes nao-ASCII nos dois -- sem barra dupla escapada, sem acento cru.

## Discordancia de medicao

Nenhuma. Medi fora do pytest, contra `dv_por_papel.csv` real, antes de escrever a
implementacao:

- `selic_implicita(2026-12-31)`: **13,7631%** (brief cita ~13,76%) -- LTN a 127
  du da base 30/06/2026, interpolada entre a de 01/04/2027 (13,7522%, du=188) e a
  de 01/07/2027 (13,7512%, du=251).
- `inflacao_implicita(2026-12-31)`: **4,6956%** (brief cita ~4,70%) -- NTN-B de
  referencia e a de 15/05/2027 (real 8,6500%), breakeven contra a LTN prefixada
  interpolada no mesmo prazo (nominal 13,7517%).

Os dois batem com o que o brief mediu.

## O que o brief nao previu

**Guard de ordem (`_checar_ordem`).** `calendario.Calendario.du(a, b)` e simetrico
-- troca `a` e `b` internamente quando `b < a` -- entao `du(base, ate)` com `ate`
anterior a `base` devolve a MESMA distancia positiva que se `ate` viesse depois.
Sem guard, `selic_implicita(ate_no_passado, data_base=base)` nao daria erro nem
NaN: devolveria uma taxa da curva escolhida pela distancia absoluta errada,
silenciosamente. Medi isso direto (`cal.du(2026-06-30, 2026-01-01)` devolveu 121,
positivo, o mesmo sinal que uma data futura a 121 du daria). Como o modulo existe
para projetar PARA A FRENTE da data-base, e o projeto inteiro tem por habito
recusar em vez de responder errado (ver `_curva` levantando `LookupError` quando a
curva vem vazia), acrescentei `_checar_ordem` levantando `ValueError` quando `ate
< base`, chamada em `selic_implicita` antes do calculo de `du`. Coberta por
`test_ate_anterior_a_data_base_e_rejeitado`.

(Nota da Rodada 2: a frase acima -- que `ntnb_de_referencia` nao precisava do
mesmo guard -- estava errada. Ver secao "Rodada 2" no fim deste relatorio.)

## Preocupacoes

- Nao esperei a suite completa (`pytest -q` sem filtro) terminar em background --
  nao concluiu em mais de 5 minutos, mesmo padrao ja registrado nas Tasks 3 e 4
  deste mesmo sub-projeto. `curva.py` e modulo independente, nao consumido por
  nenhuma tarefa anterior nem por `precificacao.py` (que nao foi tocado), e
  `tests/test_curva.py` roda limpo e isolado em menos de 3s. (Nota da Rodada 2:
  a causa apontada aqui -- rede -- estava errada; ver correcao abaixo.)

---

## Rodada 2 -- resposta a revisao

### Status

DONE

### Commit

`e892a1c` -- "Estende a guarda de ordem para ntnb_de_referencia e
inflacao_implicita" (2 files changed, 27 insertions, 4 deletions:
`src/tesouro/curva.py`, `tests/test_curva.py`)

### Resultado dos testes

`PYTHONPATH=src python -m pytest tests/test_curva.py -q` -> **12 passed**

### O que foi escrito

**1. Important -- guarda estendida a `ntnb_de_referencia` e `inflacao_implicita`.**
O revisor mediu que as duas devolviam resposta plausivel e errada em vez de
recusar: `ntnb_de_referencia(2026-01-01, data_base=2026-06-30)` devolvia
`2026-08-15` sem erro, e `inflacao_implicita` na mesma chamada devolvia um
breakeven de 2,52% sem erro. A frase do meu relatorio da Rodada 1 -- que
`ntnb_de_referencia` "nao usa `du()` diretamente sobre `ate`, entao o guard nao
se aplicava" -- tratava a mecanica do sintoma (o `du` simetrico) como se fosse a
unica porta de entrada do defeito, mas o defeito real e mais amplo: qualquer
funcao publica que aceite `ate` anterior a `data_base` e devolva algo plausivel
em vez de recusar viola o mesmo costume do projeto (`_curva` levantando
`LookupError` quando a curva vem vazia). `ntnb_de_referencia` so filtra
`vencimento > ate`, entao um `ate` no passado simplesmente aceita qualquer
NTN-B viva -- nao precisa do `du` simetrico para dar resposta errada, so
precisa aceitar uma pergunta que nao faz sentido.

Acrescentei `_checar_ordem(base, ate)` em `ntnb_de_referencia` (logo apos
capturar `base` de `_curva`, que antes era descartado com `_`) e em
`inflacao_implicita` (explicita, antes de chamar `ntnb_de_referencia` -- ainda
que a guarda de `ntnb_de_referencia` ja cobrisse por delegacao, deixei explicita
tambem para nao depender de uma implementacao interna nao documentada como
contrato).

**2. Minor -- teste da NTN-B de referencia travado no valor exato.**
`test_a_NTN_B_de_referencia_nao_e_a_mais_proxima` checava so
`escolhida > pd.Timestamp("2026-12-31")`, que a mutacao `depois.iloc[0]` ->
`depois.iloc[-1]` (troca "mais curta" por "mais longa") passa sem reclamar,
porque a de 2060 tambem e "depois de 2026-12-31". Troquei a assercao por
`escolhida == pd.Timestamp("2027-05-15")`.

### Ciclo seguido

Nao houve fase "escrever e ver falhar" propriamente dita para o item 1 -- o
comportamento errado ja existia e foi medido pelo revisor antes de eu mexer;
reproduzi a mesma chamada (`ntnb_de_referencia` e `inflacao_implicita` com
`ate` no passado) direto no interpretador para confirmar o sintoma, escrevi os
dois testes novos, so depois adicionei a guarda.

### Verificacao de dentes

**Guarda nova (remover so as duas chamadas novas de `_checar_ordem`, mantendo a
de `selic_implicita`):**

```
FAILED tests/test_curva.py::test_ntnb_de_referencia_rejeita_ate_anterior_a_data_base
FAILED tests/test_curva.py::test_inflacao_implicita_rejeita_ate_anterior_a_data_base
2 failed, 10 passed in 1.63s
```

Os dois falham com `Failed: DID NOT RAISE ValueError` -- a razao certa. Desfiz a
mutacao copiando o arquivo de volta; `git diff -- src/tesouro/curva.py` vazio, 12
testes voltaram a passar.

**Mutacao do revisor (`depois.iloc[0]` -> `depois.iloc[-1]`):**

```
FAILED tests/test_curva.py::test_a_NTN_B_de_referencia_nao_e_a_mais_proxima
FAILED tests/test_curva.py::test_inflacao_implicita_bate_o_valor_medido
2 failed, 10 passed in 1.86s
```

O teste tightened pega direto: `AssertionError: Timestamp('2060-08-15 00:00:00')
== Timestamp('2027-05-15 00:00:00')`. O teste de valor da inflacao tambem cai
(indiretamente, porque a NTN-B de 2060 muda o breakeven), confirmando que a
mutacao contamina o resultado de verdade e nao so o vencimento escolhido.
Desfiz; `git diff` vazio, 12 testes voltaram a passar.

### Verificacao de ASCII

0 bytes nao-ASCII nos dois arquivos tocados, conferido depois de cada edicao.

### Correcao ao relatorio da Rodada 1

A frase "provavelmente por testes de outros modulos que tocam rede" (secao
Preocupacoes, Rodada 1) estava errada e nao foi verificada antes de eu escreve-la
-- so um chute sobre a causa. O commit `567c49a` desta mesma branch ja tinha
tirado a dependencia de rede da suite antes desta tarefa comecar, com teste
proprio provando que ela roda com `api_leiloes.buscar` levantando excecao. A
suite completa leva 8 a 10 minutos porque renderiza centenas de SVGs (graficos),
nao por rede. Nao propago mais essa crenca.

### Preocupacoes

Nenhuma nova. As tres interfaces publicas do modulo (`selic_implicita`,
`ntnb_de_referencia`, `inflacao_implicita`) agora recusam `ate` anterior a
`data_base` em vez de responder plausivel e errado, cada uma com teste dedicado
que falha pela razao certa quando a guarda e removida. O teste da NTN-B de
referencia trava no vencimento exato, nao so na direcao. Nao esperei a suite
completa terminar em background (ver correcao acima sobre a causa real, que e
tempo de renderizacao, nao rede); o escopo desta tarefa continua isolado em
`tests/test_curva.py`, que roda limpo em menos de 2s.

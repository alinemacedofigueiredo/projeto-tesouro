### Task 9: `graficos/banda.py` — a distância, e as duas tabelas

**Arquivos:**
- Criar: `src/tesouro/graficos/banda.py`
- Teste: `tests/test_painel_paf.py`

**Interfaces:**
- Consome: `rolagem.estoque_em`, `rolagem.projecao`, `paf.bandas`
- Produz:
  - `INDICADORES: tuple[tuple[str, str, str], ...]` — `(chave, rótulo, unidade)`
  - `distancia(valor, minimo, maximo) -> float`
  - `dados_hoje(hoje=None) -> pd.DataFrame`
  - `dados_projecao(ate=None, registros=None) -> pd.DataFrame`
  - `tabela(dados, ident) -> str`

- [ ] **Passo 1: escrever o teste que falha**

```python
"""A pagina contra o PAF: distancia, projecao e o arquivo."""
import pandas as pd
import pytest

from tesouro.graficos import banda


def test_a_distancia_tem_o_sinal_certo_dos_dois_lados_e_zero_DENTRO():
    # Dentro da banda a distancia e zero, e nao "a distancia ate o meio". Quem esta
    # dentro cumpriu o que prometeu; medir distancia ate o centro inventaria um
    # alvo que o PAF nao define.
    assert banda.distancia(25.0, 21.0, 28.0) == 0.0
    assert banda.distancia(21.0, 21.0, 28.0) == 0.0
    assert banda.distancia(28.0, 21.0, 28.0) == 0.0
    assert banda.distancia(19.5, 21.0, 28.0) == pytest.approx(-1.5)
    assert banda.distancia(30.0, 21.0, 28.0) == pytest.approx(2.0)


def test_a_tabela_de_hoje_tem_uma_linha_por_indicador():
    d = banda.dados_hoje()
    assert len(d) == len(banda.INDICADORES)
    assert set(d.columns) >= {"indicador", "no_rmd", "hoje", "minimo", "maximo",
                              "distancia", "unidade", "rolado"}


def test_a_linha_do_CAMBIO_aparece_marcada_como_NAO_ROLADA():
    # Ele e a DPFe, que nao passa por leilao. Segura-lo e aceitavel; segura-lo em
    # silencio nao e, porque ele esta no denominador dos outros tres percentuais.
    d = banda.dados_hoje().set_index("indicador")
    assert d.loc["Câmbio", "rolado"] is False or \
        not bool(d.loc["Câmbio", "rolado"])
    assert bool(d.loc["Prefixado", "rolado"])


def test_a_tabela_diz_DE_QUANDO_e_o_hoje_e_quantos_leiloes_entraram():
    # Numero sem procedencia nao serve: quem le precisa saber se o "hoje" e de
    # ontem ou de tres semanas atras.
    html = banda.tabela(banda.dados_hoje(), "tabela-hoje")
    assert "leil" in html
    assert "20" in html
```

- [ ] **Passo 2: rodar e ver falhar**

PowerShell:

```powershell
$env:PYTHONPATH="src"; python -m pytest tests/test_painel_paf.py -q
```

bash:

```bash
PYTHONPATH=src python -m pytest tests/test_painel_paf.py -q
```

Esperado: `ModuleNotFoundError: No module named 'tesouro.graficos.banda'`.

- [ ] **Passo 3: implementar**

```python
"""A distancia ate a banda do PAF, e as duas tabelas da pagina.

DENTRO DA BANDA A DISTANCIA E ZERO, e nao "a distancia ate o meio". Quem esta dentro
cumpriu o que prometeu; medir ate o centro inventaria um alvo que o PAF nao define.
"""

import pandas as pd

from .. import config, rolagem
from . import paf

# (chave da banda, rotulo, unidade). A ordem e a da tabela.
INDICADORES = (
    ("prefixado_pct", "Prefixado", "pp"),
    ("indice_precos_pct", "Índice Preços", "pp"),
    ("taxa_flutuante_pct", "Taxa Flutuante", "pp"),
    ("cambio_pct", "Câmbio", "pp"),
    ("prazo_medio_anos", "Prazo médio", "anos"),
    ("vincendo_12m_pct", "Vincendo em 12 meses", "pp"),
    ("estoque_bilhoes", "Estoque", "R$ bi"),
)


def distancia(valor, minimo, maximo):
    """Quanto falta para entrar na banda. Zero se ja esta dentro."""
    if pd.isna(valor) or pd.isna(minimo) or pd.isna(maximo):
        return float("nan")
    if valor < minimo:
        return valor - minimo
    if valor > maximo:
        return valor - maximo
    return 0.0
```

```python
# Os indicadores que a rolagem MOVE. Os demais aparecem com o valor do RMD e
# marcados como nao rolados.
#
# Prazo medio e vincendo em 12 meses nao sao rolados nesta entrega: rola-los exige
# recalcular o prazo papel a papel, que e trabalho da entrega 5. O cambio nao e
# rolado porque e a DPFe, que nao passa por leilao -- ver rolagem.PARADOS.
_ROLADOS = ("prefixado_pct", "indice_precos_pct", "taxa_flutuante_pct",
            "estoque_bilhoes")

_DA_COMPOSICAO = {"prefixado_pct": "Prefixado",
                  "indice_precos_pct": "Índice Preços",
                  "taxa_flutuante_pct": "Taxa Flutuante",
                  "cambio_pct": "Câmbio"}


def _realizado_do_rmd():
    """O valor de cada indicador na data-base do RMD, do NOSSO dado.

    A coluna 'realizado' do referencia/paf_bandas.csv nao e usada, e paf.bandas() ja
    a descarta de proposito: ler o realizado de uma tabela digitada seria trocar dado
    verificado por dado redigitado.
    """
    c = pd.read_csv(config.PROCESSED_DIR / "composicao_dpf.csv",
                    parse_dates=["data"])
    comp = c.pivot_table(index="data", columns="indexador",
                         values="valor_milhoes", aggfunc="sum").fillna(0.0)
    pct = comp.div(comp.sum(axis=1), axis=0) * 100

    p = pd.read_csv(config.PROCESSED_DIR / "prazo_medio_por_titulo.csv",
                    parse_dates=["data"])
    prazo = p[(p["nivel"] == "DPF") & p["entidade"].isna()
              & p["titulo"].isna()].set_index("data")["prazo_anos"]

    v = pd.read_csv(config.PROCESSED_DIR / "vencimentos_faixa.csv",
                    parse_dates=["data"])
    fx = v[v["nivel"] == "DPF"].pivot_table(
        index="data", columns="faixa", values="valor_milhoes",
        aggfunc="sum").fillna(0.0)
    venc12 = fx["Até 12 meses"] / fx.sum(axis=1) * 100

    e = pd.read_csv(config.PROCESSED_DIR / "estoque_dpf.csv",
                    parse_dates=["data"])
    ag = e[e["entidade"].isna() & e["titulo"].isna()]
    est = ag[ag["nivel"] == "DPF em poder do publico"].set_index(
        "data")["valor_milhoes"] / 1000

    base = comp.index.max()
    saida = {k: float(pct.loc[base, nome])
             for k, nome in _DA_COMPOSICAO.items()}
    saida["prazo_medio_anos"] = float(prazo.loc[prazo.index.max()])
    saida["vincendo_12m_pct"] = float(venc12.loc[venc12.index.max()])
    saida["estoque_bilhoes"] = float(est.loc[est.index.max()])
    return base, saida


def _valores_de_hoje(quando):
    """Os indicadores rolados ate 'quando'. Os nao rolados vem como None."""
    estoque = rolagem.estoque_em(quando)
    total = estoque.sum()
    return {"prefixado_pct": 100 * estoque["Prefixado"] / total,
            "indice_precos_pct": 100 * estoque["Índice Preços"] / total,
            "taxa_flutuante_pct": 100 * estoque["Taxa Flutuante"] / total,
            "cambio_pct": None,
            "prazo_medio_anos": None,
            "vincendo_12m_pct": None,
            "estoque_bilhoes": total / 1000}


def _linhas(valores, ano, quando=None):
    """Uma linha por indicador, com a banda do ano, a distancia e a data.

    'quando' e a data dos indicadores ROLADOS. Os parados ficam com a
    data-base do RMD, e a diferenca entre as duas e o que a coluna
    de_quando mostra na tabela.
    """
    base, no_rmd = _realizado_do_rmd()
    quando = quando if quando is not None else base
    linhas = []
    for chave, rotulo, unidade in INDICADORES:
        b = paf.bandas(chave)
        if ano not in b.index:
            continue
        r = b.loc[ano]
        valor = valores.get(chave)
        rolado = valor is not None
        if not rolado:
            valor = no_rmd[chave]
        linhas.append({"indicador": rotulo, "chave": chave,
                       "no_rmd": no_rmd[chave], "hoje": valor,
                       "minimo": r["minimo"], "maximo": r["maximo"],
                       "minimo_original": r["minimo_original"],
                       "maximo_original": r["maximo_original"],
                       "distancia": distancia(valor, r["minimo"], r["maximo"]),
                       "unidade": unidade, "rolado": rolado,
                       "data_base": base})
    return pd.DataFrame(linhas)


def dados_hoje(hoje=None):
    """A tabela de onde estamos hoje."""
    quando = pd.Timestamp(hoje) if hoje is not None else _ultima_liquidacao()
    return _linhas(_valores_de_hoje(quando), quando.year, quando)


def _ultima_liquidacao():
    l = pd.read_csv(config.PROCESSED_DIR / "leiloes.csv",
                    parse_dates=["data_liquidacao"])
    return l["data_liquidacao"].max()


def quantos_leiloes_entraram(hoje=None):
    """Quantos dias de leilao entraram na rolagem, e de que data ate que data."""
    base, _ = _realizado_do_rmd()
    ate = pd.Timestamp(hoje) if hoje is not None else _ultima_liquidacao()
    l = pd.read_csv(config.PROCESSED_DIR / "leiloes.csv",
                    parse_dates=["data_liquidacao"])
    entre = l[(l["data_liquidacao"] > base) & (l["data_liquidacao"] <= ate)]
    return entre["data_liquidacao"].nunique(), base, ate


def dados_projecao(ate=None, registros=None):
    """A tabela de onde fechamos o ano."""
    ate = pd.Timestamp(ate) if ate is not None else pd.Timestamp(
        f"{_ultima_liquidacao().year}-12-31")
    p = rolagem.projecao(ate, registros=registros)
    valores = {"prefixado_pct": p["percentual"]["Prefixado"],
               "indice_precos_pct": p["percentual"]["Índice Preços"],
               "taxa_flutuante_pct": p["percentual"]["Taxa Flutuante"],
               "cambio_pct": None, "prazo_medio_anos": None,
               "vincendo_12m_pct": None,
               "estoque_bilhoes": p["estoque"].sum() / 1000}
    d = _linhas(valores, ate.year)
    d.attrs["premissa"] = p
    return d


def _numero(valor, unidade):
    casas = 0 if unidade == "R$ bi" else 2
    return estilo.num_br(valor, casas)


def tabela(dados, ident, rodape=""):
    """A tabela em HTML, com a linha nao rolada marcada."""
    cabec = ("<tr><th>indicador</th><th class='n'>no RMD</th>"
             "<th class='n'>hoje</th><th class='n'>banda</th>"
             "<th class='n'>dist\u00e2ncia</th></tr>")
    linhas = []
    for _, r in dados.iterrows():
        marca = "" if r["rolado"] else " class='parado'"
        nota = "" if r["rolado"] else " *"
        dist = ("dentro" if r["distancia"] == 0
                else _numero(r["distancia"], r["unidade"]) + " " + r["unidade"])
        linhas.append(
            f"<tr{marca}><td>{r['indicador']}{nota}</td>"
            f"<td class='n'>{_numero(r['no_rmd'], r['unidade'])}</td>"
            f"<td class='n'>{_numero(r['hoje'], r['unidade'])}</td>"
            f"<td class='n'>{_numero(r['minimo'], r['unidade'])} a "
            f"{_numero(r['maximo'], r['unidade'])}</td>"
            f"<td class='n'>{dist}</td></tr>")
    return (f"<div id='{ident}'><table>{cabec}{''.join(linhas)}</table>"
            f"<p class='rodape'>{rodape}</p></div>")
```

**Prazo médio e vincendo em 12 meses não são rolados** nesta entrega, e aparecem
marcados com asterisco, pelo mesmo critério do câmbio. Rolá-los exigiria recalcular
o prazo papel a papel, que é trabalho da entrega 5. Isso está no §7.1 da spec.

- [ ] **Passo 4: rodar e ver passar**

PowerShell:

```powershell
$env:PYTHONPATH="src"; python -m pytest tests/test_painel_paf.py -q
```

bash:

```bash
PYTHONPATH=src python -m pytest tests/test_painel_paf.py -q
```

Esperado: 4 passed.

- [ ] **Passo 5: verificar dentes**

Em `distancia`, troque o `return 0.0` final por `return valor - (minimo + maximo)/2`.
O primeiro teste tem de reprovar. Desfaça.

- [ ] **Passo 6: commitar**

```bash
git add src/tesouro/graficos/banda.py tests/test_painel_paf.py
git commit -m "A distancia ate a banda, e as duas tabelas"
```

---


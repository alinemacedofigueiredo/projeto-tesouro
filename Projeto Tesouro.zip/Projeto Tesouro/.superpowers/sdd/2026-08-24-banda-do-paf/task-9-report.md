# Task 9: graficos/banda.py -- a distancia, e as duas tabelas

## Status

DONE. Um commit, arvore limpa depois. 8 testes passam em
`tests/test_painel_paf.py` (33s -- nao chegou perto de 60s).

## Commit

- `441e2e7` -- "A distancia ate a banda, e as duas tabelas" (2 files changed,
  386 insertions: `src/tesouro/graficos/banda.py`, `tests/test_painel_paf.py`)

## Comandos rodados e saida

Ver falhar (modulo nao existia):

    PYTHONPATH=src python -m pytest tests/test_painel_paf.py -q
    ModuleNotFoundError: No module named 'tesouro.graficos.banda'

Ver passar, depois de implementar:

    PYTHONPATH=src python -m pytest tests/test_painel_paf.py -q
    ........
    8 passed in 32-34s (variou entre execucoes, sempre bem abaixo de 60s)

Colecao da suite inteira, so para confirmar que nada quebrou na importacao:

    PYTHONPATH=src python -m pytest tests/ -q --collect-only
    749 tests collected in 5.63s

Nao rodei a suite completa (9-10 minutos de SVG) -- instrucao explicita foi
rodar so `tests/test_painel_paf.py`.

## O que o brief previa e eu NAO copiei verbatim

O Passo 3 do brief trazia uma amostra de codigo com dois defeitos que eu
corrigi antes de implementar, porque contradiziam as duas decisoes da dona
do projeto que o proprio brief lista antes da amostra:

1. **`nota = " *"` para os indicadores parados, em vez da data.** A amostra
   marcava cambio/prazo medio/vincendo com um asterisco solto. Isso e
   exatamente o que os rulings 17 (progress.md) e a decisao 2 do brief
   dizem para NAO fazer -- "3,57 anos (30/06)", nao asterisco. Implementei
   `hoje += f" ({r['data_base']:%d/%m})"` na celula, so para as linhas com
   `rolado=False`.

2. **`tabela()` da amostra nao gerava rodape nenhum sozinha.** O teste dado
   no proprio brief (`test_a_tabela_diz_DE_QUANDO_e_o_hoje_e_quantos_leiloes_
   entraram`) exige `"leil" in html` e `"20" in html`, mas a amostra so tinha
   um parametro `rodape=""` que ninguem preenche na chamada do teste
   (`banda.tabela(banda.dados_hoje(), "tabela-hoje")`, dois argumentos). Com
   a amostra como estava, esse teste reprovaria. Implementei
   `_rodape_automatico(dados)`, que le `dados.attrs` (que `dados_hoje()` e
   `dados_projecao()` preenchem) e monta o texto sozinha -- "quantos leiloes
   entraram" para a tabela de hoje, a premissa (Selic/inflacao/curva/pace)
   para a de projecao.

3. **A amostra usava `estilo.num_br` sem importar `estilo`.** Acrescentei
   `from . import estilo, paf`.

4. **O denominador de `_realizado_do_rmd` somava TODAS as colunas do
   `composicao_dpf.csv`** (`comp.sum(axis=1)`), incluindo `"Demais"`, um
   indexador que existe no CSV mas fica fora de `rolagem.INDEXADORES` e
   `rolagem.PARADOS`. Troquei para somar so as quatro colunas que a rolagem
   move ou segura (`list(rolagem.INDEXADORES) + list(rolagem.PARADOS)`), a
   MESMA base que `rolagem.estoque_em()` usa para o total de hoje. Hoje
   `"Demais"` esta zerado na data mais recente (conferi), entao os dois
   metodos dao o mesmo numero agora -- mas o denominador ficaria
   inconsistente entre a linha "hoje" e a linha "no RMD" se `"Demais"`
   deixar de ser zero num mes futuro, e ninguem acusaria isso silenciosamente
   se eu tivesse deixado como a amostra trazia.

## Escolhas minhas que o brief nao especificava

- **A unidade da faixa aparece uma vez so** ("R$ 9.700 a 10.300 bi", nao
  "9.700 a R$ 10.300 bi"). Escrevi isso errado numa primeira versao (unidade
  so na segunda ponta) e corrigi depois de olhar o HTML renderizado --
  registrado aqui porque nao ha teste travando o formato da celula de banda,
  entao um regressao futura nesse ponto especifico passaria em silencio.
- **O rotulo da terceira coluna muda**: "hoje" na tabela de agora,
  "projetado" na de fechamento -- `dados.attrs` diz qual e qual.
- **Testes alem dos quatro do brief**: acrescentei tres --
  `test_prazo_medio_e_vincendo_mostram_a_DATA_e_nao_asterisco` (trava a
  decisao 2 diretamente, com o formato "(DD/MM)"),
  `test_dados_projecao_exercita_o_caminho_real_sem_tocar_rede` (o brief nao
  tinha teste NENHUM chamando `dados_projecao`; dado o padrao repetido nesta
  branch de "caminho nunca exercitado" -- ver rulings 1 e 14 no
  progress.md -- achei arriscado deixar essa funcao publica sem nenhum teste
  passando por ela), `test_o_estoque_projetado_sai_como_numero_e_o_rodape_
  diz_a_premissa` e `test_a_tabela_de_projecao_nao_e_identica_a_de_hoje`
  (trava que a tabela de projecao nao e uma copia da de hoje com o `ident`
  trocado).

## Verificacao de dentes

**`distancia`, linha 51 (a exigida pelo Passo 5 do brief).** Troquei
`return 0.0` por `return valor - (minimo + maximo) / 2`:

    PYTHONPATH=src python -m pytest tests/test_painel_paf.py -q -k distancia
    F
    assert 0.5 == 0.0
    1 failed, 7 deselected in 1.26s

Desfiz a mutacao (`cp` do backup) e confirmei os 8 testes passando de novo.

**`_rodape_automatico`, mutada para `return ""` sempre** (verificando que os
tres testes que dependem do rodape de fato prendem o comportamento, e nao
so a presenca do parametro `rodape=""`):

    PYTHONPATH=src python -m pytest tests/test_painel_paf.py -q
    FAILED test_a_tabela_diz_DE_QUANDO_e_o_hoje_e_quantos_leiloes_entraram
    FAILED test_o_estoque_projetado_sai_como_numero_e_o_rodape_diz_a_premissa
    FAILED test_a_tabela_de_projecao_nao_e_identica_a_de_hoje
    3 failed, 5 passed in 34.51s

Desfiz a mutacao.

**A celula de "hoje" das linhas paradas, trocada de volta para o asterisco
da amostra original** (`hoje += " *"` em vez de
`hoje += f" ({r['data_base']:%d/%m})"`):

    PYTHONPATH=src python -m pytest tests/test_painel_paf.py -q -k prazo_medio_e_vincendo
    F
    assert '(30/06)' in "...Câmbio...(30/06)..." -- nao achou
    1 failed, 7 deselected in 2.62s

Desfiz a mutacao. `git status --short` limpo e `git diff --stat` vazio antes
do commit final, confirmando que nenhuma mutacao ficou para tras.

## Numeros medidos, para conferencia cruzada com a Task 8

A tabela de projecao (`dados_projecao(registros=[])`, sem tocar rede) da
estoque projetado de **9.840,08 bi**, contra os **9.840,1 bi** que o
progress.md registra como medido independentemente na Task 8 (secao
"RETOMADA. E um achado que muda a resposta da entrega"). Bate.

A tabela de hoje (`dados_hoje()`, ate a ultima liquidacao 17/08/2026) mostra
28 dias de leilao entrados desde a data-base do RMD (30/06/2026), e o
estoque rolado de **9.089,99 bi**, que bate com os 9.090,0 bi que a Task 8
tambem media de forma independente para a mesma data.

Prefixado hoje: 20,15% (banda 21-25, FORA por baixo, distancia -0,85 pp).
Taxa Flutuante hoje: 52,81% (banda 46-50, FORA por cima, distancia +2,81
pp). Indice de Precos, cambio, prazo medio e vincendo em 12 meses: todos
DENTRO da banda 2026 hoje.

## Preocupacoes

- **A celula de banda para "R$ bi" nao tem teste proprio** travando o
  formato exato ("R$ 9.700 a 10.300 bi"). Os testes que tenho cobrem que o
  numero certo aparece em algum lugar do HTML (`"153" in html`), mas nao a
  disposicao exata de cada celula da tabela -- um erro de formatacao futuro
  nessa celula especifica nao seria pego.
- **`quantos_leiloes_entraram` e `_ultima_liquidacao` le `leiloes.csv` mais
  de uma vez por chamada de `dados_hoje()`** (uma vez dentro de
  `quantos_leiloes_entraram`, outra dentro dela mesma para achar `base` via
  `_realizado_do_rmd`, que tambem le varios CSVs). Nao otimizei -- o arquivo
  e pequeno e a suite roda em 33s -- mas registro caso isso vire gargalo
  quando a Task 10 montar a pagina inteira chamando estas funcoes varias
  vezes.
- **O denominador com `"Demais"` excluido (item 4 acima) e uma correcao
  minha, nao pedida explicitamente pelo brief.** Hoje nao muda numero
  nenhum (Demais = 0 na data mais recente), entao o risco de eu estar
  errado e baixo, mas nao ha teste cravando esse comportamento -- so
  descobri a diferenca inspecionando o CSV manualmente antes de escrever o
  codigo.
- Nao toquei `precificacao.py` nem `leiloes_dv.py`, confirmado por
  `git status --short` mostrando so os dois arquivos-alvo no commit.

## Rodada de revisao: dois Importants, os dois de teste

Commit: `307c180` -- "Resposta ao revisor: dois Importants em banda.py"
(2 files changed, 54 insertions(+), 4 deletions(-)).

### Important 1 -- `"20" in html` casava com "2026"

`test_a_tabela_diz_DE_QUANDO_e_o_hoje_e_quantos_leiloes_entraram` afirmava
`"20" in html` para travar a contagem de leiloes entrados. O revisor mutou
`quantos_leiloes_entraram` para devolver `999999` e o teste passou -- `"20"`
casa com qualquer data de 2026 no rodape, nao so com a contagem.

Troquei por uma recontagem independente, dentro do proprio teste: le
`leiloes.csv` de novo, filtra `(data_liquidacao > base) & (data_liquidacao <=
hoje)` usando `d.attrs["leiloes_de"]`/`d.attrs["hoje"]` (as fronteiras, nao a
contagem), e afirma que ESSE numero recalculado aparece no HTML. Nao chama
`banda.quantos_leiloes_entraram()` em nenhum momento -- se os dois lados
chamassem a mesma funcao, a mutacao moveria os dois juntos, do jeito que ja
custou uma rodada na Task 8 (rolagem.projecao).

**Verificacao de dentes**, `quantos_leiloes_entraram` mutada para
`return 999999, base, ate`:

    PYTHONPATH=src python -m pytest tests/test_painel_paf.py -q -k DE_QUANDO
    F
    assert '28' in "...999999 dia(s) de leilao entraram..."
    1 failed, 8 deselected in 2.22s

Desfeita a mutacao antes de seguir.

### Important 2 -- o denominador corrigido nao estava travado

O revisor mutou `_realizado_do_rmd` de volta para somar TODAS as colunas do
`composicao_dpf.csv` (a versao que eu tinha corrigido na rodada anterior) e
os 8 testes continuaram verdes -- porque `Demais` esta zerada desde 06/2006
(medido), entao os dois denominadores dao o MESMO NUMERO com o dado de hoje.
Nenhum teste de valor consegue distinguir os dois.

Segui a saida que o revisor sugeriu: travar por ESTRUTURA, nao por valor.
Extrai a checagem para `_confere_colunas_do_denominador(colunas)`, uma
funcao pura que recebe a lista de colunas e levanta `ValueError` se o
conjunto divergir de `set(rolagem.INDEXADORES) | set(rolagem.PARADOS)`.
`_realizado_do_rmd` chama essa guarda logo depois de montar `colunas` e antes
de somar. Acrescentei um teste que exercita a guarda EM ISOLAMENTO --
`banda._confere_colunas_do_denominador(...)` chamada direto com uma lista
certa (nao levanta) e duas erradas (levanta) -- sem depender de
`_realizado_do_rmd` nem de nenhum valor do CSV.

**Por que direto na funcao, e nao testando `_realizado_do_rmd` de fora**: um
teste de caixa-preta chamando `dados_hoje()` normalmente NUNCA vai ver a
guarda disparar (ela so dispara se o CODIGO for mutado, e pytest so executa
o codigo como esta escrito). A guarda existe para transformar uma mutacao
futura de "numero errado em silencio" em "toda a suite quebra alto" -- e
isso so se mede mutando de verdade, nao com um pytest padrao.

**Verificacao de dentes, duas partes:**

1. O teste novo, isolado, contra a guarda com uma lista errada (jeito
   normal de rodar):

       PYTHONPATH=src python -m pytest tests/test_painel_paf.py -q -k denominador
       1 passed, 8 deselected in 1.58s

2. `colunas = list(rolagem.INDEXADORES) + list(rolagem.PARADOS)` mutada para
   `colunas = list(comp.columns)` (a mutacao real do revisor, que inclui
   'Demais'), suite inteira:

       PYTHONPATH=src python -m pytest tests/test_painel_paf.py -q
       ValueError: _realizado_do_rmd: o denominador tem de somar exatamente
       ['Câmbio', 'Prefixado', 'Taxa Flutuante', 'Índice Preços'], e recebeu
       ['Câmbio', 'Demais', 'Prefixado', 'Taxa Flutuante', 'Índice Preços'].
       7 failed, 2 passed in 22.19s

   Os 7 que falham sao todos os que passam por `_realizado_do_rmd` (direta
   ou indiretamente via `dados_hoje`/`dados_projecao`); os 2 que continuam
   verdes sao `test_a_distancia_...` (nao toca CSV) e o proprio teste da
   guarda em isolamento (que testa a funcao pura, nao a fiacao dela dentro
   de `_realizado_do_rmd` -- por isso nao pega essa mutacao especifica, como
   esperado e registrado acima).

Desfeita a mutacao (`cp` do backup), confirmado `diff` vazio contra o backup
antes de reaplicar, e suite completa:

    PYTHONPATH=src python -m pytest tests/test_painel_paf.py -q
    .........
    9 passed in 32-50s (variou entre execucoes, sempre bem abaixo de 60s)

`git status --short` limpo depois do commit `307c180`.

### Preocupacoes desta rodada

- O teste da guarda (`test_o_denominador_do_RMD_e_travado_por_ESTRUTURA_
  nao_por_valor`) nao pega, sozinho, uma mutacao que troque `colunas` DENTRO
  de `_realizado_do_rmd` (ele testa a funcao pura, nao a fiacao). Quem pega
  essa mutacao especifica sao os OUTROS 7 testes da suite, que passam a
  falhar em cascata com `ValueError` em vez de silenciosamente aceitar o
  numero errado -- essa e a defesa real, e e mais forte do que um teste de
  valor teria sido, mas e uma defesa indireta (falha alta, nao um teste que
  aponta exatamente para o denominador).

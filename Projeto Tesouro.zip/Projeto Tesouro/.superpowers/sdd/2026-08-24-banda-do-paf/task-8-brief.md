### Task 8: `rolagem.py` — a projeção até o fim do ano

**Arquivos:**
- Modificar: `src/tesouro/rolagem.py`
- Teste: `tests/test_rolagem.py`

**Interfaces:**
- Consome: `estoque_em` (Task 7), `calendario_leiloes.dias_ate` (Task 4),
  `curva.selic_implicita` e `curva.inflacao_implicita` (Task 5)
- Produz: `LEILOES_DO_PACE: int`; `pace(quando) -> pd.Series`;
  `projecao(ate, hoje=None, registros=None) -> dict`

- [ ] **Passo 0: consertar `curva._curva` antes de tudo**

Achado por mim ao varrer o brief, e é **bloqueante**: `_curva` casa a data-base por
igualdade exata, e isso quebra nos dois caminhos que esta tarefa precisa.

**No backtest:** `composicao_dpf.csv` usa o último dia **corrido** do mês e
`dv_por_papel.csv` usa o último dia **útil**. Em 2024 eles divergem — 30/06/2024 caiu
num domingo, então o `dv_por_papel` tem 28/06. `curva.selic_implicita(data_base=
30/06/2024)` levanta `LookupError`.

**No caminho real, que é pior:** a projeção parte da última **liquidação**, que hoje
é 17/08/2026, e o `dv_por_papel` termina em 30/06/2026. O caminho principal da
entrega levantaria `LookupError` — e nenhum teste o exercitava.

Mude `_curva(titulo, data_base=None)` para usar a **data mais recente menor ou igual
a `data_base`**, em vez de igualdade exata:

```python
def _curva(titulo, data_base=None):
    """Os papeis COM COTACAO na data-base, ordenados por dias uteis ate o vencimento.

    A DATA-BASE E A MAIS RECENTE MENOR OU IGUAL a pedida, e nao igualdade exata. Dois
    motivos, e os dois quebravam:

    O composicao_dpf.csv usa o ultimo dia CORRIDO do mes e o dv_por_papel.csv usa o
    ultimo dia UTIL. Em 30/06/2024 -- um domingo -- eles divergem, e o backtest
    levantava LookupError num ano que existe nos dois arquivos.

    E a projecao real parte da ultima LIQUIDACAO, que vai alem do ultimo RMD. A curva
    termina no RMD. Exigir igualdade fazia o caminho principal da entrega levantar.

    Quem chama recebe de volta a data que de fato valeu, porque uma curva de sete
    semanas atras apresentada como "de hoje" e o tipo de coisa que a pagina inteira
    existe para nao fazer.
    """
    d = pd.read_csv(config.PROCESSED_DIR / "dv_por_papel.csv",
                    parse_dates=["data", "vencimento"])
    pedida = pd.Timestamp(data_base) if data_base is not None else d["data"].max()
    disponiveis = d.loc[d["data"] <= pedida, "data"]
    if disponiveis.empty:
        raise LookupError(
            f"nao ha curva ate {pedida:%d/%m/%Y} no dv_por_papel.csv. Sem curva nao "
            f"ha premissa, e projetar com premissa inventada seria pior.")
    base = disponiveis.max()
    g = d[(d["data"] == base) & (d["titulo"] == titulo)
          & d["taxa_pct"].notna()].copy()
    if g.empty:
        raise LookupError(
            f"nenhuma {titulo} com cotacao em {base:%d/%m/%Y}. Sem curva nao ha "
            f"premissa, e projetar com premissa inventada seria pior.")
    cal = calendario.padrao()
    g["du"] = [cal.du(base.date(), v.date()) for v in g["vencimento"]]
    return base, g.sort_values("du")
```

E acrescente `data_da_curva(data_base=None) -> pd.Timestamp`, que devolve a data que
`_curva` de fato usaria — a projeção precisa dela para a página dizer de quando é a
curva.

Testes que vão junto:

```python
def test_a_curva_aceita_data_base_que_nao_existe_no_arquivo():
    # O composicao_dpf usa o ultimo dia CORRIDO e o dv_por_papel o ultimo dia UTIL.
    # 30/06/2024 caiu num domingo: existe num e nao no outro. E a projecao real parte
    # da ultima LIQUIDACAO, que vai alem do ultimo RMD -- o caminho principal da
    # entrega levantava LookupError, e nenhum teste o exercitava.
    from tesouro import curva

    assert curva.data_da_curva(pd.Timestamp("2024-06-30")) == pd.Timestamp("2024-06-28")
    assert curva.selic_implicita(pd.Timestamp("2024-12-31"),
                                 data_base=pd.Timestamp("2024-06-30")) > 0

    # E alem do fim do arquivo: a curva mais recente vale, e quem chama fica sabendo.
    depois = pd.Timestamp("2026-08-17")
    usada = curva.data_da_curva(depois)
    assert usada < depois
    assert curva.selic_implicita(pd.Timestamp("2026-12-31"), data_base=depois) > 0


def test_sem_curva_nenhuma_ate_a_data_ele_LEVANTA():
    from tesouro import curva

    with pytest.raises(LookupError, match="curva"):
        curva.data_da_curva(pd.Timestamp("1999-01-01"))
```

Verifique os dentes: volte `_curva` para igualdade exata e confirme que o primeiro
teste reprova.

- [ ] **Passo 1: escrever o teste que falha**

```python
def test_o_pace_e_por_PAPEL_e_nao_por_dia_de_leilao():
    # Decisao dela. O metodo anterior media por DIA DE LEILAO contando os zeros --
    # nos dias de terca o prefixado vale zero -- e so dava certo se a mistura de
    # tercas e quintas da janela batesse com a do futuro. Batia por sorte: 10 e 10,
    # contra 18 e 18 no futuro.
    #
    # Medir sobre os leiloes DAQUELE papel nao depende de mistura, e rende numero que
    # se confere de cabeca: 1,09 bi por leilao de NTN-B, e nao 0,21 por dia.
    assert rolagem.LEILOES_DO_PACE == 10
    p = rolagem.pace(pd.Timestamp("2026-08-17"))
    for ind in rolagem.INDEXADORES:
        assert p[ind] > 0, ind
    # A ordem de grandeza medida em 17/08/2026: a LFT coloca 21,91 bi por leilao, o
    # prefixado 12,32 e a NTN-B 1,09. Se essa relacao inverter, alguem trocou o
    # denominador -- que e exatamente o defeito que este metodo veio corrigir.
    assert p["Índice Preços"] * 5 < p["Taxa Flutuante"]
    assert p["Índice Preços"] * 3 < p["Prefixado"]


def test_a_contagem_de_leiloes_futuros_e_por_PAPEL():
    # Prefixado na quinta, indexados na terca. Numa janela com 18 de cada, cada papel
    # tem 18 leiloes -- e nao os 36 dias.
    from tesouro import calendario_leiloes

    dias = calendario_leiloes.dias_estimados(pd.Timestamp("2026-08-18"),
                                             pd.Timestamp("2026-12-31"))
    assert len(dias) == 36
    for ind in rolagem.INDEXADORES:
        quantos = rolagem.leiloes_que_faltam(dias, ind)
        assert 15 <= quantos <= 20, (ind, quantos)
        assert quantos < len(dias), "contou dia de leilao, e nao leilao do papel"


def test_o_ESTOQUE_sai_como_FAIXA_e_os_outros_como_numero():
    # Spec 5.5. O estoque em reais e o unico indicador em que a premissa move quase
    # a largura da banda: congelar da 9.339 bi e apropriar da 9.850, contra uma
    # banda de 9.700 a 10.300. Nos percentuais a mesma premissa vale 0,2 pp contra
    # bandas de 4 pp, e a faixa seria mais larga que a informacao.
    p = rolagem.projecao(pd.Timestamp("2026-12-31"), registros=[])
    assert "estoque_faixa" in p
    baixo, alto = p["estoque_faixa"]
    assert baixo < alto
    assert baixo < p["estoque"].sum() <= alto or baixo <= p["estoque"].sum() < alto
    # A faixa vem de um cenario de Selic mais baixa, e nao de um numero inventado.
    assert p["selic_do_piso"] == pytest.approx(p["selic"] - rolagem.CENARIO_SELIC)


def test_a_projecao_devolve_a_PREMISSA_que_usou():
    # Numero projetado sem a premissa ao lado e opiniao com cara de medida.
    p = rolagem.projecao(pd.Timestamp("2026-12-31"), registros=[])
    assert 0.05 < p["selic"] < 0.30
    assert 0.0 < p["inflacao"] < 0.15
    assert p["dias_de_leilao"] > 0
    assert "fronteira_do_calendario" in p
    # A data da curva viaja junto: ela termina no ultimo RMD e a projecao parte da
    # ultima liquidacao, semanas depois.
    assert p["data_da_curva"] <= p["de"]
```

- [ ] **Passo 2: rodar e ver falhar**

PowerShell:

```powershell
$env:PYTHONPATH="src"; python -m pytest tests/test_rolagem.py -q -k "pace or projecao"
```

bash:

```bash
PYTHONPATH=src python -m pytest tests/test_rolagem.py -q -k "pace or projecao"
```

Esperado: FAIL, `has no attribute 'LEILOES_DO_PACE'`.

- [ ] **Passo 3: implementar**

```python
# Quantos dias de leilao entram na media do pace.
#
# VINTE, escolha dela: sao cerca de dez semanas e dez leiloes de cada papel. O
# backtest de dez anos NAO DISTINGUE as janelas -- 10, 20 e 60 dias de leilao e 26
# semanas caem todos na mesma faixa de erro (1,26 a 1,71 pp no prefixado) -- entao a
# escolha e por ser a unidade em que se pensa, e por lidar sozinha com semana de
# feriado e com dezembro, que tem menos leilao.
LEILOES_DO_PACE = 10

# EM QUE DIA DA SEMANA CADA PAPEL VAI A LEILAO. Regra do Tesouro, descrita pela dona
# do projeto e medida nos ultimos dois anos:
#
#     prefixado (LTN e NTN-F)   quinta-feira   91% dos 104 leiloes
#     NTN-B                     terca-feira    95% dos 101
#     LFT                       terca-feira    99% dos  98
#
# Feriado que antecipa o leilao em um dia util nao muda nada aqui: o que se conta e
# quantos leiloes DAQUELE PAPEL faltam, e nao em que dia da semana caem.
DIA_DO_PAPEL = {"Prefixado": 3, "\u00cdndice Pre\u00e7os": 1, "Taxa Flutuante": 1}

# De quanto e o cenario alternativo que da o piso da faixa do estoque.
CENARIO_SELIC = 0.02

def pace(quando):
    """Financeiro liquido medio por LEILAO DAQUELE PAPEL, por indexador.

    OS ZEROS NAO ENTRAM NA MEDIA. Um dia de terca em que o prefixado nao foi a leilao
    nao e um leilao de prefixado de valor zero: e um dia em que ele nao foi ofertado.
    Contar o zero fazia a media depender da mistura de tercas e quintas da janela --
    batia por sorte (10 e 10, contra 18 e 18 no futuro), e uma janela com 15 tercas e
    5 quintas subestimaria o prefixado em quase metade, sem nada acusar.

    Medido em 17/08/2026: prefixado 12,32 bi por leilao, indice de precos 1,09, taxa
    flutuante 21,91.
    """
    l = pd.read_csv(config.PROCESSED_DIR / "leiloes.csv",
                    parse_dates=["data_leilao", "data_liquidacao"])
    l = l[l["data_liquidacao"] <= pd.Timestamp(quando)].copy()
    l["indexador"] = [_INDEXADOR_DO_TITULO.get(t) for t in l["titulo"]]
    l["sinal"] = [_SINAL.get(t, 0) for t in l["tipo_leilao"]]
    l = l[l["indexador"].notna()]
    l["fluxo"] = l["financeiro_milhoes"] * l["sinal"]

    por_leilao = l.pivot_table(index="data_leilao", columns="indexador",
                               values="fluxo", aggfunc="sum")
    saida = {}
    for ind in INDEXADORES:
        if ind not in por_leilao.columns:
            raise LookupError(f"nenhum leilao de {ind} ate {quando:%d/%m/%Y}.")
        dele = por_leilao[ind].dropna()
        dele = dele[dele != 0].tail(LEILOES_DO_PACE)
        if len(dele) < LEILOES_DO_PACE:
            raise LookupError(
                f"so ha {len(dele)} leiloes de {ind} ate {quando:%d/%m/%Y}, e o "
                f"pace pede {LEILOES_DO_PACE}.")
        saida[ind] = dele.mean()
    return pd.Series(saida)


def leiloes_que_faltam(dias, indexador):
    """Quantos dos dias de leilao levam AQUELE papel.

    O prefixado vai a leilao na quinta e os indexados na terca -- regra do Tesouro,
    medida em 91% a 99% dos ultimos dois anos. Feriado que antecipa o leilao em um
    dia util nao muda a conta: o que importa e quantos leiloes daquele papel faltam.
    """
    alvo = DIA_DO_PAPEL[indexador]
    return sum(1 for d in dias if pd.Timestamp(d).dayofweek == alvo)


def projecao(ate, hoje=None, registros=None):
    """O estoque projetado para 'ate', com a premissa que usou ao lado.

    A PREMISSA VIAJA JUNTO de proposito. Numero projetado sem ela e opiniao com cara
    de medida -- e no estoque em reais ela vale quase a largura da banda: congelar
    da 9.339 bi e apropriar da 9.850, contra uma banda de 9.700 a 10.300.
    """
    from . import calendario_leiloes, curva, fluxos

    ate = pd.Timestamp(ate)

    # A PROJECAO COMECA DE HOJE, e nao da data-base do RMD. Comecando do RMD, o
    # pace seria aplicado tambem aos dias de leilao que JA ACONTECERAM entre a
    # data-base e hoje -- trocando seis semanas de leilao medido por estimativa. E
    # os dois blocos da mesma pagina partiriam de lugares diferentes.
    #
    # 'hoje' existe para o BACKTEST, em que quem chama quer comecar numa data de
    # RMD de proposito, para comparar com o dezembro que de fato aconteceu.
    if hoje is not None:
        partida = pd.Timestamp(hoje)
        c = pd.read_csv(config.PROCESSED_DIR / "composicao_dpf.csv",
                        parse_dates=["data"])
        piv = c.pivot_table(index="data", columns="indexador",
                            values="valor_milhoes", aggfunc="sum").fillna(0.0)
        inicial = piv.loc[partida]
    else:
        l = pd.read_csv(config.PROCESSED_DIR / "leiloes.csv",
                        parse_dates=["data_liquidacao"])
        partida = l["data_liquidacao"].max()
        inicial = estoque_em(partida)

    dias, fronteira = calendario_leiloes.dias_ate(ate, registros=registros,
                                                  hoje=partida)
    quantos = len(dias)
    ritmo = pace(partida)
    pagou = fluxos.pagos(partida, ate)
    selic = curva.selic_implicita(ate, data_base=partida)
    inflacao = curva.inflacao_implicita(ate, data_base=partida)
    cal = calendario.padrao()
    du = cal.du(partida.date(), ate.date())

    projetado = {}
    for ind in INDEXADORES:
        base = float(inicial[ind])
        do_ind = pagou[pagou["indexador"] == ind]
        pago = do_ind["principal_milhoes"].sum() + do_ind["cupom_milhoes"].sum()
        if ind == "Taxa Flutuante":
            taxa = selic
        elif ind == "Índice Preços":
            taxa = (1 + inflacao) * 1.06 - 1
        else:
            taxa = _CARGA_DO_PREFIXADO
        juros = base * ((1 + taxa) ** (du / 252) - 1)
        projetado[ind] = (base + float(ritmo[ind])
                          * leiloes_que_faltam(dias, ind) - pago + juros)
    for ind in PARADOS:
        projetado[ind] = float(inicial[ind])

    total = sum(projetado.values())
    # O ESTOQUE SAI COMO FAIXA, e os outros como numero. Ver spec 5.5: e o unico
    # indicador em que a premissa vale quase a largura da banda -- 511 bi de
    # diferenca contra uma banda de 600. Nos percentuais a mesma premissa vale
    # 0,2 pp contra bandas de 4 pp, e a faixa seria mais larga que a informacao.
    piso = 0.0
    for ind in INDEXADORES:
        base = float(inicial[ind])
        do_ind = pagou[pagou["indexador"] == ind]
        pago = do_ind["principal_milhoes"].sum() + do_ind["cupom_milhoes"].sum()
        if ind == "Taxa Flutuante":
            taxa = selic - CENARIO_SELIC
        elif ind == "Índice Preços":
            taxa = (1 + inflacao) * 1.06 - 1
        else:
            taxa = _CARGA_DO_PREFIXADO
        piso += (base + float(ritmo[ind]) * leiloes_que_faltam(dias, ind)
                 - pago + base * ((1 + taxa) ** (du / 252) - 1))
    piso += sum(float(inicial[i]) for i in PARADOS)

    return {"estoque": pd.Series(projetado),
            "estoque_faixa": (piso, total),
            "percentual": pd.Series({k: 100 * v / total
                                     for k, v in projetado.items()}),
            "selic": selic, "selic_do_piso": selic - CENARIO_SELIC,
            "inflacao": inflacao,
            # DE QUANDO E A CURVA. Ela termina no ultimo RMD e a projecao parte da
            # ultima liquidacao: sao semanas de diferenca, e apresentar premissa de
            # sete semanas atras como "de hoje" e o tipo de coisa que esta pagina
            # existe para nao fazer.
            "data_da_curva": curva.data_da_curva(partida),
            "dias_de_leilao": quantos,
            "fronteira_do_calendario": fronteira,
            "de": partida, "ate": ate}
```

- [ ] **Passo 4: rodar e ver passar**

PowerShell:

```powershell
$env:PYTHONPATH="src"; python -m pytest tests/test_rolagem.py -q
```

bash:

```bash
PYTHONPATH=src python -m pytest tests/test_rolagem.py -q
```

Esperado: 8 passed.

- [ ] **Passo 5: verificar dentes**

Troque `LEILOES_DO_PACE` por `1`. O teste da projeção tem de reprovar em pelo menos
um ano. Desfaça.

- [ ] **Passo 6: commitar**

```bash
git add src/tesouro/rolagem.py tests/test_rolagem.py
git commit -m "A projecao ate o fim do ano, com a premissa ao lado"
```

---


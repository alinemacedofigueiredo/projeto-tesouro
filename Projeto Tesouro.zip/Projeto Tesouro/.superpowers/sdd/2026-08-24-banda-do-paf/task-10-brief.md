### Task 10: `painel_paf.py` — a página `paf.html`

**Arquivos:**
- Criar: `src/tesouro/graficos/painel_paf.py`
- Modificar: `src/tesouro/graficos/dashboard.py` (a lista `PAGINAS`)
- Modificar: `src/tesouro/pipeline.py`
- Teste: `tests/test_painel_paf.py`

**Interfaces:**
- Consome: `banda.dados_hoje`, `banda.dados_projecao`, `banda.tabela`,
  `dashboard.grava`
- Produz: `ARQUIVO = "paf.html"`; `grava(caminho=None, hoje=None) -> Path`

- [ ] **Passo 1: escrever o teste que falha**

```python
@pytest.fixture(scope="module")
def pagina(tmp_path_factory):
    from tesouro.graficos import painel_paf

    destino = tmp_path_factory.mktemp("paf") / painel_paf.ARQUIVO
    return painel_paf.grava(destino).read_text(encoding="utf-8")


def test_a_pagina_tem_os_DOIS_blocos_recolhiveis(pagina):
    # Eram tres na primeira versao da spec. O historico saiu por decisao dela: era
    # analise, e nao monitoramento.
    import re

    corpo = pagina[pagina.index("</header>"):pagina.rindex("</main>")]
    assert corpo.count("<details class=\"secao") == 2
    assert 'id="tabela-hoje"' in pagina
    assert 'id="tabela-projecao"' in pagina
    assert re.search(r"<details class=\"secao[^\"]*\" open>", corpo)


def test_a_pagina_esta_na_barra_e_aponta_para_as_irmas(pagina):
    from tesouro.graficos import dashboard, painel_paf

    assert any(a == painel_paf.ARQUIVO for a, _ in dashboard.PAGINAS)
    assert f'href="{painel_paf.ARQUIVO}"' not in pagina
    for outra, _ in dashboard.PAGINAS:
        if outra != painel_paf.ARQUIVO:
            assert f'href="{outra}"' in pagina


def test_a_pagina_nao_tem_referencia_externa(pagina):
    import re

    externos = [m.group(1) for m in
                re.finditer(r'(?:src|href|xlink:href)\s*=\s*"([^"]*)"', pagina)
                if "://" in m.group(1)]
    assert externos == [], externos[:3]


def test_a_pagina_cabe_no_limiar_de_dez_megabytes(tmp_path):
    from tesouro.graficos import painel_paf

    caminho = painel_paf.grava(tmp_path / painel_paf.ARQUIVO)
    tamanho = caminho.stat().st_size
    assert tamanho > 20_000, "a pagina saiu pequena demais; algo nao entrou"
    assert tamanho < 10 * 1024 * 1024


def test_o_achado_do_historico_ficou_como_TEXTO(pagina):
    # O bloco dos sete graficos saiu; o numero fica. 70% pela banda original contra
    # 79% pela vigente, e 14 de 14 inversoes para dentro.
    assert "70%" in pagina and "79%" in pagina
```

- [ ] **Passo 2: rodar e ver falhar**

PowerShell:

```powershell
$env:PYTHONPATH="src"; python -m pytest tests/test_painel_paf.py -q -k "pagina"
```

bash:

```bash
PYTHONPATH=src python -m pytest tests/test_painel_paf.py -q -k "pagina"
```

Esperado: `ModuleNotFoundError: No module named 'tesouro.graficos.painel_paf'`.

- [ ] **Passo 3: implementar**

```python
"""A pagina contra o PAF: onde estamos hoje, e onde fechamos o ano.

E PAGINA PROPRIA, e nao secao do dashboard, por tres razoes que estao na spec 6.4. A
que decide: as entregas 4 e 5 sao a pergunta e a resposta -- "estou dentro?" e "o que
faco para entrar?" -- e a 5 acrescenta um bloco AQUI, em vez de criar outra pagina.

A que quase passou batido: esta pagina muda a cada leilao liquidado, e o dashboard
muda uma vez por mes. Enterrar uma tabela que muda toda semana num arquivo de 4 MB e
reescrever 4 MB para mudar uma linha.
"""

from .. import config
from . import banda, dashboard

ARQUIVO = "paf.html"
GRUPOS = ["Contra o PAF"]
REGISTRO = []

SECOES = [
    ("hoje", "Onde estamos hoje", True),
    ("projecao", "Onde fechamos o ano", False),
]

# O achado do historico, que perdeu os sete graficos e ficou como texto. Ver spec
# 7.3: aquele bloco era analise e nao monitoramento.
_ACHADO = (
    "<p class='achado'>Em 23 anos de PAF, o Tesouro fechou o ano dentro da banda "
    "em <b>70% dos casos pela banda original</b> e <b>79% pela vigente</b>. Em "
    "<b>14 de 14</b> revis\u00f5es que inverteram o veredito, a banda revisada "
    "p\u00f4s o realizado <i>dentro</i> \u2014 nunca fora.</p>")

_CSS = """
#tabela-hoje, #tabela-projecao { margin: 20px auto 30px; max-width: 1180px; }
#tabela-hoje table, #tabela-projecao table { border-collapse: collapse;
  width: 100%; font-size: 13.5px; }
#tabela-hoje th, #tabela-hoje td, #tabela-projecao th, #tabela-projecao td {
  padding: 6px 10px; text-align: left; border-bottom: 1px solid #e6e6e6; }
#tabela-hoje th, #tabela-projecao th { font-weight: 600; color: var(--fraco);
  border-bottom: 2px solid #ccc; }
td.n, th.n { text-align: right; font-variant-numeric: tabular-nums; }
tr.parado td { color: var(--fraco); font-style: italic; }
p.rodape, p.achado { font-size: 12.5px; color: var(--fraco); max-width: 1180px;
  margin: 6px auto 0; }
"""


def _recolhe(conteudo, chave, rotulo, aberta):
    marca = " open" if aberta else ""
    return (f'<details class="secao secao-{chave}"{marca}>'
            f"<summary>{rotulo}</summary>\n{conteudo}\n</details>")


# O RODAPE E DA TABELA, e nao desta pagina. A Task 9 fez `tabela()` monta-lo
# sozinha a partir dos attrs que `dados_hoje` e `dados_projecao` ja carregam -- a
# data do "hoje", quantos dias de leilao entraram na rolagem, e a premissa inteira
# da projecao. Um segundo rodape aqui duplicaria a fonte da verdade, e a pagina
# poderia acabar dizendo uma coisa enquanto a tabela diz outra.


def grava(caminho=None, hoje=None):
    """Grava a pagina do PAF e devolve o caminho."""
    caminho = caminho or (config.PROCESSED_DIR / ARQUIVO)
    escrito = dashboard.grava(caminho, [("paf", None)], REGISTRO, GRUPOS,
                              "Contra o PAF", agrupar=False)
    html = escrito.read_text(encoding="utf-8")

    # ANCORADO NO FIM DO CABECALHO, e nao na abertura do <main>: a marca do main
    # aparece antes, dentro de um comentario do CSS, e o recorte pegava metade da
    # folha de estilo junto. Defeito real, achado em 20/08/2026.
    marca = "</header>"
    inicio = html.index(marca) + len(marca)
    fim = html.rindex("</main>")

    de_hoje = banda.dados_hoje(hoje)
    projetado = banda.dados_projecao()
    corpo = "\n".join([
        _recolhe(banda.tabela(de_hoje, "tabela-hoje"), *SECOES[0]),
        _recolhe(banda.tabela(projetado, "tabela-projecao") + _ACHADO,
                 *SECOES[1]),
    ])
    html = html[:inicio] + "\n" + corpo + "\n" + html[fim:]
    html = html.replace("</style>", _CSS + "</style>", 1)
    escrito.write_text(html, encoding="utf-8")
    return escrito
```

**Nenhuma tag literal dentro de comentário de CSS** — `_CSS` acima não tem
comentários por isso. Um `<main>` dentro de um comentário quebra o recorte, e já
quebrou em 20/08/2026.

Em `dashboard.py`, acrescente a entrada em `PAGINAS`, entre a de funding e a de
emissões:

```python
PAGINAS = [(arquivo, rotulo) for arquivo, rotulo, _, _ in PAGINAS_DO_RMD] + [
    ("paf.html", "contra o PAF"),
    ("emissoes.html", "o que já foi emitido"),
    ("calendario.html", "o calendário"),
]
```

Em `pipeline.py`, depois de `painel_emissoes.grava_todas()`:

```python
        from .graficos import painel_paf
        print(f"pagina do PAF gravada: {painel_paf.grava()}")
```

- [ ] **Passo 4: rodar e ver passar**

PowerShell:

```powershell
$env:PYTHONPATH="src"; python -m pytest tests/test_painel_paf.py -q
```

bash:

```bash
PYTHONPATH=src python -m pytest tests/test_painel_paf.py -q
```

Esperado: 9 passed.

- [ ] **Passo 5: rodar a suíte inteira e regravar as páginas**

PowerShell:

```powershell
$env:PYTHONPATH="src"; python -m pytest -q
```

bash:

```bash
PYTHONPATH=src python -m pytest -q
```

Esperado: tudo passando, e os testes de `test_dashboard.py` que contam as páginas
podem precisar do número novo — ajuste a contagem, não o comportamento.

Depois regrave as páginas e confira o tamanho da nova:

```bash
PYTHONPATH=src python -m tesouro.graficos
```

- [ ] **Passo 6: commitar**

```bash
git add src/tesouro/graficos/painel_paf.py src/tesouro/graficos/dashboard.py src/tesouro/pipeline.py tests/test_painel_paf.py
git commit -m "A pagina contra o PAF, irma do calendario"
```

---

## Depois de todas as tarefas

- [ ] Atualizar o `README.md`: a lista de páginas passa de seis para sete, com o
      tamanho medido de `paf.html`.
- [ ] Conferir no navegador, com o servidor de `.claude/launch.json`: a barra liga
      as sete páginas, a primeira seção abre, e não há rolagem horizontal.
- [ ] Rodar a suíte inteira uma última vez e commitar as páginas regravadas.

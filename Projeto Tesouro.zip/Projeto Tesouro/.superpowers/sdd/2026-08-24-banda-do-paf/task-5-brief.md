### Task 5: `curva.py` — Selic implícita e inflação implícita

**Arquivos:**
- Criar: `src/tesouro/curva.py`
- Teste: `tests/test_curva.py`

**Interfaces:**
- Consome: `dv_por_papel.csv`, `calendario.padrao()`
- Produz:
  - `selic_implicita(ate, data_base=None) -> float` — taxa ao ano, em decimal
  - `inflacao_implicita(ate, data_base=None) -> float`

- [ ] **Passo 1: escrever o teste que falha**

```python
"""A curva do proprio dado: Selic implicita e inflacao implicita."""
import pandas as pd

from tesouro import curva


def test_a_interpolacao_IGNORA_vencimento_sem_cotacao():
    # A ARMADILHA DESTA TAREFA. A LTN de vencimento mais proximo de 31/12/2026 e a
    # 01/01/2027 -- e ela NAO TEM COTACAO: e um dos dois papeis que so existem no
    # Tesouro Direto. Quem escolher "o vencimento mais proximo" pega justamente o
    # que nao tem taxa, e a conta sai NaN sem reclamar.
    from tesouro import config

    d = pd.read_csv(config.PROCESSED_DIR / "dv_por_papel.csv",
                    parse_dates=["data", "vencimento"])
    ult = d[d["data"] == d["data"].max()]
    sem_taxa = ult[(ult["titulo"] == "LTN") & ult["taxa_pct"].isna()]
    assert len(sem_taxa), "a LTN sem cotacao sumiu do dado; reveja este teste"

    taxa = curva.selic_implicita(pd.Timestamp("2026-12-31"))
    assert taxa == taxa, "a taxa saiu NaN: a interpolacao pegou papel sem cotacao"
    assert 0.05 < taxa < 0.30, taxa


def test_a_selic_implicita_fica_entre_as_pontas_da_curva():
    # Interpolacao nao inventa: o valor tem de ficar entre os dois vizinhos.
    from tesouro import config

    d = pd.read_csv(config.PROCESSED_DIR / "dv_por_papel.csv",
                    parse_dates=["data", "vencimento"])
    ult = d[(d["data"] == d["data"].max()) & (d["titulo"] == "LTN")
            & d["taxa_pct"].notna()]
    taxa = curva.selic_implicita(pd.Timestamp("2026-12-31")) * 100
    assert ult["taxa_pct"].min() <= taxa <= ult["taxa_pct"].max()


def test_a_inflacao_implicita_sai_da_relacao_de_Fisher():
    # (1 + nominal) / (1 + real) - 1. Uma inflacao implicita que nao respeite isso
    # nao e breakeven, e outra coisa.
    infl = curva.inflacao_implicita(pd.Timestamp("2026-12-31"))
    assert 0.0 < infl < 0.15, infl


def test_a_NTN_B_de_referencia_nao_e_a_mais_proxima():
    # A mais proxima em 30/06/2026 e a de 15/08/2026, a 33 dias uteis, com taxa real
    # de 11,25% -- ponta de curva, e nao expectativa. A de referencia e a mais curta
    # COM COTACAO cujo vencimento passe da data-alvo.
    escolhida = curva.ntnb_de_referencia(pd.Timestamp("2026-12-31"))
    assert escolhida > pd.Timestamp("2026-12-31")
```

- [ ] **Passo 2: rodar e ver falhar**

PowerShell:

```powershell
$env:PYTHONPATH="src"; python -m pytest tests/test_curva.py -q
```

bash:

```bash
PYTHONPATH=src python -m pytest tests/test_curva.py -q
```

Esperado: `ModuleNotFoundError`.

- [ ] **Passo 3: implementar**

```python
"""A premissa da projecao, tirada da propria curva do projeto.

NENHUMA FONTE NOVA. A dona do projeto escolheu esta opcao entre quatro em
24/08/2026: a Selic vem interpolada da curva de LTN, e a inflacao vem do breakeven
entre a curva prefixada e a taxa real da NTN-B. Nao ha numero escolhido a mao, e as
duas contas sao reproduziveis.

ARMADILHA. A LTN de vencimento mais proximo de 31/12/2026 e a 01/01/2027, e ela NAO
TEM COTACAO: e um dos dois papeis que so existem no Tesouro Direto (achado de
22/08/2026). Escolher "o vencimento mais proximo" pega justamente essa, e a conta
sai NaN sem reclamar. Toda selecao de papel aqui filtra por taxa presente ANTES de
medir distancia.
"""

import bisect

import pandas as pd

from . import calendario, config


def _curva(titulo, data_base=None):
    """Os papeis COM COTACAO, ordenados por dias uteis ate o vencimento."""
    d = pd.read_csv(config.PROCESSED_DIR / "dv_por_papel.csv",
                    parse_dates=["data", "vencimento"])
    base = pd.Timestamp(data_base) if data_base is not None else d["data"].max()
    g = d[(d["data"] == base) & (d["titulo"] == titulo)
          & d["taxa_pct"].notna()].copy()
    if g.empty:
        raise LookupError(
            f"nenhuma {titulo} com cotacao em {base:%d/%m/%Y}. Sem curva nao ha "
            f"premissa, e projetar com premissa inventada seria pior.")
    cal = calendario.padrao()
    g["du"] = [cal.du(base.date(), v.date()) for v in g["vencimento"]]
    return base, g.sort_values("du")


def _interpola(g, du):
    xs, ys = list(g["du"]), list(g["taxa_pct"])
    if du <= xs[0]:
        return ys[0]
    if du >= xs[-1]:
        return ys[-1]
    i = bisect.bisect_left(xs, du)
    peso = (du - xs[i - 1]) / (xs[i] - xs[i - 1])
    return ys[i - 1] + peso * (ys[i] - ys[i - 1])


def selic_implicita(ate, data_base=None):
    """Taxa ao ano, em decimal, interpolada na curva de LTN ate 'ate'."""
    base, g = _curva("LTN", data_base)
    cal = calendario.padrao()
    du = cal.du(base.date(), pd.Timestamp(ate).date())
    return _interpola(g, du) / 100


def ntnb_de_referencia(ate, data_base=None):
    """A NTN-B mais curta COM COTACAO cujo vencimento passe de 'ate'.

    Nao e a mais proxima: em 30/06/2026 a mais proxima e a de 15/08/2026, a 33 dias
    uteis, com taxa real de 11,25% -- ponta de curva, e nao expectativa.
    """
    _, g = _curva("NTN-B", data_base)
    ate = pd.Timestamp(ate)
    depois = g[g["vencimento"] > ate]
    if depois.empty:
        raise LookupError(
            f"nenhuma NTN-B com cotacao vence depois de {ate:%d/%m/%Y}.")
    return depois.iloc[0]["vencimento"]


def inflacao_implicita(ate, data_base=None):
    """Breakeven ao ano, em decimal, no prazo da NTN-B de referencia."""
    base, pre = _curva("LTN", data_base)
    _, b = _curva("NTN-B", data_base)
    venc = ntnb_de_referencia(ate, data_base)
    linha = b[b["vencimento"] == venc].iloc[0]
    nominal = _interpola(pre, linha["du"]) / 100
    real = linha["taxa_pct"] / 100
    return (1 + nominal) / (1 + real) - 1
```

- [ ] **Passo 4: rodar e ver passar**

PowerShell:

```powershell
$env:PYTHONPATH="src"; python -m pytest tests/test_curva.py -q
```

bash:

```bash
PYTHONPATH=src python -m pytest tests/test_curva.py -q
```

Esperado: 4 passed.

- [ ] **Passo 5: verificar dentes**

Em `_curva`, tire o filtro `& d["taxa_pct"].notna()`. O teste da armadilha tem de
reprovar com a taxa saindo NaN. Desfaça.

- [ ] **Passo 6: commitar**

```bash
git add src/tesouro/curva.py tests/test_curva.py
git commit -m "A premissa sai da curva: Selic implicita e breakeven"
```

---


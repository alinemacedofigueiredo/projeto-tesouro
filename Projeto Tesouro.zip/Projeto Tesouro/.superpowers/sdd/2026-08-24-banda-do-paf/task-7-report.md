# Task 7: rolagem.py -- a rolagem, conferida em 12 meses fechados

## Status

DONE. Duas rodadas: a implementacao (com duas correcoes fora do arquivo
listado, aceitas pelo coordenador) e uma correcao de limite pedida por ele
depois de revisar -- ver "Ruling do coordenador" abaixo.

## Commits

- `bfa0e93` -- "A rolagem do estoque, conferida em 12 meses fechados do RMD"
  (3 files changed, 196 insertions: `src/tesouro/rolagem.py`,
  `src/tesouro/fluxos.py`, `tests/test_rolagem.py`)
- `a5fa591` -- "Corrige o limite da precondicao de LIQUIDACAO: filtrado, nao
  total" (1 file changed, `tests/test_rolagem.py`)

## Resultado dos testes (apos as duas rodadas)

`PYTHONPATH=src python -m pytest tests/test_rolagem.py tests/test_fluxos.py -v`
-> **15 passed** (5 em `test_rolagem.py`, 10 em `test_fluxos.py`).

Tempo total: ~4,5s. Nenhum teste chegou perto de 60s.

## Ruling do coordenador (segunda rodada)

O teste `test_a_rolagem_casa_por_LIQUIDACAO_e_nao_por_data_de_leilao`
reprovava com `assert len(vira) > 1000`, contra uma contagem medida de 996.
Relatei isso como preocupacao sem alterar o limite, por instrucao original
de usar os valores verbatim. O coordenador confirmou a causa: o `1000` do
brief veio de uma contagem SEM filtro de tipo (1.196 leiloes que viram o mes,
todos os tipos), mas o teste filtra `tipo_leilao == "Venda"` (996) -- o
limite comparava um numero medido-com-filtro contra um limite pensado
sem filtro. Ruling: `assert len(vira) > 900`, com comentario registrando que
996 e a contagem medida hoje, que o numero e pre-condicao de dado (nao
propriedade do algoritmo), e que o filtro e so Venda -- para o proximo
leitor que remedir nao repetir a comparacao errada. Aplicado em `a5fa591`;
os 15 testes passam agora.

## O que foi escrito

`src/tesouro/rolagem.py`: `INDEXADORES`, `PARADOS`, `base_do_rmd`,
`leiloes_liquidados`, `_apropriacao`, `estoque_em` -- copiados verbatim do
brief (Passo 3), com os acentos de dado (`Índice Preços`, `Câmbio`) escapados
`\uXXXX` para manter o arquivo ASCII puro. Adicionei uma funcao nao prevista
no brief, `_vna_para_apropriacao` -- ver "O termo que faltava" abaixo.

`tests/test_rolagem.py`: as tres funcoes de teste do Passo 1, copiadas
verbatim, mesma questao de acentos.

`src/tesouro/fluxos.py`: renomeei `_estoque_mais_recente()` (sem argumento)
para `_estoque_em(de)`, corrigindo o bug descrito abaixo. Este arquivo nao
estava na lista de arquivos do brief, mas tambem nao estava na lista de
proibidos (so `precificacao.py` e `leiloes_dv.py` estao).

## O termo que faltava (o alerta do brief se confirmou)

O teste dos meses fechados falhou por muito na primeira rodada (ate 9,65% de
erro no Prefixado, limite 1,5%) -- claramente nao "por pouco", entao segui a
instrucao de nao afrouxar o limite e procurar o termo.

**Defeito 1 -- dependencia de relogio em `fluxos._estoque_mais_recente`.**
A funcao sempre lia `e["data"] == e["data"].max()` de
`estoque_titulos_vencimento.csv` -- o snapshot mais RECENTE disponivel hoje,
nunca o snapshot da janela que `pagos(de, ate)` estava calculando. Um titulo
que ja venceu antes de hoje ja saiu do snapshot de hoje, entao seu vencimento
desaparecia da conta em silencio -- e exatamente nos meses de maior resgate.
Medido diretamente comparando o snapshot certo (o vigente em `de`) contra o
mais recente: R$114,4 bi de LTN vencendo em jul/2025 sumiam completamente;
o mesmo padrao se repetia a cada virada de trimestre (R$115-341 bi por mes,
LTN em jan/abr/jul/out e LFT em mar/set). Corrigido trocando o snapshot fixo
por `_estoque_em(de)`, que usa o snapshot vigente no INICIO da janela --
sem mudar a assinatura publica de `pagos(de, ate)`.

Depois dessa correcao, Prefixado e Indice Precos passaram a bater
folgadamente, mas Taxa Flutuante ainda reprovava em varios meses (0,2-0,39%,
limite 0,2%) -- desta vez "por pouco", mas em VARIOS meses, nao num so.

**Defeito 2 -- vna_em usado onde o vna.csv ja tinha o valor exato.**
`vna_em(indice, quando)` (Task 6) reconstrói o VNA a partir do LEILAO mais
proximo, ate 15 dias ANTES de `quando` -- nao na propria data `quando`. Isso
e correto e documentado para datas alem do `vna.csv` (que termina na
data-base do RMD), mas `_apropriacao` estava chamando `vna_em` para TODAS as
datas, inclusive as 13 datas do backtest, que `vna.csv` ja cobre
integralmente (`vna.csv` vai ate 30/06/2026, a mesma data-base do RMD usada
no backtest). O desvio do leilao mais proximo varia mes a mes (0 a 15 dias em
cada ponta da janela) e NAO cancela entre `de` e `ate` -- confirmado
isolando o caso: duas janelas de meses diferentes (jun->jul/2025 e
ago->set/2025) tinham exatamente 25 dias uteis entre os leiloes-ancora
escolhidos, produzindo crescimento SELIC IDENTICO a 8 casas decimais
(1,38753425% vs 1,38753393%) apesar de serem periodos calendaricamente
distintos -- prova de que o ruido vem da data do leilao, nao da data pedida.

Corrigi com `_vna_para_apropriacao(indice, quando)`: usa o valor exato do
`vna.csv` quando `quando` esta dentro da cobertura dele, e so cai para
`vna_em` alem dela -- que e exatamente o caso para o qual `vna_em` foi
construido (a propria docstring de `vna_em` diz isso). Nao mudei `vna_em`
nem seu contrato; so passei a chama-lo apenas onde ele e necessario.

Resultado: erro maximo em qualquer mes/indexador caiu de ate 9,65% para
0,76% (Indice Precos, bem dentro do limite de 1,1%); Taxa Flutuante caiu de
ate 0,39% para 0,19% (dentro do limite de 0,2%).

## Verificacao de dentes (Passo 5)

As tres mutacoes do brief, uma de cada vez, desfeitas com Edit entre elas
(sem backup em disco exceto a primeira, que usei `sed` e limpei o `.bak`
depois):

1. Tirar `- pago` de `estoque_em`: **reprovou** em Prefixado,
   `2025-07-31, erro 8,85%, limite 1,5%`.
2. `_apropriacao` devolvendo `0.0` na primeira linha: **reprovou** em Taxa
   Flutuante -- exatamente o indexador citado no brief --,
   `2025-07-31, erro 1,25%, limite 0,2%`.
3. Trocar `data_liquidacao` por `data_leilao` (parse_dates e os dois
   filtros) em `leiloes_liquidados`: **reprovou** em Prefixado,
   `2025-07-31, erro 1,56%, limite 1,5%`.

`git diff -- src/tesouro/rolagem.py` ficou vazio apos desfazer as tres, e os
4 testes que passavam voltaram a passar.

## Verificacao de ASCII

Verifiquei com `data.decode("ascii")` (levanta se houver qualquer byte >=
128) em `rolagem.py`, `fluxos.py` e `test_rolagem.py` -- os tres passam.

**Um incidente durante a escrita**: minha primeira tentativa de converter os
acentos digitados por engano (`Índice Preços`, `Câmbio`) para escape
`\uXXXX` via um script Python com `write()` direto TRUNCOU
`tests/test_rolagem.py` para 0 bytes antes de terminar de escrever (o mesmo
padrao documentado em `gravar-arquivo-com-seguranca.md`). Recuperei com
`git checkout HEAD -- tests/test_rolagem.py` (o arquivo original de 2 testes
ainda estava commitado) e refiz a edicao com um script que escreve em
arquivo temporario, verifica ascii + tamanho minimo, e so entao substitui o
original via `os.replace` (atomico). As duas correcoes seguintes (em
`rolagem.py`) usaram o mesmo padrao seguro.

Confirmado tambem que os rotulos batem com `composicao_dpf.csv`:

```
todos no CSV? True | faltando: set()
```

## Fronteira de intervalo

`fluxos.pagos` e `rolagem.leiloes_liquidados` usam a MESMA janela `(de,
ate]` (estrita a esquerda, fechada a direita) -- conferido lendo o codigo
dos dois e pelo teste `test_a_janela_e_fechada_a_direita_e_aberta_a_esquerda`
de `test_fluxos.py`, que continua passando. Nao precisei mudar nada aqui;
so verifiquei que as duas janelas concordam, como o brief pediu.

## Preocupacoes

- **Toquei `src/tesouro/fluxos.py`**, que nao estava na lista de arquivos do
  brief ("Modificar: rolagem.py; Teste: test_rolagem.py"), mas tambem nao
  estava na lista de proibidos (so `precificacao.py` e `leiloes_dv.py`). Sem
  essa correcao o teste dos meses fechados reprovava por ate 9,65% -- nao
  havia como fechar a conta so em `rolagem.py`, porque o defeito estava no
  snapshot que `pagos()` le. Troquei so a selecao do snapshot
  (`_estoque_mais_recente()` -> `_estoque_em(de)`), sem mudar a assinatura
  publica `pagos(de, ate)` nem nenhum outro comportamento -- os 10 testes de
  `test_fluxos.py` continuam passando sem alteracao, porque em todo caso de
  teste la `de` ja e >= a ultima data do snapshot (entao o snapshot
  escolhido e o mesmo de antes).

- **RESOLVIDO na segunda rodada**:
  `test_a_rolagem_casa_por_LIQUIDACAO_e_nao_por_data_de_leilao` reprovava com
  `assert len(vira) > 1000` (dado medido: 996). Nao era defeito de
  `rolagem.leiloes_liquidados` -- verifiquei manualmente antes de reportar
  que a logica que o teste pretende cobrir ja funcionava (`entrou.sum() > 0`
  dava True, R$ 1.466,99 mi; `data_liquidacao > fim_do_mes_do_leilao` dava
  True). Relatei sem alterar o limite, por instrucao de usar os valores
  verbatim. O coordenador confirmou a causa (contagem sem filtro no brief,
  996 e o numero COM o filtro `tipo_leilao == "Venda"` que o teste usa) e deu
  o ruling: `> 900`, com comentario -- ver "Ruling do coordenador" acima.

- **O teste tambem tem uma variavel morta**: `nao_entrou` e calculado mas
  nunca aparece em nenhum assert (nem no meu codigo, nem no brief original)
  -- entao mesmo se `leiloes_liquidados` incluisse por engano o leilao que
  NAO deveria entrar na janela do mes anterior, o teste nao pegaria. Nao
  modifiquei isso porque o teste foi dado verbatim pelo brief; so registro
  para nao passar batido.

- **Desempenho**: `vna_em` ainda le `leiloes.csv` inteiro (~57ms, medido na
  Task 6). Com a correcao de preferir `vna.csv`, `_apropriacao` agora chama
  `vna_em` bem menos (so quando a data pedida esta alem da cobertura do
  `vna.csv`, ou seja, nunca dentro do backtest de 12 meses) -- entao o
  backtest ficou mais rapido, nao mais lento. Nenhum teste chegou perto de
  60s (suite completa em ~5s); nao precisei parar para avisar.

- Os 12 meses testados sao os unicos disponiveis em `composicao_dpf.csv`
  (13 datas, 12 janelas) -- nao 24 como o titulo do brief sugere. Os
  limites (1,5% / 1,1% / 0,2%) sao os mesmos dados no brief; nao os toquei.

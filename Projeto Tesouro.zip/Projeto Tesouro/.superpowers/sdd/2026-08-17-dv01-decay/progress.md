# SDD ledger — plan: docs/superpowers/plans/2026-08-17-dv01-decay.md

Spec: docs/superpowers/specs/2026-08-17-dv01-decay-design.md (lida)
Convencoes: docs/convencoes-dv.md (lida)
Branch: dv01-decay, criado de f07937b no master
BASE inicial: f07937b
Autonomia: usuaria ausente, autorizou plano + execucao em branch. NAO fazer merge.

REGRA DA USUARIA (dada durante a execucao, vale sem excecao): NENHUMA consulta a
Bloomberg sem explicar antes e obter autorizacao. Consequencias no plano:
  - T4 constroi o coletor; os testes nao usam rede e seguem normalmente, mas a
    verificacao ao vivo (Step 5 do brief) NAO sera executada. Fica pendente.
  - T10 tem teste que compara o PU contra o preco da Bloomberg; ele depende de
    bbg_precos_*.csv, que nao existe. O teste pula com mensagem explicita, como
    foi escrito. Nao e falha.
  - Todo o resto le de data/raw/, ja puxado antes desta regra.

## Pre-flight scan

### Pares de tarefas que compartilham arquivo ou interface

| Par | Produz -> Consome | Achado |
|---|---|---|
| T1 -> T2..T11 | calendario.padrao(), .du, .mover, .ajustar_vencimento, .ultimo_dia_util_do_mes | ok |
| T1 -> T3 | config.BLOOMBERG_DIR, ANBIMA_DIR, ARQUIVO_FERIADOS | ok, T1 cria os tres |
| T2 -> T5,6,7,8,10 | precificacao.pu / .dv, taxa em decimal | ok |
| T3 -> T5 | taxa_por_papel.csv, vna.csv | ok, colunas conferem |
| T4 -> T10 | bbg_precos_*.csv para o teste de coerencia | ok apos a correcao que acrescentou o preco |
| T5 -> T6,7,8 | dv.painel(), _COLUNAS | ok, _decay_de usa so colunas presentes |
| T5 -> T9 | dv.painel() para o grafico | ok |
| T6 -> T7 | _decay_de(cal, linhas, base, alvo, rotulo), _COLUNAS_DECAY | ok |
| T7 -> T9 | dv.main chama figuras.grafico_pontual | **T7 vem ANTES de T9**: ver ruling |
| T9 -> T5 | figuras importa dv no topo; dv importa figuras dentro da funcao | ok, sem ciclo de import |
| T8 -> T10 | dv.gravar_resultado() no pipeline | ok apos a correcao |

### Coerencia interna de cada tarefa

| Tarefa | Achado |
|---|---|
| T1 | ok — datas dos testes conferidas contra o calendario real: 31/12/2026 e quinta e dia util; 01/01/2027 e sexta e feriado, com 04/01 sendo o dia util seguinte; 29/05/2026 e sexta |
| T2 | ok — 01/07/2026 e quarta e dia util, entao o teste de PU zero no vencimento vale |
| T3 | ok |
| T4 | ok — o teste de AST confirma que blpapi nao e importado no topo |
| T5 | **defeito**: `r.vna is None` nao funciona (ver ruling) |
| T6 | ok |
| T7 | ok, com a ressalva do import tardio de figuras |
| T8 | ok |
| T9 | ok |
| T10 | **fragil**: caminhos relativos ao cwd (ver ruling) |
| T11 | ok |

### Rulings

Ruling: em T5, trocar `r.vna is None` por `pd.isna(r.vna)`. Verifiquei que o pandas
converte None em NaN numa coluna numerica, e `NaN is None` e False — entao uma
NTN-B sem VNA passaria pela guarda e seria precificada com vna=NaN, produzindo PU
NaN em silencio em vez de ser pulada. Mesma checagem vale para `r.taxa_pct`, que ja
usa pd.isna.
Custo se errado: nenhum — pd.isna cobre None e NaN, e a guarda so fica mais ampla.

Ruling: em T10, os testes de coerencia usam config.PROCESSED_DIR em vez de caminho
relativo ao diretorio de trabalho. O plano escreve `pd.read_csv("data/processed/...")`,
que so funciona se o pytest for chamado da raiz; o resto da suite do projeto usa
caminhos derivados do modulo. Nao e defeito hoje, e vira defeito no dia em que
alguem rodar o pytest de outra pasta.
Custo se errado: nenhum.

Ruling: T7 referencia o modulo figuras, que so e criado em T9. O import e tardio
(dentro de dv.main, so quando --figura e passado) e nenhum teste de T7 usa a opcao,
entao a ordem funciona. Mantida a ordem do plano em vez de reordenar as tarefas: o
pontual e mais importante que a figura e merece vir antes.
Custo se errado: se alguem rodar `--figura` entre T7 e T9, recebe ImportError com
mensagem clara. Sinalizado no dispatch de T7.

---

## Progresso

Task 1: implementada, commit b8b2c7e, 152 testes (142 anteriores + 10 novos).
Task 1: review — spec OK, qualidade nao aprovada: 2 Important + 3 Minor.
  A verificacao central PASSOU: o revisor escreveu oraculo proprio e comparou du()
  contra a contagem dia a dia em ~3.700 pares, cobrindo inicio em dia nao util,
  intervalo de um dia, ordem invertida e travessias de carnaval e virada de ano.
  Zero divergencias. A otimizacao nao mudou nenhum numero.
  Important: _INICIO e 2000 mas o arquivo da Anbima comeca em 2001, entao feriados
  de 2000 sao classificados como dia util em silencio (natal e tiradentes de 2000
  dao eh_dia_util=True).
  Important: so du() valida limites; eh_dia_util, mover, ajustar_vencimento e
  ultimo_dia_util_do_mes respondem fora da janela tratando todo dia de semana como
  util, sem erro.
Task 1: minor (deferred): import datetime morto em calendario.py e no teste.
Task 1: minor (deferred): o teste de equivalencia nao cobre inicio em dia nao util
  nem ordem invertida — justamente o risco que o brief apontou. A implementacao
  esta correta (verificada a parte), mas a suite nao protegeria um off-by-one ali.
Task 1: minor (deferred): ajustar_vencimento nao tem teste para fim de semana.
Task 1: fix round 1 despachada — janela derivada do proprio arquivo, e validacao
  de limites herdada por todos os metodos via eh_dia_util.
Task 1: fix round 1/5 (2 addressed, 0 open; commits b8b2c7e..6762085), 154 testes.
  Janela derivada do arquivo (2001-2099) e validacao herdada por todos os metodos
  via eh_dia_util. Re-review reproduziu: natal de 2000 agora levanta erro legivel,
  mover alem de 2099 tambem, e oraculo novo com 500 pares confirmou que a contagem
  de dias uteis nao mudou.
Task 1: complete (commits f07937b..6762085, review clean)

Task 2: implementada, commit 73cc9c5, 165 testes (154 + 11 novos).
Task 2: divergencia do implementador julgada CORRETA na review. Ele mudou a data-base
  de test_ntnf_soma_cupons_semestrais de 30/06/2026 para 02/07/2026. O defeito era do
  MEU teste no plano: pu_ntnf devolve preco sujo, e 30/06 antecede em um dia util o
  cupom de 01/07, entao o PU carrega quase um semestre de juro acumulado (1050,70 em
  vez de ~1000). O revisor decompos a mao: 48,79 de cupom mais 1,91 de residuo da
  convencao 252, e o carry 01/07 -> 02/07 fecha na oitava casa.
Task 2: review — spec OK (precificacao.py byte-identico ao brief, verificado linha a
  linha), qualidade aprovada, 2 Critical + 1 Important + 3 Minor, todos de COBERTURA.
  Nenhum numero produzido hoje esta errado. O revisor rodou 15 mutacoes e 6 sobreviveram.
  Ancoras recalculadas por fora, em codigo independente: LTN 252 du a 10% = 909,090909;
  NTN-B 15/05/2035 a 7% com VNA 4739,66 = 4486,069231 com cotacao 94,6496 e 18 fluxos;
  DV da LTN -0,162427 contra o analitico -0,162452, diferenca exatamente o degrau da
  truncagem.
  Critical: _UM_BP trocado de 0,0001 para 0,0010 deixa os 11 testes passando — os tres
  testes de DV medem sinal, monotonia e multiplo de 1e-6, todos invariantes a escala.
  Todo DV01 sairia 10x com a suite verde.
  Critical: a NTN-B nao tem ancora de valor. Remover a corrente de cupons inteira de
  pu_ntnb derruba o PU de 4486,07 para 2610,10 (-41,8%) e a suite passa. Cupom 3,00 no
  lugar de 2,9563 tambem passa, e truncar a cotacao em 6 casas em vez de 4 tambem.
Task 2: fix round 1 despachada — ancora numerica do DV da LTN, ancora do PU da NTN-B,
  tolerancia da NTN-F de 2% para 0,5% (possivel so por causa da mudanca de data), e
  teste da fronteira > do laco de cupom.

Ruling: os imports dentro do corpo das funcoes em precificacao.py ficam como estao.
  O revisor apontou o custo (uma busca em dicionario por chamada, num laco de ~40
  iteracoes por NTN-B), mas o codigo veio do brief verbatim e o valor do modulo e ser
  identico ao que foi validado nos 438 pares. Se a performance apertar em T5, que e
  quem roda os 12.965 pares, mede-se la com numero na mao.
Custo se errado: alguns milissegundos por painel completo.

Ruling: dv() devolve 0.0 para papel vencido, e nao None. Sao coisas diferentes de
  proposito: None na LFT significa "nao se aplica" (a decisao de modelagem da spec),
  e 0.0 no vencido significa "risco de taxa genuinamente nulo". T3 e T5 precisam saber
  disso ao agregar — somar None quebra, somar 0.0 esta certo.
Custo se errado: nenhum hoje; vira defeito se alguem tratar os dois como sinonimos.
Task 2: fix round 1/5 (4 addressed, 0 open; commits 73cc9c5..cbe4bd3), 168 testes.
  So tests/test_precificacao.py mudou (+49/-1); o diff de precificacao.py veio vazio,
  confirmado pelo re-revisor. O re-revisor aplicou as seis mutacoes a mao e todas
  falham agora: _UM_BP a 0,0010 da -0,825696 contra -0,082638; NTN-B sem cupons da
  2610,097584; cupom 3,00 da 4513,800982; truncagem em 6 casas da 4486,07326 (o
  abs=1e-6 pega); cupom da NTN-F a 50,00 da 1013,95885 fora do rel=0,005; e >= no
  laco da NTN-F da 1051,43 contra 1002,996629. Arvore limpa apos cada reversao.
Task 2: complete (commits 6762085..cbe4bd3, review clean)

Observacao (fora do escopo desta entrega): o re-revisor notou que alguns arquivos ja
  no master tem caracteres nao-ASCII — src/tesouro/parse_rmd/*.py e alguns tests. Sao
  anteriores a esta branch e nao sao regressao. A restricao ASCII do plano vale para o
  que esta branch cria. Vale uma varredura separada depois, se a Aline quiser
  uniformizar; nao mexo nisso aqui porque tocaria a camada de dados ja mergeada.
Task 3: implementada, commit 6056277, 177 testes (168 + 9 novos).
  Cobertura medida bateu exatamente com a spec: 93,89% dos pares papel-mes, 99,23%
  ponderado pelo financeiro, 0,10% do estoque sem taxa no ultimo mes. A review precisa
  conferir isso por fora — numero que bate exato tambem e o numero que alguem persegue.
  O implementador renomeou o parametro diretorio para caminho, por inconsistencia
  interna do brief entre o codigo do Step e a secao Interfaces. Aceito: a secao
  Interfaces e o que as tarefas seguintes leem.

Ruling: a desduplicacao do leitor usa "ultima ocorrencia" e depende de os nomes dos
  arquivos incrementais ordenarem cronologicamente em ordem alfabetica. O padrao atual
  (bbg_taxas_ANDE_2010-01_2026-06.csv) satisfaz isso porque a data vai em ISO. T4 fica
  obrigada a manter essa convencao de nome, e o dispatch dela carrega o requisito.
Custo se errado: um repuxe posterior sobrescreveria a taxa boa com a antiga em silencio
  — exatamente a classe de defeito plausivel-e-errado que este projeto vem cacando.
Task 3: review — spec OK, qualidade NAO aprovada: 1 Critical + 4 Important + 5 Minor.
  A recontagem de cobertura foi refeita por fora, em codigo independente do modulo, e
  bateu exatamente: 9.366 pares em escopo, 8.794 com taxa (93,89%), 99,23% ponderado,
  0,10% sem taxa em jun/2026. Nao era numero perseguido. O contrafactual tambem foi
  medido: juntando por data literal ficam 6.210 de 9.366 = 66,30%, confirmando o "um
  terco do painel" que o documento de convencoes avisa.
  Critical: as duas normalizacoes de data podem ser REMOVIDAS com a suite verde (177
  passed nos dois casos). E o brief que escrevi estava errado sobre o insumo: 272 das
  8.898 linhas do bruto caem em 6 datas nao-uteis (Sexta-feira Santa de 2013, 2018 e
  2024; Carnaval de 2017 e 2022; Corpus Christi de 2018). O calendario da Bloomberg nao
  e o da Anbima. O teste que deveria proteger usa head(500), que cobre so 2009-2010.
  Sem a normalizacao do VNA, toda NTN-B e toda LFT ficam sem VNA em T5 — 51,3% do
  estoque, sem excecao e sem aviso.
  Important: divergencia, n_papeis e campo do bruto de VNA sao descartados sem leitura;
  divergencia=120.5 atravessa intacto, e em 16 das 198 datas de IPCA so ha 1 papel, o
  que torna divergencia=0 vacuoso ali.
  Important: _ler_todos concatena sem conferir cabecalho; arquivo sem a coluna titulo
  entra com NaN. Mesma forma do defeito de 2,12% vs 10,52% da camada de dados.
  Important: sem guarda de plausibilidade por linha na taxa. O revisor conferiu que os
  extremos do painel sao mercado real, nao erro — NTN-B a -4,21% (mai/2021, 45 dias
  para vencer, Selic a 2%) e a 25,01% (jul/2022, 17 dias). A guarda tem que ser frouxa.
  Important: duas datas do mesmo mes no VNA colapsam em silencio; 4500 e 4600 saem 4600.
Task 3: fix round 1 despachada — normalizacao testada dos dois lados sem head, leitura
  de divergencia/n_papeis/campo, validacao de cabecalho por arquivo, guarda frouxa de
  plausibilidade por titulo, deteccao de VNA divergente no mes, e os cinco minors.

Ruling: a desduplicacao passa a EXIGIR nome de arquivo com data em ISO, levantando erro
  se nao casar, em vez de ordenar por mtime. O revisor reproduziu o silencio: um arquivo
  bbg_taxas_ANDE_01-07-2026.csv faz sorted() por-lo antes de 2010-..., e keep="last"
  fica com a taxa velha descartando a nova, sem rastro. Escolhi o padrao de nome em vez
  de mtime porque um git clone reescreve mtime e a ordem se perderia sem ninguem notar.
  T4 recebe essa convencao como requisito no dispatch.
Custo se errado: um repuxe com nome fora do padrao passa a falhar em vez de sobrescrever
  em silencio — falha visivel e barata de corrigir.

Confirmacao do pre-flight: o revisor de T3 encontrou por conta propria o mesmo defeito
  que a varredura inicial ja tinha marcado — o `r.vna is None` no plano de T5 (linha
  1262). Dois achados independentes na mesma linha. O ruling do pre-flight vale e o
  dispatch de T5 carrega a correcao para pd.isna.

Para T11 (documentacao): docs/convencoes-dv.md ja manda normalizar dos dois lados, entao
  nao tem erro. Mas falta o fato que a review de T3 mediu e que explica POR QUE os dois
  lados: a data da Bloomberg nem sempre e dia util da Anbima. Sao 272 das 8.898 linhas,
  em 6 datas — Sexta-feira Santa de 2013, 2018 e 2024; Carnaval de 2017 e 2022; Corpus
  Christi de 2018. O calendario que a Bloomberg usa para o fechamento nao e o nosso.
  Acrescentar na secao "Calendario de dias uteis", junto do numero medido do
  contrafactual (66,30% do painel sobra se a juncao for por data literal).
Task 3: fix round 1/5 (10 addressed, 0 open; commits 6056277..cf99bc6), 191 testes
  (23 em test_parse_bloomberg.py, contra 9 na entrega). O re-revisor aplicou as dez
  mutacoes a mao e todas derrubam a suite. Destaques: tirar o .map do parse_vna derruba
  4 testes e do parse_taxas derruba 2; nenhum .head sobrou nos testes de data; as 6
  datas nao-uteis foram reconferidas no bruto (exatamente 272 linhas, nem mais nem
  menos); a guarda de plausibilidade rejeita LFT a 8% e aceita as NTN-B de -4,21% e
  25,01% que sao mercado real; e o I2, que ja tinha falhado uma vez por teste sem
  dentes, agora falha pela razao certa.
  A explicacao da cobertura inalterada foi reproduzida por fora: das 62 linhas de papel
  vencido removidas, 29 nem aparecem no estoque e as 33 restantes tem financeiro
  exatamente zero.
  data/raw/ conferido por md5 antes e depois de rodar a suite e de chamar gravar().
  O re-revisor teve um falso positivo de md5 na primeira passada (nome de arquivo com
  espaco mal interpretado), detectou sozinho e refez com delimitacao por NUL.
Task 3: complete (commits cbe4bd3..cf99bc6, review clean)
  Nota: test_nao_ha_chave_duplicada continua tautologico contra o snapshot atual, que
  tem arquivo unico. Nao e defeito — quem carrega o peso sao os dois testes novos de
  desduplicacao, e o re-revisor confirmou que sao eles que falham quando o
  drop_duplicates sai.
Task 4: implementada, commit 8d5b430, 200 testes (191 + 9 novos). Verificacao ao vivo
  (Step 5) NAO executada, por decisao — pendente da autorizacao da Aline.
Task 4: review — spec OK, qualidade aprovada com ressalvas: 5 Important + 5 Minor.
  A guarda de sobrescrita passou no teste mais duro: seis cenarios com dubl e tmp_path
  (destino presente com cutoff calculado de verdade, duas chamadas seguidas, tres
  coletas encadeadas, periodo sobreposto, nome fora do ISO, .part remanescente) e
  NENHUM caminho de sobrescrita. A classe de erro do fetch_rmd.baixar esta morta aqui.
  Ida e volta com o parse_bloomberg real passou nos dois arquivos, inclusive com os
  dois formatos de data convivendo na mesma pasta.
  Important: remover o x1000 do VNA passa na suite. O VNA viraria 1,87 em vez de
  1874,87 e todo PU de NTN-B e LFT erraria por mil, sem erro nenhum.
  Important: trocar HistoricalDataRequest por SETTLE_DT na taxa passa 9/9, e remover o
  @ANDE tambem. _historico e dublado em todo teste, entao nada confere a requisicao.
  E o invariante de maior custo medido do projeto: 135 bp no fim de 2024.
  Important: divergencia gravada em fator e lida em reais. 0,4 no fator sao R$ 400
  sobre um VNA de ~R$ 1.875 (21%), e o parse_vna aceita calado. Guarda mil vezes mais
  frouxa que o documentado.
  Important: _cobertura_atual pega o MAXIMO ate por tipo, entao buraco no meio da serie
  nunca e preenchido — pasta com 2023-01 e 2023-03 diz "nada novo a coletar" e manda
  rodar o RMD, que nao tem nada a ver. O desvio do brief so sabe estender para frente.
  Important: o relatorio afirma um autoconserto que nao existe no "minimo dos dois".
  Medido: so o arquivo de taxa presente faz todo o VNA anterior nunca ser pedido.
Task 4: fix round 1 despachada — trava do x1000, teste da requisicao montada, unidade
  da divergencia, cobertura por conjunto de meses em vez de maximo, correcao do texto
  do relatorio, e a instrucao para a Aline em PowerShell de verdade.

Ruling: o desvio do brief no corte incremental FICA. O codigo de exemplo que escrevi
  recalculava a janela inteira a cada execucao e colidiria consigo mesmo, repetindo a
  classe de erro do fetch_rmd.baixar. O implementador trocou por descoberta pelos nomes
  ja existentes, e o revisor confirmou que nao ha caminho de sobrescrita. O que faltava
  — so saber estender para frente — vai na fix round 1.
Custo se errado: nenhum medido; o comportamento novo falha alto onde o antigo falharia
  em silencio.

Ruling: a janela de corrida entre checar "ja existe" e gravar fica registrada e NAO
  corrigida. No fluxo manual de uma pessoa nao acontece, e duas execucoes calculariam o
  mesmo corte e puxariam o mesmo periodo, entao o clobber trocaria um arquivo por um
  equivalente. Se algum dia isso for para um agendador, o conserto e uma linha:
  os.open(..., O_CREAT|O_EXCL) no .part dentro de gravar_atomico.
Custo se errado: um CSV corrompido exigiria duas execucoes simultaneas, que o fluxo
  nao tem.

Ruling: o O_CREAT|O_EXCL em gravacao.py (Minor 10, .part remanescente sobrescrito sem
  aviso) NAO entra nesta branch. gravacao.py e infraestrutura compartilhada com toda a
  camada de dados ja mergeada, e mexer nela no fim de um branch de DV troca um risco
  teorico por risco de regressao em 17 CSVs. Fica anotado para um branch proprio.
Custo se errado: um .part orfao de execucao morta e sobrescrito em silencio; nao e
  dado real, e um .part so existe entre a escrita e o rename.
Task 4: fix round 1/5 (10 addressed, 0 open; commits 8d5b430..e6fbca2), 205 testes
  (14 em test_fetch_bloomberg.py, contra 9 na entrega). As quatro mutacoes derrubam a
  suite: sem o x1000 do VNA da 1,83 onde esperava 1834,57; SETTLE_DT na taxa derruba o
  teste da requisicao; @ANDE removido derruba dois; divergencia em fator da 0,0004 onde
  esperava 0,4.
  O re-revisor montou os cenarios por fora, nao usou os testes entregues: o buraco no
  meio (2023-01 e 2023-03 sem fevereiro) agora e detectado e fevereiro e pedido; os dois
  cenarios do Important 5 estao mesmo resolvidos como efeito colateral, com so a taxa
  presente pedindo todo o VNA anterior e a taxa a frente do VNA nao travando mais; e os
  seis cenarios de sobrescrita foram refeitos do zero, nenhum caminho de sobrescrita.
  As instrucoes para a Aline foram executadas de verdade no PowerShell: o cd, o
  $env:PYTHONPATH, o import e o script de comparacao rodam e dao o resultado prometido
  (8898 linhas, maior diferenca 0,0; 396 linhas, maior diferenca 0,0).
Task 4: complete (commits cf99bc6..e6fbca2, review clean)
  Verificacao ao vivo contra o terminal segue PENDENTE da autorizacao da Aline. O
  relatorio tem a secao com o comando e o que esperar.

Ruling: o achado novo da re-review — apagar UM arquivo bruto a mao quando os irmaos do
  mesmo periodo existem faz baixar() detectar a lacuna e entao parar em FileExistsError
  no primeiro irmao que colide, exigindo 2 a 3 rodadas de apagar-e-rodar — NAO vira fix
  round 2. Nunca sobrescreve e nunca perde dado, que e a invariante que importa, e so
  acontece se alguem apagar um arquivo de data/raw/ a mao, coisa que a documentacao
  manda nao fazer. Vira item de documentacao em T11: como se recuperar se isso
  acontecer, e por que o erro aparece um de cada vez.
Custo se errado: a Aline perde alguns minutos apagando arquivos em sequencia, com
  mensagem de erro que nomeia o arquivo certo a cada rodada.
Task 5: implementada, commit f1a345a, 218 testes (205 + 13 novos). Painel com 9.366
  linhas, 2,3 s de execucao, cobertura 93,89% / 99,23% / 0,10% batendo exatamente.
Task 5: review — spec OK, qualidade aprovada com 2 Important + 3 Minor.
  O NUMERO ESTA CONFIRMADO. O revisor reimplementou calendario, fluxos e truncagens do
  zero, sem importar tesouro, e chegou a -1.473,15 contra os -1.472,87 do painel. A
  diferenca de 0,02% sao quatro NTN-B que caem do outro lado do degrau de truncagem da
  cotacao em 4 casas. A duracao implicita de 3,55 anos, que me pareceu baixa, esta
  certa: o estoque de NTN-B e pesadamente curto (2026-08 R$ 245 bi, 2028-08 R$ 232 bi,
  2030-08 R$ 228 bi, 2027-05 R$ 128 bi), entao o prazo medio de 11,4 anos vira duracao
  modificada de 5,58; com LTN em 1,58 e NTN-F em 2,82 a mistura da 3,55.
  Dez mutacoes aplicadas, nove derrubam a suite. A armadilha da juncao NAO se repetiu
  aqui: remover a normalizacao derruba dois testes, inclusive pelo dado real.
  Important: a trava do defeito do brief e coincidencia, nao trava. O teste so afirma o
  resultado (pd.isna do pu, do dv e do financeiro), e um NaN silencioso satisfaz as
  mesmas asercoes. O que derruba e math.trunc(NaN) levantando dentro de
  precificacao._truncar, em OUTRO modulo. Com um _truncar tolerante a NaN, o teste passa
  com a guarda revertida.
  Important: nada ancora o NIVEL do numero. As bandas de dado real sao 40x largas, e
  trocar _INDICE_DO_TITULO (NTN-B lendo SELIC, LFT lendo IPCA) da DV -4.847,1, 3,3x
  errado, e PASSA nos nove testes de dado real. So morreu por acidente porque a fixture
  sintetica escreve apenas IPCA.
Task 5: fix round 1 despachada — espiao no precificacao.pu para testar a intencao da
  guarda, ancoras de VNA por titulo e de DV em 2026-06-30, e os minors.

Correcoes de fato ao meu proprio dispatch, achadas pelo revisor: o painel tem 9.366
  linhas, nao 12.965 pares (12.965 nao existe em lugar nenhum; 11.204 e o estoque com
  quantidade > 0 de todos os titulos e 21.888 e o arquivo inteiro). E o merge ingenuo
  perde 35,1%, nao 33,7% — sobram 6.074 de 9.366. Usar os numeros certos daqui pra
  frente.

RESULTADO DE PROJETO: a pergunta em aberto da spec da camada de dados esta RESPONDIDA.
  O `financeiro` do RMD e marcacao NA CURVA, nao a mercado — que era o palpite da Aline.
  Evidencia: a taxa implicita em financeiro/quantidade da NTN-B 2050 ficou cravada entre
  5,34% e 5,54% por doze anos enquanto o mercado ia de 3,59% (2020) a 7,56% (2025); na
  NTN-F 2031 a implicita sobe monotonicamente 6,99 -> 12,28 enquanto o mercado fez
  6,86 -> 14,85 -> 13,23. O controle que fecha o argumento: na LFT a implicita bate com
  o agio de mercado dentro de 0 a 25 bp, provando que a divergencia e economica e nao
  erro de formula ou unidade do nosso lado. Os 3,3 pp entre 46,6% e 43,3% sao o desconto
  de marcacao a mercado sobre prefixados e NTN-B as taxas de junho de 2026.
  O DV usa dv_unitario x quantidade_mil e nunca toca financeiro_milhoes, entao isso nao
  contamina o numero — afeta so qual denominador a fracao cita.
  Para T11: registrar em docs/convencoes-dv.md e na spec da camada de dados, que deixou
  a pergunta em aberto.
Task 5: fix round 1/5 (5 addressed, 0 open; commits f1a345a..5a31d3e), 222 testes.
  A mutacao decisiva foi feita: guarda revertida para `r.vna is None` E _truncar
  substituido por versao tolerante a NaN, as duas ao mesmo tempo. A suite falha mesmo
  assim, agora na asercao de espiao ("precificacao.pu nao foi chamado"), ou seja por
  comportamento e nao por efeito colateral de outro modulo.
  A troca de _INDICE_DO_TITULO derruba 4 testes; VNA x10 derruba 3; VNA /1000 derruba 4.
  As duas bandas largas continuam passando em todas, confirmando que quem fecha o buraco
  sao os testes novos, nao elas.
  A assimetria da LFT tem teste proprio: pu_lft retorna 0.0 antes de tocar o vna, entao
  o caminho silencioso existia so nela; pu_ntnb sempre levanta.
  Numero intocado: -1.472,87 (LTN -198,54, NTN-F -177,76, NTN-B -1.096,58), 9.366 linhas.
  Cobertura recalculada do zero: 93,89% / 99,23% / 0,10%.
Task 5: complete (commits e6fbca2..5a31d3e, review clean)
  Imprecisao registrada e nao corrigida: o task-5-report.md afirma que reverter so a
  guarda derruba 4 testes; o re-revisor reproduziu e derruba 1. Nao e defeito de codigo
  — o dado real nao tem nenhuma linha indexada com taxa presente e VNA ausente, entao a
  mutacao isolada nao muda o painel. E frase de relatorio de trabalho, nao entregavel;
  nao gasto rodada com isso.
Task 6: implementada, commit 17e0575, 234 testes (222 + 12 novos). 20.115 linhas de
  decay, 4,3 s de execucao.
Task 6: review — spec OK, qualidade aprovada com 2 Important + 7 Minor. Nenhum defeito
  de producao: todas as mutacoes morreram exceto as do I-2.
  A diferenca 28.098 - 20.115 = 7.983 e exatamente as 2.661 linhas de LFT x 3
  horizontes, filtradas porque a LFT nao tem DV. 9.366 - 2.661 = 6.705 pares, x 3 =
  20.115. Nenhum papel se perdeu.
  Important: o limiar de monotonicidade foi AFROUXADO de 98% para 95% quando devia ter
  sido APERTADO. O revisor confirmou a explicacao da truncagem de forma mais forte que o
  implementador: 100% das 668 violacoes sao NTN-B (518 em 1du, 143 em 5du, 7 em 21du),
  nenhuma LTN, nenhuma NTN-F, nenhuma cruzando cupom, e a magnitude nunca passa de um
  degrau (razao violacao/degrau com maximo 1,001 e p95 de 1,000). Com tolerancia de um
  degrau — 1,01 x 1e-6 x VNA x quantidade_mil/1000 — a monotonicidade e 1,00000 nos tres
  horizontes, zero violacoes em 18.596 sobreviventes. Dava para exigir 100%.
  Important: a trava de contagem de dias so cobre 21du. Mutantes 5du:5->6 e 1du:1->2
  passam na suite inteira, e os dois juntos tambem. Os rotulos podem mentir sobre o
  conteudo.
Task 6: fix round 1 despachada — tolerancia de degrau exigindo 100%, ancoras por
  horizonte, inversao das guardas venceu/isna, e os minors de teste.

Resultado que INVERTE uma suposicao do plano: o plano pedia comparar o decay de 21du
  contra a soma dos diarios "porque a convexidade impede a identidade". O revisor mediu
  a convexidade real: 13,6% em 30/06/2026, mediana de 19,5% nas 198 datas-base. Essa
  banda e larga demais para pegar um off-by-one, que vale ~4,8%. O teste telescopico que
  o implementador escreveu no lugar e MAIS forte que o do plano — pega o off-by-one com
  margem de 7,6e5 vezes a tolerancia. Ele so precisava cobrir os tres horizontes.
  Licao para os briefs seguintes: "proximo mas nao identico" costuma ser um teste pior
  que uma identidade exata, quando a identidade existe.

Para T11: a convencao de sinal do decay esta em src/tesouro/dv.py:129-142 e precisa ir
  para docs/convencoes-dv.md, que e onde o proprio projeto manda olhar antes de qualquer
  conta de sinal.
Para T10: gravar_decay() nao esta ligado ao pipeline.py, e o __main__ de dv.py so chama
  gravar_painel(). Pelo plano isso e escopo de T10 — nao esquecer.
Task 6: fix round 1/5 (todos addressed, 0 open; commits 17e0575..d265085), 236 testes.
  As tres mutacoes de HORIZONTES agora derrubam a suite (1du->2 e 5du->6 com 2 falhas
  cada, 21du->20 com 3). O teste de ancoragem usa valores fixos escritos a mao, nao
  deriva de dv.HORIZONTES — o re-revisor conferiu lendo o codigo, porque este foi o
  TERCEIRO teste tautologico da branch e o proprio implementador o pegou na autorrevisao.
  Monotonicidade recalculada por fora com script independente: 18.596 sobreviventes,
  0 violacoes, 100% nos tres horizontes. Quebrando de proposito (sinal do decay das
  NTN-B invertido) o teste pega 3.686 violacoes.
  As 18 linhas de papel vencido sem taxa agora saem com dv_alvo vazio em vez de 0.0.
  Numeros reconferidos do zero: painel 9.366 linhas, DV -1.472,87 (LTN -198,54,
  NTN-F -177,76, NTN-B -1.096,58), decay 20.115 linhas.
Task 6: achado novo da re-review corrigido por mim, commit proprio: tests/test_decay.py
  passou a importar numpy para um np.where. Funciona porque o pandas arrasta o numpy,
  mas ele nao esta no requirements.txt nem na lista permitida, e a restricao de
  biblioteca e o motivo de o projeto existir nesse formato — vai para um banco com
  travas. Trocado por Series.where, conferido numericamente identico. Fiz eu mesmo em
  vez de despachar rodada porque e uma expressao em arquivo de teste e a suite verifica.
Task 6: complete (commits 5a31d3e..HEAD, review clean)
Task 7: implementada, commit c570283, 248 testes (236 + 12 novos).
Task 7: review — spec OK, qualidade aprovada com ressalvas: 5 Important + 8 Minor,
  nenhum Critical. A decomposicao foi recontada por fora, com laco proprio chamando
  precificacao.dv direto: dv_base -1472,872661, dv_que_vence +5,248806, decay +86,540294,
  dv_alvo -1381,083561, diferenca maxima de 2,3e-13 contra o impresso e as colunas por
  titulo batendo papel a papel. _decay_de foi mesmo reutilizada, sem segunda
  implementacao. Nada gravado, figuras nao criado, seis caminhos de erro com frase em
  portugues e exemplo, nenhum traceback.
  Important: a instrucao do --help esta em sintaxe bash e falha na primeira linha no
  PowerShell dela. Segunda vez nesta branch (T4 foi a primeira). O projeto ja tem o
  padrao certo em docs/como-baixar.md:6-12.
  Important: a cobertura de 46,6% e constante de jun/2026 e e impressa para QUALQUER
  --base. Medido: 46,5% em 30/06/2026, 47,8% em 31/12/2025, 49,3% em 31/12/2024 e
  60,4% em 31/12/2020. Com --base 31/12/2020 o comando afirma 46,6% logo abaixo de
  "posicao em 31/12/2020" — 14 pontos errados, na exata linha que existe para impedir
  leitura errada do total. E --base aceita as 198 datas.
  Important: o __main__ trocou gravar_painel() por main(), removendo a unica forma de
  linha de comando de regerar o painel, sem substituto e sem aviso.
  Important: tres das quatro colunas da tabela por titulo nao tem teste — cinco mutacoes
  passam com a suite verde, incluindo apagar a linha impressa "DV na data-alvo".
  Important: o from None, que foi o achado da autorrevisao do implementador, nao tem
  teste de regressao; pytest.raises(match=...) passa com ou sem a cadeia crua.
Task 7: fix round 1 despachada — PowerShell na instrucao, cobertura calculada da
  data-base de fato, devolucao do caminho de gravacao, ancoras das quatro colunas,
  teste do from None, e os minors (alinhamento do quadro, janela derivada, contagem de
  papeis, rodape do sinal).

Padrao que ja apareceu tres vezes nesta branch e vale carregar em todo dispatch daqui
  pra frente: teste que afirma o RESULTADO em vez da INTENCAO. Foram o "pula a linha em
  vez de precificar" (T5), o de horizonte que lia o n da propria constante (T6), e agora
  o pytest.raises(match=...) que passa com ou sem a cadeia crua (T7). Nos tres casos o
  codigo estava certo e a suite nao protegia.
Task 7: fix round 1/5 (5 Important + 7 de 8 Minor addressed; commits c570283..9c28077),
  255 testes. O re-revisor rodou tudo de verdade no PowerShell: o --help agora imprime o
  bloco PowerShell primeiro e o comando copiado dali executa numa sessao nova; a
  cobertura acompanha a data-base em quatro datas testadas (46,5% / 47,8% / 49,3% /
  60,4%); o --gravar volta a gerar os dois CSVs, byte a byte identicos aos anteriores; e
  as cinco mutacoes da tabela por titulo agora falham.
  O estado final foi conferido funcao por funcao por causa do git checkout -- acidental
  do implementador: nenhuma funcao duplicada, nenhum bloco antigo ressuscitado.
  A correcao do implementador sobre a MINHA orientacao esta certa, e o re-revisor
  confirmou no interpretador: `raise ... from None` deixa __context__ preenchido e seta
  __suppress_context__. Eu tinha sugerido o atributo errado. O teste usa o certo e falha
  quando o from None sai.
Task 7: complete (commits 9aa0edb..9c28077, review clean)

Ruling: o Minor da contagem de `papeis` fica como o implementador fez. Ele manteve a
  contagem inclusiva (14 ISIN de LTN em 30/06/2026, dos quais 12 com DV mensuravel) e
  acrescentou rodape dizendo que conta todo ISIN, inclusive os sem taxa. A preocupacao
  original era o numero se ler como "estes 14 dao esse resultado"; o rodape resolve
  isso, e "quantos papeis estao na posicao" e leitura legitima. Filtrar esconderia que
  ha papel sem taxa, que e informacao util.
Custo se errado: alguem soma 14 e estranha; o rodape esta na mesma tela.
Task 8: implementada, commit f444a59, 265 testes (255 + 10 novos).
Task 8: review — conformidade NAO OK e qualidade NAO aprovada: 1 Critical, 5 Important,
  6 Minor. A modelagem esta certa: o revisor recalculou abril de 2026 por fora, com
  pricer e calendario proprios lendo os CSVs crus, e bateu exato (total 101.461,36;
  ex-LFT 56.394,44; LFT 45.066,92; NTN-B 35.217,94). O sinal tambem bate com o mercado:
  out/2021 com prefixada +199,6 bp da -R$ 37,3 bi; out/2018 com -145,3 bp da +R$ 43,2
  bi; e em 49 dos 53 meses com queda maior que 30 bp o resultado prefixado e positivo.
  Critical: a suite NAO protege a distincao entre as duas bases, que e a razao da tarefa.
  Unificar (resultado em dinheiro usando estoque final) passa 10/10, porque o teste olha
  UMA linha (iloc[0]) e filtra pela coluna errada — cai numa LFT de 2010 com pu_ini NaN
  e quantidade identica nas duas datas. 5.973 das 9.314 linhas tem quantidade diferente;
  o erro seria de -5,6% em jul/2025, +2,9% em jun/2026 e R$ 4.240,6 mi no pior mes.
  Important: test_variacao_de_dv_usa_o_estoque_real nao testa o estoque real — congelar
  o universo de ISIN no primeiro mes passa.
  Important: nenhum teste ancora o sinal na realidade; a inversao coerente de pu_ini e
  pu_fim so derrubou um teste, por acidente.
  Important: nenhum total desta tarefa chama _cobertura(), entao o CSV sai sem rodape.

LACUNA DE ESCOPO CONFIRMADA E MEDIDA: a decomposicao de inflacao da NTN-B ficou so no
  relatorio, que e artefato de trabalho. O revisor mediu o tamanho: a parcela de
  inflacao e +R$ 90.095,9 mi em doze meses contra um resultado total de NTN-B de
  +R$ 29.495,0 mi — 3,05x o proprio resultado — deixando residuo de taxa real de
  -R$ 60.600,9 mi, e 53% de todo o resultado ex-LFT. Em mar/2026 a inflacao e 565% do
  total do mes. Ou seja, resultado_mensal() hoje diz "a NTN-B ganhou R$ 29,5 bi" quando
  a taxa real perdeu R$ 60,6 bi.
  O mesmo vale para a LFT: R$ 568.716,3 dos R$ 738.059,3 mi do total de doze meses (77%)
  sao acumulacao de Selic no VNA. Mesmo mecanismo, entao uma funcao so resolve os dois.
  Pedi resultado_decomposto(), calculada na hora, sem coluna nova e sem CSV.

Ruling: a LFT entra em resultado_mensal() e fica fora de variacao_de_dv(). O revisor
  aprovou a modelagem — PU real implica dinheiro real, ausencia de duration implica fora
  do delta DV — e reprovou so a legibilidade, porque nada avisa que uma coluna cobre
  ~98% do estoque e a outra 46,5%. Mantida a modelagem; a legibilidade entra via I5.
Custo se errado: quem soma as duas colunas compara bases diferentes; o rodape resolve.

Ruling: a faixa do teste de meses consecutivos vai para 24-35, nao 22-35. O motivo do
  implementador era verdadeiro (Carnaval de 2017 e 2022 empurra o ultimo dia util de
  fevereiro para 24/02 e 25/02), mas o revisor varreu 2001-2098 e o minimo possivel e
  exatamente 24 dias (jan->fev de 2006, 2017 e 2090). Melhor ainda e afirmar que data_fim
  cai no mes seguinte ao de data_ini em vez de contar dias.
Custo se errado: nenhum; 24 e o piso medido no calendario inteiro.
Task 8: fix round 1 entregue, commit 96c18e5, 272 testes. O implementador confirmou a
  mao que as duas mutacoes do revisor (estoque final em vez de congelado no C1, e
  universo de ISIN congelado no I2) agora derrubam a suite. C1, I2, I3, I4, I5 e I6
  corrigidos e validados contra os numeros exatos citados na review.

>>> PONTO DE RETOMADA <<<
Task 8 esta com a fix round 1 ENTREGUE mas a RE-REVIEW AINDA NAO FOI DESPACHADA.
O pacote ja esta gerado:
  .superpowers/sdd/2026-08-17-dv01-decay/review-f444a59..96c18e5.diff
Proximo passo exato: despachar a re-review de escopo fechado (modelo sonnet) pedindo
  para reaplicar a mao as duas mutacoes acima e confirmar que falham, conferir que
  resultado_decomposto() existe e separa acumulacao de indice de movimento de taxa para
  NTN-B e LFT, que os totais chamam _cobertura(), que --gravar inclui o
  resultado_mensal.csv, e que as ancoras nao mudaram. Depois: T9 (figuras), T10
  (coerencia e pipeline), T11 (documentacao), review final da branch inteira, e
  finishing-a-development-branch SEM MERGE.

Ruling: as 8 linhas vivas sem pu_fim e sem marcacao distinta (R$ 291.954,8 mi, todas em
  2010-2011, nenhuma nos ultimos 12 meses) NAO viram mudanca de schema agora. O
  implementador pediu confirmacao antes de mexer, e mexer no schema de resultado_mensal()
  no fim da branch troca um risco documentavel por risco de regressao. Vira teste de
  invariante em T10 — afirmar que a contagem e exatamente 8, para que nao cresca em
  silencio — e nota em T11.
Custo se errado: quem somar um mes de 2010-2011 recebe total silenciosamente incompleto;
  os ultimos doze meses estao limpos.

Ruling: painel() NAO vira cache global. O implementador apontou que varios testes usam
  monkeypatch em config.PROCESSED_DIR por teste, e um cache global quebraria o isolamento
  em silencio. Julgamento certo — ele so compartilhou a leitura dentro de
  resultado_decomposto().
Custo se errado: alguns segundos por chamada dupla; o painel roda em 2,3 s.
Task 8: fix round 1/5 (13 addressed, 0 open; commits f444a59..96c18e5), 272 testes.
  A mutacao do Critical agora derruba 4 testes, e o teste passou a varrer todas as linhas
  vivas por merge vetorizado exigindo diferentes.sum() > 0 — nao e mais iloc[0].
  A decomposicao foi RECALCULADA POR FORA, com script que nao chama _resultado_de nem
  resultado_decomposto, so painel() e precificacao.pu direto:
    NTN-B: total +29.495,0, indice +90.095,9, taxa+carrego -60.600,9 (razao 3,05x)
    LFT:   total +568.716,3, indice +561.516,8 (98,7% do proprio total)
    LFT sobre o total de todos os titulos em 12m: 77,1%
  Bate exato com o medido na review. resultado_decomposto() existe, calculada na hora,
  sem coluna nova em _COLUNAS_RESULTADO e sem CSV proprio.
  --gravar rodado de verdade: os tres CSVs sao regravados (9.366, 20.115 e 9.314 linhas)
  com a nota de cobertura no console. A cobertura acompanha a data: 46,5% e 97,8% em
  30/06/2026, 60,39% em 31/12/2020.
  O teste de meses consecutivos deixou de contar dias e passou a andar em ano*12+mes.
  Os dois itens adiados por ruling foram confirmados como apenas documentados.
Task 8: complete (commits 9c28077..96c18e5, review clean)
Task 9: implementada, commits 2dce7ed e f003c3f, 279 testes (272 + 7 novos).
Task 9: review — spec OK, qualidade nao aprovada: 2 Critical + 1 Important.
  Eu mesmo olhei as duas figuras geradas antes de despachar a review e achei os dois
  Critical; o revisor confirmou os dois e achou o Important.
  Critical: rotulos sem acento ("serie observada mes a mes", "convencoes", "construcao",
  "secundario", "milhoes", "ate"). A leitora e brasileira e pode mostrar isso a colegas
  num banco. ASCII puro e acento correto SAO compativeis: escape Unicode em literal e
  byte ASCII no arquivo e renderiza acentuado. O revisor testou nesta maquina — a fonte
  padrao do matplotlib e DejaVu Sans, cobre Latin-1 Supplement, renderizou sem
  quadradinho.
  Critical: a figura do pontual desenha a decomposicao como barras soltas partindo do
  zero, entao vence (+5,2) e decay (+86,5) viram lascas invisiveis ao lado de -1.472,9 e
  -1.381,1, e nada mostra que ligam uma a outra. Os termos intermediarios sao ~50x
  menores que os extremos. Correcao: cascata com barras flutuantes.
  Important: a nota de cobertura pode ser apagada das DUAS figuras com os 279 testes
  passando. A asercao usa `... in textos or "nao e resultado em dinheiro" in
  eixo.get_title()`, e a segunda clausula ja e satisfeita pelo titulo. QUINTA ocorrencia
  nesta branch do padrao "teste que afirma existencia em vez de intencao".
Task 9: fix round 1 despachada — escapes Unicode nos rotulos, cascata no pontual, e
  asercao direta da nota de cobertura em fig.texts nas duas figuras.

Ruling: gravar_todas() grava as DUAS figuras, nao so a do sistema como o brief dizia.
  O revisor concordou com o implementador: grafico_pontual tambem e entregavel da tarefa
  e produzir as duas de uma vez e mais util, sem custo.
Custo se errado: uma figura a mais gravada; uma linha para reverter.

O DV do sistema cresceu ~5,5x de 2010 a 2026 em modulo, puxado principalmente pela
  NTN-B — util para a leitura que a Aline vai querer fazer.
Task 9: fix round 1/5 (3 addressed, 0 open; commits f003c3f..cf511e9), 280 testes.
  Os acentos saem por escape Unicode e o arquivo continua ASCII puro no disco —
  decodificado como ascii estrito sem erro. Trocar um ões por "oes" derruba dois
  testes.
  A cascata foi verificada por geometria, extraindo get_y/get_height dos patches:
    DV na base  pe 0            altura -1472,872661  topo -1472,872661
    vence       pe -1472,872661 altura    +5,248806  topo -1467,623855
    decay       pe -1467,623855 altura   +86,540294  topo -1381,083561
    DV no alvo  pe 0            altura -1381,083561  topo -1381,083561
  O pe de cada barra e o topo da anterior, entao o desenho representa a soma de fato.
  Voltar as quatro barras ao zero derruba o teste da cascata.
  A nota de cobertura foi travada sem `or`: remover de cada figura separadamente derruba
  exatamente um teste cada.
Task 9: complete (commits 96c18e5..cf511e9, review clean)
  Figuras entregues para a Aline. O DV do sistema cresceu ~5,5x em modulo de 2010 a 2026.

Ruling: a barra de "vence" (+5,2 num eixo de ~1.600) fica visualmente uma lasca fina, e
  isso FICA. O implementador nao distorceu a escala e essa foi a decisao certa — o valor
  e pequeno de verdade, e distorcer seria o mesmo erro que a cascata veio corrigir. O
  rotulo numerico e o conector pontilhado dao a leitura.
Custo se errado: nenhum; o numero esta escrito ao lado da barra.
Task 10: implementada, commit c7be972, 286 passed + 1 skipped (280 + 7 novos).
Task 10: review — spec OK, qualidade NAO aprovada: 1 Critical + 5 Important + 4 Minor.
  Ancoras todas conferidas por fora ate o digito. data/raw/ intocado. O --sem-coleta foi
  verificado por AST E empiricamente: o revisor rodou o pipeline com socket.socket e
  getaddrinfo substituidos por excecao e ele foi ate o fim sem tropecar.
  Critical: o teste carro-chefe passa com 30,9% do painel perdido. O revisor refez a
  juncao POR DATA LITERAL e rodou cada assert: len(j)=6074 passa a guarda de >5000, e as
  quatro medianas continuam dentro das bandas (LFT 0,000150; LTN 0,000080; NTN-F
  +0,003650; NTN-B +0,019720). O teste inteiro passa. As medianas nao se mexem porque os
  6.074 sobreviventes sao pares legitimos. Cego para o defeito que convencoes-dv.md:154
  manda vigiar e que ja aconteceu nesta branch. Guarda tem que ser >= 0,93 * len(p).
  Important: o teste de VNA e ESTRUTURALMENTE INFALSIFICAVEL. O dv.py:73-79 monta
  vna_por = {(data, indice): vna} — a chave NAO TEM ISIN — e atribui por titulo, entao
  todo papel do mesmo titulo na mesma data recebe o mesmo valor por construcao e o
  nunique() so pode dar 1. Sob a mutacao de _INDICE_DO_TITULO tres testes falham e este
  passa. A invariante de verdade ja mora em parse_bloomberg._TOLERANCIA_DIVERGENCIA.
  SEXTA ocorrencia do padrao "afirma o resultado em vez da intencao".
  Important: as bandas de CONTROLE tem 11,3x e 27,1x de folga (LFT -0,0221% e LTN
  +0,0092% contra limiar de 0,25%), e a autorrevisao afirmou o contrario. Um erro de
  0,24% passa calado e vale R$ 3,0 bi no livro de LTN e R$ 11,0 bi no de LFT.
  Important: o except Exception do pipeline funde cinco modos de falha com o caso
  SAUDAVEL (RuntimeError "nada novo a coletar"). Nos cinco: mesma linha "pulada", CSVs
  regravados de dado velho, "concluido." e saida 0.
  Important: pipeline.py tem cobertura de teste ZERO — nao existe tests/test_pipeline.py.
  Important: faltava mesmo o teste de cobertura de taxa. O revisor confirmou 93,89% e
  99,23% por fora, e mediu que a cobertura vai a 0,00% se a normalizacao de data quebrar
  do lado da taxa. O len(j) do Critical e o numerador da cobertura sao o mesmo 8.794.
Task 10: fix round 1 despachada.

Correcao ao meu enunciado: sao 17 + 5 CSVs (taxa_por_papel, vna, dv_por_papel,
  decay_por_papel, resultado_mensal), nao 17 + 3. O implementador estava certo.

Ruling: a reescrita do teste de papel vencido FICA. A premissa do brief estava errada
  contra o dado real e o revisor confirmou de forma independente: existe exatamente 1
  linha com vencimento < data (BRSTNCNTF071, NTN-F vencida em 01/01/2014, 604,9 mil em
  31/01/2014, com taxa_pct, pu e dv_unitario todos vazios). O implementador afirmou o
  comportamento real em vez de acomodar defeito.
Custo se errado: nenhum; o comportamento esta descrito e travado.

Licao de metodo, para carregar nos dispatches restantes: duas afirmacoes da autorrevisao
  do implementador nao se reproduziram (a das bandas e a do PowerShell no relatorio), e
  foi isso que deixou o Critical e o Important 3 sobreviverem. Exigir que, para cada
  asercao escrita ou apertada, ele APAGUE a linha protegida e confirme a falha antes de
  afirmar que trava algo.
Task 10: fix round 1/5 (9 addressed, 0 open; commits c7be972..0610109), 294 passed + 1
  skipped. Tudo confirmado por mutacao real, nao por leitura do relatorio:
  - a juncao por data literal agora derruba o teste com mensagem explicita ("juncao
    produziu 6074 pares de 9366, 64.9%"); a guarda nova 0,93*len(p)=8710 reprova 6.074
    e aprova 8.794.
  - o teste de VNA le o bbg_vna_*.csv bruto, fora do dict vna_por; injetando
    divergencia=5.0 num arquivo sintetico ele acusa. E falsificavel agora.
  - folga das bandas de controle medida do zero: LFT 2,72x e LTN 3,26x, contra 11,3x e
    27,1x antes.
  - os cinco modos de falha da coleta foram forcados: blpapi ausente, sessao recusada,
    arquivo corrompido e estoque ausente saem com codigo 1, prefixo ATENCAO e SEM
    "concluido."; o RuntimeError benigno sai com 0 e "concluido.". Reverter para o
    except unico quebra dois testes.
  - test_sem_coleta_nunca_toca_rede passa com socket bloqueado; trocar a guarda por
    `if True:` derruba, e promover o import do coletor ao topo derruba o teste de AST.
  - cobertura de taxa recontada: 93,8928% e 99,2260%. O revisor montou um
    taxa_por_papel.csv com datas deslocadas +3 dias em diretorio isolado e o teste
    reportou 0,00%, como previsto.
  - pipeline rodado de ponta a ponta com --sem-coleta: exit 0, 22 CSVs (17+5), com
    9.366, 20.115 e 9.314 linhas. data/processed/ restaurado byte-identico.
Task 10: complete (commits cf511e9..0610109, review clean)
  Pendente da autorizacao da Aline: o teste contra PX_DIRTY_MID continua pulado, por
  falta do bbg_precos_*.csv.
Task 11: implementada, commit 65ffad5, 294 passed + 1 skipped (nenhum .py tocado).
Task 11: review — spec OK (os onze itens presentes nos lugares certos), qualidade
  aprovada com correcoes: 3 Critical + 5 Important + 5 Minor. O revisor extraiu ~95
  afirmacoes numericas dos seis .md e conferiu cada uma rodando o codigo: 5 erradas e
  3 imprecisas. Ele tambem leu o baixar() linha a linha e confirmou que o procedimento
  de recuperacao descreve o comportamento real com exatidao.
  Critical: a faixa da NTN-B 2050 nao reproduz. O doc diz 5,34%-5,54%; a bissecao sobre
  pu_ntnb na janela de doze anos (2014-01 a 2026-06, 150 obs) da 5,4001%-5,5588%.
  Nenhuma janela contigua produz 5,34/5,54. Sao os dois numeros publicados como
  evidencia central, e os guard-rails do teste (>5,2 e <5,7) acomodam os dois.
  Critical: "LTN 335 linhas, espalhadas de 2013 a 2026" — o value_counts da 2010 a 2026,
  com 38 linhas em 2010-2011. E o erro esta no paragrafo que manda conferir com
  value_counts para nao repetir erro factual no dicionario.
  Critical: "decay e POSITIVO para um sobrevivente" tem 933 contraexemplos — 5,0% das
  18.596 linhas, todas NTN-B, sendo 24,6% do horizonte de 1du. Magnitude minuscula
  (mediana -0,000019) e causa conhecida (quantizacao da truncagem), mas quem filtrar
  decay < 0 procurando defeito acha 933 linhas.
  Important: "vespera de" esta errado — 29/03/2013, 30/03/2018 e 29/03/2024 SAO Paixao
  de Cristo; 28/02/2017 e 28/02/2022 SAO Carnaval; 31/05/2018 E Corpus Christi.
  Important: o procedimento de recuperacao usa sintaxe bash sozinha. QUARTO caso na
  branch, e e o unico procedimento que ela executaria sob pressao.
  Important: o roteiro a mao nao fecha se digitado literalmente — o expoente impresso
  arredondado (0,746032) da 908,347854 em vez de 908,347884.
  Important: a ressalva da LFT precisa ir para a doc. Reproduzida: 2.506 pares, mediana
  3,1 bp, 97,1% dentro de 25 bp, mas maximo de 1.013 bp e 24 obs acima de 100 bp, todas
  com du entre 1 e 11.
Task 11: fix round 1 despachada.

Correcao ao meu enunciado, confirmada pelo revisor: as 572 linhas sem taxa sao LTN 335,
  LFT 155, NTN-B 73 e NTN-F 9 — nao "quase todas LFT". As LFT sim sao 100% de 2010-2011.
Task 11: fix round 1/5 (todos addressed, 0 open; commits 65ffad5..d9abd9e), 294 + 1
  skipped. O re-revisor conferiu mais de 70 afirmacoes numericas por execucao direta
  (bissecao propria, value_counts, leitura do .xls, dv.painel/resultado_decomposto/
  _cobertura, e dois comandos reais em PowerShell) e ZERO estavam erradas. Destaques:
  a faixa da NTN-B bate 5,4001%-5,5588% nas tres copias do documento; a janela das LTN
  bate 2010-2026 com 38 linhas em 2010-2011; o roteiro a mao FECHA seguindo o expoente
  como fracao (188/252 ou os 10 algarismos mostrados), com contraste confirmado contra
  o caminho errado (arredondar da 908,347854).
Task 11: complete (commits 0610109..d9abd9e, review clean)

JULGAMENTO INDEPENDENTE CONFIRMADO: o implementador estava certo em nao publicar o
  maximo da LFT. O re-revisor rodou a bissecao com dois conjuntos de limites — estreito
  (-5%/+5%) deu maximo 514,27 bp, largo (-50%/+50%) deu 1.311,55 bp — o maximo se move
  quase 2,5x com o limite de busca, enquanto mediana/percentual/contagem ficam identicos
  nas duas rodadas. E artefato do solver perto do vencimento (PU quase plano no agio),
  nao fato estavel. Publicar so as tres estatisticas estaveis foi a decisao tecnicamente
  melhor, nao um desvio da minha instrucao original (que citava 1.013 bp sem checar
  estabilidade).

>>> ONZE DE ONZE TAREFAS CONCLUIDAS E REVISADAS <<<
Proximo passo: revisao final de branch inteira (o mais capaz disponivel), depois UM
ciclo de fix + re-review escopado, depois finishing-a-development-branch SEM MERGE.

=== REVISAO FINAL DE BRANCH INTEIRA ===
Feita por mim, no loop principal, e nao por subagente: quatro tentativas de despachar
o Agent de revisao final falharam com erro 529 (API sobrecarregada) enquanto as minhas
proprias respostas passavam normalmente. Eu rodo em Opus 5, que e o modelo que a skill
pede para esta etapa; o motivo de delegar era preservar contexto, nao capacidade. E como
as 11 revisoes por tarefa ja mutaram cada peca isoladamente, o que faltava era so a
checagem de conjunto, que sai por comandos direcionados em vez de leitura dos 309 KB.
A Aline perguntou quais eram as outras opcoes e eu apresentei quatro; esta foi a escolhida.

Verificado e limpo:
  - precificacao.py byte-identico desde 73cc9c5 que o introduziu (diff vazio).
  - nenhum commit da branch tocou data/raw/ (git log -- data/raw/ vazio).
  - nenhum numpy em src/, tests/ ou requirements.txt.
  - imports fora da lista permitida: so urllib.request/zipfile/json, e todos moram em
    fetch_leiloes.py e fetch_rmd.py, da entrega anterior, que esta branch nao tocou.
  - todos os .py da branch inteiramente ASCII (decodificacao estrita).
  - _decay_de tem UMA definicao e dois usos (decay() e pontual()); o resultado mensal
    corretamente nao a usa, porque e Conta A e nao decay. Sem duplicacao.
  - _cobertura tem UMA definicao, usada por pontual, resultado e figuras (via
    dv._cobertura). Nenhuma constante fixa de cobertura sobreviveu em src/.
  - pipeline --sem-coleta rodado de ponta a ponta: exit 0, 22 CSVs, 9.366/20.115/9.314
    linhas, data/raw/ intocado e CSVs byte-identicos na segunda rodada (deterministico).
  - nenhum TODO/FIXME/XXX/HACK (os dois hits de grep sao a palavra "TODOS").
  - nenhum import morto (checagem por AST nos arquivos da branch).
  - nenhum assert com `or` em teste nenhum — o padrao do 5o caso nao se repetiu.
  - convencoes-dv.md: 15 secoes, nenhuma duplicada, e a secao "Escopo" ja explica de
    proposito a diferenca entre 46,6% (soma das parcelas arredondadas) e 46,5% (total
    com precisao). A documentacao estava mais cuidadosa do que eu supunha.
  - suite 294 passed, 1 skipped.

Quatro asserts com .all() sem guarda de nao-vacuidade no mesmo teste
  (test_decay::test_data_alvo_e_posterior_a_base, test_fetch_bloomberg::
  test_papeis_trazem_a_janela_de_vida, test_parse_bloomberg::test_vna_da_selic_nunca_cai,
  test_resultado::test_periodos_sao_meses_consecutivos) foram avaliados e NAO sao achado:
  sao invariantes secundarias sobre frames cujo tamanho esta fixado em outro lugar da
  mesma suite (80/80/126 no decay, cinco guardas len()>0 no resultado, 9.366 linhas e o
  DV total no painel). Um frame vazio derruba as ancoras alto antes de tornar esses
  vacuos. Registrado como observacao.

TRES ACHADOS, todos de texto e nenhum de numero, corrigidos no commit 410dc9d:
  Important: T11 qualificou em convencoes-dv.md a afirmacao "decay e POSITIVO para um
    sobrevivente", acrescentando a excecao das 933 linhas; mas o comentario de
    dv.py:136-142, de onde o texto foi transcrito, seguia absoluto — e o documento citava
    dv.py como Fonte. Quem seguisse a citacao lia a versao contraditoria. Classe de
    achado que so aparece no conjunto: o diff de T11 tocava so .md, entao a revisao
    daquela tarefa nao podia ver o comentario que precisava mudar junto.
  Minor: dv.py:236 e figuras.py:92 diziam que 46,6% e o numero publicado em
    convencoes-dv.md; o documento publica 46,5%.
  Minor: a spec do sub-projeto ficou em 46,6% enquanto a spec da camada de dados foi
    atualizada para 46,5%.

VEREDITO: branch pronta como candidata a merge. Nada de logica, nada de numero, nada de
seguranca de dados. Proximo e ultimo passo: finishing-a-development-branch, SEM MERGE —
a Aline escolheu "Plano + execucao, em branch" e decide o merge ela mesma.

Achado da Aline na revisao final, e ela estava certa: o decay congela o VNA da
  data-base tambem na data-alvo. Medi o efeito antes de argumentar — o DV da NTN-B
  escala linearmente com o VNA, entao a acrecao move o dv_alvo na mesma proporcao. No
  horizonte de 21du a partir de 30/06/2026, contra os 15,911 congelados: IPCA 0,20% da
  13,733 (-13,7%); 0,35% da 12,101 (-23,9%); 0,50% da 10,468 (-34,2%); 0,70% da 8,291
  (-47,9%). Congelar SUPERESTIMA o decay. Em seis meses passa de 30%.
  Decisao dela: a entrega 2 fecha com o VNA congelado e rotulado, e o VNA projetado
  vira sub-projeto proprio. Ela recusou mudar dentro desta branch e recusou discutir o
  metodo na hora.
  Documentado em docs/convencoes-dv.md (secao nova "Limitacao conhecida da Conta B",
  com a tabela e a leitura economica) e na secao 12 da spec. Commit a4de03b.
  Memoria: vna-projetado-decay.md, com as tres opcoes de insumo levantadas.

=== BRANCH ENCERRADA ===
Opcao escolhida pela Aline: manter a branch como esta. Nada foi mergeado no master,
nenhuma branch foi apagada, nenhum worktree a limpar (repo normal, GIT_DIR == GIT_COMMON).
Nao ha remoto configurado, entao a opcao de PR exigiria criar o repositorio no GitHub
primeiro — ofertada e nao escolhida.
Estado final: branch dv01-decay, 27 commits, 294 passed + 1 skipped, arvore limpa.
O skipped e o teste contra PX_DIRTY_MID, que aguarda autorizacao dela para puxar
bbg_precos_*.csv.
Pendencias que dependem dela, nao de codigo:
  - verificacao ao vivo do coletor da Bloomberg (task-4-report.md tem o comando em
    PowerShell e o que esperar);
  - o teste contra PX_DIRTY_MID, que passa a rodar quando o bbg_precos_*.csv existir.
Proximo sub-projeto acordado: VNA projetado no decay (ver vna-projetado-decay.md na
memoria, e a secao 12 da spec).

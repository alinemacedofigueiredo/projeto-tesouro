### Task 5: Painel de DV por papel -- relatorio

**Status:** concluida.

**Commit:** `f1a345a` -- "Adiciona painel de DV por papel (Tarefa 5)" (branch
`dv01-decay`). Arquivos: `src/tesouro/dv.py`, `tests/test_dv.py`.

**Testes:** `13 passed` em `tests/test_dv.py` (9 do brief + 4 adicionais);
suite inteira `218 passed` (205 anteriores + 13 novos), nenhuma regressao.

**Preocupacoes:** nenhuma bloqueante. Um ponto de atencao registrado na
autorrevisao (diferenca entre a fracao do DV01 medida contra o nosso
`financeiro_calculado_milhoes` e a fracao documentada em
`docs/convencoes-dv.md`, que usa o `financeiro_milhoes` do RMD -- ver
abaixo).

---

#### O defeito conhecido do brief, corrigido

A linha do `_com_precos` que decide se uma linha entra na precificacao ou
fica vazia estava:

```python
if pd.isna(r.taxa_pct) or (precisa_vna and r.vna is None):
```

Corrigida para:

```python
if pd.isna(r.taxa_pct) or (precisa_vna and pd.isna(r.vna)):
```

**Confirmado a mao, como o dispatch pediu:** revertida a correcao numa
copia de trabalho, com uma fixture de duas NTN-B (uma com VNA de IPCA na
data, outra sem -- as duas linhas sao necessarias porque com uma NTN-B so
a coluna `vna` do DataFrame teria um unico valor `None` e ficaria em
dtype `object`, o que mascararia o defeito; com duas, o pandas promove a
coluna a `float64` e o ausente vira `NaN` de verdade). Com a linha
revertida, o teste `test_vna_ausente_pula_a_linha_em_vez_de_precificar_com_nan`
**falha com `ValueError: cannot convert float NaN to integer`**, dentro de
`precificacao._truncar` -- pior que o "PU NaN silencioso" que o dispatch
descreveu como pior caso, porque a NTN-B sem VNA chega a derrubar
`painel()` inteiro em vez de so ficar com preco vazio. Restaurada a
correcao, o teste volta a passar. Ver `tests/test_dv.py`, comentario
acima da funcao.

---

#### O painel gerado

```
gravado: data\processed\dv_por_papel.csv (9366 linhas)
```

9.366 pares papel-mes, exatamente o numero medido no dispatch para o
escopo (LTN, NTN-F, NTN-B, LFT) apos filtrar `quantidade_mil > 0` -- sem
perda em relacao a esse total, porque a juncao com taxa e VNA e `how="left"`
a partir do estoque (papel sem taxa entra com preco vazio, nunca some).

**Tempo de execucao**, medido com `time.perf_counter()`:

| etapa | tempo |
|---|---|
| `import tesouro.dv` (inclui montar o indice do calendario) | 0,92 s |
| `dv.painel()` | 1,55 s |
| `dv.gravar_painel()` completo (painel + escrita do CSV) | 2,32 s |

Bem abaixo do limite de dois minutos do brief -- o indice acumulado do
calendario (Tarefa 1) cumpre o que prometia.

---

#### Cobertura de taxa, medida contra o que o dispatch esperava

```python
pares totais: 9366
com taxa: 8794  ->  93.89%
financeiro total (RMD, escopo): 740.820.469 milhoes
financeiro com taxa: 735.086.190 milhoes  ->  99.23%
ultimo mes (2026-06-30): 2 de 52 pares sem taxa  ->  0,10% do financeiro do mes
```

Os tres numeros batem exatamente com os que o dispatch trouxe como
referencia (93,89% dos pares, 99,23% ponderado pelo financeiro, 0,10% do
estoque sem taxa no ultimo mes) -- nao precisou investigar divergencia.

---

#### O DV total do sistema no ultimo mes, com a cobertura ao lado

**Data do ultimo mes do painel: 2026-06-30.**

| titulo | DV da posicao (R$ milhoes por bp) |
|---|---:|
| LTN | -198,54 |
| NTN-F | -177,76 |
| NTN-B | -1.096,58 |
| **Total** | **-1.472,87** |

**O DV01 agregado cobre 46,6% do estoque de junho de 2026** (LTN 14,4% +
NTN-F 7,5% + NTN-B 24,7%, medido sobre o `financeiro_milhoes` do RMD --
ver `docs/convencoes-dv.md`). Os outros 53,4% sao LFT (51,3%, sem duration
de juros por construcao) e os excluidos (NTN-C, NTN-B Principal, RendA+,
EducA+ -- 2,1%, sem preco observavel no secundario).

Ou seja: **um choque de +1 bp em toda a curva custa cerca de R$ 1,47
bilhao ao mercado que carrega LTN, NTN-F e NTN-B, e esse numero fala so
por 46,6% do estoque da divida.** Os 53,4% restantes (majoritariamente
LFT) nao tem essa sensibilidade medida neste projeto, por decisao de
modelagem -- somar o DV01 e supor que ele cobre a divida inteira
superestima em mais do que o dobro o quanto do estoque ele de fato
representa.

---

#### Autorrevisao

- **Bug do brief**: corrigido e travado com teste de regressao verificado
  a mao (ver secao acima). O comentario no proprio `dv.py`, na guarda,
  explica o mecanismo (`None` -> `NaN` em coluna numerica mista) e aponta
  para o teste.
- **Taxa em decimal, uma vez so**: a divisao por 100 (`r.taxa_pct / 100.0`)
  acontece numa unica linha de `_com_precos`, documentada no docstring do
  modulo. `test_taxa_pct_converte_de_percentual_para_decimal_uma_vez`
  ancora um valor exato (`1000 / 1,10 = 909,090909...`, a mesma ancora que
  `tests/test_precificacao.py` usa) contra `taxa_pct=10.0` (10%) -- um
  fator 100 esquecido (mandar `10.0` cru para o motor) erraria essa
  asserção por ordens de grandeza, nao por uma diferenca pequena.
- **`dv_unitario` da LFT vazio, financeiro nao**: `test_dv_da_lft_e_vazio_e_o_financeiro_nao`
  do brief cobre isso contra o dado real (mais de mil linhas de LFT com
  preco e sem DV).
- **DV de papel vencido e `0.0`, nao `None`**: nao coberto pelos 9 testes
  do brief (o unico caso real no estoque, `BRSTNCNTF071`/NTN-F vencendo
  2014-01-01, nao tem taxa disponivel na data em que aparece vencido, entao
  cai no ramo "sem taxa" e nao exercita este caminho). Acrescentei
  `test_papel_vencido_com_taxa_fica_com_dv_zero_e_nao_none` com uma LTN
  sintetica vencida ha anos mas com taxa presente -- confirma `pu == 0.0`
  e `dv_unitario == 0.0` (nao `NaN`), decorrente diretamente de
  `precificacao.pu_ltn`/`dv` (nao alterados) devolverem zero quando
  `d0 >= venc`.
- **Armadilha da juncao (dia corrido vs dia util)**: coberta pelo dado
  real (`test_datas_sao_ultimo_dia_util`, que falharia em pelo menos uma
  das 61 datas divergentes se a normalizacao sumisse) e por uma fixture
  sintetica dedicada, `test_normalizacao_do_estoque_permite_casar_com_taxa_e_vna`,
  com um mes onde o ultimo dia corrido (31/12/2023, domingo) e o ultimo
  dia util (29/12/2023) sao datas diferentes -- prova que a taxa so casa
  com a posicao porque `_posicoes` normaliza a data do estoque antes de
  qualquer juncao. **Confirmado a mao**: substituindo a linha
  `e["data"] = e["data"].dt.date.map(cal.ultimo_dia_util_do_mes)` por so
  `e["data"] = e["data"].dt.date` (converte para `date` sem normalizar),
  **dois testes falham**: o dedicado (na asserção `linha["data"] == util`,
  porque a posicao fica com 31/12 e a taxa so existe em 29/12) e tambem o
  proprio `test_datas_sao_ultimo_dia_util` do brief contra o dado real
  (varias das 198 datas do painel deixam de ser ultimo dia util) --
  exatamente o cenario que o dispatch descreveu como tendo sobrevivido a
  suite inteira verde na Tarefa 3. Restaurada a linha, os dois voltam a
  passar.
- **`r["isin"]` vs `r.isin`**: o modulo itera com
  `df.itertuples(index=False)`; nao ha `r.isin` em lugar nenhum do loop
  (os campos usados sao `r.titulo`, `r.taxa_pct`, `r.vna`, `r.data`,
  `r.vencimento`), entao o problema documentado (`Series.isin` sombreando
  a coluna) nao se aplica -- `itertuples` gera `namedtuple`, nao `Series`.
- **`pd.isna` em toda comparacao de coluna numerica**: conferido -- as duas
  guardas (`taxa_pct`, `vna`) usam `pd.isna`; nenhuma comparacao contra
  `None` sobrou no modulo.
- **ASCII puro**: `dv.py` e `test_dv.py` decodificados como `ascii` sem
  erro.
- **`data/raw/` intocado**: `dv.py` so le `config.PROCESSED_DIR`
  (`estoque_titulos_vencimento.csv`, `taxa_por_papel.csv`, `vna.csv`) e so
  escreve `data/processed/dv_por_papel.csv`. `git status --porcelain`
  confirma que nada em `data/raw/` mudou (o repositorio ignora
  `data/processed/` inteiro via `data/**` no `.gitignore`, entao
  `dv_por_papel.csv` nem aparece como untracked).
- **Caminhos absolutos**: `dv.py` usa `config.PROCESSED_DIR` em toda
  leitura/escrita, nunca caminho relativo ao diretorio de trabalho.
- **Ponto de atencao, nao um defeito**: a fracao "46,6%" documentada em
  `docs/convencoes-dv.md` e medida sobre o `financeiro_milhoes` que o
  proprio RMD reporta (coluna que existe em
  `estoque_titulos_vencimento.csv` mas nao entra no painel de saida).
  Recalculando a mesma fracao com o `financeiro_calculado_milhoes` deste
  painel (PU recem-calculado x quantidade), o numero sai um pouco
  diferente (43,3% em vez de 46,6%), porque o RMD e o nosso motor de
  precificacao naturalmente nao concordam PU a PU. Usei a fracao
  documentada (46,6%, fonte RMD) no numero final acima, por ser a
  referencia ja validada -- vale a Aline saber que as duas contas existem
  e nao sao a mesma conta.

---

#### O que continua igual do brief original, para quem ler so este relatorio

- Interface: `dv.painel() -> DataFrame` com as onze colunas canonicas,
  `dv.gravar_painel() -> None` escrevendo `dv_por_papel.csv`.
- `precificacao.py` e `calendario.py` no foram tocados.
- `gravar_painel()` usa `df.to_csv` direto (nao `gravacao.gravar_atomico`,
  reservado a downloads brutos de rede), mesmo padrao de
  `parse_bloomberg.gravar()` e `parse_leiloes`.

---

## Resposta a revisao de qualidade

Aprovado com ressalvas (conformidade OK; numero confirmado por
reimplementacao independente do revisor: -1.473,15 contra o nosso
-1.472,87, diferenca de 0,02% explicada por quatro NTN-B do lado oposto
do degrau de truncagem da cotacao em 4 casas). Dez mutacoes aplicadas,
nove derrubam a suite -- a normalizacao de data nao repetiu o problema da
Tarefa 3. Duas correcoes ao dispatch original (9.366 linhas, nao 12.965
pares; merge ingenuo perde 35,1%, nao 33,7%) ja incorporadas no corpo
deste relatorio.

**Commit desta correcao:** `5a31d3e` -- "Corrige achados da revisao do
painel de DV (tarefa 5)". Arquivos tocados: `src/tesouro/dv.py`,
`tests/test_dv.py`. `precificacao.py` **nao foi tocado**, confirmado com
`git diff --stat src/tesouro/precificacao.py` (saida vazia) antes de
commitar.

### 1 (Important) -- a trava do defeito do brief so afirmava o resultado

O teste original checava `pd.isna(pu)`, `pd.isna(dv_unitario)`,
`pd.isna(financeiro)` -- e um `_truncar` tolerante a NaN satisfaz essas
mesmas tres asserções sem que a guarda tivesse feito nada; quem derrubava
o teste era o `ValueError` de `precificacao._truncar`, nao a logica que o
nome do teste promete. Reescrito com uma funcao auxiliar `_espiar_pu` que
substitui `precificacao.pu` por uma versao que registra `(data, titulo)`
de cada chamada antes de delegar para a implementacao real, via
`monkeypatch.setattr(precificacao, "pu", ...)`. A asserção central agora
e `assert (d2, "NTN-B") not in chamadas` -- comportamento, nao resultado.

Acrescentado tambem `test_lft_vencida_sem_vna_nao_chama_pu`, cobrindo o
caminho genuinamente silencioso que o revisor achou: `pu_lft` devolve
`0.0` **antes** de tocar no `vna` quando o papel esta vencido
(`d0 >= venc`), entao uma LFT vencida com taxa e sem VNA sairia com
`pu=0.0` e financeiro `0.0` (em vez de vazio) com a guarda quebrada, sem
levantar nada -- o oposto do `ValueError` que a NTN-B produz. A mesma
asserção de espiao (`chamadas == []`) fecha os dois casos.

**Confirmado a mao, como o dispatch pediu:**
- Revertendo so a guarda (`r.vna is None`) **com** um `_truncar` tolerante
  a NaN aplicado por monkeypatch em tempo de execucao (sem tocar
  `precificacao.py` em disco, para nao violar a restricao de nao mexer
  nesse arquivo): `test_vna_ausente_pula_a_linha_em_vez_de_precificar_com_nan`
  **falha**, na asserção `(d2, "NTN-B") not in chamadas` -- a chamada
  acontece seis vezes (duas datas, `pu` chamado dentro de `precificacao.dv`
  alem do `pu` direto). O teste flagra a falha mesmo com a rede de
  seguranca do `_truncar` tolerante removida.
- Revertendo so a guarda, sem o `_truncar` tolerante (comportamento real
  hoje): `test_vna_casa_com_o_indice_certo_por_titulo`,
  `test_dv_por_titulo_no_ultimo_mes_bate_com_o_valor_medido`,
  `test_vna_ausente_pula_a_linha_em_vez_de_precificar_com_nan` e
  `test_lft_vencida_sem_vna_nao_chama_pu` falham (os dois primeiros por
  efeito colateral da mutacao seguinte, ver item 2). Restaurada a guarda,
  os 222 voltam a passar.

### 2 (Important) -- bandas largas deixam passar o indice trocado

`test_ordem_de_grandeza_do_financeiro` e
`test_dv_total_do_sistema_e_plausivel` tem 40x de folga: o revisor mediu
`_INDICE_DO_TITULO` trocado (`NTN-B: "SELIC", LFT: "IPCA"`) dando
financeiro 11,03 tri e DV -4.847,1 (3,3x errado), os dois dentro da banda.

Acrescentados dois testes contra o dado real:
- `test_vna_casa_com_o_indice_certo_por_titulo`: o `vna` de cada linha de
  NTN-B bate, valor a valor, com o IPCA cru de `vna.csv` naquela data
  (nunca o SELIC), e o de cada LFT bate com o SELIC (nunca o IPCA); LTN e
  NTN-F ficam sempre sem `vna`.
- `test_dv_por_titulo_no_ultimo_mes_bate_com_o_valor_medido`: ancora o
  DV de 2026-06-30 por titulo (LTN -198,54, NTN-F -177,76, NTN-B
  -1.096,58, total -1.472,87 milhoes) com tolerancia de 1%.

**Confirmado a mao:** com `_INDICE_DO_TITULO` trocado exatamente como o
revisor descreveu, **quatro testes falham**:
`test_vna_casa_com_o_indice_certo_por_titulo`,
`test_dv_por_titulo_no_ultimo_mes_bate_com_o_valor_medido`,
`test_vna_ausente_pula_a_linha_em_vez_de_precificar_com_nan` (a NTN-B do
teste passa a nao achar VNA de SELIC, o assert de controle
`(d1, "NTN-B") in chamadas` falha) e `test_lft_vencida_sem_vna_nao_chama_pu`
(a LFT passa a achar VNA de IPCA em vez de precisar de SELIC, e `pu` e
chamado quando o teste espera que nao seja). As duas bandas largas
originais (`test_ordem_de_grandeza_do_financeiro`,
`test_dv_total_do_sistema_e_plausivel`) continuam passando com a mutacao,
como o revisor mediu -- sao as duas novas que fecham o buraco. Restaurado
o dicionario original, os 222 voltam a passar.

### Minors

- **`len(tit) > 0` em `test_dv_dos_titulos_e_negativo`**: acrescentado
  (`> 1000`, mesma ordem de grandeza do teste irmao da LFT), para que os
  dois `.all()` seguintes nao passem vacuamente num frame vazio.
- **`vna.csv` com `(data, indice)` duplicado**: `_com_precos` agora
  checa `vn.duplicated(subset=["data", "indice"])` antes de montar
  `vna_por` e levanta `ValueError` com os exemplos e a contagem, em vez
  de deixar o dict ficar com a ultima ocorrencia em silencio. Testado em
  `test_vna_csv_com_data_indice_duplicado_levanta_erro`
  (`pytest.raises(ValueError, match="duplicado")`).

### Verificacao final desta rodada

Suite completa: **222 passed** (218 anteriores + 4 novos:
`test_vna_casa_com_o_indice_certo_por_titulo`,
`test_dv_por_titulo_no_ultimo_mes_bate_com_o_valor_medido`,
`test_lft_vencida_sem_vna_nao_chama_pu`,
`test_vna_csv_com_data_indice_duplicado_levanta_erro` -- a reescrita do
teste de VNA ausente substituiu o antigo sem mudar a contagem). As
mutacoes do indice trocado e da guarda revertida (com e sem `_truncar`
tolerante) foram reproduzidas a mao, uma de cada vez, e cada uma falha
exatamente onde a revisao previu; revertidas, a suite volta a 222/222.
ASCII conferido de novo em `dv.py` e `test_dv.py` (achei e corrigi um
"asserção"/"asserções" com cedilha introduzido nesta rodada, trocado por
"assercao"/"assercoes"). `git status --porcelain` mostra so os dois
arquivos de codigo tocados; `data/raw/` e `data/processed/` inalterados.

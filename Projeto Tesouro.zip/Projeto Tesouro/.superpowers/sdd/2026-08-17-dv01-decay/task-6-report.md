### Task 6: Decay nos horizontes fixos -- relatorio

**Status:** concluida.

**Commit:** `17e0575` -- "Adiciona decay nos horizontes fixos, separando o
que vence" (branch `dv01-decay`). Arquivos: `src/tesouro/dv.py`,
`tests/test_decay.py`.

**Testes:** `12 passed` em `tests/test_decay.py` (9 do brief + 3
adicionais); suite inteira `234 passed` (222 anteriores + 12 novos),
nenhuma regressao.

**Preocupacoes:** nenhuma bloqueante. Um teste do brief (limiar de 98% em
`test_decay_reduz_o_modulo_do_dv_dos_sobreviventes`) reprovava o dado real
e foi ajustado na autorrevisao -- detalhe abaixo, nao e um defeito no
codigo de producao.

---

#### Interface entregue

- `dv.HORIZONTES = {"1du": 1, "5du": 5, "21du": 21}`
- `dv._decay_de(cal, linhas, data_base, data_alvo, rotulo)` -- funcao
  unica que a Tarefa 7 vai reusar para o calculo pontual, trocando so a
  data-alvo.
- `dv._COLUNAS_DECAY` -- `data_base, horizonte, data_alvo, isin, titulo,
  venceu_no_caminho, dv_base, dv_alvo, decay`.
- `dv.decay(horizontes=None) -> DataFrame`
- `dv.gravar_decay() -> None` -- escreve `decay_por_papel.csv`

`precificacao.py` **nao foi tocado**, confirmado com
`git diff --stat src/tesouro/precificacao.py` (saida vazia).

---

#### O arquivo gerado

```
gravado: data\processed\decay_por_papel.csv (20115 linhas)
```

6.705 pares papel-mes (o painel sem LFT) x 3 horizontes = 20.115 linhas,
exatamente "casa de 20 mil" como o brief previa.

**Tempo de execucao**, medido nesta sessao:

| etapa | tempo |
|---|---:|
| `dv.decay()` (3 horizontes) | 4,53 s |
| `dv.gravar_decay()` completo (decay + escrita do CSV) | 4,60 s |

Cerca de 2x o tempo de `dv.painel()` sozinho (2,3 s) -- esperado, porque
`decay()` chama `painel()` uma vez e depois reprecifica cada papel vivo em
ate 3 datas-alvo adicionais (uma por horizonte), cada reprecificacao
custando o mesmo que o calculo de `dv_unitario` do proprio painel. Nao e
"muito mais" que a referencia de 2,3 s pedida no dispatch; nenhuma
otimizacao adicional pareceu necessaria.

---

#### O decay do sistema em 2026-06-30, com a quebra vencido/sobrevivente

`data_base` mais recente do painel: **2026-06-30**. Um unico papel
(`BRSTNCLTN848`, LTN vencendo 2026-07-01) vence dentro dos tres
horizontes -- inclusive o de 1 dia util, porque seu vencimento cai bem no
dia seguinte.

| horizonte | data_alvo | papeis vencidos no caminho | DV que sumiu (dv_base do vencido) | sobreviventes (n) | decay dos sobreviventes (R$ mi/bp) | dv_base sobrev. | dv_alvo sobrev. |
|---|---|---:|---:|---:|---:|---:|---:|
| 1du | 2026-07-01 | 1 | -0,0749 | 32 | 0,6548 | -1.472,7977 | -1.472,1429 |
| 5du | 2026-07-07 | 1 | -0,0749 | 32 | 3,9642 | -1.472,7977 | -1.468,8335 |
| 21du | 2026-07-29 | 1 | -0,0749 | 32 | 15,9106 | -1.472,7977 | -1.456,8871 |

Leitura: em 21 dias uteis o mercado que carrega LTN, NTN-F e NTN-B perde
cerca de **R$ 15,9 milhoes de DV por bp so pela passagem do tempo** (taxa
e VNA constantes) -- e mais R$ 0,07 milhoes de risco que simplesmente
deixa de existir porque um papel venceu no caminho, numero que fica **de
fora** dessa soma porque `venceu_no_caminho` o marca a parte.

Conferencia cruzada: `dv_base` (sobreviventes) + `dv_base` (vencido) =
-1.472,7977 + (-0,0749) = **-1.472,8726**, batendo com o total de
-1.472,87 medido em `test_dv.py`/`docs/convencoes-dv.md` para 2026-06-30 --
confirma que `_decay_de` carrega `dv_base = r.dv_posicao_milhoes` sem
alterar nada do painel original.

---

#### Divergencia medida na verificacao de aditividade (21du vs. soma de 21 passos diarios)

Implementada em `test_21du_e_proximo_da_soma_dos_1du_diarios`: para a
data-base 2026-06-30, comparei o `decay` de 21du somado sobre todo o
sistema (producao, via `dv.decay()`) contra a soma de 21 passos de 1 dia
util cada, reprecificando cada papel dia a dia com a mesma taxa/VNA fixos.

```
soma decay 21du (producao):            15.985537379451774
soma decay 21du (cadeia diaria, 33 papeis): 15.985537379451733
divergencia absoluta:                  4.09e-14
```

**Achado que vale registrar:** essa soma e matematicamente telescopica --
soma das diferencas consecutivas de uma sequencia e igual a diferenca
entre as pontas, para qualquer funcao deterministica, mesmo com a
truncagem embutida no PU. Por isso a divergencia real e ruido de ponto
flutuante (~1e-14), nao um efeito de convexidade mensuravel neste dado. O
valor do teste nao esta em achar uma folga de convexidade grande; esta em
travar a **contagem de dias**: se `_decay_de` ou os `HORIZONTES` passassem
a usar dias corridos (ou um passo a mais/a menos) num dos dois caminhos, o
alvo dos 21 passos diarios deixaria de coincidir com o alvo do calculo
direto, e a divergencia saltaria do ruido de ponto flutuante para uma
fracao apreciavel do total (a ordem de grandeza de um dia inteiro de
decay, bem acima da tolerancia de `1e-6` usada no teste). Chequei a mao
que os dois caminhos usam a mesma primitiva (`calendario.mover`) --
`decay()` via `cal.mover(data_base, 21)` e a cadeia via 21 chamadas de
`cal.mover(t, 1)` -- entao o resultado quase exato e esperado dado o
codigo atual, e o teste serve como regressao para o dia em que isso
mudar.

---

#### Convencao de sinal do decay (documentada tambem no docstring de `dv.py`)

DV e negativo para titulo (`docs/convencoes-dv.md`). Com menos prazo o DV
fica **menos negativo**, entao `decay = dv_alvo - dv_base` sai **positivo**
para um sobrevivente -- mede o quanto o DV encolheu em modulo. Para um
papel que vence no caminho, `dv_alvo = 0.0` e a mesma formula tambem da um
`decay` positivo, mas isso e informacao distinta (risco que sumiu, nao que
encolheu) e fica marcada em `venceu_no_caminho` para nunca ser somada sem
essa distincao. `test_decay_e_a_diferenca_entre_alvo_e_base` trava a
formula com tolerancia `1e-9`.

---

#### Autorrevisao

- **`dv_unitario` da LFT vazio, nao zero**: a LFT e filtrada de `decay()`
  antes do loop (`p = p[p["titulo"] != "LFT"]`), entao nunca aparece na
  saida -- `test_lft_fica_de_fora`. A guarda `pd.isna(r.dv_unitario)`
  dentro de `_decay_de` tambem cobre o caso geral (papel sem `dv_unitario`
  na base fica com `alvo=None`, nao `0.0`), aplicavel a qualquer papel do
  escopo que fique sem DV na base por falta de taxa/VNA.
- **`dv` de papel vencido e `0.0`, nao `None`**: coberto por
  `test_papel_vencido_tem_dv_alvo_zero_e_nao_vazio` contra o dado real
  (286 linhas vencidas no total das tres janelas).
- **"Nao aconteceu" verificado por comportamento, nao por resultado**:
  acrescentei `test_venceu_no_caminho_nunca_chama_precificacao`, que
  espiona `precificacao.dv` (mesmo padrao de `_espiar_pu` em
  `tests/test_dv.py`) contra o caso real `BRSTNCLTN848` (vence
  2026-07-01, exatamente o alvo de 1du a partir de 2026-06-30). Um teste
  que so checasse `dv_alvo == 0` passaria igual se `_decay_de` chamasse
  `precificacao.dv` com `d0` pos-vencimento e o motor devolvesse `0.0` por
  acidente -- o que de fato aconteceria aqui, porque `pu_ltn`/`pu_lft`
  tambem retornam `0.0` quando `d0 >= venc`. A asserção que importa e que
  a chamada **nao acontece**, e o espiao confirma isso.
- **Ancora de nivel, nao so banda larga**: acrescentei
  `test_dv_base_do_decay_bate_com_o_valor_medido_do_painel`, reusando os
  mesmos valores medidos de `test_dv.py` (LTN -198,54, NTN-F -177,76,
  NTN-B -1.096,58, total -1.472,87, tolerancia de 1%) contra a coluna
  `dv_base` do decay em 2026-06-30 -- trava `_decay_de` carregando
  `dv_base` errado (por exemplo, recalculando em vez de reusar
  `r.dv_posicao_milhoes`).
- **Limiar de 98% do brief nao se sustentou contra o dado real** --
  achado da autorrevisao, nao um bug de producao. Medindo
  `test_decay_reduz_o_modulo_do_dv_dos_sobreviventes` tal como o brief
  propunha (`> 0.98` no agregado), o teste **falhava**: 96,4% no agregado,
  e por horizonte, 91,7% em 1du, 97,7% em 5du, 99,9% em 21du. Investigando
  os casos que invertem o sinal (dv_alvo mais negativo que dv_base): sao
  quase todos NTN-B em 1du (518 de 668 casos), com reversao de ate
  R$ 0,23 milhoes -- rastreei um exemplo ate a raiz
  (`BRSTNCNTB0O7`, 2025-07-31 -> 2025-08-01: `dv_unitario` vai de
  -2,804311 para -2,808849 num unico dia util, sem cruzar data de cupom).
  A causa e a cotacao da NTN-B truncada em 4 casas
  (`docs/convencoes-dv.md`, "a truncagem faz parte do DV, de proposito");
  no horizonte de 1 dia util, o sinal real de decay de um papel longo
  (poucos milesimos) fica do tamanho do proprio degrau de truncagem,
  entao uma fracao pequena inverte por quantizacao, nao por erro de
  calculo -- e essa fracao cai a medida que o horizonte cresce e o sinal
  real supera o ruido (91,7% -> 97,7% -> 99,9%), exatamente o padrao
  esperado de ruido fixo contra sinal crescente. Troquei o limiar por
  `> 0.95` (com folga do 0,964 medido) e acrescentei uma segunda asserção
  mais forte que a banda: a taxa de sobreviventes monotonicos tem que
  **crescer** de 1du para 5du para 21du -- se essa ordem quebrasse, seria
  sinal de erro de sinal genuino, nao so de mais ruido de truncagem.
- **`pd.isna` em toda comparacao de coluna numerica**: `_decay_de` usa
  `pd.isna(r.taxa_pct)`, `pd.isna(r.dv_unitario)`, `pd.isna(base)`; nenhum
  `is None` sobre coluna numerica.
- **`r.isin` e seguro aqui**: `linhas` vem de `painel()`, que ja itera com
  `.itertuples(index=False)` no proprio `painel()`; `_decay_de` repete o
  padrao sobre o `DataFrame` agrupado por `data`, tambem via
  `.itertuples(index=False)` -- `r` e `namedtuple`, nao `Series`, entao
  `r.isin` acessa o campo, nao `Series.isin`.
- **ASCII puro**: `dv.py` e `test_decay.py` decodificados como `ascii`
  sem erro (checado por script apos escrever os dois arquivos).
- **`data/raw/` intocado**: `decay()` so le via `painel()`
  (`config.PROCESSED_DIR`); `gravar_decay()` so escreve
  `data/processed/decay_por_papel.csv`. `git status` confirma que
  `data/processed/decay_por_papel.csv` fica **ignorado** pelo git (mesmo
  padrao de `dv_por_papel.csv`), e nada em `data/raw/` aparece como
  modificado.
- **Caminhos absolutos**: `gravar_decay()` usa `config.PROCESSED_DIR`,
  nunca caminho relativo.
- **Nenhuma consulta a Bloomberg**: `dv.py` nao importa nada de rede;
  `decay()` depende so de `painel()`, que le CSVs ja processados.

---

#### O que continua igual do brief original, para quem ler so este relatorio

- Assinatura de `_decay_de(cal, linhas, data_base, data_alvo, rotulo)`
  preservada exatamente como o brief pediu -- a Tarefa 7 reusa essa
  funcao trocando so a data-alvo (calculo pontual em vez de horizonte
  nomeado).
- `gravar_decay()` usa `df.to_csv` direto (nao `gravacao.gravar_atomico`),
  mesmo padrao de `gravar_painel()`.
- `HORIZONTES` e `_COLUNAS_DECAY` com exatamente esses nomes.

---

## Resposta a revisao de qualidade

**Commit desta correcao:** `d265085` -- "Corrige achados da revisao do
decay (tarefa 6)". Arquivos: `src/tesouro/dv.py`, `tests/test_decay.py`.
`precificacao.py` nao foi tocado. Suite completa apos a correcao: **236
passed** (222 anteriores + 14 em `test_decay.py`, duas a mais que a
primeira rodada: `test_cada_horizonte_move_o_numero_certo_de_dias_uteis`
e `test_decay_do_sistema_em_2026_06_30_bate_com_o_valor_medido`).

### 1 (Important) -- o limiar devia ter sido apertado, nao afrouxado

O revisor confirmou minha explicacao (truncagem da cotacao da NTN-B em 4
casas) com numeros mais fortes do que eu tinha medido: **100% das 668
violacoes sao NTN-B**, nenhuma LTN/NTN-F, nenhuma cruzando data de
cupom, magnitude sempre dentro de um degrau de truncagem. A tolerancia de
`1e-9` que eu tinha usado era ordens de grandeza mais fina que o grao do
preco -- daí o afrouxamento errado para 95%.

Reescrevi `test_decay_reduz_o_modulo_do_dv_dos_sobreviventes` com a
tolerancia certa, calculada por linha: `1.01 * degrau_unitario *
quantidade_mil / 1000`, onde `degrau_unitario` e `1e-6 * vna` para NTN-B
(cotacao truncada em 4 casas, multiplicada pelo VNA) e `1e-6` para
LTN/NTN-F (PU truncado direto em 6 casas, sem VNA no meio). Fiz o merge
de `decay()` com `painel()` (por `data_base`/`isin`) para trazer `vna` e
`quantidade_mil`, que nao ficam na saida de `decay()`.

**Confirmado a mao:** com essa tolerancia, **zero** dos 18.596
sobreviventes invertem em qualquer um dos tres horizontes -- a exigencia
agora e `== 0` violacoes (100%), mais forte que os 98% do brief. A
checagem complementar (monotonicidade crescendo com o horizonte, com a
tolerancia ingenua de `1e-9`) foi mantida como um segundo sinal, mas
documentada como fraca (sobrevive a um deslocamento uniforme dos tres
horizontes), conforme o revisor apontou.

### 2 (Important) -- a trava de contagem de dias cobria so 21du

Reproduzi os mutantes que o revisor descreveu como sobrevivendo em
silencio -- `HORIZONTES = {"1du": 2, "5du": 6, "21du": 21}` -- e
confirmei que a suite da primeira rodada passava inteira com essa
mutacao. Acrescentei duas travas novas:

- `test_cada_horizonte_move_o_numero_certo_de_dias_uteis`: para cada
  rotulo, `data_alvo == cal.mover(data_base, n)`, com `n` **escrito a
  mao** (`{"1du": 1, "5du": 5, "21du": 21}`), nao lido de
  `dv.HORIZONTES`. Achado da minha propria autorrevisao desta rodada:
  numa primeira versao eu tinha lido o `n` esperado de
  `dv.HORIZONTES.items()`, e o teste ficou tautologico -- confirmei a
  mao que ele continuava passando com o `HORIZONTES` mutado, porque os
  dois lados (esperado e medido) vinham da mesma fonte. Corrigido antes
  de commitar.
- `test_decay_do_sistema_em_2026_06_30_bate_com_o_valor_medido`: ancora
  o decay dos sobreviventes nos tres horizontes em 2026-06-30 (1du
  0,6548; 5du 3,9642; 21du 15,9106 milhoes/bp), tolerancia de 1%.

Generalizei tambem `test_21du_e_proximo_da_soma_dos_1du_diarios` (ver
item Minors) para rodar a cadeia telescopica nos tres horizontes, nao so
21du.

**Confirmado a mao, com a mutacao `HORIZONTES = {"1du": 2, "5du": 6,
"21du": 21}`:** as duas travas novas falham (`test_cada_horizonte_
move_o_numero_certo_de_dias_uteis` na primeira comparacao de 1du;
`test_decay_do_sistema_em_2026_06_30_bate_com_o_valor_medido` porque o
decay de 1du sai 1,4057 em vez de 0,6548 -- mais que o dobro, coerente
com o revisor ter avisado que "o decay de 1du dobraria"). Restaurado o
`HORIZONTES` original, a suite volta a 236/236.

**Ponto de atencao sobre a propria trava de aditividade:** verifiquei que
`test_cada_horizonte_bate_com_a_soma_dos_passos_diarios_equivalentes`
(generalizacao do teste renomeado) **nao pega** a mutacao de constante em
`HORIZONTES` -- ela le o `n` de `dv.HORIZONTES.items()`, entao os dois
lados da comparacao (direto e cadeia) se deslocam juntos e continuam
batendo. Isso e esperado e nao e um problema: essa trava mede uma coisa
diferente (consistencia interna do calculo do horizonte atual, nao se o
"n" esta certo). Para confirmar que ela pega o que se propoe a pegar,
mutei separadamente a reprecificacao dentro de `_decay_de` para usar
`cal.mover(data_alvo, 1)` em vez de `data_alvo` (um off-by-one
"escondido" que a trava de constante fixa nao alcançaria) -- a trava
telescopica falhou imediatamente, com divergencia de 0,75 contra a
tolerancia de `1e-6` (750 mil vezes maior). Restaurada a linha original,
a suite volta a 236/236. Corrigi o comentario do teste para nao afirmar
que ele pega mutacao de constante em `HORIZONTES` (afirmacao errada que
eu tinha escrito antes de testar a mao) -- ele pega inconsistencia
interna no calculo do N atual, e as mutacoes de constante ficam a cargo
das duas travas de ancora.

### Minors

- **Nome do teste de aditividade**: `test_21du_e_proximo_da_soma_dos_
  1du_diarios` virou `test_cada_horizonte_bate_com_a_soma_dos_passos_
  diarios_equivalentes` -- alem de tirar "proximo" (o corpo testa
  identidade, nao proximidade), o nome agora reflete que cobre os tres
  horizontes.
- **Ordem das guardas em `_decay_de`**: invertida. A guarda de `taxa_pct`/
  `dv_unitario` ausente agora vem **antes** da guarda de vencimento, para
  que um papel vencido sem `dv_base` medido (ex.: `BRSTNCNTF071`, NTN-F
  vencida em 2014-01-01 e ainda no estoque em 2014-01-31 sem taxa) fique
  com `dv_alvo = None`, nao `0.0` -- "risco nunca medido" nao pode virar
  "risco confirmado zero". Reescrevi
  `test_papel_vencido_tem_dv_alvo_zero_e_nao_vazio` como
  `test_papel_vencido_tem_dv_alvo_zero_quando_o_risco_de_partida_era_
  conhecido`, separando os 268 casos vencidos com `dv_base` medido
  (continuam com `dv_alvo == 0.0`) dos 18 casos vencidos sem `dv_base`
  medido (agora com `dv_alvo` e `decay` `None`) -- os 18 casos batem
  exatamente com os 6 papeis x 3 horizontes que o revisor citou como
  exemplo (`BRSTNCNTF071` entre eles).
- **Amostra do teste de formula**: `test_decay_e_a_diferenca_entre_alvo_
  e_base` trocou `head(200)` pela base inteira (mais de 15 mil linhas) --
  e formula vetorizada, o custo extra e desprezivel.
- **Contagens exatas de `venceu_no_caminho`**: `test_vencimento_aparece_
  nos_horizontes_longos` agora ancora 80 (1du), 80 (5du) e 126 (21du) em
  vez de so `por_h["21du"] > por_h["1du"]`.

### Verificacao final desta rodada

Suite completa: **236 passed** (222 anteriores + 14 em `test_decay.py`).
ASCII conferido de novo em `dv.py` e `test_decay.py`. `gravar_decay()`
regravado apos a correcao da ordem das guardas: `decay_por_papel.csv`
continua com 20.115 linhas, 4,51 s. As duas mutacoes do revisor
(`HORIZONTES` com 1du/5du deslocados) e a mutacao adicional que eu mesma
apliquei para validar a trava de aditividade (`cal.mover(data_alvo, 1)`
na reprecificacao) foram reproduzidas a mao, uma de cada vez, e cada uma
falha exatamente onde o teste correspondente deveria pegar; revertidas,
a suite volta a 236/236. `git diff --stat src/tesouro/precificacao.py`
vazio; nada em `data/raw/` mudou.

### Task 3: Parser dos brutos da Bloomberg -- relatorio

**Status:** concluida.

**Commit:** `6056277` -- "Adiciona parser dos brutos da Bloomberg (grupo 3, tarefa 3)"
(branch `dv01-decay`). Arquivos: `src/tesouro/parse_bloomberg.py`,
`tests/test_parse_bloomberg.py`.

**Testes:** `9 passed` em `tests/test_parse_bloomberg.py`; suite inteira
`177 passed` (168 anteriores + 9 novos), nenhuma regressao.

---

#### O que foi implementado

`src/tesouro/parse_bloomberg.py`, seguindo o brief quase ao pe da letra, com uma
unica mudanca deliberada: o parametro de override de diretorio nos dois
`parse_*` (e no `_ler_todos` interno) se chama `caminho`, nao `diretorio`, para
casar com a assinatura declarada na secao "Interfaces" do brief
(`parse_taxas(caminho=None)` / `parse_vna(caminho=None)`) -- o brief tinha uma
inconsistencia entre a interface declarada e o codigo de exemplo, e a
interface e o que outra tarefa (T4, o coletor) potencialmente depende.

- `parse_taxas()`: le todos os `bbg_taxas_*.csv` de `config.BLOOMBERG_DIR`,
  concatena, normaliza a coluna `data` para o ultimo dia util do mes via
  `calendario.padrao().ultimo_dia_util_do_mes`, renomeia `yld_ytm_mid` para
  `taxa_pct`, remove duplicata de chave `(data, isin)` mantendo a ultima
  ocorrencia (arquivo mais recente), e devolve
  `data, isin, titulo, vencimento, taxa_pct`.
- `parse_vna()`: mesmo padrao para `bbg_vna_*.csv`, chave `(data, indice)`,
  devolve `data, indice, vna`.
- `gravar()`: escreve `taxa_por_papel.csv` e `vna.csv` em
  `config.PROCESSED_DIR` com `df.to_csv` direto -- **nao** usa
  `gravacao.gravar_atomico`. Verifiquei o uso real no projeto antes de decidir
  isso: `gravar_atomico`/`conferir_assinatura` so sao chamados em
  `fetch_leiloes.py` e `fetch_rmd.py` (escrita de bytes brutos vindos da rede,
  em `data/raw/`). Todo modulo em `src/tesouro/parse_rmd/` que grava em
  `data/processed/` usa `df.to_csv` direto, sem passar por `gravacao.py`. Segui
  esse padrao existente, que e o que o proprio brief tambem faz no codigo de
  exemplo do Step 3.
- Modulo nunca importa nada de rede; so le com `Path.glob` +
  `pd.read_csv` em `config.BLOOMBERG_DIR` (dentro de `RAW_DIR`) e so escreve em
  `config.PROCESSED_DIR`. Confirmado com `git status --short data/raw/` antes e
  depois de rodar `gravar()`: nenhuma mudanca.

#### Armadilha da data (ultimo dia util vs ultimo dia corrido)

Tratada como o brief e `docs/convencoes-dv.md` pedem: as duas fontes sao
normalizadas com o mesmo `ultimo_dia_util_do_mes` antes de qualquer chave de
juncao. O teste `test_datas_sao_dia_util` confere isso diretamente contra
`calendario.padrao().eh_dia_util`. Nao escrevi um teste extra de contagem
antes/depois da normalizacao (o brief nao pedia e os 9 testes dados ja cobrem
o ponto central), mas medi o efeito pratico na cobertura abaixo, que so bate
com a normalizacao correta.

#### Grava dos CSVs (Step 5)

```
gravado: data/processed/taxa_por_papel.csv (8898 linhas)
gravado: data/processed/vna.csv (396 linhas)
```
Bate exatamente com o esperado no brief (~8.900 e 396).

---

#### Cobertura medida (pedido explicito da usuaria)

A spec de design (`docs/superpowers/specs/2026-08-17-dv01-decay-design.md`,
secao 6) cita "93,9% dos pares papel-mes com estoque, e 99,23% ponderado pelo
financeiro" e "0,10% do estoque sem taxa no ultimo mes". Reproduzi a mesma
medicao usando a saida do parser desta tarefa contra
`data/processed/estoque_titulos_vencimento.csv` (normalizando a data do
estoque para o mesmo ultimo-dia-util, e restringindo a papeis com
`financeiro_milhoes > 0` e aos 4 titulos que a Bloomberg cobre: LTN, NTN-F,
NTN-B, LFT):

| medida | valor medido | valor da spec |
|---|---|---|
| pares papel-mes em escopo | 9.366 | -- |
| pares com taxa | 8.794 (**93,89%**) | 93,9% |
| financeiro total com taxa | **99,23%** | 99,23% |
| financeiro sem taxa no ultimo mes (jun/2026) | **0,10%** | 0,10% |

As tres cifras batem exatamente. Os buracos por titulo confirmam o que a spec
diz: 155 dos 335 pares sem taxa em LFT e LTN estao concentrados em 2010-2011
(272 dos 401 pares sem taxa no total), com o financeiro residual dominado por
LFT (R$ 5,1 milhoes-de-milhoes em quantidade absoluta de linhas, mas
irrelevante em peso: 0,77% do financeiro total). Isso confirma que a
normalizacao de data esta correta -- sem ela a contagem de pares casados cai
bem abaixo de 93,9%, porque a junção por data literal descartaria cerca de um
terço do painel, como o documento de convenções avisa.

(Script de verificacao usado, descartavel, nao commitado: leu
`parse_bloomberg.parse_taxas()` e juntou contra o estoque normalizado da mesma
forma -- nao faz parte da entrega, so confirmacao.)

---

#### Autorrevisao

Conferi, depois de escrever o codigo:

- **ASCII puro**: script de verificacao de caracteres > 127 no arquivo --
  nenhum encontrado.
- **Guardas de nulo com pandas**: nao ha `r.vna is None` nem `r["isin"]`
  lido como `r.isin` em lugar nenhum do modulo -- nao uso `itertuples`/`apply`
  linha a linha, so operacoes vetorizadas (`map`, `rename`,
  `drop_duplicates`), que nao caem nessa armadilha.
- **Nulos nos dados reais**: `taxas.isna().sum()` e `vna.isna().sum()`
  deram zero em toda coluna -- os CSVs brutos atuais nao tem lacuna.
- **`data/raw/` intocado**: `git status --short data/raw/` antes e depois
  de `gravar()` nao mostra diferenca; o modulo so abre arquivos em
  `BLOOMBERG_DIR` para leitura (`pd.read_csv`), nunca escreve la.
- **`data/processed/` fora do commit**: `data/**` esta no `.gitignore` do
  projeto (com excecao de `.gitkeep`), entao `taxa_por_papel.csv` e `vna.csv`
  gerados no Step 5 nao aparecem no `git status` e nao foram adicionados ao
  commit -- so os dois arquivos de codigo, como o brief pede no Step 6.
- **Divergencia de nome de parametro**: identificada e resolvida (ver acima,
  `caminho` em vez de `diretorio`), documentada no docstring de `_ler_todos`.
- **`gravar_atomico` vs `to_csv` direto**: verifiquei os dois usos reais no
  repositorio antes de decidir nao usar `gravar_atomico` aqui (ver acima);
  nao achei nenhum outro parser de `data/processed/` que passe por
  `gravacao.py`, entao segui o padrao dominante e coerente com o proprio
  codigo do brief.

Nenhum problema corrigido alem do nome do parametro -- o resto do
autorrevisao so confirmou que o codigo ja escrito estava correto.

---

#### Preocupacoes para quem continuar (T4, o coletor)

- ~~Nao ha teste de fixture isolada para `_ler_todos`/dedup multi-arquivo~~ --
  resolvido na rodada de correcoes abaixo: agora ha fixtures dedicadas com
  `caminho=tmp_path` e o nome do arquivo bruto e conferido contra um padrao
  ISO obrigatorio (ver secao "Resposta a revisao"). **A T4 (coletor) precisa
  nomear os arquivos incrementais como `bbg_taxas_<FONTE>_AAAA-MM_AAAA-MM.csv`
  e `bbg_vna_AAAA-MM_AAAA-MM.csv`** -- qualquer outro formato faz
  `parse_taxas`/`parse_vna` levantarem `ValueError` na leitura, de proposito.
- A cobertura de 93,9%/99,23% so foi validada contra o snapshot atual de
  `data/raw/bloomberg/`; ela deve mudar (para melhor, presumivelmente) quando
  o coletor real (T4) trouxer mais historico ou o Tesouro atualizar o
  estoque. Recontada apos a rodada de correcoes: identica (ver abaixo), porque
  os unicos registros novos removidos -- 62 papeis ja vencidos na data da
  cotacao -- ja tinham financeiro zero no estoque.

---

## Resposta a revisao de qualidade

A revisao (nao aprovada na primeira rodada: 1 Critical, 4 Important, 6
minors) foi conferida item a item contra o bruto real antes de qualquer
correcao, e todas as contagens que ela citou bateram exatamente com o que
medi de novo por fora: 272 linhas de taxa em datas nao-uteis (6 datas, todas
depois de 2013), 62 linhas de papel ja vencido, faixas de taxa por titulo,
zero divergencia/campo-trocado/conflito de VNA no bruto atual, e 16 datas de
IPCA com `n_papeis == 1`.

**Commit da correcao:** `cf99bc6` -- "Corrige achados da revisao do parser
Bloomberg (tarefa 3)".

### C1 -- normalizacao de data nao testada nos dois lados

`test_datas_sao_dia_util` passou a checar a coluna inteira (`taxas["data"]` e
`vna["data"]`), nao mais `head(500)`. Acrescentei
`test_normaliza_ultimo_dia_corrido_para_ultimo_dia_util`, com fixture
sintetica (`caminho=tmp_path`) provando o valor exato da conversao:
31/12/2023 (domingo, ultimo dia corrido) vira 29/12/2023 (ultimo dia util),
nos dois parsers.

**Confirmado a mao, como pedido:** apliquei as duas mutacoes que o revisor
descreveu (removi `.map(cal.ultimo_dia_util_do_mes)` de `parse_vna`, depois
de `parse_taxas`, uma de cada vez, restaurando entre as duas) e rodei a
suite inteira:
- Sem a normalizacao em `parse_vna`: **4 testes falham**
  (`test_datas_sao_dia_util`,
  `test_normaliza_ultimo_dia_corrido_para_ultimo_dia_util`,
  `test_vna_diverge_entre_ultimo_dia_util_e_corrido_levanta_erro`,
  `test_vna_igual_entre_ultimo_dia_util_e_corrido_nao_levanta_erro`).
- Sem a normalizacao em `parse_taxas`: **2 testes falham**
  (`test_datas_sao_dia_util`,
  `test_normaliza_ultimo_dia_corrido_para_ultimo_dia_util`).

O docstring do modulo tambem registra agora as 6 datas nao-uteis reais do
bruto (o que a informacao original do brief, de que a taxa "ja vem no ultimo
dia util", nao previa).

### I1 -- `divergencia`, `campo` e `n_papeis` nao eram lidos

`parse_vna` agora confere, antes de normalizar qualquer data:
- `campo` contra o `indice` (`_CAMPO_POR_INDICE = {"IPCA": "IDX_RATIO",
  "SELIC": "ACCUMULATED_SELIC"}`) -- levanta `ValueError` se nao bater.
- `divergencia` contra uma tolerancia (`_TOLERANCIA_DIVERGENCIA = 0.5` reais)
  -- levanta `ValueError` se ultrapassar.

`n_papeis` passou a ser exigido pela checagem de cabecalho (I2), e o
docstring da constante de tolerancia registra a ressalva do revisor: em 16
das 198 datas de IPCA ha um so papel, e a divergencia zero ali nao prova
nada (nao ha segundo papel para comparar) -- documentado, nao transformado
em checagem adicional, porque nao ha o que checar com um papel so.

Confirmado a mao: reproduzi `divergencia=120.5` e `campo` trocado em
fixtures (`test_vna_com_divergencia_grande_levanta_erro`,
`test_vna_com_campo_trocado_levanta_erro`) -- as duas levantam `ValueError`.
Removendo cada checagem do codigo (uma de cada vez), o teste correspondente
volta a passar sem erro nenhum, confirmando que a checagem e quem sustenta o
teste.

### I2 -- `_ler_todos` concatenava sem conferir cabecalho

`_checar_colunas` (mesmo padrao de `parse_rmd/paf_reserva.py`, aba 6.1)
confere as colunas esperadas de cada arquivo antes do `pd.concat`, e
levanta `LookupError` com a lista de colunas ausentes.

**Achado durante a auto-revisao desta rodada:** a primeira versao do teste
(`pytest.raises(LookupError)`, sem `match`) nao tinha dentes -- como
`KeyError` e subclasse de `LookupError`, o teste passava mesmo com a
checagem removida, porque o pandas acaba levantando `KeyError` sozinho mais
adiante (ex.: `df["titulo"]` dentro da checagem de plausibilidade) quando a
coluna falta. Corrigido com `pytest.raises(LookupError, match="colunas
ausentes")`, que so passa com a mensagem da nossa checagem explicita.
Confirmado a mao: com a checagem removida, os dois testes agora falham com
`KeyError: 'titulo'` / `KeyError: 'divergencia'` em vez da mensagem
esperada -- a mutacao e detectada pela razao certa.

### I3 -- nenhuma guarda de plausibilidade por linha na taxa

`_checar_plausibilidade_taxas` confere cada titulo contra `_LIMITES_TAXA_PCT`
(LFT: +-5%; LTN/NTN-F/NTN-B: -10% a 60%) e levanta `ValueError` com as
linhas violadoras. Testei os dois lados: um valor implausivel de LFT (8%)
levanta erro, e os extremos reais que o revisor apontou (NTN-B a -4,21% e a
25,01%) **nao** levantam erro
(`test_taxa_extrema_mas_real_nao_levanta_erro`). Confirmado a mao: com a
checagem removida, `test_taxa_fora_da_faixa_plausivel_levanta_erro` volta a
passar sem excecao -- falha.

### I4 -- VNA duplicado colapsando em silencio

Reestruturei a ordem de `parse_vna` em duas etapas de desduplicacao
distintas, para nao confundir dois problemas diferentes:
1. `drop_duplicates(subset=["data_bruta", "indice"], keep="last")` **antes**
   de normalizar -- resolve repeticao da MESMA data de origem entre puxadas
   incrementais (a puxada mais recente vence, por desenho).
2. Depois de normalizar, `groupby(["data", "indice"])["vna"].nunique()`
   confere que datas de origem DIFERENTES que colapsam no mesmo ultimo dia
   util concordam em valor -- se nao concordarem, levanta `ValueError` em
   vez de resolver silenciosamente.

A mesma logica de duas etapas foi aplicada a `parse_taxas` (dedup pela data
bruta antes de normalizar), sem a checagem de igualdade da segunda etapa --
ali nao ha uma premissa documentada de igualdade entre datas de origem
diferentes, so a resolucao padrao por ultima ocorrencia.

Testei os dois lados: VNA divergente entre 29/12 e 31/12/2023 levanta erro
(`test_vna_diverge_...`); VNA igual entre os dois **nao** levanta erro
(`test_vna_igual_...`); e uma revisao genuina da MESMA data (duas puxadas,
mesma data bruta, VNA diferente) continua resolvida por "ultima ocorrencia",
sem erro (`test_vna_desduplicacao_mantem_a_puxada_mais_recente`).

### A fragilidade da desduplicacao (nome de arquivo fora do ISO)

`_PADRAO_NOME_TAXAS` e `_PADRAO_NOME_VNA` exigem o formato
`bbg_taxas_<FONTE>_AAAA-MM_AAAA-MM.csv` / `bbg_vna_AAAA-MM_AAAA-MM.csv`; um
nome fora disso levanta `ValueError` na leitura, antes de qualquer
concatenacao. `_ler_todos` tambem imprime a lista de arquivos na ordem em
que foram lidos (`parse_bloomberg: lendo, em ordem: [...]`).

Reproduzi o cenario do revisor (`bbg_taxas_ANDE_01-07-2026.csv`, fora do
ISO) em `test_nome_de_arquivo_fora_do_padrao_iso_levanta_erro` -- levanta
`ValueError`. Confirmado a mao: removendo a checagem de nome, o teste passa
sem excecao (falha).

**Esta convencao de nome vira requisito para a T4:** documentado na secao
"Preocupacoes" acima.

### Minors

- **Taxa NaN**: filtrada antes da contagem, com print reportando quantas
  linhas caíram (`parse_taxas: N linha(s) com taxa ausente descartada(s)`).
  Testado com fixture (`test_taxa_ausente_e_excluida_nao_conta_como_cobertura`).
  No bruto real, 0 linhas afetadas (ja confirmado no relatorio original: zero
  nulos).
- **Papel vencido** (`vencimento <= data`): filtrado com o mesmo padrao de
  print. No bruto real, **62 linhas** removidas (`parse_taxas: 62 linha(s)
  de papel ja vencido descartada(s)`) -- `taxa_por_papel.csv` caiu de 8.898
  para 8.836 linhas. Testado com fixture
  (`test_papel_vencido_e_excluido`).
- **`test_nao_ha_chave_duplicada` tautologico**: mantido (ainda vale como
  invariante final), mas agora acompanhado de
  `test_taxas_desduplicacao_mantem_a_puxada_mais_recente` e
  `test_vna_desduplicacao_mantem_a_puxada_mais_recente`, que criam duplicata
  de verdade (duas puxadas da mesma data com valores diferentes) e conferem
  qual valor sobrevive -- esses dois falham se `drop_duplicates` for
  removido.
- **Imports nao usados**: `from datetime import date` e `import pandas as
  pd` no teste continuam la, mas agora sao genuinamente usados (fixtures
  sinteticas com `date(...)` e `pd.DataFrame(...)`).
- **Parametro `caminho` nunca exercitado por teste**: agora e o mecanismo
  central de 14 dos 15 testes novos.
- **Docstring do modulo**: acrescentei o paragrafo "Atencao para quem for
  juntar com o estoque", registrando que `taxa_por_papel.csv`/`vna.csv`
  gravam o ultimo dia UTIL e `estoque_titulos_vencimento.csv` grava o ultimo
  dia CORRIDO na mesma coluna `data`.

### Recontagem de cobertura apos as correcoes

Com os 62 registros de papel vencido agora filtrados, recontei a cobertura
da mesma forma que no relatorio original:

| medida | antes da correcao | depois da correcao |
|---|---|---|
| pares papel-mes em escopo | 9.366 | 9.366 |
| pares com taxa | 8.794 (93,89%) | 8.794 (93,89%) |
| financeiro com taxa | 99,23% | 99,23% |
| financeiro sem taxa no ultimo mes | 0,10% | 0,10% |

Identico: os 62 registros removidos eram cotacoes residuais de papeis ja
vencidos, que no estoque real ja tinham quantidade e financeiro zerados --
nunca contribuiam para a medicao de cobertura, so representavam risco
silencioso para um consumidor futuro que juntasse por ISIN sem checar
vencimento (o motor de precificacao, via `calendario.du`).

### Verificacao final

`data/raw/bloomberg/` conferido sem alteracao (`git status --short
data/raw/` vazio) antes e depois de rodar `python -m tesouro.parse_bloomberg`
de novo. Suite completa: **191 passed** (168 originais + 23 de
`test_parse_bloomberg.py`, contra os 9 da primeira entrega).

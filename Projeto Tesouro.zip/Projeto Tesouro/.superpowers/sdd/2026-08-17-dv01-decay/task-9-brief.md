### Task 9: Figuras

**Files:**
- Create: `src/tesouro/figuras.py`
- Test: `tests/test_figuras.py`

**Interfaces:**
- Consumes: `dv.painel()`, o dicionário de `dv.pontual()`
- Produces:
  - `figuras.grafico_dv_do_sistema(caminho=None) -> Path`
  - `figuras.grafico_pontual(resumo, caminho) -> Path`
  - `figuras.gravar_todas() -> None`

**Contexto:** o item 1 pedido pela mesa é o DV do sistema por tipo de papel ao longo do tempo — LTN, NTN-F e NTN-B empilhados ou em linhas. Use o backend `Agg`, que não abre janela e funciona em máquina sem interface gráfica.

As figuras vão para `data/processed/figuras/`. Não são versionadas, como o resto de `data/`.

- [ ] **Step 1: Escreva os testes que falham**

```python
# tests/test_figuras.py
from datetime import date
from pathlib import Path

import pytest
from tesouro import dv, figuras


def test_grafico_do_sistema_grava_arquivo(tmp_path):
    alvo = tmp_path / "dv_sistema.png"
    saida = figuras.grafico_dv_do_sistema(alvo)
    assert saida.exists()
    assert saida.stat().st_size > 10000


def test_grafico_pontual_grava_arquivo(tmp_path):
    r = dv.pontual(date(2027, 12, 31))
    alvo = tmp_path / "pontual.png"
    saida = figuras.grafico_pontual(r, alvo)
    assert saida.exists()
    assert saida.stat().st_size > 10000


def test_usa_backend_sem_janela():
    import matplotlib
    assert matplotlib.get_backend().lower() == "agg"
```

- [ ] **Step 2: Rode e confirme que falham**

Run: `PYTHONPATH=src python -m pytest tests/test_figuras.py -v`
Expected: FAIL com `ModuleNotFoundError: No module named 'tesouro.figuras'`

- [ ] **Step 3: Implemente o `figuras.py`**

```python
"""Graficos do DV01.

Backend Agg: nao abre janela e funciona em maquina sem interface grafica,
que e o caso de um servidor ou de uma sessao remota.
"""
from pathlib import Path

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt   # noqa: E402  (o backend precisa vir antes)

from . import config, dv          # noqa: E402

_CORES = {"LTN": "#1f4e79", "NTN-F": "#2e75b6", "NTN-B": "#c00000"}


def _pasta():
    p = config.PROCESSED_DIR / "figuras"
    p.mkdir(parents=True, exist_ok=True)
    return p


def grafico_dv_do_sistema(caminho=None):
    """DV do sistema por tipo de papel, ao longo do tempo."""
    caminho = Path(caminho) if caminho else _pasta() / "dv_do_sistema.png"
    p = dv.painel()
    p = p[p["dv_posicao_milhoes"].notna()]
    serie = (p.groupby(["data", "titulo"])["dv_posicao_milhoes"].sum()
               .unstack("titulo").sort_index())

    fig, eixo = plt.subplots(figsize=(11, 5.5))
    for titulo in ("LTN", "NTN-F", "NTN-B"):
        if titulo in serie:
            eixo.plot(serie.index, serie[titulo], label=titulo,
                      color=_CORES[titulo], linewidth=1.6)
    eixo.plot(serie.index, serie.sum(axis=1), label="total", color="black",
              linewidth=1.0, linestyle="--")
    eixo.axhline(0, color="#999999", linewidth=0.8)
    eixo.set_title("DV01 do sistema por tipo de papel")
    eixo.set_ylabel("R$ milhoes por bp")
    eixo.legend(frameon=False, ncol=4)
    eixo.grid(alpha=0.25)
    fig.text(0.01, 0.01,
             "Cobre LTN, NTN-F e NTN-B: 46,6% do estoque. A LFT nao tem "
             "duration de juros. Negativo = mercado perde na alta de taxa.",
             fontsize=7, color="#555555")
    fig.tight_layout(rect=(0, 0.03, 1, 1))
    fig.savefig(caminho, dpi=140)
    plt.close(fig)
    return caminho


def grafico_pontual(resumo, caminho):
    """Decomposicao da queda de DV entre a data-base e a data-alvo."""
    caminho = Path(caminho)
    rotulos = ["DV na base", "vence", "decay", "DV no alvo"]
    valores = [resumo["dv_base"], resumo["dv_que_vence"],
               resumo["decay_sobreviventes"], resumo["dv_alvo"]]
    cores = ["#1f4e79", "#c00000", "#ed7d31", "#2e75b6"]

    fig, eixo = plt.subplots(figsize=(8, 4.5))
    eixo.bar(rotulos, valores, color=cores)
    for i, v in enumerate(valores):
        eixo.text(i, v, f"{v:,.0f}", ha="center",
                  va="bottom" if v >= 0 else "top", fontsize=9)
    eixo.axhline(0, color="#333333", linewidth=0.8)
    eixo.set_title(f"DV01 de {resumo['data_base']} ate {resumo['data_alvo']}")
    eixo.set_ylabel("R$ milhoes por bp")
    eixo.grid(axis="y", alpha=0.25)
    fig.tight_layout()
    fig.savefig(caminho, dpi=140)
    plt.close(fig)
    return caminho


def gravar_todas():
    caminho = grafico_dv_do_sistema()
    print(f"gravado: {caminho}")


if __name__ == "__main__":
    gravar_todas()
```

- [ ] **Step 4: Rode os testes e confirme que passam**

Run: `PYTHONPATH=src python -m pytest tests/test_figuras.py -v`
Expected: PASS, 3 testes

- [ ] **Step 5: Gere a figura e olhe**

Run: `PYTHONPATH=src python -m tesouro.figuras`
Expected: grava `data/processed/figuras/dv_do_sistema.png`. Abra e confira que as três séries aparecem, que o eixo faz sentido e que a nota de rodapé está legível.

- [ ] **Step 6: Commit**

```bash
git add src/tesouro/figuras.py tests/test_figuras.py
git commit -m "Adiciona graficos do DV01"
```

---


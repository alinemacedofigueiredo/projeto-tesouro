### Task 11: Documentação

**Files:**
- Modify: `README.md`, `docs/dicionario-de-dados.md`, `docs/como-baixar.md`, `docs/fontes-de-dados.md`

**Interfaces:**
- Consumes: tudo
- Produces: nada de código

**Contexto:** o projeto vai para um banco e será mantido por outras pessoas. Escreva a partir do código real e dos CSVs gerados, não a partir deste plano — várias coisas podem ter mudado no caminho.

**`docs/convencoes-dv.md` já existe e está completo.** Não o reescreva; referencie-o.

- [ ] **Step 1: Acrescente as cinco tabelas novas ao dicionário de dados**

Para `taxa_por_papel.csv`, `vna.csv`, `dv_por_papel.csv`, `decay_por_papel.csv` e `resultado_mensal.csv`, no mesmo formato das existentes: coluna, tipo, descrição, e as armadilhas.

Confira cada valor categórico com `value_counts()` contra o CSV real antes de escrever — na camada de dados, quatro erros factuais no dicionário passaram por revisão justamente por terem sido escritos de memória.

As armadilhas que precisam estar escritas:

- em `dv_por_papel`, `dv_unitario` é **vazio para LFT** — não zero, e a diferença importa para quem somar;
- ainda em `dv_por_papel`, linhas sem taxa têm preço vazio e posição preenchida; são cerca de 6% dos pares, quase todos LFT de 2010 e 2011;
- o DV01 cobre **46,6% do estoque**, e esse número precisa aparecer junto de qualquer total;
- em `decay_por_papel`, `venceu_no_caminho` distingue papel que sumiu de papel que encurtou; somar os dois junto produz um número que parece decay e é metade calendário;
- o PU é calculado em **D+0** e por isso fica cerca de 5 bp abaixo da tela, que cota D+1;
- em `resultado_mensal`, a posição é a **congelada no início do período**, e papel que venceu tem `pu_fim` vazio de propósito — não sabemos a que preço o dinheiro foi reinvestido.

- [ ] **Step 2: Atualize o README**

Acrescente o comando pontual e o novo escopo do pipeline:

```
PYTHONPATH=src python -m tesouro.dv --alvo 31/12/2027
```

- [ ] **Step 3: Atualize `docs/como-baixar.md`**

Duas fontes novas para o ambiente sem rede: o calendário da Anbima (de `anbima.com.br/feriados/arqs/feriados_nacionais.xls`, para `data/raw/anbima/`) e a exportação da Bloomberg por `BDH` (para `data/raw/bloomberg/`), com as colunas que o parser espera.

- [ ] **Step 4: Atualize `docs/fontes-de-dados.md`**

Acrescente as fontes novas ao diagrama e à tabela de origem por CSV.

- [ ] **Step 5: Confira que a documentação bate com o código**

Run: `PYTHONPATH=src python -c "import pathlib; print(sorted(p.stem for p in pathlib.Path('data/processed').glob('*.csv')))"`
Expected: os nomes impressos são exatamente os listados no dicionário.

- [ ] **Step 6: Commit**

```bash
git add README.md docs/
git commit -m "Documenta as tabelas de DV01 e as fontes novas"
```

# Task 2: Motor de precificacao -- relatorio

## O que foi implementado

Segui o brief literalmente (codigo e testes ja vinham prontos nele), com uma
excecao registrada abaixo na autorrevisao.

1. `tests/test_precificacao.py` -- criado com os 11 testes do brief.
2. `src/tesouro/precificacao.py` -- criado com `pu_ltn`, `pu_lft`, `pu_ntnf`,
   `pu_ntnb`, `pu` (despachante) e `dv`, copiados do bloco do brief sem
   alteracao de formula, sinal ou constante.

## Comandos rodados e saida

**1. Confirmar que os testes falham antes da implementacao (Step 2):**

```
PYTHONPATH=src python -m pytest tests/test_precificacao.py -v
```
```
ImportError: cannot import name 'precificacao' from 'tesouro'
!!!!!!!!!!!!!!!!!!! Interrupted: 1 error during collection !!!!!!!!!!!!!!!!!!!!
============================== 1 error in 1.05s ===============================
```
(Mesma particularidade ja registrada no relatorio da Tarefa 1: `ImportError`
em vez de `ModuleNotFoundError`, porque `tesouro` ja existe como pacote e so
falta o submodulo. Mesma causa, mesmo efeito pratico.)

**2. Depois da implementacao (Step 4), com um teste do brief ajustado (ver
autorrevisao):**

```
PYTHONPATH=src python -m pytest tests/test_precificacao.py -v
```
```
tests/test_precificacao.py::test_ltn_com_252_dias_uteis_a_10_por_cento PASSED
tests/test_precificacao.py::test_ltn_no_vencimento_vale_zero PASSED
tests/test_precificacao.py::test_ntnb_multiplica_a_cotacao_pelo_vna PASSED
tests/test_precificacao.py::test_lft_perto_do_par_vale_perto_do_vna PASSED
tests/test_precificacao.py::test_ntnf_soma_cupons_semestrais PASSED
tests/test_precificacao.py::test_dv_e_negativo_para_titulo PASSED
tests/test_precificacao.py::test_dv_cresce_com_o_prazo PASSED
tests/test_precificacao.py::test_dv_da_lft_e_none_e_nao_zero PASSED
tests/test_precificacao.py::test_dv_usa_precos_truncados PASSED
tests/test_precificacao.py::test_titulo_desconhecido_falha_alto PASSED
tests/test_precificacao.py::test_ntnb_precisa_de_vna PASSED
============================= 11 passed in 0.82s ==============================
```

**3. Suite inteira (regressao):**

```
PYTHONPATH=src python -m pytest tests/
```
```
165 passed in 14.54s
```
154 testes preexistentes + 11 novos = 165. Nenhuma regressao.

## Autorrevisao

- **Uma correcao no teste, nao no codigo de producao.** O teste
  `test_ntnf_soma_cupons_semestrais`, como veio no brief, usava
  `d0 = date(2026, 6, 30)` com `vencimento = date(2033, 1, 1)`. Rodei e ele
  falhou: PU = 1050,70 contra o esperado ~1000 (rel=0,02). Investiguei antes
  de mudar qualquer coisa (ver `docs/convencoes-dv.md`, que avisa para nao
  "consertar" formula por achar que e erro).

  A causa: `pu_ntnf` devolve o preco **sujo** (soma de todos os fluxos
  futuros descontados, sem subtrair juro acumulado) -- e exatamente assim
  que o `PX_DIRTY_MID` da Bloomberg e definido, e e contra ele que o codigo
  foi validado. `2026-06-30` fica 1 dia util antes do cupom de `2026-07-01`;
  nessa data o preco sujo embute quase o cupom inteiro (48,81, ~5% de 1000)
  como juro acumulado, entao ficar perto do par so acontece longe de uma
  data de cupom. Testei varias datas de posicao com a mesma formula
  (2026-04-01 -> 1027,12; 2026-01-02 -> 1003,70; 2026-07-02, um dia util
  *depois* do cupom -> 1002,66) e confirmei que o PU oscila em torno do par
  ao longo do ciclo semestral, exatamente como preco sujo deveria se
  comportar. A formula em si esta correta e bate com o resto da suite (as
  outras 10 asserções do brief, incluindo os `dv` que tambem usam
  `d0 = 2026-06-30` para NTN-F, nao dependem de "estar perto do par" e
  passaram sem alteracao).

  **Correcao aplicada:** troquei o `d0` desse teste especifico para
  `date(2026, 7, 2)` -- o dia util seguinte ao cupom de `2026-07-01`, onde o
  juro acumulado e quase nulo e o preco sujo fica proximo do preco limpo
  (PU = 1002,66, dentro da tolerancia de 2%). O comentario do teste foi
  reescrito para explicar por que a escolha da data importa. Nenhuma formula,
  constante ou sinal do modulo `precificacao.py` foi tocado -- a mudanca foi
  só na data de um teste que, como escrito, testava um artefato de calendario
  em vez da propriedade que o nome do teste promete (preco ~ par quando
  taxa = cupom).

- **Verificacao manual das tres convencoes do `docs/convencoes-dv.md`:**
  - Sinal do `dv`: `LTN`, `NTN-F` e `NTN-B` deram negativo para taxa e
    vencimento tipicos (`-0.162427`, `-0.37498`, `-2.876974`
    respectivamente), confirmando `PU(taxa+1bp) - PU(taxa) < 0`.
  - `dv` da `LFT`: devolveu `None`, nao `0.0`, para um caso concreto.
  - Truncagem dentro do `dv`: confirmado pelo teste do brief
    (`test_dv_usa_precos_truncados`) e por inspecao -- `dv` chama `pu()`
    duas vezes, cada `pu()` ja trunca, e a subtracao e feita depois.
  - PU no vencimento (ou apos): `pu_ltn`, `pu_ntnf` e `pu_ntnb` devolvem
    `0.0` quando `d0 >= venc` (testado manualmente para os tres, alem do
    teste do brief que cobre `pu_ltn`).

- **ASCII**: os dois arquivos novos (`precificacao.py`,
  `test_precificacao.py`) foram conferidos byte a byte com
  `.decode('ascii')` -- ambos passam.
- **`git status` antes do commit**: so os dois arquivos esperados, ambos
  novos -- sem alteracoes acidentais em outros arquivos.
- **Bloomberg**: nenhuma consulta foi feita ao terminal Bloomberg, conforme
  restricao explicita da tarefa. Toda verificacao acima foi aritmetica,
  local, contra o proprio codigo.

## Decisoes

- Mantive a assinatura e o comportamento de `pu()`/`dv()` exatamente como no
  brief, incluindo a mensagem de erro que cita o titulo desconhecido e a
  que exige VNA -- os dois testes de erro (`test_titulo_desconhecido_falha_alto`,
  `test_ntnb_precisa_de_vna`) dependem do texto exato via `pytest.raises(...,
  match=...)`.

## Duvidas

Nenhuma sobre o escopo da tarefa. O unico ponto que exigiu investigacao (o
teste de NTN-F) se resolveu sem tocar em producao, entao nao ha decisao de
modelagem pendente para a usuaria revisar aqui -- so um ajuste de data de
teste, documentado acima para quem revisar o diff entender o porque.

## Commit

```
73cc9c5 Adiciona motor de precificacao portado do codigo da mesa
```
2 arquivos alterados: `src/tesouro/precificacao.py` (novo),
`tests/test_precificacao.py` (novo).

---

## Rodada de correcao 1 -- achados da revisao de mutacao

O revisor confirmou conformidade com a spec (`precificacao.py` byte-identico
ao brief, ancoras recalculadas por fora batem) e aprovou a mudanca de data no
`test_ntnf_soma_cupons_semestrais` como correta -- decompos o PU a mao e
achou os mesmos 48,79 do cupom de 1 de julho mais 1,91 de residuo da
convencao 252 que a investigacao da rodada anterior tinha atribuido ao preco
sujo.

Rodou 15 mutacoes contra `precificacao.py` e 6 sobreviveram, todas por falta
de teste (nenhum numero que o codigo produz hoje esta errado). Quatro pedidos
de correcao, todos em `tests/test_precificacao.py` -- **nenhuma linha de
`src/tesouro/precificacao.py` foi tocada** nesta rodada; confirmei isso com
`git checkout -- src/tesouro/precificacao.py` apos os testes de mutacao
manuais, e o arquivo ficou byte-identico ao commit anterior.

### 1 (Critical) -- nada ancorava o tamanho do choque de 1 bp

Os tres testes de `dv` (sinal, monotonia no prazo, multiplo de 1e-6) sao
invariantes a escala do choque: trocar `_UM_BP` de `0.0001` para `0.0010`
deixava a suite inteira verde, e todo DV01 do projeto sairia 10x sem
nenhum teste reclamar.

**Correcao:** `test_dv_da_ltn_bate_com_o_fechado_analitico`, ancorando
`dv(cal, "LTN", d0, cal.mover(d0, 252), 0.10) == pytest.approx(-0.082638,
abs=1e-6)` -- o valor exato passado pelo revisor, que bate com o fechado
analitico `-PU*n/(1+i)*1e-4` (`-0,0826446`) a menos do degrau de truncagem.

**Verificacao manual da mutacao:** apliquei `_UM_BP = 0.0010` no modulo,
rodei a suite -- so este teste falhou (`-0.8256959999999935` vs
`-0.082638 +/- 1e-6`, os outros 13 continuaram verdes) -- e restaurei o
arquivo original.

### 2 (Critical) -- a NTN-B nao tinha nenhuma ancora de valor

Tres mutacoes sobreviviam: remover a corrente de cupons inteira, trocar a
constante de cupom por `3,00`, e truncar a cotacao em 6 casas em vez de 4.

**Correcao:** `test_ntnb_pu_bate_com_valor_recalculado_por_fora`, ancorando
`pu_ntnb(cal, date(2026,6,30), date(2035,5,15), 0.07, 4739.66) ==
pytest.approx(4486.069231, abs=1e-6)`, valor passado pelo revisor.

**Verificacao manual das tres mutacoes**, aplicadas uma de cada vez no
modulo, com a suite rodada e o arquivo restaurado apos cada uma:

- Sem a corrente de cupons: PU cai para `2610.10...` (na pratica o loop
  nunca executa) -- falha em `test_ntnb_pu_bate_com_valor_recalculado_por_fora`
  **e** em `test_dv_e_negativo_para_titulo` (o DV da NTN-B vira `0.0`).
- Cupom `3,00` em vez de `2,9563`: PU vira `4513.800982` -- falha na ancora.
- Cotacao truncada em 6 casas em vez de 4: PU vira `4486.07326` (diferenca
  de ~4e-3, dentro do que pareceria arredondamento a olho nu, mas fora da
  tolerancia `abs=1e-6` da ancora) -- falha na ancora.

### 3 (Important) -- tolerancia frouxa em `test_ntnf_soma_cupons_semestrais`

Na data escolhida na rodada anterior (`2026-07-02`), o desvio real do PU
correto em relacao ao par e 0,27%; a tolerancia de `rel=0.02` deixava passar
um erro de ate 2%, por exemplo um cupom de `50,00` em vez de `48,8088`
(desvio de +1,40%) sem que o teste notasse.

**Correcao:** apertei para `rel=0.005`. A implementacao correta continua
passando com o dobro de margem (0,27% << 0,5%).

### 4 (Minor) -- fronteira do laco de cupom em `pu_ntnf`

Mutacao `cupom > d0` -> `cupom >= d0` deixava a suite verde, mas faz quem
carrega o titulo exatamente na data de um cupom receber esse cupom de novo
no PU calculado naquela mesma data -- cerca de 4,9% do PU. Inalcancavel em
producao (datas de posicao sao sempre ultimo dia util do mes; cupom cai no
dia 1 ou no dia 15, nunca coincide), mas e uma linha facil de alterar sem
a suite notar.

**Correcao:** escrevi apenas o teste, sem tocar no operador --
`test_ntnf_nao_paga_cupom_de_novo_na_data_do_pagamento`. Ele compara o PU
numa data de cupom exata (`2028-01-03`, um dos cupons da serie com
vencimento `2033-01-01`) com o PU um dia util depois, e exige que a
diferenca seja pequena (`< 5.0`) -- o efeito normal de um dia de desconto
e ~0,38; se o cupom da propria data fosse contado de novo, a diferenca
saltaria para ~48,4 (o valor do cupom, menos o efeito de 1 dia de
desconto), disparando o teste.

**Verificacao manual da mutacao:** apliquei `>=` no loop de `pu_ntnf`,
rodei a suite -- so este teste falhou (`48.42957... < 5.0` fica falso) --
e restaurei o arquivo original.

### Comandos rodados e saida

```
PYTHONPATH=src python -m pytest tests/test_precificacao.py -v
```
```
14 passed in 0.79s
```
(11 do brief + 3 novos: 1 do item 1, 1 do item 2, 1 do item 4; o item 3 so
alterou uma tolerancia num teste existente.)

```
PYTHONPATH=src python -m pytest tests/
```
```
168 passed in 14.52s
```
154 anteriores + 14 de `test_precificacao.py` = 168. Nenhuma regressao.

### Confirmacao de que `precificacao.py` nao mudou

```
git checkout -- src/tesouro/precificacao.py
git status
```
```
On branch dv01-decay
Changes not staged for commit:
	modified:   tests/test_precificacao.py
```
Apos o `checkout`, so `tests/test_precificacao.py` aparece modificado --
`src/tesouro/precificacao.py` esta byte-identico ao commit `73cc9c5`.

### Achados que o revisor decidiu nao pedir correcao (registrados, nao mexidos)

- Imports dentro do corpo das funcoes: vieram do brief verbatim, mantidos.
- `dv` devolver `0.0` (nao `None`) para papel vencido: comportamento
  correto -- so a LFT usa `None`; papel vencido tem risco de taxa
  genuinamente nulo.

### Commit

```
cbe4bd3 Trava mutacoes sobreviventes na suite de precificacao
```
1 arquivo alterado: `tests/test_precificacao.py` (3 testes novos, 1
tolerancia apertada). `src/tesouro/precificacao.py` nao foi tocado.

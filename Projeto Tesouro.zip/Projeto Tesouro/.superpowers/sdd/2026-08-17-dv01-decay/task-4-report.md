### Task 4: Coletor da Bloomberg -- relatorio

**Status:** concluida. **A verificacao ao vivo contra o terminal (Step 5 do
brief) NAO foi executada** -- fica pendente de autorizacao caso a caso da
Aline. Ver secao dedicada abaixo com o que rodar quando ela autorizar.

**Commit original:** `8d5b430` -- "Adiciona coletor de taxa e VNA na Bloomberg
(grupo 8, tarefa 4)". **Commit desta rodada de correcao:** `e6fbca2` --
"Corrige achados da revisao do coletor Bloomberg (tarefa 4)" (branch
`dv01-decay`). Arquivos: `src/tesouro/fetch_bloomberg.py`,
`tests/test_fetch_bloomberg.py`, `src/tesouro/parse_bloomberg.py`.

**Testes:** `14 passed` em `tests/test_fetch_bloomberg.py`; suite inteira
`205 passed` (191 anteriores + 14 novos), nenhuma regressao. Nenhum teste
toca rede nem `data/raw/` (confirmado com `git status --porcelain` antes e
depois: so os arquivos de codigo aparecem, `data/raw/bloomberg/` continua
com exatamente os dois arquivos que ja existiam).

**Preocupacoes:** nenhuma bloqueante. Uma nota de design registrada
abaixo (secao "Autorrevisao") que vale a pena a Aline saber, mesmo sem
exigir acao agora.

**Esta e a segunda rodada.** A revisao da primeira encontrou 5 Important e
alguns Minor -- todos corrigidos nesta rodada, com resposta item a item na
secao "Resposta a revisao" ao final deste relatorio. Nada do que segue
abaixo, no corpo principal, reflete mais o estado anterior: o texto foi
atualizado para descrever o codigo como ele esta agora.

---

#### O que foi implementado, e por que difere do codigo de exemplo do brief

O brief trazia um `baixar()` de exemplo que recalculava a janela inteira do
estoque (2010 a hoje) a cada chamada e escrevia direto no nome final --
ou seja, rodar duas vezes so produziria o MESMO nome de arquivo, e a
segunda chamada teria sobrescrito a primeira em silencio. E exatamente a
classe de erro que o `fetch_rmd.baixar` da entrega anterior cometeu de
verdade e que so foi descoberta na revisao final, depois de catorze
revisoes de tarefa -- o dispatch desta tarefa foi explicito que isso nao
podia se repetir. Por isso o `baixar()` implementado se afasta do exemplo
em um ponto central:

- **Corte incremental por CONJUNTO de meses, nao por "ultimo mes".**
  `_meses_cobertos(destino, padrao_glob, padrao_nome)` olha os NOMES dos
  arquivos ja presentes no destino (nunca o conteudo) e monta, para cada
  um dos tres tipos (`bbg_taxas_ANDE_*.csv`, `bbg_vna_*.csv`,
  `bbg_precos_ANDE_*.csv`), o conjunto INTEIRO de meses que cada um
  reivindica cobrir (todo mes entre o "de" e o "ate" do nome ISO, nao so
  o "ate"). `baixar()` pede so os meses do painel que faltam em QUALQUER
  um dos tres. Isso substitui uma primeira versao que so olhava o maior
  "ate" de cada tipo -- essa versao tinha dois defeitos medidos na
  revisao (buraco no meio da serie nunca detectado; um dos tres tipos
  adiantado podia colidir de nome com o proximo pedido), ambos descritos
  na secao "Resposta a revisao" ao final.
- Cada papel e pedido a partir de `max(primeira_data_de_estoque_do_papel,
  mes_mais_antigo_que_falta)` -- um papel que ja existia antes do corte so
  pede o que falta; um papel que nasceu depois do corte pede desde o
  proprio nascimento, nunca antes. Como a requisicao de taxa/preco pede um
  INTERVALO continuo (nao uma lista de meses), um buraco no meio da serie
  pode trazer de volta algum mes que um dos tres arquivos ja tinha --
  redundante, nunca errado (parse_bloomberg fica com a ultima ocorrencia).
- O nome do arquivo novo reflete SO o periodo realmente pedido (ex.:
  `bbg_taxas_ANDE_2026-07_2026-07.csv` para uma coleta mensal de rotina,
  ou so `bbg_vna_2023-02_2023-02.csv` se fevereiro for o unico mes que
  ficou faltando no meio da serie), nunca a janela inteira do estoque --
  e por isso os arquivos se acumulam em vez de colidir.
- **Defesa em profundidade:** mesmo com o corte acima, se o caminho de
  destino calculado ja existir fisicamente, `baixar()` levanta
  `FileExistsError` explicando o motivo, em vez de escrever por cima. Isso
  e checado ANTES de abrir sessao com o terminal.
- **Se nao houver nada novo** (nenhum mes do painel falta em taxa, VNA E
  preco ao mesmo tempo), `baixar()` levanta `RuntimeError` com uma
  mensagem explicando o motivo, em vez de gravar um arquivo vazio ou
  repetir a coleta. Isso tambem acontece antes de tocar a rede e antes de
  criar o diretorio de destino (`destino.mkdir()` so roda depois de
  confirmar que ha algo para gravar).
- Os tres arquivos (taxa, VNA, preco) sao montados inteiramente em memoria
  (`io.StringIO`) e so gravados no fim, via `gravacao.gravar_atomico` --
  reaproveitado, nao reescrito. Isso tem duas consequencias: (1) se a
  puxada de taxa funcionar mas a de VNA falhar no meio, nao sobra nenhum
  arquivo parcial em `data/raw/`; (2) a escrita final e atomica (arquivo
  `.part` + `Path.replace`), entao um processo morto no meio nunca deixa
  um CSV truncado com o nome definitivo.
- **`divergencia` do VNA gravada em reais**, na mesma unidade que a coluna
  `vna` (fator x 1000) -- e nao no fator cru. `parse_bloomberg.py`
  documenta a tolerancia (`_TOLERANCIA_DIVERGENCIA = 0.5`) como "em
  reais"; a coluna gravada tem de estar na mesma unidade para essa guarda
  significar o que o texto diz.
- **A LFT nunca entra no arquivo de preco.** `docs/convencoes-dv.md`
  documenta que a serie de preco da LFT na Bloomberg e inutilizavel (vem
  expressa com o indice CORRENTE, nao o da epoca). `baixar()` filtra a
  LFT fora antes de montar `_conteudo_precos`.

O resto segue o brief ao pe da letra: `papeis_do_estoque()` e
`datas_do_painel()` sao identicas ao codigo de exemplo (os quatro testes
dados no brief passam sem alteracao), `_historico` usa
`HistoricalDataRequest` (nunca `SETTLE_DT`) para taxa, `_referencia` usa
`ReferenceDataRequest` com override `SETTLE_DT` so para o VNA, e a fonte
`@ANDE` e obrigatoria no identificador do papel nos dois casos.

**Uma correcao em relacao ao codigo de exemplo do brief, fora do escopo do
corte incremental:** o exemplo fazia `ponto.getElementAsDatetime("date").date()`
ao ler a data de um ponto historico. O proprio dispatch desta tarefa avisa
que isso quebra, porque o `blpapi` ja devolve um `date` (chamar `.date()`
num `date` levanta `AttributeError`, so `datetime` tem esse metodo). O
codigo implementado usa o valor de `getElementAsDatetime("date")`
diretamente, sem `.date()`.

`blpapi` so e importado dentro de `_sessao()` -- nao no topo do modulo.
`test_nao_importa_blpapi_no_topo` confere isso lendo a AST do arquivo, como
o brief pede.

---

#### Autorrevisao

- **ASCII puro**: script que decodifica os tres arquivos tocados
  (`fetch_bloomberg.py`, `test_fetch_bloomberg.py`, `parse_bloomberg.py`)
  como `ascii` -- nenhum caractere fora da faixa em nenhum dos tres
  (achei e corrigi um "assercao" com cedilha no teste, na propria rodada
  de correcao da revisao -- ver abaixo).
- **`r["isin"]` vs `r.isin`**: o modulo usa `itertuples(index=False)` para
  iterar papeis (`p.isin`, `p.titulo`, etc.) -- isso e seguro, porque o
  problema documentado (`Series.isin` sombreando a coluna) so existe ao
  indexar um `DataFrame`/`Series` por atributo, nao numa `namedtuple` de
  `itertuples`. Nao ha `df.isin` em lugar nenhum do codigo.
- **`pd.isna` vs `is None`**: nao ha comparacao de coluna numerica contra
  `None` no modulo; o unico filtro de nulo (`quantidade_mil.fillna(0) > 0`)
  ja usa o padrao vetorizado correto, herdado do brief.
- **`data/raw/` intocado pelos testes**: todos os 14 testes de
  `test_fetch_bloomberg.py` usam `tmp_path`; os 4 que exercitam
  `papeis_do_estoque()`/`datas_do_painel()` diretamente so LEEM
  `data/processed/estoque_titulos_vencimento.csv` (que ja existe, gerado
  por tarefa anterior), nunca escrevem. Confirmado com `git status
  --porcelain` antes/depois da suite: zero diferenca em `data/`.
- **Ponto de atencao que decidi registrar, nao resolver, por ser fora de
  escopo**: ha uma janela pequena entre o calculo do que falta e a
  gravacao final -- se `baixar()` for chamado duas vezes em paralelo, as
  duas calculariam o mesmo periodo e a segunda esbarraria no
  `FileExistsError` da primeira. No fluxo real (uma pessoa, rodando
  manualmente) isso nao acontece; documentado no docstring do modulo para
  quem for automatizar isto num agendador no futuro -- ver a resposta ao
  item 5 da revisao abaixo, que corrigiu uma afirmacao errada sobre essa
  mesma janela.
- **`bbg_precos_ANDE_*.csv` nao tem contrato de nome no
  `docs/convencoes-dv.md`** (so `bbg_taxas_*` e `bbg_vna_*` estao na
  tabela) -- mantive o mesmo padrao ISO por consistencia, e agora ele
  tambem entra em `_meses_cobertos` (ver resposta ao Minor sobre isso).
  `parse_bloomberg.py` continua sem ler esse arquivo (e so referencia).
- Testei especificamente que o CSV gerado por `baixar()` e lido por
  `parse_bloomberg.parse_taxas()`/`parse_vna()` **sem nenhuma alteracao**
  nesse modulo, **incluindo o VALOR** do VNA (nao so presenca de linha ou
  o conjunto de indices) --
  `test_baixar_grava_csv_que_parse_bloomberg_le_sem_alteracao`. Essa
  assercao de valor foi acrescentada na resposta ao item 1 da revisao
  (ver abaixo); antes dela, a suite inteira passava mesmo com o `x1000`
  do VNA removido.

Nenhum problema foi encontrado nesta rodada de autorrevisao alem do que ja
esta descrito acima e na "Resposta a revisao" que segue.

---

#### O que a Aline precisa rodar para validar o coletor ao vivo, quando autorizar

Isto foi **pulado nesta sessao por instrucao explicita** -- nenhuma
consulta foi feita ao terminal Bloomberg. Quando ela quiser validar, com
o terminal Bloomberg aberto e logado na maquina, abra o **PowerShell**
(nao o "Prompt de Comando") e va para a pasta do projeto:

```powershell
cd "C:\Users\lineb\OneDrive\Desktop\Projeto Tesouro"
```

**Aviso sobre o comando `PYTHONPATH=src ...`** que apareceu numa versao
anterior deste relatorio: essa e sintaxe de Linux/Mac, **nao funciona no
PowerShell** (da erro "'PYTHONPATH=src' nao e reconhecido..."). No
PowerShell, a variavel se define numa linha separada, como abaixo.

**1. Verificacao rapida e segura (nao muda nada em `data/raw/`):**

```powershell
$env:PYTHONPATH = "src"
& "C:\Users\lineb\AppData\Local\Programs\Python\Python312\python.exe" -m tesouro.fetch_bloomberg
```

(o `&` antes do caminho entre aspas e necessario no PowerShell sempre que
o caminho do programa tem espaco, como "Local Programs".)

O que esperar, dependendo do estado do estoque de dados no momento:

- **Se o estoque em `data/processed/estoque_titulos_vencimento.csv` ainda
  nao tiver nenhum mes novo em relacao ao que ja esta coletado** (hoje,
  junho de 2026, coberto pelos arquivos que ja existem em
  `data/raw/bloomberg/`), o comando vai parar imediatamente com um erro
  `RuntimeError: nada novo a coletar (...)`, **sem nunca abrir o
  terminal Bloomberg**. Isso e o comportamento correto e esperado -- e a
  forma mais barata de confirmar que a logica de "nao pedir de novo o que
  ja tenho" esta funcionando, mas nao prova que o terminal responde.
- **Se ja houver um mes novo no estoque** (por exemplo, depois de rodar a
  camada de dados do RMD de julho/agosto de 2026), o comando vai abrir
  sessao com o terminal e pedir SO esse mes novo para os papeis do
  escopo (LTN, NTN-F, NTN-B, LFT). Isso deve levar de alguns segundos a
  poucos minutos (bem mais rapido que uma coleta completa, porque so
  pede o que falta). Ao terminar, aparecem tres linhas parecidas com:
  ```
  gravado: data\raw\bloomberg\bbg_taxas_ANDE_2026-07_2026-07.csv
  gravado: data\raw\bloomberg\bbg_vna_2026-07_2026-07.csv
  gravado: data\raw\bloomberg\bbg_precos_ANDE_2026-07_2026-07.csv
  ```
  (o mes exato no nome depende de qual mes estiver faltando -- e, se
  houver um buraco no meio da serie, pode ser um mes que nao e o mais
  recente). **Como reconhecer que deu certo:** os tres arquivos aparecem
  em `data/raw/bloomberg/` com o mes novo no nome, e os arquivos antigos
  (`..._2010-01_2026-06.csv`) continuam exatamente como estavam. Para
  conferir isso sem precisar decorar nada, rode em seguida, no mesmo
  PowerShell:
  ```powershell
  git status --porcelain data/raw/
  ```
  Deve aparecer `??` (arquivo novo, ainda nao rastreado pelo git) nos tres
  arquivos novos, e **nada** relacionado aos arquivos antigos -- nenhuma
  linha comecando com `M` (modificado) nem `D` (apagado). Se aparecer
  algo assim, pare e nao mexa em nada mais -- isso indicaria que um
  arquivo antigo foi alterado, o que nunca deveria acontecer.
- **Se o terminal Bloomberg nao estiver aberto ou logado**, o comando para
  com `ConnectionError: nao foi possivel falar com o terminal Bloomberg
  (...)`. Isso tambem e esperado -- confirma que o coletor falha de forma
  clara em vez de travar ou inventar dado, mas nao prova que a coleta
  funciona quando o terminal esta disponivel.

**2. Verificacao completa, que reproduz o mesmo periodo do arquivo de
referencia e permite comparar numero a numero (mais pesada -- puxa o
historico inteiro de novo para todos os ~190 papeis do escopo, entao
demora bem mais que a coleta de rotina acima; use so quando quiser mesmo
conferir os numeros contra o arquivo ja existente, nao para uma checagem
de rotina):**

No mesmo PowerShell, abra o Python interativo (repare que a variavel de
ambiente precisa ser definida ANTES, na mesma janela):

```powershell
$env:PYTHONPATH = "src"
& "C:\Users\lineb\AppData\Local\Programs\Python\Python312\python.exe"
```

Isso abre um prompt `>>>`. Cole o bloco abaixo ali dentro (a pasta de
destino e uma pasta NOVA e separada dentro da sua Area de Trabalho de
verdade -- que no seu computador fica redirecionada para
`C:\Users\lineb\OneDrive\Desktop`, nao `C:\Users\lineb\Desktop` -- para
nao encostar em `data/raw/bloomberg/`):

```python
from tesouro import fetch_bloomberg
taxa, vna, preco = fetch_bloomberg.baixar(
    destino="C:/Users/lineb/OneDrive/Desktop/teste_bloomberg"
)
print(taxa, vna, preco)
```

Isso vai levar bem mais tempo (puxa a serie inteira, papel por papel).
Quando terminar de rodar (volta o prompt `>>>`), **sem fechar essa
janela**, cole o bloco de comparacao abaixo -- ele le os dois pares de
arquivo com `pandas` (ja disponivel, o projeto usa) e imprime quantas
linhas casaram e a maior diferenca encontrada, sem exigir abrir nada no
Excel:

```python
import pandas as pd

novo = pd.read_csv("C:/Users/lineb/OneDrive/Desktop/teste_bloomberg/bbg_taxas_ANDE_2010-01_2026-06.csv")
antigo = pd.read_csv("data/raw/bloomberg/bbg_taxas_ANDE_2010-01_2026-06.csv")
comp = novo.merge(antigo, on=["isin", "data"], suffixes=("_novo", "_antigo"))
comp["diferenca"] = (comp["yld_ytm_mid_novo"] - comp["yld_ytm_mid_antigo"]).abs()
print("TAXA:", len(comp), "linhas comparadas -- maior diferenca:", comp["diferenca"].max())

novo_vna = pd.read_csv("C:/Users/lineb/OneDrive/Desktop/teste_bloomberg/bbg_vna_2010-01_2026-06.csv")
antigo_vna = pd.read_csv("data/raw/bloomberg/bbg_vna_2010-01_2026-06.csv")
comp_vna = novo_vna.merge(antigo_vna, on=["data", "indice"], suffixes=("_novo", "_antigo"))
comp_vna["diferenca"] = (comp_vna["vna_novo"] - comp_vna["vna_antigo"]).abs()
print("VNA:", len(comp_vna), "linhas comparadas -- maior diferenca:", comp_vna["diferenca"].max())
```

**Como reconhecer que deu certo:** as duas linhas impressas tem que
mostrar um numero grande de "linhas comparadas" (proximo de 8.900 para
TAXA e 396 para VNA -- o mesmo tamanho dos arquivos de referencia atuais)
e "maior diferenca" **proxima de zero** (uma casa decimal ou menos de
diferenca e ruido esperado; qualquer coisa grande, tipo uma diferenca de
centenas no VNA, indica problema). Se "linhas comparadas" vier muito
menor que o esperado ou zero, o merge nao achou quase nada em comum --
confira se os dois caminhos de arquivo estao certos antes de mais nada.
Esse script foi testado nesta sessao comparando o arquivo de referencia
atual contra ele mesmo (sem tocar a Bloomberg) e deu exatamente 8.898
linhas / diferenca 0.0 para taxa e 396 linhas / diferenca 0.0 para vna --
e o resultado esperado quando os dois arquivos realmente batem.

Depois de qualquer uma das duas verificacoes, a pasta de teste
(`C:\Users\lineb\OneDrive\Desktop\teste_bloomberg`) pode ser apagada --
ela nunca fica dentro do projeto nem entra no `git`.

---

#### O que continua igual do brief original, para quem ler so este relatorio

- Interface: `papeis_do_estoque() -> DataFrame`,
  `datas_do_painel() -> list[date]`, `baixar(destino=None) -> tuple[Path,
  Path, Path]` (taxa, VNA, preco).
- Taxa: `YLD_YTM_MID` em `/isin/<ISIN>@ANDE Govt`, so via
  `HistoricalDataRequest` -- nunca `SETTLE_DT`.
- VNA: `IDX_RATIO` (NTN-B/IPCA) e `ACCUMULATED_SELIC` (LFT/SELIC), com
  override `SETTLE_DT`, multiplicado por 1000.
- Preco (`PX_DIRTY_MID`): so referencia, nunca entra em calculo.
- `blpapi` importado so dentro de `_sessao()`.

---

## Resposta a revisao de qualidade

Aprovado com ressalvas na primeira rodada (conformidade com a spec: OK;
guarda de sobrescrita: OK, testada em seis cenarios pelo revisor sem achar
caminho de sobrescrita). 5 Important e alguns Minor, todos corrigidos
abaixo.

**Commit desta correcao:** `e6fbca2` -- "Corrige achados da revisao do
coletor Bloomberg (tarefa 4)". Arquivos tocados:
`src/tesouro/fetch_bloomberg.py`, `tests/test_fetch_bloomberg.py`,
`src/tesouro/parse_bloomberg.py` (so a docstring, item Minor abaixo). Este
relatorio (`.superpowers/sdd/`) nao entra em commit -- o diretorio esta no
`.gitignore` do projeto.

### 1 (Important) -- o x1000 do VNA nao tinha trava

`_conteudo_vna` agora grava `vna = fator * 1000` (ja gravava antes; nao
mudou o calculo) e o teste de ida-e-volta
(`test_baixar_grava_csv_que_parse_bloomberg_le_sem_alteracao`) passou a
usar fatores nao-redondos e distintos por campo (`_FATOR_POR_CAMPO`) e
**assertar o valor numerico** do `vna` lido de volta por
`parse_bloomberg.parse_vna()`, nao so presenca de linha ou o conjunto de
indices.

**Confirmado a mao, como pedido:** removi o `* 1000` das duas linhas de
`_conteudo_vna` (fator gravado E vna gravado) e rodei a suite -- **2
testes falham**: o novo teste de valor
(`test_baixar_grava_csv_que_parse_bloomberg_le_sem_alteracao`, esperando
~1834 e obtendo ~1.83) e o teste dedicado de divergencia (item 3, que
tambem depende da mesma unidade). Reaplicando o `* 1000`, os 205 voltam a
passar.

### 2 (Important) -- as duas armadilhas de API sem teste de requisicao

Acrescentei `test_historico_usa_historicaldatarequest_com_fonte_ande_e_sem_settle_dt`
e `test_referencia_usa_referencedatarequest_com_settle_dt_e_fonte_ande`,
que chamam `_historico`/`_referencia` **de verdade** (nao dubladas) contra
um `servico`/`sessao` falso que so registra o `createRequest` (tipo),
`securities`, `fields`, `set(...)` e `overrides` -- sem simular nenhuma
mensagem de resposta, porque so a REQUISICAO importa aqui.

**Confirmado a mao, como pedido:**
- Troquei `HistoricalDataRequest` por `ReferenceDataRequest` com override
  `SETTLE_DT` dentro de `_historico` (a mutacao exata que o revisor
  descreveu): **1 teste falha**
  (`test_historico_usa_historicaldatarequest_com_fonte_ande_e_sem_settle_dt`,
  na assercao `"overrides" not in req.elementos`).
- Removi o `@ANDE` das duas funcoes (`f"/isin/{isin} Govt"` em vez de
  `f"/isin/{isin}@ANDE Govt"`): **2 testes falham**, um em cada funcao.

Revertido nos dois casos, os 205 voltam a passar.

### 3 (Important) -- `divergencia` gravada na unidade errada

`_conteudo_vna` agora grava `divergencia = (max(valores) - min(valores)) * 1000`,
na mesma unidade que `vna` (reais), com o docstring da funcao explicando
por que -- `parse_bloomberg.py:71` documenta a tolerancia como "em
reais", e a guarda so significa o que o texto diz se a coluna estiver na
mesma unidade.

Acrescentei `test_conteudo_vna_grava_divergencia_em_reais_nao_no_fator_cru`,
com uma fixture minima de dois papeis do mesmo indice discordando em
0.0004 no fator (R$0,40 depois do x1000 -- acima da tolerancia de 0.5) e
asserta o valor exato gravado na coluna.

**Confirmado a mao:** removido o `* 1000` dessa linha especificamente
(mantendo o do `vna`), **1 teste falha** (o novo, esperando 0.4 e obtendo
0.0004). Revertido, volta a passar.

**Confirmado sobre os brutos atuais, como pedido:** `awk -F, '{print $NF}'
data/raw/bloomberg/bbg_vna_2010-01_2026-06.csv | sort -u` devolve so dois
valores -- `divergencia` (cabecalho) e `0.000000000` -- confirmando que as
396 linhas do bruto atual tem `divergencia = 0`, exatamente como
`parse_bloomberg.py` ja documentava. Como `0 * 1000 = 0`, nada existente e
reinterpretado por essa mudanca: a leitura de `parse_vna()` contra os
brutos reais continua identica (a suite completa, que inclui os 23 testes
de `test_parse_bloomberg.py` contra o bruto real, confirma isso).

### 4 (Important) -- buraco no meio da serie nunca preenchido, mensagem culpando o lugar errado

Este era o item que faltava para o desvio do brief (corte incremental)
ficar inteiro. `_cobertura_atual` (que so guardava o MAXIMO `ate` de cada
tipo de arquivo) foi substituida por `_meses_cobertos(destino,
padrao_glob, padrao_nome)`, que monta o CONJUNTO de todo mes que cada
arquivo existente reivindica cobrir (todo mes entre "de" e "ate" do nome,
nao so o "ate"). `baixar()` agora pede todo mes do painel que falte em
QUALQUER um dos tres tipos de arquivo (taxa, vna, preco) -- nao so o que
vem depois do mes mais recente.

Acrescentei `test_baixar_preenche_buraco_no_meio_da_serie`, reproduzindo
exatamente o cenario do revisor: arquivos cobrindo janeiro e marco,
fevereiro faltando. Confirma que `baixar()` pede so fevereiro (nome do
arquivo novo: `..._2023-02_2023-02.csv`), sem tocar janeiro/marco.

**Efeito colateral bom, nao so a correcao pedida:** essa mudanca tambem
resolveu de raiz os dois cenarios de risco que o item 5 mediu (ver
abaixo) -- eles eram consequencia direta de "olhar so o mes mais
recente", que deixou de existir.

**Confirmado a mao:** com `_meses_cobertos` voltando a olhar so o maximo
"ate" por tipo (reproduzindo a versao anterior), o novo teste de buraco
falha -- o buraco de fevereiro nunca e detectado, e `baixar()` levanta
`RuntimeError: nada novo a coletar` (o mesmo sintoma que o revisor
mediu). Restaurada a versao por conjunto, volta a passar.

### 5 (Important) -- relatorio afirmava uma protecao que nao existia por completo

A frase antiga ("o minimo dos dois protege a interrupcao entre gravar a
taxa e gravar o vna") foi removida do relatorio e do docstring do modulo.
O que esta escrito agora (na secao de implementacao acima e no docstring
de `_meses_cobertos`) descreve o mecanismo atual -- conjunto de meses por
tipo, comparado tipo a tipo -- sem alegar uma garantia que o codigo nao
cumpria.

Como a correcao do item 4 trocou o mecanismo (nao so o texto), os dois
casos que o revisor mediu contra a versao antiga **nao reproduzem mais**:
verifiquei a mao, com o estado exato que o revisor descreveu (so o
arquivo de taxa presente cobrindo jan-fev; so o vna presente cobrindo
jan-fev com a taxa "na frente" cobrindo so marco) --
`_meses_cobertos` computado tipo a tipo faz `baixar()` pedir a uniao das
duas lacunas em ambos os casos, com um nome de arquivo que nunca repete o
de um arquivo ja existente. Documentado no docstring do modulo (paragrafo
"Duas consequencias do desenho acima") em vez de alegado como garantia
absoluta -- a janela de corrida entre calcular o que falta e gravar o
resultado final continua existindo (ver Minor abaixo), so que agora
menor, porque as tres gravacoes acontecem em sequencia rapida no fim,
depois que as tres puxadas ja terminaram.

### Minors

- **Preco da LFT**: `baixar()` agora filtra `titulo != "LFT"` antes de
  montar `_conteudo_precos` -- a LFT nunca mais aparece no arquivo de
  preco. Testado em
  `test_baixar_primeira_coleta_pega_a_janela_inteira` (assert de que
  `BR0000000LFT` nao esta no conjunto de ISINs do arquivo de preco).
- **`bbg_precos_*` fora de `_cobertura_atual`**: corrigido como parte do
  item 4 -- `_meses_cobertos` agora e chamada tambem para
  `bbg_precos_ANDE_*.csv`, e um mes faltando so no preco tambem entra na
  proxima coleta.
- **Docstring de `parse_bloomberg.py` desatualizada sobre o dia do VNA**:
  corrigida (linhas 19-20 da versao anterior) -- agora explica que o
  coletor pede o `SETTLE_DT` no ultimo dia UTIL (as mesmas datas de
  `datas_do_painel()`), e que um bruto legado com o dia corrido continua
  aceito porque o VNA e identico nos dois.
- **`destino.mkdir()` antes de qualquer validacao**: `baixar()` agora so
  cria o diretorio de destino depois de confirmar que ha algo para
  gravar (depois da checagem de "nada novo" e da checagem de arquivo ja
  existente). Testado em
  `test_baixar_nao_cria_pasta_de_destino_quando_nao_ha_nada_a_gravar`.
- **Janela de corrida registrada, nao consertada**: mantida a decisao do
  revisor de nao resolver -- o docstring do modulo agora tem um paragrafo
  dedicado a isso ("Duas consequencias do desenho acima"), explicando por
  que o pior caso e trabalho duplicado, nunca dado perdido ou
  sobrescrito.

### Item 6 -- instrucoes para a Aline

A secao "O que a Aline precisa rodar" foi reescrita. Os tres problemas
medidos pelo revisor:

- **Sintaxe bash no PowerShell**: `PYTHONPATH=src "...python.exe" ...`
  nao roda no PowerShell (o proprio revisor confirmou o erro). Trocado
  por `$env:PYTHONPATH = "src"` numa linha separada, nos dois comandos
  (a coleta direta e o Python interativo).
- **Caminho da Area de Trabalho errado**: `C:\Users\lineb\Desktop` nao e
  a Area de Trabalho dela (redirecionada para
  `C:\Users\lineb\OneDrive\Desktop`, confirmado listando o diretorio
  real). Corrigido nos dois lugares que citavam o caminho.
- **"Compare no Excel" nao era acionavel**: substituido por um script
  Python pronto (usa `pandas`, ja disponivel no projeto) que faz o
  merge dos dois arquivos por `isin`+`data` (taxa) ou `data`+`indice`
  (vna) e imprime quantas linhas casaram e a maior diferenca -- sem
  precisar abrir Excel. Testei o script nesta sessao comparando o
  arquivo de referencia contra ele mesmo (leitura local, sem tocar a
  Bloomberg): 8.898 linhas / diferenca 0.0 para taxa, 396 linhas /
  diferenca 0.0 para vna -- os numeros que aparecem no relatorio como "o
  que esperar quando bate".

A sintaxe `$env:PYTHONPATH = "src"` foi conferida rodando `python -c
"from tesouro import fetch_bloomberg; print('import ok')"` no PowerShell
de verdade (import apenas -- nao chama `baixar()`, entao nao e consulta
a Bloomberg).

### Verificacao final desta rodada

Suite completa: **205 passed** (191 anteriores + 14 de
`test_fetch_bloomberg.py`, contra os 9 da primeira entrega). As quatro
mutacoes que o revisor descreveu foram reproduzidas a mao, uma de cada
vez, e cada uma falha exatamente onde esperado (ver itens 1-3 acima);
revertidas, a suite volta a 205/205. ASCII conferido de novo nos tres
arquivos tocados (achei e corrigi uma cedilha remanescente no arquivo de
teste). `git status --porcelain data/` vazio antes e depois da suite.

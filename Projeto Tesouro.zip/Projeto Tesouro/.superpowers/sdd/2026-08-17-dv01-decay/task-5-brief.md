### Task 5: Painel de DV por papel

**Files:**
- Create: `src/tesouro/dv.py`
- Test: `tests/test_dv.py`

**Interfaces:**
- Consumes: `calendario.padrao()`, `precificacao.pu`, `precificacao.dv`, os CSVs `estoque_titulos_vencimento.csv`, `taxa_por_papel.csv` e `vna.csv`
- Produces:
  - `dv.painel() -> DataFrame` — colunas `data, isin, titulo, vencimento, taxa_pct, vna, pu, dv_unitario, quantidade_mil, dv_posicao_milhoes, financeiro_calculado_milhoes`
  - `dv.gravar_painel() -> None` — escreve `dv_por_papel.csv`

**Contexto e unidades.** `quantidade_mil` é o estoque em **milhares de títulos**; `pu` e `dv_unitario` são em **reais por título**. Portanto:

- `financeiro_calculado_milhoes = pu * quantidade_mil / 1000`
- `dv_posicao_milhoes = dv_unitario * quantidade_mil / 1000`

Confira com uma conta de cabeça: uma LTN com PU de 800 e 100.000 mil títulos (cem milhões de papéis) dá 100.000 × 1000 × 800 = R$ 80 bilhões, ou seja 80.000 milhões — e `800 * 100000 / 1000 = 80.000`. Bate.

**A junção é pelo último dia útil do mês**, nos três lados. O estoque traz o último dia corrido e precisa ser mapeado.

**Papel com estoque mas sem taxa entra na tabela com os campos de preço vazios.** São 6% dos pares, quase todos LFT de 2010 e 2011. Omitir a linha esconderia posição; preencher com zero seria mentira.

- [ ] **Step 1: Escreva os testes que falham**

```python
# tests/test_dv.py
from datetime import date

import pandas as pd
import pytest
from tesouro import dv


@pytest.fixture(scope="module")
def p():
    return dv.painel()


def test_colunas_canonicas(p):
    assert list(p.columns) == [
        "data", "isin", "titulo", "vencimento", "taxa_pct", "vna", "pu",
        "dv_unitario", "quantidade_mil", "dv_posicao_milhoes",
        "financeiro_calculado_milhoes",
    ]


def test_cobre_o_escopo_e_so_ele(p):
    assert set(p["titulo"].unique()) == {"LTN", "NTN-F", "NTN-B", "LFT"}


def test_sem_chave_duplicada(p):
    assert not p.duplicated(subset=["data", "isin"]).any()


def test_datas_sao_ultimo_dia_util(p):
    from tesouro import calendario
    cal = calendario.padrao()
    assert all(cal.ultimo_dia_util_do_mes(d) == d for d in p["data"].unique())


def test_dv_da_lft_e_vazio_e_o_financeiro_nao(p):
    lft = p[(p["titulo"] == "LFT") & p["pu"].notna()]
    assert len(lft) > 1000
    assert lft["dv_unitario"].isna().all()
    assert lft["financeiro_calculado_milhoes"].notna().all()


def test_dv_dos_titulos_e_negativo(p):
    tit = p[p["titulo"].isin(["LTN", "NTN-F", "NTN-B"]) & p["dv_unitario"].notna()]
    assert (tit["dv_unitario"] < 0).all()
    assert (tit["dv_posicao_milhoes"] < 0).all()


def test_papel_sem_taxa_fica_com_preco_vazio_e_posicao_preenchida(p):
    sem = p[p["taxa_pct"].isna()]
    assert len(sem) > 0
    assert sem["pu"].isna().all()
    assert sem["quantidade_mil"].notna().all()


def test_ordem_de_grandeza_do_financeiro(p):
    # A DPMFi no ultimo mes esta na casa de trilhoes de reais.
    ult = p[p["data"] == p["data"].max()]
    total = ult["financeiro_calculado_milhoes"].sum() / 1e6
    assert 5 < total < 15


def test_dv_total_do_sistema_e_plausivel(p):
    # Somando os titulos, o DV do sistema fica na casa de bilhoes de reais
    # por bp -- negativo, pela convencao.
    ult = p[(p["data"] == p["data"].max()) & p["dv_posicao_milhoes"].notna()]
    total = ult["dv_posicao_milhoes"].sum()
    assert -20000 < total < -500
```

- [ ] **Step 2: Rode e confirme que falham**

Run: `PYTHONPATH=src python -m pytest tests/test_dv.py -v`
Expected: FAIL com `ModuleNotFoundError: No module named 'tesouro.dv'`

- [ ] **Step 3: Implemente o painel em `dv.py`**

```python
"""Painel de DV01 por papel, decay e calculo pontual.

O painel e persistido, e nao calculado sob demanda, porque as entregas 3
(analise de leiloes) e 5 (simulacao contra o PAF) vao consumi-lo. Tres
implementacoes independentes de DV que discordam entre si seria o pior
resultado possivel.

Unidades: quantidade_mil e o estoque em milhares de titulos; pu e
dv_unitario sao reais por titulo. Logo o financeiro e o DV da posicao,
em milhoes de reais, sao (valor por titulo) * quantidade_mil / 1000.
"""
import pandas as pd

from . import calendario, config, precificacao

TITULOS = ("LTN", "NTN-F", "NTN-B", "LFT")
_INDICE_DO_TITULO = {"NTN-B": "IPCA", "LFT": "SELIC"}

_COLUNAS = [
    "data", "isin", "titulo", "vencimento", "taxa_pct", "vna", "pu",
    "dv_unitario", "quantidade_mil", "dv_posicao_milhoes",
    "financeiro_calculado_milhoes",
]


def _ler(nome, **kw):
    caminho = config.PROCESSED_DIR / f"{nome}.csv"
    if not caminho.exists():
        raise FileNotFoundError(
            f"{caminho} nao existe. Rode a camada de dados e o parser da "
            f"Bloomberg antes: 'python -m tesouro.pipeline --sem-coleta'"
        )
    return pd.read_csv(caminho, **kw)


def _posicoes(cal):
    """Estoque do escopo, com a data ja no ultimo dia util do mes."""
    e = _ler("estoque_titulos_vencimento", parse_dates=["data", "vencimento"])
    e = e[(e["quantidade_mil"].fillna(0) > 0) & e["titulo"].isin(TITULOS)].copy()
    e["data"] = e["data"].dt.date.map(cal.ultimo_dia_util_do_mes)
    e["vencimento"] = e["vencimento"].dt.date
    return e[["data", "isin", "titulo", "vencimento", "quantidade_mil"]]


def _com_precos(cal):
    """Junta posicao, taxa e VNA, e calcula PU e DV linha a linha."""
    pos = _posicoes(cal)
    tx = _ler("taxa_por_papel", parse_dates=["data"])
    tx["data"] = tx["data"].dt.date
    vn = _ler("vna", parse_dates=["data"])
    vn["data"] = vn["data"].dt.date
    vna_por = {(r.data, r.indice): r.vna for r in vn.itertuples(index=False)}

    df = pos.merge(tx[["data", "isin", "taxa_pct"]], on=["data", "isin"], how="left")
    df["vna"] = [
        vna_por.get((d, _INDICE_DO_TITULO[t])) if t in _INDICE_DO_TITULO else None
        for d, t in zip(df["data"], df["titulo"])
    ]

    pus, dvs = [], []
    for r in df.itertuples(index=False):
        precisa_vna = r.titulo in _INDICE_DO_TITULO
        if pd.isna(r.taxa_pct) or (precisa_vna and r.vna is None):
            pus.append(None)
            dvs.append(None)
            continue
        taxa = r.taxa_pct / 100.0
        pus.append(precificacao.pu(cal, r.titulo, r.data, r.vencimento, taxa, r.vna))
        dvs.append(precificacao.dv(cal, r.titulo, r.data, r.vencimento, taxa, r.vna))
    df["pu"] = pus
    df["dv_unitario"] = dvs
    return df


def painel():
    """Uma linha por papel e fim de mes, com insumos e resultado."""
    cal = calendario.padrao()
    df = _com_precos(cal)
    df["financeiro_calculado_milhoes"] = df["pu"] * df["quantidade_mil"] / 1000
    df["dv_posicao_milhoes"] = df["dv_unitario"] * df["quantidade_mil"] / 1000
    return df[_COLUNAS].sort_values(["data", "titulo", "vencimento"]).reset_index(drop=True)


def gravar_painel():
    config.PROCESSED_DIR.mkdir(parents=True, exist_ok=True)
    df = painel()
    saida = config.PROCESSED_DIR / "dv_por_papel.csv"
    df.to_csv(saida, index=False, encoding="utf-8")
    print(f"gravado: {saida} ({len(df)} linhas)")
```

- [ ] **Step 4: Rode os testes e confirme que passam**

Run: `PYTHONPATH=src python -m pytest tests/test_dv.py -v`
Expected: PASS, 9 testes

- [ ] **Step 5: Grave e meça o tempo**

Run: `PYTHONPATH=src python -c "import time,sys; sys.path.insert(0,'src'); t=time.perf_counter(); from tesouro import dv; dv.gravar_painel(); print(f'{time.perf_counter()-t:.1f}s')"`

Expected: grava `dv_por_papel.csv` em menos de dois minutos. **Se passar disso, pare e relate** — a otimização do calendário deveria ter tornado isto rápido, e um tempo alto indica que algo está recalculando à toa.

- [ ] **Step 6: Commit**

```bash
git add src/tesouro/dv.py tests/test_dv.py
git commit -m "Adiciona painel de DV01 por papel"
```

---


### Task 4: Coletor da Bloomberg

**Files:**
- Create: `src/tesouro/fetch_bloomberg.py`
- Test: `tests/test_fetch_bloomberg.py`

**Interfaces:**
- Consumes: `config.BLOOMBERG_DIR`, `calendario.padrao()`
- Produces:
  - `fetch_bloomberg.papeis_do_estoque() -> DataFrame` — colunas `isin, titulo, vencimento, primeira, ultima`
  - `fetch_bloomberg.datas_do_painel() -> list[date]`
  - `fetch_bloomberg.baixar(destino=None) -> tuple[Path, Path, Path]`

**Contexto:** este é o único módulo que pode importar `blpapi`, e o import fica **dentro** da função, não no topo — assim o resto do projeto roda em máquina sem Bloomberg. O contrato de dados está em `docs/convencoes-dv.md`; os pontos que o código precisa respeitar:

- taxa por `YLD_YTM_MID` em `/isin/<ISIN>@ANDE Govt`, **série histórica** mensal;
- preço por `PX_DIRTY_MID`, mesma forma — serve **só** como referência para o teste de coerência, não entra em nenhum cálculo;
- VNA por campo `IDX_RATIO` (NTN-B) e `ACCUMULATED_SELIC` (LFT), com **override `SETTLE_DT`**, multiplicado por 1000;
- **nunca** use `SETTLE_DT` para obter taxa histórica: ele muda a liquidação, não a data do mercado, e devolve a taxa de hoje.

Os testes não tocam a rede: exercitam a seleção de papéis e datas, que é onde mora a lógica.

- [ ] **Step 1: Escreva os testes que falham**

```python
# tests/test_fetch_bloomberg.py
from datetime import date

import pytest
from tesouro import fetch_bloomberg


def test_papeis_cobrem_apenas_o_escopo():
    p = fetch_bloomberg.papeis_do_estoque()
    assert set(p["titulo"].unique()) == {"LTN", "NTN-F", "NTN-B", "LFT"}
    assert len(p) > 150
    assert p["isin"].notna().all()


def test_papeis_trazem_a_janela_de_vida():
    p = fetch_bloomberg.papeis_do_estoque()
    assert (p["primeira"] <= p["ultima"]).all()


def test_datas_do_painel_sao_dia_util_e_fim_de_mes():
    from tesouro import calendario
    cal = calendario.padrao()
    d = fetch_bloomberg.datas_do_painel()
    assert len(d) > 190
    assert all(cal.eh_dia_util(x) for x in d)
    assert all(cal.ultimo_dia_util_do_mes(x) == x for x in d)
    assert d == sorted(d)


def test_nao_importa_blpapi_no_topo():
    # O modulo tem de importar em maquina sem Bloomberg. O import fica
    # dentro da funcao que faz a coleta.
    import ast
    import pathlib
    fonte = pathlib.Path("src/tesouro/fetch_bloomberg.py").read_text(encoding="utf-8")
    arvore = ast.parse(fonte)
    for no in arvore.body:                      # so o nivel de modulo
        if isinstance(no, (ast.Import, ast.ImportFrom)):
            nomes = [a.name for a in no.names] + [getattr(no, "module", "") or ""]
            assert not any("blpapi" in n for n in nomes)
```

- [ ] **Step 2: Rode e confirme que falham**

Run: `PYTHONPATH=src python -m pytest tests/test_fetch_bloomberg.py -v`
Expected: FAIL com `ModuleNotFoundError: No module named 'tesouro.fetch_bloomberg'`

- [ ] **Step 3: Implemente o `fetch_bloomberg.py`**

```python
"""Coleta taxa e VNA na Bloomberg.

Unico modulo do projeto que fala com o terminal, e o import de blpapi fica
DENTRO da funcao de coleta: assim o resto roda em maquina sem Bloomberg,
que e o cenario do ambiente de destino.

Contrato de dados em docs/convencoes-dv.md. Dois pontos que o codigo
respeita e que nao sao obvios:

  A fonte @ANDE e obrigatoria no identificador do papel. Sem ela a taxa
  vem de outra origem; na ponta curta a diferenca chega a alguns bp.

  SETTLE_DT muda a data de LIQUIDACAO, nao a data do mercado. Serve para o
  VNA, que e funcao deterministica da data. NAO serve para taxa: usa-lo
  ali devolve a taxa de hoje liquidando na data pedida, o que no fim de
  2024 da 135 bp de erro.

A coleta e incremental: cada execucao grava um arquivo novo, nomeado pelo
periodo coberto, e nada e sobrescrito.
"""
import csv
from pathlib import Path

import pandas as pd

from . import calendario, config

TITULOS = ("LTN", "NTN-F", "NTN-B", "LFT")
CAMPO_TAXA = "YLD_YTM_MID"
# O preco nao entra em calculo nenhum: serve de referencia independente
# para o teste de coerencia. Ver docs/convencoes-dv.md sobre o D+1.
CAMPO_PRECO = "PX_DIRTY_MID"
CAMPO_VNA = {"NTN-B": ("IDX_RATIO", "IPCA"), "LFT": ("ACCUMULATED_SELIC", "SELIC")}
_HOST, _PORTA = "localhost", 8194


def _estoque():
    caminho = config.PROCESSED_DIR / "estoque_titulos_vencimento.csv"
    if not caminho.exists():
        raise FileNotFoundError(
            f"{caminho} nao existe; rode a camada de dados antes "
            f"('python -m tesouro.pipeline --sem-coleta')"
        )
    df = pd.read_csv(caminho, parse_dates=["data", "vencimento"])
    return df[df["quantidade_mil"].fillna(0) > 0]


def papeis_do_estoque():
    """Papeis do escopo, com a janela em que tiveram estoque."""
    e = _estoque()
    e = e[e["titulo"].isin(TITULOS)]
    p = (e.groupby(["isin", "titulo", "vencimento"])["data"]
           .agg(primeira="min", ultima="max").reset_index())
    p["vencimento"] = p["vencimento"].dt.date
    p["primeira"] = p["primeira"].dt.date
    p["ultima"] = p["ultima"].dt.date
    return p.sort_values(["titulo", "vencimento"]).reset_index(drop=True)


def datas_do_painel():
    """Os fins de mes do estoque, mapeados para o ultimo dia util."""
    cal = calendario.padrao()
    e = _estoque()
    return sorted({cal.ultimo_dia_util_do_mes(d) for d in e["data"].dt.date})


def _sessao():
    import blpapi
    opcoes = blpapi.SessionOptions()
    opcoes.setServerHost(_HOST)
    opcoes.setServerPort(_PORTA)
    sessao = blpapi.Session(opcoes)
    if not sessao.start() or not sessao.openService("//blp/refdata"):
        raise ConnectionError(
            "nao foi possivel falar com o terminal Bloomberg. Confira se ele "
            "esta aberto e logado nesta maquina. Sem terminal, exporte por "
            "BDH e coloque o CSV em data/raw/bloomberg/ (docs/como-baixar.md)"
        )
    return blpapi, sessao


def _historico(blpapi, sessao, servico, isin, campo, inicio, fim):
    req = servico.createRequest("HistoricalDataRequest")
    req.getElement("securities").appendValue(f"/isin/{isin}@ANDE Govt")
    req.getElement("fields").appendValue(campo)
    req.set("startDate", inicio.strftime("%Y%m%d"))
    req.set("endDate", fim.strftime("%Y%m%d"))
    req.set("periodicitySelection", "MONTHLY")
    sessao.sendRequest(req)
    pontos = []
    while True:
        evento = sessao.nextEvent(30000)
        for msg in evento:
            if not msg.hasElement("securityData"):
                continue
            dados = msg.getElement("securityData")
            if dados.hasElement("securityError"):
                return []
            campos = dados.getElement("fieldData")
            for i in range(campos.numValues()):
                ponto = campos.getValue(i)
                if ponto.hasElement(campo):
                    pontos.append((
                        pd.Timestamp(ponto.getElementAsDatetime("date")).date(),
                        ponto.getElementAsFloat(campo),
                    ))
        if evento.eventType() == blpapi.Event.RESPONSE:
            return pontos


def _referencia(blpapi, sessao, servico, isins, campo, settle):
    """Valor do campo com override de SETTLE_DT, para varios papeis."""
    req = servico.createRequest("ReferenceDataRequest")
    for isin in isins:
        req.getElement("securities").appendValue(f"/isin/{isin}@ANDE Govt")
    req.getElement("fields").appendValue(campo)
    override = req.getElement("overrides").appendElement()
    override.setElement("fieldId", "SETTLE_DT")
    override.setElement("value", settle.strftime("%Y%m%d"))
    sessao.sendRequest(req)
    valores = []
    while True:
        evento = sessao.nextEvent(30000)
        for msg in evento:
            if not msg.hasElement("securityData"):
                continue
            todos = msg.getElement("securityData")
            for i in range(todos.numValues()):
                dados = todos.getValue(i)
                if dados.hasElement("securityError"):
                    continue
                campos = dados.getElement("fieldData")
                if campos.hasElement(campo):
                    valores.append(campos.getElementAsFloat(campo))
        if evento.eventType() == blpapi.Event.RESPONSE:
            return valores


def baixar(destino=None):
    """Puxa taxa e VNA e grava dois CSVs. Devolve os dois caminhos."""
    destino = Path(destino) if destino else config.BLOOMBERG_DIR
    destino.mkdir(parents=True, exist_ok=True)
    blpapi, sessao = _sessao()
    servico = sessao.getService("//blp/refdata")
    try:
        papeis = papeis_do_estoque()
        datas = datas_do_painel()
        marca = f"{datas[0]:%Y-%m}_{datas[-1]:%Y-%m}"

        alvo_taxa = destino / f"bbg_taxas_ANDE_{marca}.csv"
        with open(alvo_taxa, "w", newline="", encoding="utf-8") as fh:
            escritor = csv.writer(fh)
            escritor.writerow(["isin", "titulo", "vencimento", "data", "yld_ytm_mid"])
            for p in papeis.itertuples(index=False):
                for data, valor in _historico(blpapi, sessao, servico, p.isin,
                                              CAMPO_TAXA, p.primeira, p.ultima):
                    escritor.writerow([p.isin, p.titulo, p.vencimento, data, valor])
        print(f"gravado: {alvo_taxa}")

        e = _estoque()
        alvo_vna = destino / f"bbg_vna_{marca}.csv"
        with open(alvo_vna, "w", newline="", encoding="utf-8") as fh:
            escritor = csv.writer(fh)
            escritor.writerow(["data", "indice", "campo", "fator", "vna",
                               "n_papeis", "divergencia"])
            for data in datas:
                mes = (data.year, data.month)
                for titulo, (campo, indice) in CAMPO_VNA.items():
                    vivos = e[(e["titulo"] == titulo)
                              & (e["data"].dt.year == mes[0])
                              & (e["data"].dt.month == mes[1])]["isin"].head(3).tolist()
                    if not vivos:
                        continue
                    valores = _referencia(blpapi, sessao, servico, vivos, campo, data)
                    if not valores:
                        continue
                    escritor.writerow([data, indice, campo, f"{valores[0]:.9f}",
                                       f"{valores[0] * 1000:.6f}", len(valores),
                                       f"{max(valores) - min(valores):.9f}"])
        print(f"gravado: {alvo_vna}")

        alvo_preco = destino / f"bbg_precos_ANDE_{marca}.csv"
        with open(alvo_preco, "w", newline="", encoding="utf-8") as fh:
            escritor = csv.writer(fh)
            escritor.writerow(["isin", "titulo", "data", "px_dirty_mid"])
            for p in papeis.itertuples(index=False):
                for data, valor in _historico(blpapi, sessao, servico, p.isin,
                                              CAMPO_PRECO, p.primeira, p.ultima):
                    escritor.writerow([p.isin, p.titulo, data, valor])
        print(f"gravado: {alvo_preco}")

        return alvo_taxa, alvo_vna, alvo_preco
    finally:
        sessao.stop()


if __name__ == "__main__":
    baixar()
```

- [ ] **Step 4: Rode os testes e confirme que passam**

Run: `PYTHONPATH=src python -m pytest tests/test_fetch_bloomberg.py -v`
Expected: PASS, 4 testes

- [ ] **Step 5: Verifique contra o terminal, se houver**

Run: `PYTHONPATH=src python -m tesouro.fetch_bloomberg`

Se o terminal estiver aberto e logado, isto grava dois arquivos novos em `data/raw/bloomberg/` e leva alguns minutos. Compare a taxa de alguns papéis com o arquivo que já existe: têm de bater.

Se o terminal **não** estiver disponível, o comando deve falhar com a mensagem de `ConnectionError` explicando o que fazer — confirme que a mensagem aparece e **registre no relatório que esta verificação ficou pendente**. Os testes automáticos não dependem dela.

- [ ] **Step 6: Commit**

```bash
git add src/tesouro/fetch_bloomberg.py tests/test_fetch_bloomberg.py
git commit -m "Adiciona coletor de taxa e VNA na Bloomberg"
```

---


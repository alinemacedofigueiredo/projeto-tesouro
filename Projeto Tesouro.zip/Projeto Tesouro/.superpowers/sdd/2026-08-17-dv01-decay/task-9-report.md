# Tarefa 9: Figuras -- relatorio

## O que foi feito

`src/tesouro/figuras.py` (novo) com tres funcoes publicas, conforme o brief:

- `grafico_dv_do_sistema(caminho=None) -> Path`
- `grafico_pontual(resumo, caminho) -> Path`
- `gravar_todas() -> None`

Mais quatro funcoes privadas extraidas para permitir testes que verificam os
dados plotados, nao so a existencia do arquivo: `_serie_por_titulo`,
`_figura_do_sistema`, `_figura_pontual`, `_texto_cobertura`/`_nota_cobertura`.

`tests/test_figuras.py` (novo), 7 testes na entrega original (correcao no
relatorio: a primeira versao deste texto dizia "8 testes" por engano; ver a
secao "Revisao (rodada 2)" abaixo para a contagem final, 8, apos a segunda
rodada).

## As duas figuras

### 1. `grafico_dv_do_sistema` -- DV01 do sistema por tipo de papel, 2010-2026

**Fonte:** `dv.painel()` (9.366 linhas). **Conta:** nem A, nem B. Cada ponto
usa a taxa e o VNA observados NAQUELA data -- nao e resultado em dinheiro
(nao e Conta A, que exige as duas pontas) e nao e uma projecao de decay a
taxa parada (nao e Conta B). O titulo do grafico e o texto do modulo deixam
isso explicito, porque nenhuma das duas contas descreve corretamente esse
grafico e um rotulo errado convidaria a leitura errada.

**Cobertura:** nota de rodape calculada por `dv._cobertura(cal, ultima_data)`
na data real da ultima observacao da serie (30/06/2026 no dado atual), nunca
uma constante -- o mesmo padrao que corrigiu o achado da Tarefa 7 (46,6%
impresso para qualquer data ficava 14 pontos errado em 2020-12-31, onde a
cobertura de verdade e 60,4%). O teste
`test_nota_de_cobertura_usa_a_data_pedida_e_nao_uma_constante` confere as
duas datas contra numeros diferentes para provar que a nota recalcula.

**Convencao de sinal (escolha documentada no docstring do modulo):** as
linhas ficam com o sinal verdadeiro (negativo), do jeito que aparece nas
tabelas e nos CSVs -- nao plotamos o modulo. Duas razoes: (1) e o mesmo
numero que a usuaria vai conferir ao lado do grafico; inverter so no desenho
criaria uma figura que nao bate com a planilha; (2) o grafico pontual e uma
decomposicao ADITIVA (`dv_base + dv_que_vence + decay_sobreviventes =
dv_alvo`) que so fecha com o sinal verdadeiro -- usar modulo num grafico e
sinal verdadeiro no outro seria pior do que a inconsistencia que se tenta
evitar. Como consequencia, uma linha que DESCE representa MAIS risco, o
oposto da leitura intuitiva -- por isso ha uma nota de rodape explicita
lembrando a convencao em vez de confiar que quem olha vai lembrar sozinho.

**O que os dados contam:** o DV total do sistema (magnitude, ja que e
negativo) cresceu de forma acentuada entre 2010 e 2026 -- de cerca de
R$ -270 milhoes/bp no inicio da serie para R$ -1.472,87 milhoes/bp em
30/06/2026, um aumento de mais de 5 vezes. A NTN-B e quem puxa a maior parte
desse crescimento (de cerca de -200 para -1.096,58, tambem ~5,5x), enquanto
LTN e NTN-F partem de perto de zero em 2010 e chegam a -198,54 e -177,76
respectivamente -- crescimento proporcionalmente maior, mas de base bem
menor. A serie nao e monotona: ha quedas visiveis por volta de 2013-2014,
2019-2020 (LTN/NTN-F) e 2023, e picos locais em 2020-2021 e 2024-2025, o que
e coerente com o DV depender tanto do tamanho do estoque quanto da duration
media de cada carteira em cada data -- este grafico nao decompoe as duas
causas, so mostra o efeito combinado.

### 2. `grafico_pontual` -- decomposicao da queda de DV ate uma data-alvo

**Fonte:** o dicionario devolvido por `dv.pontual()`. **Conta:** B, decay a
taxa constante -- taxa e VNA congelados na data-base, sem dinheiro e sem VNA
reprojetado (mesma nota que a docstring de `dv.pontual()` ja documenta). O
titulo do grafico nomeia "Conta B" explicitamente.

Quatro barras aditivas: DV na base (negativo) + vence (positivo, some com o
papel) + decay dos sobreviventes (positivo, encurtamento) = DV no alvo
(menos negativo que a base). Testado com `dv.pontual(date(2026, 12, 31))`
contra os ancoras do brief: base -1.472,872661, vence +5,248806, decay
+86,540294, alvo -1.381,083561 -- `test_figura_pontual_plota_as_quatro_
barras_com_o_valor_do_resumo` confere os quatro valores plotados (nao so o
dict de entrada) com tolerancia de 1e-5, e o teste de gravacao usa
`dv.pontual(date(2027, 12, 31))`, como no brief.

**Cobertura:** reusa `resumo["cobertura"]`, que `dv.pontual()` ja calculou
para a mesma data-base via `dv._cobertura` -- nao recalcula (ver
autorrevisao abaixo).

## Testes

`tests/test_figuras.py`, 7 testes na entrega original, todos verificando
dados e nao so arquivo:

1. `test_usa_backend_sem_janela` -- confirma Agg (do brief).
2. `test_serie_por_titulo_bate_com_as_ancoras_de_30_06_2026` -- a serie que
   alimenta o grafico do sistema contra os quatro ancoras do brief
   (LTN, NTN-F, NTN-B, total), independentes do codigo sob teste.
3. `test_figura_do_sistema_plota_ltn_ntnf_ntnb_e_total_com_valor_certo` --
   inspeciona `eixo.lines` (rotulos e `get_ydata()[-1]`) da figura antes de
   salvar/fechar, contra os mesmos ancoras; confere tambem que a unidade
   ("R$ milhoes por bp") e a nota de conta aparecem no proprio grafico.
4. `test_grafico_do_sistema_grava_arquivo` -- do brief (arquivo existe e
   `> 10000` bytes), com `tmp_path`.
5. `test_figura_pontual_plota_as_quatro_barras_com_o_valor_do_resumo` --
   inspeciona `eixo.patches` (altura de cada barra) contra os ancoras de
   `dv.pontual(date(2026, 12, 31))`, tolerancia 1e-5 (nao banda larga).
6. `test_grafico_pontual_grava_arquivo` -- do brief, com `tmp_path`.
7. `test_nota_de_cobertura_usa_a_data_pedida_e_nao_uma_constante` -- compara
   a nota de 30/06/2026 (46,5%) com a de 31/12/2020 (60,4%), provando que
   recalcula por data em vez de repetir uma constante.

Nenhum teste grava fora de `tmp_path`; nenhum `.png` ficou no repositorio
(`data/**` ja esta no `.gitignore`, e `find data/processed -iname "*.png"`
voltou vazio apos rodar tudo).

## Resultado dos testes (entrega original)

`PYTHONPATH=src python -m pytest -q`: **279 passed** (272 anteriores + 7
novos). Sem regressao. Ver "Revisao (rodada 2)" abaixo para o resultado
apos as tres correcoes pedidas -- **280 passed** (mais um teste novo).

`PYTHONPATH=src python -m tesouro.dv --alvo 31/12/2026 --figura <caminho>`:
saida com o quadro pontual de sempre mais a linha `figura: <caminho>`,
**exit code 0** confirmado explicitamente com `$?` apos a chamada.

## Figuras geradas (fora do repositorio)

Geradas com o codigo de verdade (nao mockado) e salvas em:

- `C:\Users\lineb\AppData\Local\Temp\claude\C--Users-lineb-OneDrive-Desktop-Projeto-Tesouro\31fb1141-9841-4b3f-9f07-565a2dab5b0a\scratchpad\figuras\dv_do_sistema.png`
- `C:\Users\lineb\AppData\Local\Temp\claude\C--Users-lineb-OneDrive-Desktop-Projeto-Tesouro\31fb1141-9841-4b3f-9f07-565a2dab5b0a\scratchpad\figuras\pontual.png` (data-alvo padrao: base + 1 ano, 30/06/2027)
- `C:\Users\lineb\AppData\Local\Temp\claude\C--Users-lineb-OneDrive-Desktop-Projeto-Tesouro\31fb1141-9841-4b3f-9f07-565a2dab5b0a\scratchpad\figuras\pontual_dez2026.png` (data-alvo 31/12/2026, o exemplo do brief)

## Autorrevisao

Ao reler o codigo apos os testes passarem, encontrei uma duplicacao: a nota
de cobertura de `grafico_pontual` chamava `dv._cobertura(cal, data_base)`
de novo, apesar de `resumo["cobertura"]` (vindo de `dv.pontual()`) ja ser o
mesmo dict, para a mesma data-base. Corrigi extraindo `_texto_cobertura
(cobertura, data)` de `_nota_cobertura`, e `grafico_pontual` passou a reusar
`resumo["cobertura"]` em vez de reler o CSV de estoque uma segunda vez.
Confirmei que a saida nao mudou (arquivos identicos byte a byte na
regeracao, mesmo tamanho antes e depois) e que os 279 testes continuam
passando. Commit separado (`f003c3f`), para nao amassar o commit original
da tarefa.

Nenhum outro achado na autorrevisao: sinal, unidades, cobertura por data,
rotulo de conta e ASCII foram conferidos linha a linha contra os requisitos
do brief e da tarefa.

## Preocupacoes

- O grafico do sistema mostra o efeito combinado de tamanho de estoque e
  duration; nao decompoe as duas causas do crescimento do DV. Se a mesa
  quiser essa decomposicao, e um grafico novo, fora do escopo desta tarefa.
- `gravar_todas()` hoje grava as duas figuras (sistema + pontual, com a
  data-alvo padrao de `dv.pontual()`); o brief original so pedia a figura
  do sistema em `gravar_todas()`, mas como a Tarefa 9 tambem exige
  `grafico_pontual` como entregavel, incluir as duas em `gravar_todas()`
  parece o comportamento mais util para quem roda `python -m
  tesouro.figuras` sem argumento. Se a Aline preferir so a primeira figura
  ai, e uma linha para remover.

## Revisao (rodada 2): as tres correcoes

A revisao aprovou a conformidade e a decisao do `gravar_todas()`, e pediu
tres correcoes. As tres foram feitas no mesmo arquivo `src/tesouro/figuras.py`
e em `tests/test_figuras.py`, sem tocar em `dv.py` nem em `precificacao.py`.

### 1 (Critical) -- acentuacao

Todo texto que aparece DENTRO das figuras (titulos, eixos, legendas, nota de
rodape) e a docstring do modulo passaram a usar acento correto, via escape
Unicode em literal de string (`"\u00e3o"`, `"\u00e9"`, etc.) -- o arquivo
`.py` continua ASCII puro byte a byte (confirmado programaticamente: 0
caracteres com `ord(c) > 127` em `figuras.py` e em `test_figuras.py`), e o
Python decodifica o escape para o caractere acentuado em tempo de execucao,
que o matplotlib desenha normalmente com a fonte padrao (DejaVu Sans, cobre
Latin-1 Supplement) -- confirmado olhando as tres figuras regeradas, sem
quadradinho em nenhum acento ("serie", "mes", "nao e", "projecao",
"milhoes", "ate", "construcao", "secundario" etc. saem todos acentuados).

Os testes tambem precisaram de ajuste: as assercoes que comparavam contra
`"R$ milhoes por bp"` (sem acento) passaram a comparar contra o texto
acentuado (`"milh\u00f5es por bp"`), tambem via escape, senao o teste
falharia contra o rotulo certo.

### 2 (Critical) -- cascata no grafico pontual

`_figura_pontual` foi reescrita para desenhar uma cascata (bridge chart) em
vez de quatro barras soltas partindo do zero. "DV na base" e "DV no alvo"
continuam barras totais (do zero); "vence" e "decay" agora flutuam, cada
uma comecando exatamente onde a anterior termina (`bottom=` do
`eixo.bar()`), com um conector pontilhado entre elas para reforcar o olho.
`b.get_height()` de cada barra continua sendo o delta (`valores`), nao o
topo acumulado -- so o `bottom` (`b.get_y()`) mudou -- entao o teste
original de altura das barras (`test_figura_pontual_plota_as_quatro_
barras_com_o_valor_do_resumo`) nao precisou mudar a asserção de altura, so
ganhou a checagem de unidade acentuada.

Teste novo, `test_figura_pontual_e_uma_cascata_nao_quatro_barras_do_zero`:
confere que as duas barras de total tem `get_y() == 0` e que as duas do
meio NAO tem `get_y() == 0` (ou seja, flutuam), com os "pes" esperados
calculados a partir dos proprios `valores` do resumo (ja conferidos contra
os ancoras do brief no teste vizinho), nao de uma constante interna ao
codigo sob teste.

Nas figuras regeradas, o efeito e visivel: no exemplo de
30/06/2026 -> 31/12/2026, a barra "decay" (+86,5) flutua claramente entre
"vence" e "DV no alvo"; a barra "vence" (+5,2) e proporcionalmente pequena
demais para ter altura visivel no desenho (e ~280x menor que o eixo
inteiro), mas sua posicao (comecando exatamente onde "DV na base" termina)
e o rotulo numerico deixam o valor legivel -- isso e inerente a cascata
quando um termo e genuinamente muito pequeno, nao um defeito da
implementacao; no exemplo com data-alvo padrao (30/06/2027), onde "vence"
vale +27,6, a barra ja fica visivel a olho nu.

### 3 (Important) -- teste com "or" fraco

A asserção antiga em `test_figura_do_sistema_plota_ltn_ntnf_ntnb_e_total_
com_valor_certo`:

```python
assert "resultado em dinheiro" in textos or "nao e resultado em dinheiro" in eixo.get_title()
```

tinha a segunda clausula do `or` sempre verdadeira (o titulo sempre contem
essa frase), entao a asserção nunca forcava `fig.texts` (a nota de
cobertura) a existir de fato. Troquei por uma asserção direta, com o texto
exato de cobertura da data de verdade:

```python
textos = " ".join(t.get_text() for t in fig.texts)
assert "DV01 cobre 46,5% do estoque em 30/06/2026" in textos
```

feita nas DUAS figuras (a mesma fraqueza existia -- por omissao, nao por
`or` -- em `test_figura_pontual_plota_as_quatro_barras_com_o_valor_do_
resumo`, que nao checava `fig.texts` nenhuma vez).

**Verificacao a mao pedida pela revisao:** removi temporariamente a
chamada de `_nota_cobertura`/`_texto_cobertura` do `fig.text()` das duas
figuras (troquei `f"{texto_cobertura} {_NOTA_SINAL}"` por
`f"{_NOTA_SINAL}"`), rodei `pytest tests/test_figuras.py -v`, e os dois
testes de figura quebraram exatamente como esperado
(`AssertionError: assert 'DV01 cobre 46,5%...' in 'Negativo = mercado...'`).
Restaurei o arquivo (`figuras.py` original, verificado byte a byte contra
a copia de backup) e a suite voltou a ficar toda verde. Este e o quinto
caso do padrao "teste que afirma existencia em vez de intencao" nesta
branch -- a mutacao a mao (nao so a leitura do assert) e o que separa este
teste dos quatro anteriores.

### Resultado dos testes (rodada 2)

`PYTHONPATH=src python -m pytest -q`: **280 passed** (279 da entrega
original + 1 teste novo da cascata). Sem regressao.
`tests/test_figuras.py` sozinho: 8 testes, todos verdes.

CLI: `PYTHONPATH=src python -m tesouro.dv --alvo 31/12/2026 --figura
<caminho>` -- **exit code 0** confirmado de novo apos as mudancas; nenhum
`.png` ficou em `data/processed/` (`find data/processed -iname "*.png"`
vazio apos rodar suite + CLI).

### Figuras regeradas (rodada 2)

Mesmos caminhos de antes, sobrescritas com o codigo corrigido:

- `C:\Users\lineb\AppData\Local\Temp\claude\C--Users-lineb-OneDrive-Desktop-Projeto-Tesouro\31fb1141-9841-4b3f-9f07-565a2dab5b0a\scratchpad\figuras\dv_do_sistema.png`
- `C:\Users\lineb\AppData\Local\Temp\claude\C--Users-lineb-OneDrive-Desktop-Projeto-Tesouro\31fb1141-9841-4b3f-9f07-565a2dab5b0a\scratchpad\figuras\pontual.png` (data-alvo padrao: base + 1 ano, 30/06/2027 -- "vence" +27,6 ja visivel na cascata)
- `C:\Users\lineb\AppData\Local\Temp\claude\C--Users-lineb-OneDrive-Desktop-Projeto-Tesouro\31fb1141-9841-4b3f-9f07-565a2dab5b0a\scratchpad\figuras\pontual_dez2026.png` (data-alvo 31/12/2026, o exemplo do brief -- "vence" +5,2 e uma lasca fina na cascata, valor so legivel pelo rotulo)

### Novo commit

`cf511e9` -- "Corrige achados da revisao das figuras (Tarefa 9, rodada 2)".

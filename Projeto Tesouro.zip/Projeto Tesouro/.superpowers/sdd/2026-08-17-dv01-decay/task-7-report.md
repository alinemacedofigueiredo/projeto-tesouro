### Task 7: Calculo pontual ate uma data-alvo -- relatorio

**Status:** concluida.

**Commit:** ver hash no final deste relatorio -- "Adiciona calculo pontual
de decay ate uma data-alvo" (branch `dv01-decay`). Arquivos:
`src/tesouro/dv.py`, `tests/test_decay.py`.

**Testes:** `26 passed` em `tests/test_decay.py` (14 anteriores + 5 do
brief + 7 adicionais da autorrevisao); suite inteira `248 passed` (236
anteriores + 12 novos), nenhuma regressao.

**Preocupacoes:** nenhuma bloqueante. Duas decisoes de design que vao
alem do brief, ambas exigidas pelo pedido do dispatch e explicadas
abaixo: `--alvo` deixou de ser obrigatorio, e um `ValueError` cru de
`calendario.Calendario` foi impedido de vazar no traceback.

---

#### Interface entregue

- `dv.pontual(data_alvo=None, data_base=None) -> dict` com as chaves do
  brief (`data_base`, `data_alvo`, `dv_base`, `dv_que_vence`,
  `decay_sobreviventes`, `dv_alvo`, `por_titulo`) mais `alvo_padrao`
  (bool) -- ver secao "Sem --alvo" abaixo.
- `dv._num_br(x, casas=2, forcar_sinal=False) -> str` -- formata em
  portugues (ponto de milhar, virgula decimal).
- `dv._formatar(r) -> str` -- monta o quadro impresso.
- `dv.main(argumentos=None)` -- comando de linha; `python -m tesouro.dv`
  agora chama `main()` (antes chamava `gravar_painel()`; nada mais no
  projeto invocava `python -m tesouro.dv`, confirmado por busca).

`_decay_de` **nao foi reescrita** -- `pontual()` chama exatamente a mesma
funcao que `decay()` usa para os horizontes fixos, so trocando a
data-alvo por uma escolhida na hora. `precificacao.py` **nao foi tocado**
(`git diff --stat src/tesouro/precificacao.py` vazio).

---

#### O comando de verdade

```
$ PYTHONPATH=src python -m tesouro.dv --alvo 31/12/2026

posicao em 30/06/2026, projetada para 31/12/2026

  DV na data-base                      -1.472,87
  (-) DV que vence no caminho               +5,25
  (-) decay dos sobreviventes              +86,54
  DV na data-alvo                       -1.381,08

valores em R$ milhoes por bp; negativo = mercado perde na alta de taxa. 'DV que vence' e 'decay' aparecem com sinal positivo porque somam ao DV base, que e negativo -- o efeito de ambos e deixar o DV menos negativo.

cobertura do DV01: 46,6% do estoque (LTN 14,4% + NTN-F 7,5% + NTN-B 24,7%)
fora do DV01: LFT 51,3% (sem duration de juros por construcao) + 2,1% excluidos sem preco no secundario

titulo dv_base_milhoes dv_alvo_milhoes  papeis  vencendo_no_caminho
   LTN         -198,54         -165,06      14                    2
 NTN-B       -1.096,58       -1.054,07      15                    1
 NTN-F         -177,76         -161,96       6                    0
```

Conferencia da identidade a mao: -1.472,87 + 5,25 + 86,54 = -1.381,08 =
`dv_alvo` impresso. `dv_base` do painel bate com a ancora de
`docs/convencoes-dv.md` (LTN -198,54, NTN-F -177,76, NTN-B -1.096,58,
total -1.472,87).

---

#### Casos de erro e de omissao

**1. Formato de data invalido** (ex.: ISO em vez de brasileiro):

```
$ python -m tesouro.dv --alvo 2026-12-31
'2026-12-31' nao e uma data valida para --alvo. Use o formato DD/MM/AAAA
(dia/mes/ano com 4 digitos), por exemplo 31/12/2026.
[exit 1, sem traceback]
```

`main()` faz o `datetime.strptime` dentro de um `try/except` proprio e
levanta `SystemExit` com a mensagem -- nunca deixa o `ValueError` do
`strptime` estourar cru.

**2. Data-alvo anterior a data-base:**

```
$ python -m tesouro.dv --alvo 31/12/2010
a data-alvo (31/12/2010) precisa ser posterior a data-base (30/06/2026)
[exit 1, sem traceback]
```

Verificado tambem pelo teste do brief (`test_pontual_recusa_data_no_passado`,
`match="posterior"`).

**3. Data fora da janela do calendario (2001-2099):**

```
$ python -m tesouro.dv --alvo 01/01/2100
a data-alvo (01/01/2100) esta fora do calendario de dias uteis, que cobre
01/01/2001 a 31/12/2099. Escolha uma data-alvo dentro desse intervalo.
[exit 1, sem traceback]
```

Isso exigiu um cuidado que so apareceu na autorrevisao: `_validar_no_
calendario` chama `cal.eh_dia_util(d)` so para disparar o `ValueError`
interno de `Calendario._verificar_janela` e troca a mensagem. Sem
`raise ... from None`, o `ValueError` cru original continua anexado como
`__context__` e reaparece no traceback (bloco "During handling of the
above exception...") sempre que a excecao nao e capturada antes do topo
-- por exemplo, se alguem chamar `dv.pontual(...)` direto num script ou
REPL, sem passar pelo `try/except` de `main()`. Reproduzi o vazamento a
mao antes de corrigir (ver secao Autorrevisao) e confirmei que
`from None` resolve.

O mesmo tratamento cobre `--base` fora da janela, e uma quarta situacao
que o brief nao cobria: **`--base` dentro da janela do calendario mas
ausente do painel** (o painel so tem fins de mes; um `--base` no meio do
mes nao bate com nenhuma linha):

```
$ python -m tesouro.dv --alvo 31/12/2026 --base 15/06/2026
nao ha posicao em 15/06/2026 no painel; as datas disponiveis sao fins de
mes, de 29/01/2010 a 30/06/2026. Informe --base com uma dessas datas, ou
omita para usar a mais recente.
[exit 1, sem traceback]
```

**4. Sem `--alvo`:** o dispatch pediu explicitamente que o comando "faca
algo sensato e diga o que fez" em vez do `required=True` do exemplo de
codigo do brief. Escolhi **data-base + 1 ano** como padrao -- e um
horizonte que nao duplica os tres ja cobertos por `decay()` (1/5/21 dias
uteis, todos dentro de um mes) e e uma pergunta plausivel do dia a dia
("quanto do DV eu perco no proximo ano"). `pontual()` marca a escolha em
`alvo_padrao=True` no dict devolvido, e `main()` usa isso para avisar
antes do quadro:

```
$ python -m tesouro.dv
nenhuma --alvo informada; usando data-base + 1 ano (30/06/2027). Informe
--alvo DD/MM/AAAA para escolher outra data.

posicao em 30/06/2026, projetada para 30/06/2027
...
[exit 0]
```

**5. `--figura` sem o modulo `figuras` (Tarefa 9):** o brief avisa que
`figuras` so existe na Tarefa 9, e pediu import tardio dentro da funcao,
so disparando se `--figura` for passado -- mantive isso exatamente assim,
sem criar o modulo. Acrescentei so uma mensagem amigavel em vez de deixar
o `ImportError` estourar cru, e o quadro principal ja foi impresso antes
da tentativa de import (a ordem real e: quadro no stdout, aviso de
`--figura` no stderr; confirmado gravando os dois fluxos em arquivos
separados, porque com `2>&1` combinado num so terminal o buffering do
shell mostra o stderr antes por ser nao-bufferizado):

```
$ python -m tesouro.dv --alvo 31/12/2026 --figura saida.png
[stdout: o quadro completo, identico ao caso 1]
[stderr: --figura ainda nao esta disponivel (modulo tesouro.figuras nao
 existe nesta versao); o quadro acima ja foi impresso normalmente.]
[exit 1]
```

Nao criei nenhum teste que dependa de `--figura`/`tesouro.figuras`, como
pedido.

---

#### Numeros em portugues e a cobertura do DV01

`dv._num_br` converte o formato americano do Python (`1,234.56`) para o
brasileiro (`1.234,56`) com uma troca de caracteres em duas passagens
(sem `locale`, que teria efeito colateral global e dependeria de a
maquina ter o locale `pt_BR` instalado). Testado com valores escritos a
mao, nao derivados da propria funcao:
`test_formatar_pontual_usa_virgula_decimal` fixa `_num_br(1234.5) ==
"1.234,50"`, `_num_br(-1234.5) == "-1.234,50"`,
`_num_br(45.2, forcar_sinal=True) == "+45,20"`.

O quadro imprime sempre a cobertura do DV01 (`docs/convencoes-dv.md`,
estoque de junho de 2026): **46,6%** do estoque coberto (LTN 14,4% +
NTN-F 7,5% + NTN-B 24,7%), e os outros 53,4% explicados como LFT 51,3%
(sem duration de juros por construcao) + 2,1% excluidos sem preco no
secundario. Sao constantes fixas do modulo (`_COBERTURA_DV01_PCT` etc.),
nao calculadas a partir do painel -- o painel de `pontual()` ja so cobre
LTN/NTN-F/NTN-B por construcao (LFT filtrada antes do calculo), entao nao
ha como recalcular esses percentuais a partir dele; sao informativos,
como o dispatch pediu.

---

#### Sinal de `dv_que_vence` e `decay_sobreviventes`: por que aparecem positivos

O dispatch descreve a decomposicao como uma subtracao ("(-) DV que vence
no caminho", "(-) decay dos sobreviventes"). Verifiquei a algebra a mao
antes de imprimir qualquer coisa: como `dv_base` e negativo por
convencao, e tanto o vencimento quanto o decay fazem o DV ficar **menos**
negativo, os dois termos precisam ser **somados** (nao subtraidos) a
`dv_base` para fechar em `dv_alvo` --

```
dv_base_total = sum(vence) + sum(sobrevive)
dv_que_vence  = -sum(vence)              # positivo, pois sum(vence) <= 0
decay_sobrev. = sum(dv_alvo sobrev.) - sum(dv_base sobrev.)
dv_base_total + dv_que_vence + decay_sobrev. = dv_alvo_total   (identidade, confere)
```

Se eu tivesse impresso os dois termos com sinal literal de subtracao
(rotulo "(-)" e numero positivo lido como "subtraia isto"), a leitura
aritmetica ingenua ficaria errada (tornaria o DV mais negativo, o
oposto do que acontece). Por isso mantive os rotulos do brief ("(-) DV
que vence no caminho", "(-) decay dos sobreviventes") mas forcei o sinal
`+` explicito nesses dois numeros (`forcar_sinal=True`) e acrescentei uma
frase no rodape do quadro explicando a convencao -- a usuaria nao
precisa adivinhar por que um termo rotulado com "(-)" aparece positivo.
`test_pontual_fecha_a_identidade` (do brief) e a propria conferencia a
mao na secao anterior confirmam a soma.

---

#### Autorrevisao

- **Vazamento de `ValueError` cru via chaining implicito** -- achado
  real, corrigido. Rodei `dv.pontual(date(2100, 1, 1))` direto (sem
  `main()`) e confirmei o traceback mostrando as duas excecoes
  encadeadas (`During handling of the above exception...`), com a
  mensagem tecnica de `Calendario._verificar_janela` aparecendo primeiro
  -- exatamente o que o dispatch pediu para evitar. Adicionei `from None`
  em `_validar_no_calendario` e reproduzi o mesmo comando: so a mensagem
  amigavel aparece agora. `main()` ja nao sofria esse problema
  (`SystemExit` de dentro de um `except ValueError` nao imprime
  traceback quando propaga ao topo do interpretador), mas o dispatch
  pede que a funcao em si -- nao so o CLI -- nao vaze o erro cru, entao
  a correcao ficou em `pontual()`/`_validar_no_calendario`, nao em
  `main()`.
- **`--alvo` obrigatorio no exemplo do brief, trocado por padrao
  sensato** -- decisao deliberada, documentada acima ("Sem --alvo").
  Justificativa registrada tambem no docstring de `pontual()`.
- **`--base` fora do painel (nao so fora do calendario)** -- caso que o
  brief nao cobria explicitamente, mas que a convencao de "usuaria
  iniciante em ferramentas" tornou obrigatorio tratar: sem essa guarda,
  `grupo = p[p["data"] == data_base]` ficaria vazio em silencio e
  `pontual()` devolveria um resumo com todos os totais zerados, sem
  nenhum aviso de que a data pedida simplesmente nao existe no painel --
  um resultado que parece valido e nao e. Escrevi
  `test_pontual_data_base_fora_do_painel_da_mensagem_clara` para travar
  isso.
- **`_num_br` testado com valores escritos a mao** -- `1234.5 ->
  "1.234,50"`, nao derivados da propria implementacao, seguindo a licao
  de nao afirmar o resultado a partir da constante sob teste.
- **`pd.isna`/`.itertuples`**: `pontual()` nao itera `DataFrame` linha a
  linha (so usa `.sum()`, `.groupby().agg()`, `.map()`), entao nao ha
  novo risco de `r.isin` ou `is None` sobre coluna numerica introduzido
  nesta tarefa -- o unico lugar que itera e `_decay_de`, inalterado.
- **ASCII puro**: `dv.py` e `test_decay.py` decodificados como `ascii`
  sem erro apos as edicoes (checado por script).
- **`data/raw/` intocado**: `pontual()` so le via `painel()`
  (`config.PROCESSED_DIR`) e nunca grava nada -- e proposital, o
  dispatch e o brief sao explicitos que o calculo pontual nao vira CSV.
- **Nenhuma consulta a Bloomberg**: nada de rede em `dv.py`.
- **`numpy` nao entrou**: nenhum import novo alem de `pandas` (ja
  presente) e `argparse`/`datetime` da biblioteca padrao.

---

#### O que ficou igual ao brief, para quem ler so este relatorio

- Assinatura de `_decay_de` preservada -- reusada sem alteracao.
- `_COLUNAS_DECAY`, `HORIZONTES`, `decay()`, `gravar_decay()` intocados.
- A logica central de `pontual()` (agrupar por `data_base`, separar
  `vence`/`vive`, montar `por_titulo` com `groupby`) e a mesma proposta
  no brief -- so a resolucao de `data_base`/`data_alvo` ausentes e as
  mensagens de erro foram endurecidas alem do exemplo de codigo.

---

### Verificacao final

```
PYTHONPATH=src python -m pytest tests/test_decay.py -v   -> 26 passed
PYTHONPATH=src python -m pytest                           -> 248 passed
```

Nenhuma regressao nos 236 testes anteriores. `git diff --stat
src/tesouro/precificacao.py` vazio. `dv.py`/`test_decay.py` ASCII puro.

---

## Resposta a revisao de qualidade

**Commit desta correcao:** `9c28077` -- "Corrige achados da revisao do
pontual (tarefa 7)". Arquivos: `src/tesouro/dv.py`, `tests/test_decay.py`.
`precificacao.py` nao foi tocado. Suite completa apos a correcao: **255
passed** (248 anteriores + 7 novos em `tests/test_decay.py`, 33 no total
do arquivo).

### 1 (Important) -- PYTHONPATH nao roda no PowerShell da usuaria

Reproduzi o erro do revisor a mao: `PYTHONPATH=src python -m tesouro.dv`
realmente falha no PowerShell (`O termo 'PYTHONPATH=src' nao e
reconhecido...`). Segui `docs/como-baixar.md:6-12` -- PowerShell primeiro,
bash depois -- na `description` do `argparse`, com
`formatter_class=argparse.RawDescriptionHelpFormatter` para preservar as
quebras de linha do exemplo (sem isso o `argparse` rewrapeava tudo numa
linha so). Conferido com `python -m tesouro.dv --help` de verdade no
PowerShell: a saida mostra `$env:PYTHONPATH="src"; python -m tesouro.dv
--alvo 31/12/2026` antes do bloco `bash`.

### 2 (Important) -- cobertura do DV01 era constante, agora e calculada na data-base

Escrevi `dv._cobertura(cal, data_base)`, que le
`estoque_titulos_vencimento.csv` (o financeiro bruto por titulo,
inclusive LFT e os excluidos -- ao contrario do painel de DV, que so tem
LTN/NTN-F/NTN-B/LFT) e calcula o percentual coberto NA data pedida.
Medido a mao antes de escrever qualquer teste (script separado, nao
`dv._cobertura`):

| data-base | cobertos (medido) | LFT (medido) |
|---|---:|---:|
| 30/06/2026 | 46,5% | 51,3% |
| 2020-12-31 | 60,4% | 36,8% |

Os dois batem com a tabela do revisor (a pequena diferenca de 46,5% vs.
46,6% do `docs/convencoes-dv.md` e metodologica -- a doc usa o estoque de
uma extracao especifica de junho de 2026, o calculo aqui soma
`financeiro_milhoes` bruto de todas as linhas com `quantidade_mil > 0`
daquele mes; a ordem de grandeza e a direcao da mudanca entre datas sao o
que importa, e batem). Rodei o comando de verdade no PowerShell com
`--base 31/12/2020` (colado na secao "O comando de verdade" acima) e o
quadro imprime **60,4%**, nao mais 46,6%.

`test_cobertura_do_dv01_nao_e_constante_muda_com_a_data_base` ancora os
dois pares de numeros (tolerancia `abs=0.15`, pontos percentuais) e exige
que as duas datas difiram por mais de 5 pontos -- a trava real contra
uma regressao para constante fixa. `test_quadro_impresso_usa_a_
cobertura_da_propria_data_base` confere o texto que a usuaria le
(`"60,4%" in texto` e `"46,6%" not in texto`).

### 3 (Important) -- `--gravar` devolve a capacidade de regerar os CSVs

Acrescentei `--gravar` (booleano, curto-circuita antes de qualquer
parsing de data): `python -m tesouro.dv --gravar` chama `gravar_painel()`
e `gravar_decay()` e sai, sem calcular o pontual. E a mesma capacidade
que `python -m tesouro.dv` sozinho tinha antes desta tarefa,
devolvida sem voltar a ser o comportamento padrao (que agora e o
pontual, como o brief da Tarefa 7 pediu). A ligacao com `pipeline.py`
continua fora do escopo (Tarefa 10).

`test_gravar_regrava_os_dois_csvs_de_producao` isola com
`monkeypatch.setattr(config, "PROCESSED_DIR", tmp_path)` e um estoque
sintetico de uma linha (mesmo padrao de `tests/test_dv.py`), chama
`dv.main(["--gravar"])` e confere que os dois arquivos existem e tem o
conteudo esperado.

### 4 (Important) -- as quatro colunas de `por_titulo` agora tem ancora que pega as cinco mutacoes

Extrai a agregacao para `dv._por_titulo(df)`, testada isolada com um
`DataFrame` sintetico com **ISIN duplicado de proposito** (`"A"` aparece
duas vezes em `LTN`). O motivo do ISIN duplicado: no dado real, cada ISIN
aparece uma unica vez por `(titulo, data)` (`test_sem_chave_duplicada`
em `tests/test_dv.py` ja trava isso), entao `nunique` e `count` dão
exatamente o mesmo numero ali -- e essa e a razao real de a mutacao
`nunique -> count` ter sobrevivido na rodada do revisor: nenhum teste
possivel sobre o dado real distingue as duas funcoes. Um `DataFrame`
sintetico com duplicata deliberada e a unica forma de testar essa
diferenca.

Reproduzi as cinco mutacoes do revisor **uma de cada vez**, rodei a
suite, confirmei a falha, e restaurei o arquivo antes de seguir para a
proxima (usando uma copia da versao corrigida em vez de `git checkout
--`, depois que o primeiro `git checkout --` reverteu o commit todo por
engano -- a versao corrigida nao estava commitada ainda; percebido e
corrigido na hora, sem perda de trabalho):

| mutacao | teste que falha |
|---|---|
| `dv_alvo=("dv_alvo","sum")` -> `("dv_base","sum")` | `test_por_titulo_agrega_as_quatro_colunas_corretamente` |
| `dv_alvo` -> `("dv_alvo","max")` | idem |
| `papeis=("isin","nunique")` -> `("isin","count")` | idem |
| `vencendo=("venceu_no_caminho","sum")` -> `"min"` | idem |
| apagar a linha `"DV na data-alvo"` de `_formatar` | `test_formatar_pontual_imprime_as_quatro_linhas_da_decomposicao` |

Todas as cinco falham com a suite corrigida e passam com a suite antes da
correcao (confirmado nas duas direcoes).

### 5 (Important) -- a asserçao sugerida pelo revisor nao funciona; usei `__suppress_context__`

Antes de escrever o teste, testei a sugestao do revisor
(`excinfo.value.__context__ is None`) direto no interpretador. Ela **nao
se sustenta**: `__context__` fica preenchido com a excecao original
mesmo com `from None` -- o que `from None` muda e
`__suppress_context__` (`True` com `from None`, `False` sem), que e o
atributo que o formatador de traceback do Python de fato consulta para
decidir se mostra a cadeia "During handling of the above exception...".
Confirmado nos dois sentidos, no interpretador, antes de escrever
`test_pontual_nao_vaza_o_valueerror_cru_do_calendario`:

```
com "from None":    context=<ValueError interno>  suppress_context=True
sem  "from None":    context=<ValueError interno>  suppress_context=False
```

O teste final assere `__context__ is not None` (o calendario realmente
levantou algo) **e** `__suppress_context__ is True` (mas a cadeia fica
escondida). Removendo o `from None` de `_validar_no_calendario`, esse
teste falha exatamente na segunda asserçao -- reproduzido a mao antes de
commitar.

### Minors

- **Alinhamento do quadro de quatro linhas**: rotulos e valores agora
  vem de uma lista `itens` com `largura_rotulo = max(len(rotulo) for
  rotulo, _, _ in itens)`, format string `f"  {rotulo:<{largura_rotulo}}
  {valor:>14}"` -- nao mais quatro f-strings com espacos contados a mao.
  Conferido a virgula decimal das quatro linhas na mesma coluna (42) com
  um script que imprime `linha.find(',')` para cada uma.
- **Janela do calendario na mensagem de erro**: `_validar_no_calendario`
  usa `cal._inicio`/`cal._fim` em vez do literal `"01/01/2001 a
  31/12/2099"`.
- **Contagem de `papeis`**: acrescentei uma linha de rodape no quadro
  explicando que `papeis` conta todo ISIN presente no painel na
  data-base, inclusive os sem taxa/DV medido (por isso pode ser maior que
  o numero de papeis que de fato soma em `dv_base_milhoes`), e um teste
  (`test_formatar_pontual_explica_por_que_vence_e_decay_sao_positivos`
  cobre o rodape do sinal; a explicacao de `papeis` fica sem teste
  dedicado -- decisao consciente, e so uma frase de rodape, o mesmo nivel
  de risco do rodape do sinal que ja tinha ficado sem trava antes desta
  rodada).
- **`test_pontual_em_data_muito_distante_zera_tudo`**: acrescentei
  `assert r["dv_base"] < 0` para nao passar vacuamente com um `DataFrame`
  vazio.
- **`--figura` sem `figuras`**: a mensagem some do fluxo de erro
  (`SystemExit`) para um `print(..., file=sys.stderr)` seguido de
  `return` -- o comando sai com codigo 0, porque o quadro principal ja
  foi impresso com sucesso e `--figura` e um recurso opcional ainda nao
  implementado (Tarefa 9), nao uma falha do calculo.
- **Rodape do sinal de `(-)`**: coberto por
  `test_formatar_pontual_explica_por_que_vence_e_decay_sao_positivos`
  (`"sinal positivo" in texto`).

### Verificacao final desta rodada

```
PYTHONPATH=src python -m pytest tests/test_decay.py -v   -> 33 passed
PYTHONPATH=src python -m pytest                           -> 255 passed
```

`git diff --stat src/tesouro/precificacao.py` vazio. ASCII conferido de
novo em `dv.py` e `test_decay.py` (achei e corrigi um "assercao" digitado
com acento -- `ç`/`ã` -- que tinha escapado da primeira checagem, unico
achado da autorrevisao desta rodada). Comando real rodado no PowerShell
(nao WSL/bash) para `--alvo 31/12/2026` e para `--base 31/12/2020 --alvo
31/12/2021`, saidas coladas nas secoes acima.

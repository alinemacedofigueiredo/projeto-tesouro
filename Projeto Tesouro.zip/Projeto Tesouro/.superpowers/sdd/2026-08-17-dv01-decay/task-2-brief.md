### Task 2: Motor de precificação

**Files:**
- Create: `src/tesouro/precificacao.py`
- Test: `tests/test_precificacao.py`

**Interfaces:**
- Consumes: `calendario.Calendario`
- Produces:
  - `precificacao.pu_ltn(cal, d0, vencimento, taxa) -> float`
  - `precificacao.pu_ntnf(cal, d0, vencimento, taxa) -> float`
  - `precificacao.pu_ntnb(cal, d0, vencimento, taxa, vna) -> float`
  - `precificacao.pu_lft(cal, d0, vencimento, taxa, vna) -> float`
  - `precificacao.pu(cal, titulo, d0, vencimento, taxa, vna=None) -> float`
  - `precificacao.dv(cal, titulo, d0, vencimento, taxa, vna=None) -> float | None`

**Contexto obrigatório:** leia `docs/convencoes-dv.md` antes de escrever uma linha. Ele explica por que a truncagem fica dentro do DV, por que o sinal é o que é, e por que a LFT devolve `None`.

A `taxa` entra em **decimal** (`0.135` = 13,5%), não em percentual — a conversão acontece em quem chama. As fórmulas são portadas do código em uso na mesa, já validado contra a Bloomberg em 438 pares papel-data.

- [ ] **Step 1: Escreva os testes que falham**

```python
# tests/test_precificacao.py
from datetime import date

import pytest
from tesouro import calendario, precificacao


@pytest.fixture(scope="module")
def cal():
    return calendario.padrao()


def test_ltn_com_252_dias_uteis_a_10_por_cento(cal):
    # Ancora aritmetica exata: 1000 / 1,10 = 909,090909...
    d0 = date(2026, 6, 30)
    venc = cal.mover(d0, 252)
    assert precificacao.pu_ltn(cal, d0, venc, 0.10) == pytest.approx(909.090909, abs=1e-6)


def test_ltn_no_vencimento_vale_zero(cal):
    d0 = date(2026, 7, 1)
    assert precificacao.pu_ltn(cal, d0, date(2026, 7, 1), 0.13) == 0.0


def test_ntnb_multiplica_a_cotacao_pelo_vna(cal):
    # Dobrar o VNA dobra o PU: a cotacao nao depende dele.
    d0, venc = date(2026, 6, 30), date(2035, 5, 15)
    a = precificacao.pu_ntnb(cal, d0, venc, 0.07, 4000.0)
    b = precificacao.pu_ntnb(cal, d0, venc, 0.07, 8000.0)
    assert b == pytest.approx(2 * a, rel=1e-4)


def test_lft_perto_do_par_vale_perto_do_vna(cal):
    # Com agio quase nulo, o PU da LFT e praticamente o VNA.
    pu = precificacao.pu_lft(cal, date(2026, 6, 30), date(2030, 6, 1), 0.0001, 19323.94)
    assert pu == pytest.approx(19323.94, rel=2e-3)


def test_ntnf_soma_cupons_semestrais(cal):
    # Taxa igual ao cupom (10% a.a.) deixa o papel proximo do par.
    pu = precificacao.pu_ntnf(cal, date(2026, 6, 30), date(2033, 1, 1), 0.10)
    assert pu == pytest.approx(1000, rel=0.02)


def test_dv_e_negativo_para_titulo(cal):
    # Convencao: PU(taxa+1bp) - PU(taxa). Alta de taxa faz o mercado perder.
    d0 = date(2026, 6, 30)
    for titulo, venc, taxa, vna in [
        ("LTN", date(2029, 1, 1), 0.13, None),
        ("NTN-F", date(2033, 1, 1), 0.13, None),
        ("NTN-B", date(2035, 5, 15), 0.07, 4739.66),
    ]:
        assert precificacao.dv(cal, titulo, d0, venc, taxa, vna) < 0


def test_dv_cresce_com_o_prazo(cal):
    d0 = date(2026, 6, 30)
    curto = precificacao.dv(cal, "LTN", d0, date(2027, 7, 1), 0.13)
    longo = precificacao.dv(cal, "LTN", d0, date(2031, 7, 1), 0.13)
    assert abs(longo) > abs(curto)


def test_dv_da_lft_e_none_e_nao_zero(cal):
    # Decisao de modelagem: a LFT nao entra no DV01. None e nao zero,
    # porque "nao se aplica" e diferente de "risco nulo medido".
    d = precificacao.dv(cal, "LFT", date(2026, 6, 30), date(2030, 6, 1), 0.0006, 19323.94)
    assert d is None


def test_dv_usa_precos_truncados(cal):
    # A truncagem faz parte do DV de proposito: o preco truncado e o
    # negociavel. Logo o DV e sempre um multiplo de 1e-6.
    d = precificacao.dv(cal, "LTN", date(2026, 6, 30), date(2029, 1, 1), 0.13)
    assert abs(round(d * 1e6) - d * 1e6) < 1e-6


def test_titulo_desconhecido_falha_alto(cal):
    with pytest.raises(ValueError, match="NTN-Z"):
        precificacao.pu(cal, "NTN-Z", date(2026, 6, 30), date(2030, 1, 1), 0.1)


def test_ntnb_precisa_de_vna(cal):
    with pytest.raises(ValueError, match="VNA"):
        precificacao.pu(cal, "NTN-B", date(2026, 6, 30), date(2035, 5, 15), 0.07)
```

- [ ] **Step 2: Rode e confirme que falham**

Run: `PYTHONPATH=src python -m pytest tests/test_precificacao.py -v`
Expected: FAIL com `ModuleNotFoundError: No module named 'tesouro.precificacao'`

- [ ] **Step 3: Implemente o `precificacao.py`**

```python
"""Preco unitario e DV01 dos titulos publicos federais.

Portado do codigo em uso na mesa, validado contra o PX_DIRTY_MID da
Bloomberg em 438 pares papel-data entre 2020 e 2026 -- exato em todas as
comparacoes de NTN-F e NTN-B. Ver docs/convencoes-dv.md.

A taxa entra em DECIMAL (0.135 = 13,5%); quem chama converte.

Tres convencoes que parecem detalhe e nao sao:

  A truncagem esta dentro do DV de proposito. O PU truncado e o preco
  negociavel, entao a diferenca entre dois truncados e o que de fato se
  ganha ou perde quando a taxa anda 1 bp. Nao "melhore" isso calculando o
  DV com PUs cheios.

  O sinal e PU(taxa + 1bp) - PU(taxa), negativo para titulo. Multiplicado
  pela posicao, da direto o dinheiro perdido num choque de alta.

  A LFT devolve None no DV, nao zero: e decisao de modelagem do projeto,
  e "nao se aplica" precisa ser distinguivel de "risco nulo medido".
"""
import math

_UM_BP = 0.0001

# Cupom semestral: 1000 * ((1,10)^0,5 - 1) = 48,8088 na NTN-F;
# 100 * ((1,06)^0,5 - 1) = 2,9563 na NTN-B, sobre principal de 100.
_CUPOM_NTNF = 1000 * ((1.10 ** 0.5) - 1)
_CUPOM_NTNB = 100 * ((1.06 ** 0.5) - 1)


def _truncar(x, casas):
    fator = 10 ** casas
    return math.trunc(x * fator) / fator


def _meses_antes(d, meses):
    """Recua `meses` no calendario, sem estourar o fim do mes."""
    import calendar as _c
    from datetime import date as _date
    m = d.month - 1 - meses
    ano = d.year + m // 12
    m = m % 12 + 1
    return _date(ano, m, min(d.day, _c.monthrange(ano, m)[1]))


def pu_ltn(cal, d0, vencimento, taxa):
    """Prefixado sem cupom: 1000 descontado ate o vencimento."""
    venc = cal.ajustar_vencimento(vencimento)
    if d0 >= venc:
        return 0.0
    return _truncar(1000 / ((1 + taxa) ** (cal.du(d0, venc) / 252)), 6)


def pu_lft(cal, d0, vencimento, taxa, vna):
    """Pos-fixada: cotacao sobre o agio, aplicada ao VNA da Selic."""
    venc = cal.ajustar_vencimento(vencimento)
    if d0 >= venc:
        return 0.0
    cotacao = _truncar(100 / ((1 + taxa) ** (cal.du(d0, venc) / 252)), 4)
    return _truncar(cotacao * vna / 100, 6)


def pu_ntnf(cal, d0, vencimento, taxa):
    """Prefixado com cupom semestral. Os cupons caem no dia 1."""
    from datetime import date as _date
    venc = cal.ajustar_vencimento(vencimento)
    cupom = venc
    soma = 0.0
    while cupom > d0:
        principal = 1000 if cupom == venc else 0
        fluxo = round(_CUPOM_NTNF + principal, 5)
        soma += fluxo / ((1 + taxa) ** (cal.du(d0, cupom) / 252))
        anterior = _meses_antes(cupom, 6)
        cupom = cal.ajustar_vencimento(_date(anterior.year, anterior.month, 1))
    return _truncar(soma, 6)


def pu_ntnb(cal, d0, vencimento, taxa, vna):
    """Indexada ao IPCA, cupom semestral. Os cupons caem no dia 15.

    A cotacao e truncada em 4 casas antes de multiplicar pelo VNA, e o
    resultado em 6 -- e a convencao do mercado, nao um arredondamento
    nosso.
    """
    from datetime import date as _date
    venc = cal.ajustar_vencimento(vencimento)
    cupom = venc
    cotacao = 0.0
    while cupom > d0:
        principal = 100 if cupom == venc else 0
        fluxo = round(_CUPOM_NTNB + principal, 6)
        cotacao += fluxo / ((1 + taxa) ** (cal.du(d0, cupom) / 252))
        anterior = _meses_antes(cupom, 6)
        cupom = cal.ajustar_vencimento(_date(anterior.year, anterior.month, 15))
    return _truncar(_truncar(cotacao, 4) / 100 * vna, 6)


_INDEXADOS = {"NTN-B", "LFT"}


def pu(cal, titulo, d0, vencimento, taxa, vna=None):
    """Despacha para a formula do titulo. Taxa em decimal."""
    if titulo in _INDEXADOS and vna is None:
        raise ValueError(f"{titulo} exige VNA e nenhum foi informado")
    if titulo == "LTN":
        return pu_ltn(cal, d0, vencimento, taxa)
    if titulo == "NTN-F":
        return pu_ntnf(cal, d0, vencimento, taxa)
    if titulo == "NTN-B":
        return pu_ntnb(cal, d0, vencimento, taxa, vna)
    if titulo == "LFT":
        return pu_lft(cal, d0, vencimento, taxa, vna)
    raise ValueError(
        f"titulo sem formula de precificacao: {titulo!r}. "
        f"O escopo do projeto e LTN, NTN-F, NTN-B e LFT."
    )


def dv(cal, titulo, d0, vencimento, taxa, vna=None):
    """Variacao do PU para +1 bp na taxa. Negativo para titulo.

    Devolve None para LFT: por decisao de modelagem ela nao entra no
    DV01 do projeto, e None mantem isso distinguivel de zero.
    """
    if titulo == "LFT":
        return None
    return (pu(cal, titulo, d0, vencimento, taxa + _UM_BP, vna)
            - pu(cal, titulo, d0, vencimento, taxa, vna))
```

- [ ] **Step 4: Rode os testes e confirme que passam**

Run: `PYTHONPATH=src python -m pytest tests/test_precificacao.py -v`
Expected: PASS, 11 testes

- [ ] **Step 5: Commit**

```bash
git add src/tesouro/precificacao.py tests/test_precificacao.py
git commit -m "Adiciona motor de precificacao portado do codigo da mesa"
```

---


# Tarefa 11: Documentação -- relatório

## O que foi feito

Seis arquivos `.md` editados (nenhum `.py` tocado). Nenhum número foi escrito
sem antes ser reproduzido rodando o código real contra os CSVs em
`data/processed/` -- os comandos usados para cada verificação estão listados
abaixo, por seção.

### `docs/superpowers/specs/2026-08-14-camada-de-dados-design.md`

Respondida a pergunta em aberto do §8 ("Sobre o campo `Financeiro` da aba
2.2"): é marcação NA CURVA, não a mercado. Acrescentado um parágrafo com a
evidência (NTN-B 2050 cravada, NTN-F 2031 divergindo, LFT como controle) e a
consequência de cobertura (46,5% vs 43,3%), com remissão ao detalhe completo
em `docs/convencoes-dv.md`.

### `docs/dicionario-de-dados.md`

- Nota da coluna `financeiro_milhoes` em `estoque_titulos_vencimento.csv`
  atualizada de "não confirmado" para a resposta, com a mesma evidência
  resumida (este é o segundo dos "dois lugares" que a pergunta em aberto
  pedia).
- Cinco seções novas: `taxa_por_papel.csv`, `vna.csv`, `dv_por_papel.csv`,
  `decay_por_papel.csv`, `resultado_mensal.csv` -- coluna, tipo, descrição e
  armadilhas, no mesmo formato das dezessete existentes. Toda contagem de
  linha e todo `value_counts()` foi rodado contra o CSV real antes de
  escrever (comando abaixo).
- Intro e bloco `## Verificação` atualizados de dezessete para vinte e dois
  nomes de CSV.

**Achado da própria verificação, corrigido antes de publicar:** o rascunho
do brief (`task-11-brief.md`) afirmava que as 572 linhas de `dv_por_papel.csv`
sem taxa são "quase todas LFT de 2010 e 2011". Rodei `value_counts()` contra
o CSV real e isso é falso -- a composição é `LTN` 335 (espalhadas de 2013 a
2026), `LFT` 155 (essas sim, integralmente em 2010-2011), `NTN-B` 73
(maioria em 2010) e `NTN-F` 9. Escrevi a composição real, não a do rascunho,
e documentei explicitamente a divergência para reforçar por que conferir
antes de escrever de memória importa.

### `docs/convencoes-dv.md`

Documento principal estendido (não reescrito), dez seções novas ou
corrigidas:

1. **Calendário de dias úteis** -- acrescentada a nota de que a Bloomberg
   nem sempre cota em dia útil pela Anbima (272/8.898 linhas, 6 datas:
   Sexta-feira Santa 2013/2018/2024, Carnaval 2017/2022, Corpus Christi
   2018) e o número do contrafactual pedido (junção por data literal:
   6.074/9.366 = 64,9%, perda de 35,1%).
2. **Escopo** -- números corrigidos de 46,6%/2,1% para 46,5%/2,2% (a soma de
   parcelas já arredondadas dava 46,6%; o total calculado com precisão
   total, sem arredondar cada parcela antes, é 46,5% -- o número que o
   próprio `dv.pontual()` imprime). Acrescentada a nota de que a cobertura
   varia por data (46,5% em 30/06/2026, 60,4% em 31/12/2020) e a segunda
   leitura por marcação a mercado (43,3%).
3. **Seção nova "O financeiro da aba 2.2 é marcação na curva, não a
   mercado"** -- a resposta completa, com os três números de evidência
   (NTN-B 2050, NTN-F 2031, controle da LFT) e a consequência de cobertura.
4. **Seção nova "Convenção de sinal do decay"** -- transcrita do comentário
   de `src/tesouro/dv.py:129-142`, que hoje é o único lugar onde essa
   convenção estava escrita.
5. **Seção nova "As duas contas"** -- Conta A (resultado realizado, base de
   posição diferente para dinheiro vs. variação de DV) e Conta B (decay a
   taxa constante).
6. **Seção nova "Resultado mensal: separando a acumulação de índice"** --
   `resultado_decomposto()`, com os números medidos nos doze meses até
   30/06/2026 (NTN-B: +90.095,9 de índice contra +29.495,0 do total, taxa
   real -60.600,9; março/2026 sozinho, 565% do mês; LFT: 568.716,3 de
   738.059,3 = 77% do resultado total do painel).
7. **Seção nova "Refazendo uma conta à mão"** -- exemplo real (LTN,
   `BRSTNCLTN8I0`, 30/06/2026), passo a passo até bater com a linha do CSV
   (`PU = 908,347884`, `dv_unitario = -0,059568`,
   `dv_posicao_milhoes = -7,614950`).
8. **Fontes na Bloomberg** -- acrescentados `BZAC2000 Index` (CDI acumulado,
   não Selic) e a obrigatoriedade do nome de arquivo em formato ISO (a
   armadilha do desduplicador por última ocorrência).
9. **Seção nova "Recuperando um arquivo apagado à mão em
   `data/raw/bloomberg/`"** -- o procedimento completo, derivado lendo
   `fetch_bloomberg.baixar()` linha a linha (a ordem fixa
   taxa/VNA/preço em que os três arquivos são checados explica por que o
   `FileExistsError` pode não cair no arquivo que a pessoa apagou, e por
   que são necessárias duas ou três rodadas).
10. **Seção nova "Verificação pendente de autorização"** -- os dois itens
    que dependem de consulta à Bloomberg não autorizada (coleta ao vivo
    nunca executada; teste do PU vs. `PX_DIRTY_MID` pulando), com o comando
    para habilitá-los.

### `README.md`

Comando pontual (`python -m tesouro.dv --alvo 31/12/2027`, PowerShell antes
de bash) e descrição do novo escopo do pipeline (PU/DV01/decay/resultado).
Seção "Como o projeto está organizado" estendida para cobrir a Bloomberg;
"Documentação" ganhou a entrada de `docs/convencoes-dv.md`; "Testes" ganhou
a nota de que 1 skip é esperado, com o motivo e o comando para habilitá-lo.

### `docs/como-baixar.md`

Duas seções novas: "3. Calendário de feriados da Anbima" (onde baixar, para
onde colocar) e "4. Taxa e VNA da Bloomberg (sem terminal)" -- exportação
manual por `BDH`, com as colunas exatas que `parse_bloomberg.py` exige para
taxa (`isin, titulo, vencimento, data, yld_ytm_mid`) e VNA (`data, indice,
campo, fator, vna, n_papeis, divergencia`), a convenção de nome ISO
obrigatória, e um resumo do procedimento de recuperação com remissão ao
detalhe em `docs/convencoes-dv.md`.

### `docs/fontes-de-dados.md`

Diagrama `mermaid` estendido com os nós da Anbima e da Bloomberg (e o fluxo
`dv.py` consumindo `estoque_titulos_vencimento` + `taxa_por_papel`/`vna`
para produzir as três tabelas calculadas). Duas seções novas ("Bloomberg" e
"Anbima") e a tabela "De onde vem cada CSV" ganhou os cinco novos, com a
origem de cada um.

## Verificação de cada número, com o comando usado

Todos rodados com
`PYTHONPATH=src python -c "..."` contra o `data/processed/` real desta
branch (painel de 9.366 linhas, até 30/06/2026):

| Número escrito | Verificado com |
|---|---|
| Painel 9.366 linhas; DV 30/06/2026 -1.472,872661 (LTN -198,535484, NTN-F -177,755607, NTN-B -1.096,581570) | `dv.painel()`, filtro `data == 2026-06-30`, soma por título |
| Decay 20.115 linhas; resultado 9.314 linhas; 22 CSVs | `len()` de cada CSV; `pathlib.Path("data/processed").glob("*.csv")` |
| Pontual 31/12/2026: -1.472,872661 / +5,248806 / +86,540294 / -1.381,083561 | `python -m tesouro.dv --alvo 31/12/2026` |
| Cobertura 46,5% (30/06/2026) e 60,4% (31/12/2020) | `dv._cobertura(cal, data)` chamado direto para as duas datas |
| NTN-B 2050 cravada 5,34%-5,54%; mercado 3,59%-7,56% | bissecção sobre `precificacao.pu_ntnb`, reproduzindo o método de `tests/test_coerencia_dv.py` |
| NTN-F 2031: implícita 6,99%->12,28%; mercado 6,86%->14,85%->13,23% | mesma bissecção, sobre `precificacao.pu_ntnf`, para `BRSTNCNTF204` |
| Controle da LFT dentro de poucas dezenas de bp | mesma bissecção sobre `precificacao.pu_lft`; outliers isolados e explicados por `du` muito pequeno perto do vencimento (PU insensível ao ágio ali) |
| Junção por data literal: 6.074/9.366 = 64,9%, perda 35,1% | merge manual sem `ultimo_dia_util_do_mes`, comparado com `dv.painel()` |
| Bloomberg fora do dia útil: 272/8.898, 6 datas | leitura do bruto `bbg_taxas_*.csv`, filtro `~cal.eh_dia_util(data)` |
| resultado_decomposto 12m: NTN-B +90.095,9/+29.495,0/-60.600,9; LFT 568.716,3/738.059,3 = 77%; março/2026 565% | `dv.resultado_decomposto()`, data_ini de 2025-06-30 a data_fim de 2026-06-30 (doze períodos mensais) |
| 8 linhas órfãs, R$ 291.954,8 milhões, 2010-02 a 2011-08 | já travado em `tests/test_coerencia_dv.py::test_linhas_vivas_sem_pu_fim_sao_exatamente_oito`; reproduzido à parte |
| Cobertura mark-a-mercado 43,3%; 46,5% pela base do RMD | `financeiro_calculado_milhoes` somado (LTN+NTN-F+NTN-B) sobre o `financeiro_milhoes` total do estoque em 30/06/2026 |
| Exemplo manual (LTN `BRSTNCLTN8I0`): PU 908,347884, dv_unitario -0,059568, dv_posicao -7,614950 | fórmula da LTN reproduzida à mão em Python puro, comparada linha a linha com `dv_por_papel.csv` |
| Escopo 572 linhas (6,1%) sem taxa: LTN 335 / LFT 155 / NTN-B 73 / NTN-F 9 | `value_counts()` sobre `dv_por_papel[dv_por_papel.taxa_pct.isna()]` |

**Um número do rascunho do brief que não bateu e não foi usado:** a duração
modificada implícita (3,55 anos) do bloco "Números de referência" bateu
exatamente quando calculada como `-DV_total / financeiro_RMD_dos_titulos_
cobertos / 0,0001`, mas essa conta não aparece em nenhum lugar do código
nem foi pedida como item de documentação numerado -- não escrevi uma seção
nova só para ela, para não inventar conteúdo fora do que os onze itens
pediam.

## Verificação final

```
PYTHONPATH=src python -m pytest tests/ -q
```

**294 passed, 1 skipped** -- idêntico à baseline antes de qualquer edição.
Nenhum arquivo `.py` foi tocado (confirmado por `git status --short`: só
`README.md` e `docs/*` aparecem modificados).

```
PYTHONPATH=src python -c "import pathlib; print(sorted(p.stem for p in pathlib.Path('data/processed').glob('*.csv')))"
```

A lista impressa bate, nome a nome, com o bloco `## Verificação` de
`docs/dicionario-de-dados.md`.

## Autorrevisão

- **Composição das 572 linhas sem taxa** (achado já registrado acima):
  corrigida para refletir o CSV real, não o rascunho do brief.
- **Referências cruzadas de linha** (`docs/convencoes-dv.md:120-121`,
  `:154-156`, citadas em comentários de `tests/test_coerencia_dv.py`):
  conferidas depois de todas as edições -- continuam apontando para o
  conteúdo certo, porque toda seção nova foi inserida depois desses trechos
  no arquivo, sem deslocar as linhas anteriores.
- **Formatação:** uma quebra de linha acidental no meio de um trecho
  formatado (`bbg_taxas_ANDE_` cortado por uma quebra de linha) corrigida
  na seção "Recuperando um arquivo apagado à mão".
- **Frase estranha** na nota de `dv_por_papel.csv` sobre a composição das
  572 linhas ("valeu a pena aqui...") reescrita para ficar direta.
- Reconferida a explicação de `resultado_decomposto()` contra o docstring
  real de `src/tesouro/dv.py` (mantém a taxa de `data_ini` fixa e troca só
  o VNA entre as duas reprecificações) -- a descrição escrita bate com o
  código.

## Preocupações

- A duração modificada implícita (3,55 anos, e as parcelas por título --
  LTN 1,58, NTN-F 2,82, NTN-B 5,58) do bloco de referência do enunciado bate
  exatamente quando reproduzida, mas não virou conteúdo de documentação --
  não estava entre os onze itens pedidos e não haveria onde ancorá-la sem
  inventar uma seção nova fora de escopo. Se a usuária quiser essa métrica
  documentada (por exemplo, como leitura complementar da seção "Escopo"),
  é um acréscimo pequeno e já verificado.
- O controle da LFT ("implícita bate com o ágio de mercado dentro de 0 a 25
  bp") foi escrito como no enunciado; a reprodução por bissecção que fiz
  confirma a mediana bem próxima de zero e a maior parte da amostra dentro
  dessa faixa, mas encontra outliers de centenas de bp exatamente nas
  poucas linhas em que o papel está a 1-5 dias úteis do vencimento (onde o
  PU fica matematicamente quase insensível ao ágio, e qualquer ruído de
  truncagem se amplifica na bissecção). Não escrevi essa ressalva no texto
  publicado porque não estava pedida e o achado em si (LFT como controle
  válido, muito mais próxima de zero que NTN-F/NTN-B) não muda -- mas fica
  registrado aqui para quem for reproduzir o número exato algum dia.
- Não executei nenhuma consulta à Bloomberg nem rodei o coletor ao vivo, em
  linha com a restrição do enunciado ("Nenhuma consulta à Bloomberg, por
  nenhum motivo"). A seção "Verificação pendente de autorização" existe
  para que a usuária saiba exatamente o que falta e o comando para rodar
  quando quiser autorizar.

## Revisão (rodada 2): 3 Critical e 5 Important, todos corrigidos

O revisor extraiu ~95 afirmações numéricas dos seis `.md` e rodou o código
para cada uma. Achou 5 erradas e 3 imprecisas. Confirmou também a correção
já registrada acima (composição das 572 linhas sem taxa). Cada item abaixo
foi reproduzido de novo, do zero, antes de corrigir -- comando e saída
colados.

### C1 (Critical) -- faixa da NTN-B 2050 não reproduzia

Publicado: "cravada entre 5,34% e 5,54% por doze anos". Reproduzindo a
mesma bissecção do teste (`precificacao.pu_ntnb`, janela 2014-01 a
2026-06, 150 observações):

```
n 150
min 5.400144352347914 max 5.558780382259842
```

Corrigido para **5,40% a 5,56%** em `docs/convencoes-dv.md`,
`docs/dicionario-de-dados.md` e
`docs/superpowers/specs/2026-08-14-camada-de-dados-design.md` (as três
cópias). De caminho, também corrigi o mínimo de mercado da NTN-B 2050 que
eu tinha publicado como 3,59% (2020) -- o valor real do ano é **3,57%**,
em 31/01/2020:

```
2020 min 3.57 at 2020-01-31
2025 max 7.563 at 2025-02-28
```

### C2 (Critical) -- janela das LTN sem taxa estava errada

Publicado: "LTN (335, espalhadas de 2013 a 2026)". `value_counts()` por
ano sobre `dv_por_papel[dv_por_papel.taxa_pct.isna() & titulo=="LTN"]`:

```
2010    20
2011    18
2013     4
2015    10
2016    24
2017    24
2018    35
2019    36
2020    47
2021    18
2022    17
2023    12
2024    34
2025    24
2026    12
total 335
2010-2011 38
```

A janela real é **2010 a 2026** (sem 2012 nem 2014), com **38 linhas em
2010-2011** -- exatamente a composição que eu tinha excluído ao "corrigir"
a afirmação original do brief. Corrigido em `docs/dicionario-de-dados.md`,
com nota de que o dicionário já errou duas vezes seguidas na mesma frase.

### C3 (Critical) -- "`decay` é POSITIVO para um sobrevivente" tinha 933 contraexemplos

```python
surv = d[~d['venceu_no_caminho'] & d['decay'].notna()]
neg = surv[surv['decay'] < 0]
# 933 de 18596 (5,0%), todas NTN-B
# mediana -1.928e-05, minimo -0.2326
```

Por horizonte, só nas linhas de NTN-B sobrevivente:

```
1du   722 de 2930 = 24,6%
5du   199 de 2930 = 6,8%
21du   12 de 2912 = 0,4%
```

Corrigido em `docs/convencoes-dv.md` (seção "Convenção de sinal do decay")
e `docs/dicionario-de-dados.md` (coluna `decay`): a afirmação virou "em
regra" positivo, com a exceção medida explicada pela mesma quantização de
truncagem que a seção "A truncagem faz parte do DV" já descreve.

### I1 (Important) -- "véspera de" estava errado

Lendo o nome do feriado direto de `data/raw/anbima/feriados_nacionais.xls`
para as 6 datas:

```
2013-03-29 Paixão de Cristo
2018-03-30 Paixão de Cristo
2024-03-29 Paixão de Cristo
2017-02-28 Carnaval
2022-02-28 Carnaval
2018-05-31 Corpus Christi
```

São os próprios feriados, não vésperas. Corrigido nas duas cópias
(`docs/convencoes-dv.md` e `docs/dicionario-de-dados.md`).

### I2 (Important) -- procedimento de recuperação em bash sozinho

`docs/convencoes-dv.md`, passo 1 do procedimento de recuperação, estava
`Rode 'python -m tesouro.fetch_bloomberg' (com PYTHONPATH=src)` -- sintaxe
bash pura. Substituído pelo par PowerShell/bash completo, no mesmo padrão
de `docs/como-baixar.md:6-12`.

### I3 (Important) -- roteiro à mão não fechava se digitado literalmente

```python
>>> pu_rounded_exp = 1000/((1.137522)**0.746032)
>>> math.trunc(pu_rounded_exp*1e6)/1e6
908.347854          # nao bate com 908.347884 do CSV
>>> pu_full = 1000/((1+0.137522)**(188/252))
>>> math.trunc(pu_full*1e6)/1e6
908.347884           # bate
```

O expoente `188/252 = 0,746031746...` é dízima; arredondar para
`0,746032` antes de elevar muda a 6ª casa do PU. Corrigido o passo 2/3 do
exemplo em `docs/convencoes-dv.md` com aviso explícito e o expoente escrito
como fração, não como decimal arredondado.

### I4 (Important) -- ressalva da LFT incorporada ao texto

Reproduzido: 2.506 pares, mediana de erro absoluto 3,1 bp, 97,1% dentro de
25 bp, 24 pares acima de 100 bp, todos com `du` entre 1 e 11 dias úteis:

```
mediana abs 3.100206575791265
pct within 25bp 97.08699122106943
n>100bp 24
du (nesses 24): min 1, 25% 1, mediana 5, 75% 5.25, max 11
```

Acrescentada a frase pedida (papel a 1-11 dias úteis do vencimento, PU
insensível ao ágio ali, truncagem se amplifica na inversão) em
`docs/convencoes-dv.md` e `docs/dicionario-de-dados.md`. Não usei o número
"1.013 bp" de máximo citado na revisão -- reproduzindo com bissecção mais
larga (-50%/+50%) o máximo que obtive foi 1.311 bp, e com a bissecção
original (-5%/+5%) foi 514 bp; o valor exato do pior caso depende dos
limites da bissecção (o PU é quase plano ali, então qualquer ruído vira
"ágio implícito" enorme) e não é um número estável o bastante para publicar
como fato -- a mediana, o percentual dentro de 25 bp e a contagem acima de
100 bp são estáveis nas duas tentativas e são os que ficaram no texto.

### I5 (Important) -- "sobe monotonicamente" era falso; pico de mercado errado

```
implicita: quedas em jan->fev/2020 (6.986177 -> 6.960800),
           jan->fev/2022 (8.549002 -> 8.545612),
           out->dez/2023 (8.567947 -> 8.533257)
mercado: pico real em 2024-12-31 = 15.6813% (nao 14.8520%, que e jan/2025)
serie continua ate 2026-06-30: implicita 12.488484, mercado 14.2984
```

Corrigido nas três cópias (`convencoes-dv.md`, `dicionario-de-dados.md` via
a nota de `estoque_titulos_vencimento.csv`, e a spec da camada de dados):
"sobe de forma geral, não estritamente monotônica", com os pontos datados
(jan/2020, jan/2026) e o pico de mercado corrigido para 15,68% em
dez/2024.

### Minors corrigidos

- `taxa_por_papel.csv`: exemplo de deságio negativo da LFT trocado de
  "-0,39%" (inventado, não existe no arquivo) para o mínimo real,
  **-0,0903%** (935 das 2.522 linhas de LFT são negativas), com a nota de
  que o mínimo do arquivo inteiro (-4,2102%) é da NTN-B, não da LFT.
- `dv_alvo`: "`0.0` se `venceu_no_caminho`" ganhou a exceção medida -- 18
  das 286 linhas vencidas ficam vazias (as que já não tinham `dv_base`
  conhecido na base).
- Nota de `financeiro_milhoes`: corrigida a atribuição errada de que
  `dv_por_papel.csv` "usa" essa coluna para o cruzamento -- quem cruza é
  `tests/test_coerencia_dv.py`; `dv_por_papel.csv` nem tem essa coluna.
- `README.md`: "`sys.path`" trocado por uma frase sem jargão de
  desenvolvedor ("ensina o Python a achar o código sozinho").
- Este relatório: a descrição da janela de `resultado_decomposto()`
  corrigida de "2025-07-31 a 2026-06-30" (11 períodos se lida como
  `data_ini`) para "`data_ini` de 2025-06-30 a `data_fim` de 2026-06-30
  (doze períodos mensais)" -- os números publicados sempre vieram da
  janela certa (o código usava `data_fim > 2025-06-30`, doze períodos);
  só a descrição em prosa estava ambígua.

### Verificação final (rodada 2)

```
PYTHONPATH=src python -m pytest tests/ -q
```

**294 passed, 1 skipped** -- sem regressão. `git status --short` mostra só
`.md` modificados (`README.md`, `docs/convencoes-dv.md`,
`docs/dicionario-de-dados.md`,
`docs/superpowers/specs/2026-08-14-camada-de-dados-design.md`); nenhum
`.py` tocado.

### Novo commit

Ver hash na resposta final desta rodada.

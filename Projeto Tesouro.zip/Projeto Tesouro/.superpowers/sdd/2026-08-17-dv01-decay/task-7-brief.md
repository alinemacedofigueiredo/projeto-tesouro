### Task 7: Cálculo pontual até uma data-alvo

**Files:**
- Modify: `src/tesouro/dv.py`
- Test: `tests/test_decay.py` (acrescentar)

**Interfaces:**
- Consumes: `dv.painel()`, `dv._decay_de`
- Produces:
  - `dv.pontual(data_alvo, data_base=None) -> dict` com as chaves `data_base`, `data_alvo`, `dv_base`, `dv_que_vence`, `decay_sobreviventes`, `dv_alvo`, `por_titulo` (DataFrame)
  - `dv.main(argumentos=None)` — comando de linha

**Contexto:** este é o número que a mesa vai olhar no dia a dia: *da posição de hoje, quanto do meu DV some até tal data*. A decomposição da spec:

```
DV na data-base
(−) DV que vence no caminho
(−) decay dos sobreviventes
= DV na data-alvo
```

A identidade tem de fechar por construção: `dv_alvo == dv_base + dv_que_vence + decay_sobreviventes`, onde `dv_que_vence` é negativo do ponto de vista do total (o DV somiu) — atenção ao sinal, e o teste verifica.

`data_base` ausente significa o último fim de mês disponível no painel.

- [ ] **Step 1: Acrescente os testes que falham**

```python
# acrescentar em tests/test_decay.py
from datetime import date


def test_pontual_fecha_a_identidade():
    r = dv.pontual(date(2027, 12, 31))
    soma = r["dv_base"] + r["dv_que_vence"] + r["decay_sobreviventes"]
    assert abs(soma - r["dv_alvo"]) < 1e-6


def test_pontual_separa_o_que_vence():
    # Ate o fim de 2027 vence bastante papel; a parcela nao pode ser zero.
    r = dv.pontual(date(2027, 12, 31))
    assert r["dv_que_vence"] != 0
    assert r["dv_base"] < 0            # convencao de sinal
    assert abs(r["dv_alvo"]) < abs(r["dv_base"])


def test_pontual_por_titulo_soma_o_total():
    r = dv.pontual(date(2027, 12, 31))
    assert set(r["por_titulo"]["titulo"]) <= {"LTN", "NTN-F", "NTN-B"}
    assert abs(r["por_titulo"]["dv_base"].sum() - r["dv_base"]) < 1e-6


def test_pontual_recusa_data_no_passado():
    with pytest.raises(ValueError, match="posterior"):
        dv.pontual(date(2010, 1, 31))


def test_pontual_em_data_muito_distante_zera_tudo():
    # Depois de 2060 nao sobra papel vivo.
    r = dv.pontual(date(2070, 1, 2))
    assert abs(r["dv_alvo"]) < 1e-6
```

- [ ] **Step 2: Rode e confirme que falham**

Run: `PYTHONPATH=src python -m pytest tests/test_decay.py -k pontual -v`
Expected: FAIL com `AttributeError: module 'tesouro.dv' has no attribute 'pontual'`

- [ ] **Step 3: Acrescente o pontual e o comando ao `dv.py`**

```python
def pontual(data_alvo, data_base=None):
    """Decompoe a queda de DV entre duas datas.

    Responde a pergunta do dia a dia: da posicao de hoje, quanto do DV
    some ate a data-alvo, e quanto disso e vencimento em vez de encurtar.
    """
    cal = calendario.padrao()
    p = painel()
    p = p[p["titulo"] != "LFT"]

    if data_base is None:
        data_base = max(p["data"])
    if data_alvo <= data_base:
        raise ValueError(
            f"a data-alvo ({data_alvo}) precisa ser posterior a data-base "
            f"({data_base})"
        )

    grupo = p[p["data"] == data_base]
    linhas = _decay_de(cal, grupo, data_base, data_alvo, "pontual")
    df = pd.DataFrame(linhas, columns=_COLUNAS_DECAY)

    vence = df[df["venceu_no_caminho"]]
    vive = df[~df["venceu_no_caminho"]]
    resumo = {
        "data_base": data_base,
        "data_alvo": data_alvo,
        "dv_base": df["dv_base"].sum(),
        "dv_que_vence": -vence["dv_base"].sum(),
        "decay_sobreviventes": vive["decay"].sum(),
        "dv_alvo": df["dv_alvo"].sum(),
    }
    resumo["por_titulo"] = (
        df.groupby("titulo")
          .agg(dv_base=("dv_base", "sum"), dv_alvo=("dv_alvo", "sum"),
               papeis=("isin", "nunique"),
               vencendo=("venceu_no_caminho", "sum"))
          .reset_index()
    )
    return resumo


def _formatar(r):
    linhas = [
        f"posicao em {r['data_base']}, projetada para {r['data_alvo']}",
        "",
        f"  DV na data-base           {r['dv_base']:14,.2f}",
        f"  (-) DV que vence          {r['dv_que_vence']:14,.2f}",
        f"  (-) decay dos que vivem   {r['decay_sobreviventes']:14,.2f}",
        f"  DV na data-alvo           {r['dv_alvo']:14,.2f}",
        "",
        "valores em R$ milhoes por bp; negativo = mercado perde na alta de taxa",
        "",
        r["por_titulo"].to_string(index=False),
    ]
    return "\n".join(linhas)


def main(argumentos=None):
    import argparse
    from datetime import datetime

    analisador = argparse.ArgumentParser(
        description="Decay do DV01 ate uma data-alvo. Requer PYTHONPATH=src."
    )
    analisador.add_argument("--alvo", required=True,
                            help="data-alvo, no formato DD/MM/AAAA")
    analisador.add_argument("--base", default=None,
                            help="data-base; o padrao e o ultimo mes do painel")
    analisador.add_argument("--figura", default=None,
                            help="caminho para gravar o grafico (opcional)")
    opcoes = analisador.parse_args(argumentos)

    ler = lambda s: datetime.strptime(s, "%d/%m/%Y").date()
    r = pontual(ler(opcoes.alvo), ler(opcoes.base) if opcoes.base else None)
    print(_formatar(r))
    if opcoes.figura:
        from . import figuras
        figuras.grafico_pontual(r, opcoes.figura)
        print(f"\nfigura: {opcoes.figura}")


if __name__ == "__main__":
    main()
```

- [ ] **Step 4: Rode os testes e confirme que passam**

Run: `PYTHONPATH=src python -m pytest tests/test_decay.py -v`
Expected: PASS, 14 testes

- [ ] **Step 5: Rode o comando de verdade**

Run: `PYTHONPATH=src python -m tesouro.dv --alvo 31/12/2027`
Expected: imprime o quadro com a decomposição e a quebra por título.

- [ ] **Step 6: Commit**

```bash
git add src/tesouro/dv.py tests/test_decay.py
git commit -m "Adiciona calculo pontual de decay ate uma data-alvo"
```

---


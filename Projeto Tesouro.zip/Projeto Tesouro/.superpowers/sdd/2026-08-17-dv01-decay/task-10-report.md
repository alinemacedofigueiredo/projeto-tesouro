# Tarefa 10: Testes de coerência e integração no pipeline -- relatório

## O que foi feito

`tests/test_coerencia_dv.py` (novo), 7 testes, e `src/tesouro/pipeline.py`
(modificado) para chamar `parse_bloomberg`, `dv` e `figuras` depois do RMD.

Todos os cruzamentos usam `config.PROCESSED_DIR`/`config.BLOOMBERG_DIR`, nunca
caminho relativo ao diretório de trabalho -- o brief original escrevia
`pd.read_csv("data/processed/...")`, que só funciona se o pytest for chamado
da raiz; corrigido ao transcrever.

## Os testes de coerência, o que cada um mediu e o que pegaria se quebrasse

### 1. `test_pu_vezes_quantidade_bate_com_o_financeiro_do_tesouro`

**Mediu:** cruza `pu * quantidade_mil / 1000` (nossa marcação a mercado) com
`financeiro_milhoes` da aba 2.2, em 8.794 pares papel-mês. Mediana do erro
relativo por título, nesta sessão:

| título | mediana do erro relativo |
|---|---|
| LFT (controle) | -0,02% |
| LTN (controle) | +0,01% |
| NTN-F | +0,36% |
| NTN-B | +1,95% |

**Responde a pergunta em aberto da spec da camada de dados:** LFT e LTN (sem
cupom futuro embutido no PU) batem com o financeiro do Tesouro dentro de
poucos bp -- controle de que a fórmula e a unidade estão certas. NTN-F e
NTN-B (cupom semestral) divergem de forma sistemática e positiva, na mesma
direção -- a assinatura de que **o financeiro da aba 2.2 é marcação NA
CURVA, não a mercado**. Consequência numérica conferida à parte: a cobertura
do DV01 em 30/06/2026 sai 46,5% pela base do RMD e 43,3% pela nossa marcação
a mercado -- os 3,3 pp são o desconto de marcação.

**O que pegaria se quebrasse:** um erro de escala/unidade do nosso lado
apareceria no controle (LFT/LTN saindo da banda de 25 bp) -- o teste distingue
isso de uma mudança na convenção de marcação do Tesouro (NTN-F/NTN-B saindo
das faixas medidas). Confirmado por mutação: trocar `_INDICE_DO_TITULO`
(NTN-B<->SELIC, LFT<->IPCA) em `dv.py` faz a mediana de NTN-B disparar para
~-8% e a de LFT sair da banda de controle -- o teste quebra.

### 2. `test_ntnb_2050_tem_taxa_implicita_cravada_no_financeiro_do_tesouro`

**Mediu:** a taxa que reproduz `financeiro_milhoes/quantidade_mil*1000` da
NTN-B 15/05/2050 (ISIN `BRSTNCNTB3D4`), obtida por bissecção sobre
`precificacao.pu_ntnb` (o motor não tem solver de yield). Confirmado nesta
sessão: de 2014 em diante a implícita fica entre 5,33% e 5,56% (a asserção
usa uma banda um pouco mais larga, 5,2%-5,7%, para não travar em ruído de
bissecção), enquanto a taxa de mercado (`taxa_pct`) no mesmo papel varia de
3,26% a 7,64%.

**É a evidência mais direta do achado do item 1:** uma "taxa" que fica presa
numa banda estreita por mais de uma década enquanto o mercado real se move
livremente só é possível se o número não vier do mercado -- é o preço de uma
curva interna do Tesouro, não da negociação secundária.

**O que pegaria se quebrasse:** confirmado por mutação (mesma troca de
`_INDICE_DO_TITULO` do item 1) -- a implícita sai da banda 5,2%-5,7% e some
para a casa de 14%-26% em poucos anos, porque o VNA errado desloca o
financeiro implícito por completo.

### 3. `test_pu_reproduz_o_preco_da_bloomberg_com_deslocamento_de_d1`

**Mediu:** nada nesta rodada -- **pula** com mensagem explícita, porque
`data/raw/bloomberg/bbg_precos_*.csv` não existe. A usuária exige autorizar
cada consulta à Bloomberg caso a caso e não autorizou esta; o teste não tenta
puxar o arquivo. Mensagem do skip:

```
sem bbg_precos_*.csv em data/raw/bloomberg/: este teste cruza o PU calculado
contra o PX_DIRTY_MID da Bloomberg (fonte ANDE), e a usuaria exige autorizar
cada consulta a Bloomberg caso a caso -- consulta ainda nao autorizada. Peca
a ela para autorizar e rodar a coleta de precos, e colocar o(s) arquivo(s)
'bbg_precos_*.csv' em data/raw/bloomberg/ antes de habilitar este teste.
```

O código já aplica o deslocamento D+1 (liquidação em D+1, e na NTN-B o VNA de
D+1 também) para quando o arquivo existir -- inclui NTN-B além de NTN-F/LTN
(o rascunho do brief definia o dicionário de VNA por IPCA mas nunca o usava
no laço, e restringia a comparação a NTN-F/LTN só; corrigido aqui para cobrir
os três títulos, coerente com a validação de 438 pares já documentada em
`docs/convencoes-dv.md`).

**O que pegaria se quebrasse, quando habilitado:** se a produção fosse
"corrigida" para D+0/D+1 misturado, ou se o deslocamento fosse removido, a
mediana do erro sairia de perto de zero para a mediana pré-D+1 documentada
(-5 bp em LTN/NTN-F, -1,95 bp em NTN-B) -- a mensagem de erro do teste avisa
explicitamente para reler `docs/convencoes-dv.md` antes de mexer em
`precificacao.py`.

### 4. `test_vna_e_o_mesmo_entre_papeis_do_indice`

**Mediu:** para NTN-B e LFT, agrupado por data no painel (9.366 linhas):
todas as 198 datas de cada título têm 2 ou mais ISINs distintos com VNA
não-nulo, e o VNA é idêntico entre eles em 100% das datas.

**Cuidado do brief, tratado explicitamente:** `docs/convencoes-dv.md` avisa
que 16 das 198 datas de IPCA na colheita bruta da Bloomberg têm um só papel,
e divergência zero ali não prova nada. No **painel do projeto** (que só tem
NTN-B, não o universo IPCA inteiro da colheita -- NTN-B Principal, RendA+,
EducA+ ficam fora por decisão de escopo), isso não ocorre: confirmei que as
198 datas de NTN-B e as 198 de LFT no painel sempre têm 2+ ISINs. O teste
verifica isso (`n_papeis >= 2`) **antes** de exigir VNA único, para nunca
aprovar uma comparação vácua sem avisar.

**O que pegaria se quebrasse:** um VNA por papel (em vez de por índice) ou um
lookup errado de índice faria `n_vna == 1` falhar. A mesma mutação do item 1
(`_INDICE_DO_TITULO` trocado) **não** quebra este teste -- é esperado: a
troca ainda produz um valor único e consistente por (título, data), só que o
errado; quem pega essa mutação especificamente é
`tests/test_dv.py::test_vna_casa_com_o_indice_certo_por_titulo`, já existente.

### 5. `test_papel_vencido_residual_sem_taxa_fica_com_dv_vazio_nao_zero`

**Mediu:** exatamente 1 linha no painel com `vencimento < data`
(`BRSTNCNTF071`, NTN-F, vencimento 2014-01-01, ainda em estoque em
2014-01-31), e ela tem `taxa_pct`, `pu` e `dv_unitario` todos vazios (não
zero).

**Nota de processo:** a primeira versão deste teste (copiada do padrão
`test_dv_de_papel_vencido_nao_aparece_no_painel` do brief) presumia que papel
vencido nunca aparece no painel -- **essa premissa é falsa** no dado real, e
rodar contra o dado de verdade (em vez de só ler o brief) pegou o erro antes
que ele virasse uma trava incorreta. O caso real existente é justamente o que
prova a distinção do item 4 do enunciado da tarefa: "não se aplica" (aqui,
porque a taxa nunca foi conhecida) fica vazio, não zero. O caso complementar
(vencido COM taxa conhecida, DV genuinamente 0.0) só ocorre em dado sintético
hoje e já está travado, linha a linha, em
`tests/test_dv.py::test_papel_vencido_com_taxa_fica_com_dv_zero_e_nao_none` e
`tests/test_decay.py::test_papel_vencido_tem_dv_alvo_zero_quando_o_risco_de_partida_era_conhecido`
-- não duplicado aqui.

**O que pegaria se quebrasse:** se um novo caso de estoque residual aparecer
(contagem != 1) ou se este caso passar a ter taxa preenchida por engano
(bug de leitura que atribuísse uma taxa de outro papel/data), o teste falha e
aponta exatamente qual investigar.

### 6. Aditividade do decay -- **nenhum teste novo adicionado, por decisão**

Já travada na Tarefa 6, em
`tests/test_decay.py::test_cada_horizonte_bate_com_a_soma_dos_passos_diarios_equivalentes`,
por identidade telescópica exata -- mais forte que a comparação aproximada
que o brief desta tarefa pedia (`test_decay_diario_soma_o_decay_de_21_dias`):
a identidade telescópica pega um off-by-one de dias úteis com folga de 760
mil vezes a tolerância, enquanto a banda de convexidade real (13,6% medida no
histórico) seria larga demais para pegar o mesmo defeito. Escrever a versão
mais fraca do brief por cima seria regressão de rigor, não adição; conforme
instruído, não substituí o que já existe.

Em vez disso, adicionei um cruzamento complementar (não duplicado):

**`test_horizonte_de_21du_bate_com_o_recalculo_direto`** -- mediu: para uma
linha real e viva do decay em `horizonte == "21du"`, `cal.du(data_base,
data_alvo) == 21` e `dv_alvo` bate (tolerância 1e-9) com uma reprecificação
independente via `precificacao.dv` chamada diretamente pelo teste (não pelo
código sob teste). **O que pegaria:** confirmado por mutação -- mudar
`HORIZONTES["21du"]` de 21 para 22 em `dv.py` faz `cal.du(...) == 21` falhar
imediatamente (`22 == 21`), o erro mais grosseiro possível (horizonte mapeado
para o número errado de dias), que um teste de forma não pegaria porque o
resultado continua com a cara certa.

### 7. `test_linhas_vivas_sem_pu_fim_sao_exatamente_oito`

**Mediu:** em `resultado_mensal()` (9.314 linhas), exatamente **8** linhas
têm `pu_ini` conhecido, não venceram no período (`venceu_no_periodo ==
False`) e mesmo assim ficam com `pu_fim` vazio -- o ISIN some do painel do
mês seguinte sem ter vencido (dado de origem da época, não defeito do
parser). Somam **R$ 291.954,8 milhões** de financeiro
(`pu_ini * quantidade_mil_ini / 1000`), todas entre 2010-02 e 2011-08,
nenhuma nos últimos doze meses do painel.

**Por que existe:** invariante pedida pela usuária, fora do brief original.
Ela decidiu, no fim da branch, não mudar o schema para distinguir esse caso
de "não se aplica" -- este teste garante que a contagem não cresça em
silêncio.

**O que pegaria se quebrasse:** confirmado por mutação -- a mesma troca de
`_INDICE_DO_TITULO` do item 1 muda os PUs da LFT o bastante para que o
financeiro somado das 8 linhas caia de R$ 291.954,8 mi para R$ 150.956,0 mi
(a contagem de 8 linhas continua igual, mas o valor não bate) -- a asserção
de financeiro pega isso mesmo quando a contagem não muda.

## Verificação por mutação (não só leitura do assert)

Para as asserções centrais, apliquei a disciplina do brief de forma mais
forte que apagar uma linha: mutei a **produção** (não o teste) e confirmei a
falha, depois reverti com `git checkout --`.

1. `_INDICE_DO_TITULO = {"NTN-B": "SELIC", "LFT": "IPCA"}` (troca de índice)
   -- quebrou os itens 1, 2 e 7 (financeiro, NTN-B cravada, 8-linhas); **não**
   quebrou o item 4 (VNA único), como esperado e explicado acima.
2. `HORIZONTES = {"1du": 1, "5du": 5, "21du": 22}` -- quebrou o item 6
   (recalculo direto), com a mensagem `assert 22 == 21`.

Ambas revertidas (`git checkout -- src/tesouro/dv.py`); suite confirmada
limpa depois.

## Integração com o pipeline

`src/tesouro/pipeline.py`, dentro de `main`, depois de `parse_rmd.gravar_tudo()`:

```python
print("\n--- bloomberg ---")
from . import parse_bloomberg
parse_bloomberg.gravar()

print("\n--- dv01 e decay ---")
from . import dv as _dv
_dv.gravar_painel()
_dv.gravar_decay()
_dv.gravar_resultado()

print("\n--- figuras ---")
from . import figuras
figuras.gravar_todas()
```

E, dentro do bloco `if not opcoes.sem_coleta`, junto dos outros coletores:

```python
from . import fetch_bloomberg
try:
    fetch_bloomberg.baixar()
except Exception as erro:               # noqa: BLE001
    print(f"coleta da Bloomberg pulada: {erro}")
```

**As duas restrições que não podiam quebrar, verificadas:**

- **`--sem-coleta` nunca toca rede.** O import de `fetch_bloomberg` (como os
  outros coletores) fica dentro do bloco `if not opcoes.sem_coleta`, e o novo
  bloco de `parse_bloomberg`/`dv`/`figuras` (que só lê `data/processed/`) fica
  fora desse `if`, sempre executado -- nenhum coletor é importado quando
  `--sem-coleta` é passado. Confirmado rodando `python -m tesouro.pipeline
  --sem-coleta` de ponta a ponta (abaixo): nenhuma tentativa de rede, nenhum
  traceback de `urllib`/timeout.
- **`data/raw/` não foi tocado.** `git status --short data/raw/` ficou vazio
  antes e depois da corrida do pipeline (a pasta é gitignorada por inteiro,
  então qualquer escrita nova apareceria como untracked); os dois arquivos
  Bloomberg em `data/raw/bloomberg/` mantiveram o mtime de antes da sessão.
  Nenhum teste novo escreve fora de `tmp_path`/`config.PROCESSED_DIR`.

### Corrida real do pipeline

PowerShell:

    $env:PYTHONPATH="src"; python -m tesouro.pipeline --sem-coleta

bash:

    PYTHONPATH=src python -m tesouro.pipeline --sem-coleta

Gerou os 22 CSVs esperados em `data/processed/` (17 da camada de dados + 5
novos: `taxa_por_papel.csv`, `vna.csv`, `dv_por_papel.csv`,
`decay_por_papel.csv`, `resultado_mensal.csv`) mais as duas figuras em
`data/processed/figuras/`. Linhas conferidas: `dv_por_papel.csv` 9.366,
`decay_por_papel.csv` 20.115, `resultado_mensal.csv` 9.314 -- batem com as
âncoras do enunciado.

## Resultado dos testes

PowerShell: `$env:PYTHONPATH="src"; python -m pytest tests/test_coerencia_dv.py -v`
bash: `PYTHONPATH=src python -m pytest tests/test_coerencia_dv.py -v`
-- **6 passed, 1 skipped** (o teste da Bloomberg, com a mensagem explicada acima).

PowerShell: `$env:PYTHONPATH="src"; python -m pytest tests/ -q`
bash: `PYTHONPATH=src python -m pytest tests/ -q`
-- **286 passed, 1 skipped** (280 anteriores + 7 novos = 287; a diferença é o skip). Sem regressão. Ver "Revisão (rodada 2)" abaixo para o resultado após as correções pedidas.

## Autorrevisão

- **Achado corrigido durante a escrita, não depois:** o teste
  `test_dv_de_papel_vencido_nao_aparece_no_painel` do brief falhou ao rodar
  contra o dado real (existe 1 linha real com estoque residual pós-
  vencimento). Investiguei antes de "consertar" o teste com um `!= 0`
  qualquer -- confirmei que é o caso documentado `BRSTNCNTF071` (já citado
  em comentários de `test_dv.py`/`test_decay.py`) e reescrevi o teste para
  afirmar o comportamento real e correto (vencido residual sem taxa fica
  vazio, não zero), em vez de uma ausência que a produção nunca garantiu.
- **Ampliei o escopo do teste 3 além do brief:** o rascunho do brief
  definia `ipca = {...}` (VNA por data, para o deslocamento de D+1 na
  NTN-B) mas nunca usava esse dicionário, e restringia a comparação a
  NTN-F/LTN. Como o teste está pulado por falta de arquivo, a diferença só
  importa no dia em que for habilitado -- mas deixá-lo correto agora evita
  que alguém habilite o arquivo e receba um teste incompleto (faltando
  NTN-B, que é 210 dos 438 pares já validados a mão).
  Corrigido para incluir NTN-B com o VNA de D+1.
  Também troquei os caminhos hardcoded (`"data/raw/bloomberg/..."`) por
  `config.BLOOMBERG_DIR`/`config.PROCESSED_DIR`, por instrução direta da
  usuária.
- **Reconferi os 5 padrões de defeito listados no enunciado:** nenhuma
  asserção usa `or` com uma cláusula sempre-verdadeira; nenhuma banda tem
  mais que ~4x de folga (a maior é a de NTN-B, 0,01-0,04, cerca de 2x em
  torno do valor medido); nenhum valor esperado é derivado da constante sob
  teste (os "21" dias do item 6 e os "8" do item 7 são literais, não lidos
  de `dv.HORIZONTES` nem recalculados a partir do próprio resultado); e este
  relatório documenta comandos PowerShell/bash corretamente nos poucos
  lugares em que apareceram.
- Todos os arquivos (`tests/test_coerencia_dv.py`, `src/tesouro/pipeline.py`)
  confirmados ASCII puro (`open(..., encoding="ascii")` sem erro).

## Preocupações

- O teste da Bloomberg (item 2 do enunciado) continua sem rodar de verdade
  nesta branch -- é uma decisão da usuária, não uma lacuna a resolver aqui,
  mas significa que a validação de 438 pares documentada em
  `docs/convencoes-dv.md` não é re-verificada automaticamente até que o
  arquivo `bbg_precos_*.csv` exista.
- A cobertura de taxa (93,89% dos pares papel-mês, 99,23% ponderada pelo
  financeiro, citada no enunciado da tarefa) não ganhou teste dedicado --
  não estava entre os 6 itens numerados nem no brief, e não é um
  cruzamento entre fontes independentes (é uma estatística interna de
  `taxa_por_papel.csv`). Sinalizando aqui para que a usuária confirme que
  isso está fora do escopo desejado desta tarefa.
- A bissecção do item 2 (taxa implícita da NTN-B 2050) roda 60 iterações por
  linha sobre ~150 linhas -- rápido (frações de segundo), mas é a única
  conta do arquivo que não é vetorizada; se o padrão for repetido para
  outros papéis no futuro, vale extrair um helper de bissecção genérico em
  vez de copiar a função interna do teste.

## Revisão (rodada 2): 1 Critical e 5 Important

A revisão aprovou a conformidade (âncoras exatas, `data/raw/` intocado,
`--sem-coleta` verificado por AST e empiricamente com socket bloqueado,
aditividade do decay não duplicada) mas reprovou a qualidade. Correções, uma
por achado, todas no commit `0610109`.

### 1 (Critical) -- guarda cega a um terço do painel perdido

`tests/test_coerencia_dv.py::test_pu_vezes_quantidade_bate_com_o_financeiro_do_tesouro`
usava `assert len(j) > 5000`. O revisor refez a junção por **data literal**
(sem `ultimo_dia_util_do_mes`) e mostrou que ela perde 30,9% do painel
(6.074 de 9.366 linhas) e ainda assim passa em todas as asserções, porque os
6.074 sobreviventes são pares legítimos e as medianas mal se movem.

Troquei a guarda por `len(j) >= 0.93 * len(p)` (8.710 de 9.366), ancorada no
tamanho do próprio painel em vez de uma constante solta. Confirmado por
mutação (reproduzindo a junção por data literal do revisor, à mão, fora do
teste): 6.074 é menor que 8.710 -- a guarda nova derruba exatamente o caso
que a antiga deixava passar.

### 2 (Important) -- teste de VNA estruturalmente infalsificável

O teste rodava contra `dv.painel()`, agrupando por `(titulo, data)` e
conferindo `nunique(vna) == 1`. `dv.py:73-79` monta o dicionário `vna_por`
chaveado por `(data, indice)`, **sem ISIN** -- todo papel do mesmo título na
mesma data recebe o mesmo valor por construção, então o teste só podia dar 1,
sempre; a mutação de `_INDICE_DO_TITULO` que derruba três outros testes não
move este em nada, como o revisor mediu.

Removido o teste antigo. No lugar,
`test_vna_nao_diverge_entre_papeis_na_colheita_bruta` lê o arquivo **bruto**
da colheita (`bbg_vna_*.csv`, colunas `n_papeis`/`divergencia`) direto de
`config.BLOOMBERG_DIR` -- o cruzamento de verdade, entre papéis cotados de
forma independente pela Bloomberg, antes do dicionário de `dv.py` colapsar
tudo. Confere: 16 datas de IPCA com um só papel (vácuas, excluídas antes da
asserção principal) contra 0 datas de SELIC; divergência menor ou igual a
R$0,50 em todas as datas com 2+ papéis, para os dois índices. O limiar de
0,50 é escrito como literal no teste, não importado de
`parse_bloomberg._TOLERANCIA_DIVERGENCIA`, para que uma mudança de tolerância
na produção não arraste esta trava junto sem ninguém perceber.

### 3 (Important) -- bandas de controle com 11x/27x de folga

Medianas reais: LFT -0,0221%, LTN +0,0092%; limiar antigo 0,25% (11,3x e
27,1x de folga). Um erro de 0,24% no controle passaria calado e vale, em
30/06/2026, cerca de R$ 3,0 bilhões no livro de LTN e R$ 11,0 bilhões no de
LFT.

Apertei para 0,06% (LFT) e 0,03% (LTN) -- folga de cerca de 2,7x e 3,3x, na
mesma ordem das faixas de NTN-F (2,8x-3,6x) e NTN-B (cerca de 2x) que já
estavam corretas. A autorrevisão original tinha afirmado "nenhuma banda tem
mais que ~4x de folga" -- isso era falso, e é exatamente o tipo de
afirmação não verificada que a rodada anterior deveria ter pego. Não repeti
o erro: os números acima (11,3x/27,1x antigos, 2,7x/3,3x novos) vêm de rodar
o teste com os valores reais impressos, não de estimativa.

### 4 (Important) -- `except Exception` funde rotina com falha real

`src/tesouro/pipeline.py` tratava `RuntimeError("nada novo a coletar")`
(caso saudável: painel já em dia) e qualquer falha real (blpapi ausente,
sessão recusada, arquivo corrompido, estoque ausente) sob a mesma linha
neutra "coleta da Bloomberg pulada", sempre com código de saída 0. Corrigido:

- `except RuntimeError` isolado para o caso benigno -- mensagem neutra, sem
  alarme, não entra na lista de falhas.
- `except Exception` (qualquer outra exceção) marca falha real: prefixo
  `ATENCAO:`, guardada numa lista `falhas`.
- Se `falhas` não está vazia ao final, o resumo é repetido perto de
  "concluído" (não só uma linha no topo do log) e `main()` devolve `1` em
  vez de `0` -- `sys.exit(main())` propaga o código não-zero.
- Comentário novo documentando que `from . import fetch_bloomberg` (fora do
  `try`) é seguro porque `import blpapi` mora dentro de
  `fetch_bloomberg._sessao()`, travado por
  `tests/test_fetch_bloomberg.py::test_nao_importa_blpapi_no_topo`.

Confirmado por mutação: revertendo o `except` para a forma antiga (um só
`except Exception`, mensagem "pulada"), os dois testes que verificam falha
real (`ConnectionError` e `ModuleNotFoundError`) quebram com
`assert 0 != 0` -- a evidência de que a correção é o que os faz passar, não
coincidência.

### 5 (Important) -- `pipeline.py` sem nenhum teste

Novo `tests/test_pipeline.py`, 7 testes, todos com monkeypatch nas funções
de gravação/coleta reais (sem IO pesado, sem dado real necessário):

1. `test_sem_coleta_nunca_toca_rede` -- bloqueia `socket.socket` e
   `socket.getaddrinfo` para levantar `AssertionError` se chamados, roda
   `pipeline.main(["--sem-coleta"])` de verdade. Mesmo método usado pelo
   revisor à mão.
2. `test_sem_coleta_nao_importa_nenhum_coletor_no_topo_do_modulo` -- AST,
   no molde de `test_nao_importa_blpapi_no_topo`: nenhum dos três
   coletores pode aparecer num import de nível de módulo.
3. `test_pipeline_grava_as_sete_etapas_na_ordem_certa` -- contrato: as sete
   chamadas de gravação (`parse_leiloes.gravar` -> `parse_rmd.gravar_tudo`
   -> `parse_bloomberg.gravar` -> `dv.gravar_painel` -> `dv.gravar_decay`
   -> `dv.gravar_resultado` -> `figuras.gravar_todas`) acontecem
   exatamente uma vez, nessa ordem -- a ordem importa porque cada etapa lê
   o que a anterior gravou.
4. `test_coleta_sem_novidade_nao_e_tratada_como_falha` -- `RuntimeError`
   ("nada novo") dá código 0, sem `ATENCAO` na saída.
5. `test_coleta_com_falha_real_fica_marcada_e_derruba_o_codigo_de_saida` --
   `ConnectionError` dá código diferente de zero, `ATENCAO` presente,
   inclusive depois de "--- figuras ---" (repetido perto do fim).
6. `test_coleta_com_blpapi_ausente_tambem_conta_como_falha_real` --
   `ModuleNotFoundError` cai no mesmo ramo de falha real, não no benigno.
7. `test_import_do_fetch_bloomberg_fica_fora_do_sem_coleta` -- com
   `--sem-coleta`, `fetch_bloomberg.baixar` nunca é chamado.

Não cobre a contagem exata dos 22 CSVs/linhas (isso continua verificado à
mão contra o dado real, registrado acima) -- o teste automatizado trava a
fiação (ordem, contrato de chamadas, invariante de rede, ramos do
try/except), que é o que o revisor pediu como "barato de travar por AST".

### 6 (Important) -- faltava o teste de cobertura de taxa

O revisor reproduziu por fora: 93,89% simples (8.794/9.366) e 99,23%
ponderado pelo financeiro, batendo exato com os números do enunciado da
tarefa -- e mostrou que uma junção de data quebrada do lado da taxa faz a
cobertura cair a 0,00%. Minha autorrevisão anterior tinha justificado a
ausência dizendo que não era "cruzamento entre fontes independentes" --
errado nos fatos: o numerador (taxa, Bloomberg) e o denominador (estoque,
RMD) são duas fontes publicadas de forma independente.

Novo teste, `test_cobertura_de_taxa_bate_com_a_medida_no_estoque`: cobertura
simples via `p["taxa_pct"].notna().sum() / len(p)` (93,89%, com
`pytest.approx` e tolerância de 0,1 ponto percentual) e ponderada pelo
financeiro bruto do RMD (99,23%). Como o revisor notou, o numerador desta
conta (8.794) é o mesmo `len(j)` do item 1 -- os dois se resolvem juntos:
uma junção de data quebrada derruba as duas guardas ao mesmo tempo.

### Minors

- Removida a asserção morta em
  `test_linhas_vivas_sem_pu_fim_sao_exatamente_oito` (as duas asserções de
  janela de data já implicam "não nos últimos doze meses" estritamente, e a
  forma antiga levantava `ValueError` sempre que a última data do painel
  caísse em 29 de fevereiro -- alcançável, já que 29/02/2024 é quinta-feira
  útil).
- Mensagem do skip do teste 2 reescrita para se dirigir a quem roda o
  pytest diretamente (segunda pessoa, não "peça a ela"), com os dois
  comandos para habilitar o teste (PowerShell primeiro, bash depois, padrão
  de `docs/como-baixar.md:6-12`).
- Teste da Bloomberg (item 2): mediana agora calculada por título (`NTN-F`,
  `LTN`, `NTN-B` separados), não num balaio só -- evita que uma regressão
  isolada na NTN-B (210 dos 438 pares) se dilua contra LTN/NTN-F e passe.
  Limiar apertado de 0,5 bp para 0,05 bp (era 60x de folga sobre o máximo
  documentado de 0,0083 bp; agora cerca de 6x).
- Este relatório: os dois comandos que só apareciam em bash (rodar o
  pipeline e rodar a suíte) agora trazem PowerShell primeiro.

### Verificação por mutação (rodada 2)

Além da checagem já registrada acima (troca de `_INDICE_DO_TITULO`,
reconfirmada contra os testes novos/reescritos desta rodada), fiz duas
mutações novas, direto na produção, revertidas com `git checkout --`:

1. Junção por data literal (sem `ultimo_dia_util_do_mes`) reproduzida à mão
   fora do teste, confirmando que 6.074 é menor que 8.710 -- a guarda nova
   do item 1 quebra exatamente como o revisor previu.
2. `except` da coleta da Bloomberg revertido para a forma antiga (um só
   `except Exception`, mensagem "pulada") -- os dois testes de falha real
   em `tests/test_pipeline.py` quebraram (`assert 0 != 0`), confirmando que
   a correção do item 4 é o que os faz passar.

### Resultado dos testes (rodada 2)

PowerShell: `$env:PYTHONPATH="src"; python -m pytest tests/ -q`
bash: `PYTHONPATH=src python -m pytest tests/ -q`

**294 passed, 1 skipped** (286 da rodada 1 + 8 novos: 1 teste de cobertura
de taxa em `test_coerencia_dv.py` + 7 em `tests/test_pipeline.py`). Sem
regressão.

Pipeline real rodado de novo com `--sem-coleta` após todas as correções:
mesmos 22 CSVs, mesmas âncoras (`dv_por_papel.csv` 9.366, `decay_por_papel.csv`
20.115, `resultado_mensal.csv` 9.314), exit code 0, `data/raw/` intocado
(confirmado por `git status --short data/raw/` vazio antes e depois -- a
pasta é gitignorada por inteiro).

### Novo commit

`0610109` -- "Corrige achados da revisao de qualidade da Tarefa 10".

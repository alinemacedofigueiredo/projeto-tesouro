### Task 3: Parser dos brutos da Bloomberg

**Files:**
- Create: `src/tesouro/parse_bloomberg.py`
- Test: `tests/test_parse_bloomberg.py`

**Interfaces:**
- Consumes: `config.BLOOMBERG_DIR`, `config.PROCESSED_DIR`, `calendario.padrao()`
- Produces:
  - `parse_bloomberg.parse_taxas(caminho=None) -> DataFrame` — colunas `data, isin, titulo, vencimento, taxa_pct`
  - `parse_bloomberg.parse_vna(caminho=None) -> DataFrame` — colunas `data, indice, vna`
  - `parse_bloomberg.gravar() -> None` — escreve `taxa_por_papel.csv` e `vna.csv`

**Contexto:** os brutos já estão em `data/raw/bloomberg/`. O de taxas tem `isin,titulo,vencimento,data,yld_ytm_mid`, com a taxa **em percentual** e a data no **último dia útil** do mês. O de VNA tem `data,indice,campo,fator,vna,n_papeis,divergencia`, com a data no **último dia corrido** — verificado durante o design que o VNA é idêntico nos dois, porque não acumula em dia não-útil.

O parser normaliza as duas para o **último dia útil do mês**, que é a chave de junção do projeto.

Os arquivos podem ser mais de um por pasta (a coleta é incremental): leia **todos** os `bbg_taxas_*.csv` e todos os `bbg_vna_*.csv`, concatene, e em caso de repetição fique com a última ocorrência.

- [ ] **Step 1: Escreva os testes que falham**

```python
# tests/test_parse_bloomberg.py
from datetime import date

import pandas as pd
import pytest
from tesouro import parse_bloomberg


@pytest.fixture(scope="module")
def taxas():
    return parse_bloomberg.parse_taxas()


@pytest.fixture(scope="module")
def vna():
    return parse_bloomberg.parse_vna()


def test_taxas_tem_as_colunas_canonicas(taxas):
    assert list(taxas.columns) == ["data", "isin", "titulo", "vencimento", "taxa_pct"]
    assert len(taxas) > 8000


def test_taxa_fica_em_percentual(taxas):
    # Convencao do projeto: 13.5 significa 13,5%.
    prefixados = taxas[taxas["titulo"] == "LTN"]["taxa_pct"]
    assert prefixados.median() > 5
    assert prefixados.median() < 20


def test_agio_da_lft_e_pequeno_e_pode_ser_negativo(taxas):
    lft = taxas[taxas["titulo"] == "LFT"]["taxa_pct"]
    assert lft.abs().median() < 1
    assert (lft < 0).any()


def test_datas_sao_dia_util(taxas):
    from tesouro import calendario
    cal = calendario.padrao()
    assert all(cal.eh_dia_util(d) for d in taxas["data"].head(500))


def test_vna_tem_as_colunas_canonicas(vna):
    assert list(vna.columns) == ["data", "indice", "vna"]
    assert set(vna["indice"].unique()) == {"IPCA", "SELIC"}


def test_vna_da_selic_nunca_cai(vna):
    # A Selic acumula sempre; queda indica erro de leitura.
    s = vna[vna["indice"] == "SELIC"].sort_values("data")["vna"]
    assert (s.diff().dropna() >= 0).all()


def test_vna_do_ipca_cai_em_meses_de_deflacao(vna):
    i = vna[vna["indice"] == "IPCA"].sort_values("data")["vna"]
    assert (i.diff().dropna() < 0).any()


def test_vna_em_ordem_de_grandeza_de_reais(vna):
    ult = vna[vna["data"] == vna["data"].max()].set_index("indice")["vna"]
    assert 4000 < ult["IPCA"] < 6000
    assert 15000 < ult["SELIC"] < 25000


def test_nao_ha_chave_duplicada(taxas, vna):
    assert not taxas.duplicated(subset=["data", "isin"]).any()
    assert not vna.duplicated(subset=["data", "indice"]).any()
```

- [ ] **Step 2: Rode e confirme que falham**

Run: `PYTHONPATH=src python -m pytest tests/test_parse_bloomberg.py -v`
Expected: FAIL com `ModuleNotFoundError: No module named 'tesouro.parse_bloomberg'`

- [ ] **Step 3: Implemente o `parse_bloomberg.py`**

```python
"""Converte os brutos da Bloomberg nas tabelas canonicas.

A coleta e incremental por desenho: cada puxada grava um arquivo novo em
data/raw/bloomberg/ e nada e sobrescrito. Por isso o parser le TODOS os
arquivos de cada tipo, concatena, e em caso de repeticao fica com a
ultima ocorrencia -- que e a puxada mais recente.

As duas fontes trazem a data em convencoes diferentes: a de taxas ja vem
no ultimo dia util do mes (e o que a periodicidade mensal da Bloomberg
devolve), e a de VNA vem no ultimo dia corrido, porque foi assim que o
override de SETTLE_DT foi pedido. Verificado durante o design que o VNA e
identico nos dois dias, porque nao acumula em dia nao util. As duas sao
normalizadas para o ultimo dia util, que e a chave de juncao do projeto.
"""
from pathlib import Path

import pandas as pd

from . import calendario, config


def _ler_todos(padrao, diretorio=None):
    diretorio = Path(diretorio) if diretorio else config.BLOOMBERG_DIR
    arquivos = sorted(diretorio.glob(padrao))
    if not arquivos:
        raise FileNotFoundError(
            f"nenhum arquivo {padrao!r} em {diretorio}; rode a coleta com "
            f"'python -m tesouro.fetch_bloomberg' ou coloque a exportacao "
            f"do BDH nessa pasta (veja docs/como-baixar.md)"
        )
    return pd.concat([pd.read_csv(a) for a in arquivos], ignore_index=True)


def parse_taxas(diretorio=None):
    """Taxa indicativa Anbima por papel e fim de mes, em percentual."""
    cal = calendario.padrao()
    df = _ler_todos("bbg_taxas_*.csv", diretorio)
    df["data"] = pd.to_datetime(df["data"]).dt.date.map(cal.ultimo_dia_util_do_mes)
    df["vencimento"] = pd.to_datetime(df["vencimento"]).dt.date
    df = df.rename(columns={"yld_ytm_mid": "taxa_pct"})
    df = df.drop_duplicates(subset=["data", "isin"], keep="last")
    return df[["data", "isin", "titulo", "vencimento", "taxa_pct"]].sort_values(
        ["data", "titulo", "isin"]
    ).reset_index(drop=True)


def parse_vna(diretorio=None):
    """VNA por indice e fim de mes, em reais.

    O VNA e por indice, nao por papel: verificado que o valor e identico
    entre papeis diferentes na mesma data, em todas as datas do painel.
    """
    cal = calendario.padrao()
    df = _ler_todos("bbg_vna_*.csv", diretorio)
    df["data"] = pd.to_datetime(df["data"]).dt.date.map(cal.ultimo_dia_util_do_mes)
    df = df.drop_duplicates(subset=["data", "indice"], keep="last")
    return df[["data", "indice", "vna"]].sort_values(
        ["data", "indice"]
    ).reset_index(drop=True)


def gravar():
    config.PROCESSED_DIR.mkdir(parents=True, exist_ok=True)
    for nome, df in (("taxa_por_papel", parse_taxas()), ("vna", parse_vna())):
        saida = config.PROCESSED_DIR / f"{nome}.csv"
        df.to_csv(saida, index=False, encoding="utf-8")
        print(f"gravado: {saida} ({len(df)} linhas)")


if __name__ == "__main__":
    gravar()
```

- [ ] **Step 4: Rode os testes e confirme que passam**

Run: `PYTHONPATH=src python -m pytest tests/test_parse_bloomberg.py -v`
Expected: PASS, 9 testes

- [ ] **Step 5: Grave os CSVs e confira**

Run: `PYTHONPATH=src python -m tesouro.parse_bloomberg`
Expected: grava `taxa_por_papel.csv` (~8.900 linhas) e `vna.csv` (396 linhas).

- [ ] **Step 6: Commit**

```bash
git add src/tesouro/parse_bloomberg.py tests/test_parse_bloomberg.py
git commit -m "Adiciona parser dos brutos da Bloomberg"
```

---


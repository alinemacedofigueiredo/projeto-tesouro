### Task 10: Testes de coerência e integração no pipeline

**Files:**
- Create: `tests/test_coerencia_dv.py`
- Modify: `src/tesouro/pipeline.py`

**Interfaces:**
- Consumes: tudo
- Produces: `pipeline` com as etapas novas

**Contexto:** estes são os testes que mais pegam, porque cruzam fontes independentes. Um deles responde de graça a pergunta que ficou aberta na spec da camada de dados: se `PU × quantidade` bate com o `financeiro` da aba 2.2, o número do Tesouro é marcação a mercado; se divergir de forma sistemática, é curva.

**O teste contra a Bloomberg precisa aplicar o deslocamento de D+1** — liquidação em D+1 e, na NTN-B, VNA em D+1 também. A produção calcula em D+0 por decisão. **Se este teste falhar, não mude a produção para D+0/D+1 sem antes reler `docs/convencoes-dv.md`**: o erro provável está no teste, não no cálculo.

- [ ] **Step 1: Escreva os testes de coerência**

```python
# tests/test_coerencia_dv.py
"""Cruzamentos entre fontes independentes.

Testes unitarios verificam que a funcao faz o que o autor achou que ela
fazia. Estes verificam contra numeros que outra pessoa publicou.
"""
from datetime import date

import pandas as pd
import pytest
from tesouro import calendario, dv, precificacao


@pytest.fixture(scope="module")
def p():
    return dv.painel()


@pytest.fixture(scope="module")
def cal():
    return calendario.padrao()


def test_vna_e_o_mesmo_entre_papeis_do_indice(p):
    # Verificado na coleta: divergencia exatamente zero. Se um dia dois
    # papeis discordarem, a data ou o campo mudaram.
    for titulo in ("NTN-B", "LFT"):
        sub = p[(p["titulo"] == titulo) & p["vna"].notna()]
        por_data = sub.groupby("data")["vna"].nunique()
        assert (por_data == 1).all(), f"{titulo} tem VNA divergente"


def test_pu_vezes_quantidade_bate_com_o_financeiro_do_tesouro(p):
    """Responde a questao aberta da spec da camada de dados.

    Se bater, o 'financeiro' da aba 2.2 e marcacao a mercado. Se divergir
    de forma sistematica e na mesma direcao, e marcacao na curva.
    """
    e = pd.read_csv("data/processed/estoque_titulos_vencimento.csv",
                    parse_dates=["data"])
    cal = calendario.padrao()
    e["data"] = e["data"].dt.date.map(cal.ultimo_dia_util_do_mes)
    j = p.merge(e[["data", "isin", "financeiro_milhoes"]], on=["data", "isin"],
                how="inner")
    j = j[j["financeiro_calculado_milhoes"].notna()
          & (j["financeiro_milhoes"] > 0)]
    assert len(j) > 5000

    j["erro_rel"] = (j["financeiro_calculado_milhoes"] / j["financeiro_milhoes"]) - 1
    mediana = j["erro_rel"].median()
    # Tolerancia larga de proposito: o objetivo e detectar erro de escala
    # ou de unidade, nao afinar convencao de marcacao.
    assert abs(mediana) < 0.05, (
        f"PU calculado difere do financeiro do Tesouro em {mediana:.2%} na "
        f"mediana; investigue antes de relaxar esta tolerancia"
    )


def test_pu_reproduz_o_preco_da_bloomberg_com_deslocamento_de_d1(cal):
    """A Bloomberg cota para liquidacao em D+1; a producao calcula em D+0.

    Este teste aplica o deslocamento. Se ele falhar, o erro provavel esta
    aqui e nao na producao -- leia docs/convencoes-dv.md antes de mexer no
    calculo.
    """
    bruto = pd.read_csv("data/raw/bloomberg/bbg_taxas_ANDE_2010-01_2026-06.csv",
                        parse_dates=["data", "vencimento"])
    vna = pd.read_csv("data/processed/vna.csv", parse_dates=["data"])
    vna["data"] = vna["data"].dt.date
    ipca = {r.data: r.vna for r in vna[vna["indice"] == "IPCA"].itertuples(index=False)}

    import pathlib
    precos = sorted(pathlib.Path("data/raw/bloomberg").glob("bbg_precos_*.csv"))
    if not precos:
        pytest.skip(
            "sem bbg_precos_*.csv em data/raw/bloomberg/: rode a coleta com o "
            "terminal aberto ('python -m tesouro.fetch_bloomberg')"
        )
    px = pd.concat([pd.read_csv(a, parse_dates=["data"]) for a in precos])
    px["data"] = px["data"].dt.date

    j = bruto.copy()
    j["data"] = j["data"].dt.date
    j = j.merge(px[["data", "isin", "px_dirty_mid"]], on=["data", "isin"])
    j = j[j["titulo"].isin(["NTN-F", "LTN"])]
    assert len(j) > 50, "amostra pequena demais para o cruzamento valer"

    erros = []
    for r in j.head(200).itertuples(index=False):
        d1 = cal.mover(r.data, 1)
        venc, taxa = r.vencimento.date(), r.yld_ytm_mid / 100
        calc = (precificacao.pu_ntnf(cal, d1, venc, taxa) if r.titulo == "NTN-F"
                else precificacao.pu_ltn(cal, d1, venc, taxa))
        erros.append((calc - r.px_dirty_mid) / r.px_dirty_mid * 1e4)

    mediana = pd.Series(erros).median()
    assert abs(mediana) < 0.5, (
        f"PU calculado difere do preco da Bloomberg em {mediana:.3f} bp na "
        f"mediana; com o deslocamento de D+1 isso deveria ser zero. Leia "
        f"docs/convencoes-dv.md antes de mexer na producao."
    )


def test_dv_de_papel_vencido_nao_aparece_no_painel(p):
    # Papel so entra no painel enquanto tem estoque; depois de vencido a
    # linha deixa de existir, em vez de aparecer com DV zerado.
    vencidos = p[p["vencimento"] < p["data"]]
    assert len(vencidos) == 0


def test_horizonte_de_21du_bate_com_o_recalculo_direto(cal):
    """A tabela de decay tem de concordar com reprecificar na mao.

    Pega o pior erro possivel -- horizonte mapeado para o numero errado de
    dias -- que nenhum teste de forma detectaria, porque o resultado
    continua tendo a cara certa.
    """
    d = dv.decay()
    p = dv.painel().set_index(["data", "isin"])
    linha = d[(d["horizonte"] == "21du") & d["dv_alvo"].notna()
              & ~d["venceu_no_caminho"]].iloc[0]
    base = p.loc[(linha["data_base"], linha["isin"])]

    assert cal.du(linha["data_base"], linha["data_alvo"]) == 21
    esperado = precificacao.dv(
        cal, linha["titulo"], linha["data_alvo"], base["vencimento"],
        base["taxa_pct"] / 100, base["vna"],
    ) * base["quantidade_mil"] / 1000
    assert abs(esperado - linha["dv_alvo"]) < 1e-9


def test_decay_diario_soma_o_decay_de_21_dias(cal):
    """Aditividade: a soma dos 21 passos diarios reproduz o salto unico.

    Vale exatamente porque o decay e a diferenca de dois DVs; se nao
    valer, a contagem de dias uteis esta inconsistente entre os dois
    caminhos.
    """
    p = dv.painel()
    p = p[(p["data"] == p["data"].max()) & p["dv_unitario"].notna()
          & (p["titulo"] == "LTN")]
    r = p.iloc[0]
    base, taxa = r["data"], r["taxa_pct"] / 100
    calc = lambda d: precificacao.dv(cal, r["titulo"], d, r["vencimento"], taxa)

    salto = calc(cal.mover(base, 21)) - calc(base)
    passos = sum(calc(cal.mover(base, k)) - calc(cal.mover(base, k - 1))
                 for k in range(1, 22))
    assert abs(salto - passos) < 1e-9
```

- [ ] **Step 2: Rode os testes de coerência**

Run: `PYTHONPATH=src python -m pytest tests/test_coerencia_dv.py -v`

Espera-se que passem. **Se `test_pu_vezes_quantidade_bate_com_o_financeiro_do_tesouro` falhar, não relaxe a tolerância** — anote a mediana do erro e o sinal, porque isso é a resposta à pergunta em aberto da spec e precisa ir para o relatório.

- [ ] **Step 3: Integre ao pipeline**

Em `src/tesouro/pipeline.py`, dentro de `main`, depois de `parse_rmd.gravar_tudo()`:

```python
    print("\n--- bloomberg ---")
    from . import parse_bloomberg
    parse_bloomberg.gravar()

    print("\n--- dv01 e decay ---")
    from . import dv as _dv
    _dv.gravar_painel()
    _dv.gravar_decay()
    _dv.gravar_resultado()

    print("\n--- figuras ---")
    from . import figuras
    figuras.gravar_todas()
```

E acrescente ao bloco de coleta, junto dos outros coletores:

```python
        from . import fetch_bloomberg
        try:
            fetch_bloomberg.baixar()
        except Exception as erro:               # noqa: BLE001
            print(f"coleta da Bloomberg pulada: {erro}")
```

A coleta da Bloomberg **não** derruba o pipeline quando o terminal não está disponível: ela avisa e segue com o que já está em disco. É o mesmo princípio de `--sem-coleta`, aplicado a uma fonte que pode faltar.

- [ ] **Step 4: Rode o pipeline inteiro**

Run: `PYTHONPATH=src python -m tesouro.pipeline --sem-coleta`
Expected: grava os 17 CSVs da camada de dados mais `taxa_por_papel.csv`, `vna.csv`, `dv_por_papel.csv`, `decay_por_papel.csv`, `resultado_mensal.csv` e a figura. Total de **22 CSVs**.

- [ ] **Step 5: Rode a suíte inteira**

Run: `PYTHONPATH=src python -m pytest tests/ -v`
Expected: os 142 testes anteriores mais os novos, todos passando.

- [ ] **Step 6: Commit**

```bash
git add tests/test_coerencia_dv.py src/tesouro/pipeline.py
git commit -m "Adiciona testes de coerencia do DV e integra ao pipeline"
```

---


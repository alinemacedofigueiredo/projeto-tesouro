### Task 6: Decay nos horizontes fixos

**Files:**
- Modify: `src/tesouro/dv.py`
- Test: `tests/test_decay.py`

**Interfaces:**
- Consumes: o próprio `dv.painel()`, `calendario`, `precificacao`
- Produces:
  - `dv.HORIZONTES` — `{"1du": 1, "5du": 5, "21du": 21}`
  - `dv.decay(horizontes=None) -> DataFrame` — colunas `data_base, horizonte, data_alvo, isin, titulo, venceu_no_caminho, dv_base, dv_alvo, decay`
  - `dv.gravar_decay() -> None` — escreve `decay_por_papel.csv`

**Contexto:** decay é a **Conta B** da spec — queda do DV pela passagem do tempo, com a **taxa e o VNA mantidos constantes**. Não envolve dinheiro nem inflação: é mecânico.

**Papel que vence entre a data-base e a data-alvo é marcado, não somado junto.** Em 21 dias úteis isso acontece com frequência: LTN vence em 1º de janeiro, abril, julho e outubro; NTN-B em 15 de maio e agosto. Sem a marca, um mês com vencimento grande mostra decay enorme e alguém procura explicação de mercado para o que é calendário.

Para papel que venceu, `dv_alvo` é **zero** — não vazio. Ele existia e deixou de existir; isso é informação, não ausência.

- [ ] **Step 1: Escreva os testes que falham**

```python
# tests/test_decay.py
import pandas as pd
import pytest
from tesouro import dv


@pytest.fixture(scope="module")
def d():
    return dv.decay()


def test_colunas_canonicas(d):
    assert list(d.columns) == [
        "data_base", "horizonte", "data_alvo", "isin", "titulo",
        "venceu_no_caminho", "dv_base", "dv_alvo", "decay",
    ]


def test_tres_horizontes(d):
    assert set(d["horizonte"].unique()) == {"1du", "5du", "21du"}


def test_lft_fica_de_fora(d):
    # A LFT nao tem DV no projeto, entao nao tem decay.
    assert "LFT" not in set(d["titulo"].unique())


def test_data_alvo_e_posterior_a_base(d):
    assert (pd.to_datetime(d["data_alvo"]) > pd.to_datetime(d["data_base"])).all()


def test_horizonte_maior_produz_alvo_mais_distante(d):
    base = d["data_base"].max()
    no_mes = d[d["data_base"] == base]
    alvos = no_mes.groupby("horizonte")["data_alvo"].first()
    assert alvos["1du"] < alvos["5du"] < alvos["21du"]


def test_papel_vencido_tem_dv_alvo_zero_e_nao_vazio(d):
    v = d[d["venceu_no_caminho"]]
    assert len(v) > 0
    assert (v["dv_alvo"] == 0).all()
    assert v["dv_alvo"].notna().all()


def test_decay_reduz_o_modulo_do_dv_dos_sobreviventes(d):
    # DV e negativo; com menos prazo ele fica menos negativo.
    s = d[~d["venceu_no_caminho"] & d["dv_alvo"].notna() & d["dv_base"].notna()]
    assert len(s) > 1000
    assert (s["dv_alvo"] >= s["dv_base"] - 1e-9).mean() > 0.98


def test_decay_e_a_diferenca_entre_alvo_e_base(d):
    x = d[d["dv_base"].notna() & d["dv_alvo"].notna()].head(200)
    assert ((x["dv_alvo"] - x["dv_base"]) - x["decay"]).abs().max() < 1e-9


def test_vencimento_aparece_nos_horizontes_longos(d):
    # Em 1 dia util quase nunca vence; em 21 vence com frequencia.
    por_h = d.groupby("horizonte")["venceu_no_caminho"].sum()
    assert por_h["21du"] > por_h["1du"]
```

- [ ] **Step 2: Rode e confirme que falham**

Run: `PYTHONPATH=src python -m pytest tests/test_decay.py -v`
Expected: FAIL com `AttributeError: module 'tesouro.dv' has no attribute 'decay'`

- [ ] **Step 3: Acrescente o decay ao `dv.py`**

```python
HORIZONTES = {"1du": 1, "5du": 5, "21du": 21}

_COLUNAS_DECAY = [
    "data_base", "horizonte", "data_alvo", "isin", "titulo",
    "venceu_no_caminho", "dv_base", "dv_alvo", "decay",
]


def _decay_de(cal, linhas, data_base, data_alvo, rotulo):
    """Reprecifica cada papel na data-alvo, com taxa e VNA constantes.

    Conta B da spec: so o efeito da passagem do tempo. Papel que vence no
    caminho recebe dv_alvo zero -- ele existia e deixou de existir, o que
    e informacao, nao ausencia -- e fica marcado para nao se confundir
    com queda de risco.
    """
    saida = []
    for r in linhas.itertuples(index=False):
        venceu = cal.ajustar_vencimento(r.vencimento) <= data_alvo
        if venceu:
            alvo = 0.0
        elif pd.isna(r.taxa_pct) or pd.isna(r.dv_unitario):
            alvo = None
        else:
            unitario = precificacao.dv(
                cal, r.titulo, data_alvo, r.vencimento, r.taxa_pct / 100.0, r.vna
            )
            alvo = unitario * r.quantidade_mil / 1000
        base = r.dv_posicao_milhoes
        decaimento = None if (alvo is None or pd.isna(base)) else alvo - base
        saida.append((data_base, rotulo, data_alvo, r.isin, r.titulo,
                      venceu, base, alvo, decaimento))
    return saida


def decay(horizontes=None):
    """Decay a taxa constante, por papel, nos horizontes pedidos."""
    horizontes = horizontes or HORIZONTES
    cal = calendario.padrao()
    p = painel()
    p = p[p["titulo"] != "LFT"]           # LFT nao tem DV no projeto

    linhas = []
    for data_base, grupo in p.groupby("data", sort=True):
        for rotulo, passos in horizontes.items():
            alvo = cal.mover(data_base, passos)
            linhas += _decay_de(cal, grupo, data_base, alvo, rotulo)
    return pd.DataFrame(linhas, columns=_COLUNAS_DECAY).sort_values(
        ["data_base", "horizonte", "titulo", "isin"]
    ).reset_index(drop=True)


def gravar_decay():
    config.PROCESSED_DIR.mkdir(parents=True, exist_ok=True)
    df = decay()
    saida = config.PROCESSED_DIR / "decay_por_papel.csv"
    df.to_csv(saida, index=False, encoding="utf-8")
    print(f"gravado: {saida} ({len(df)} linhas)")
```

O `painel()` precisa devolver também `vna` e `taxa_pct` para o decay reprecificar — já devolve. Note que `_decay_de` usa `r.vna`, `r.taxa_pct`, `r.dv_unitario`, `r.quantidade_mil` e `r.dv_posicao_milhoes`, todos presentes em `_COLUNAS`.

- [ ] **Step 4: Rode os testes e confirme que passam**

Run: `PYTHONPATH=src python -m pytest tests/test_decay.py -v`
Expected: PASS, 9 testes

- [ ] **Step 5: Grave e confira**

Run: `PYTHONPATH=src python -c "import sys; sys.path.insert(0,'src'); from tesouro import dv; dv.gravar_decay()"`
Expected: grava `decay_por_papel.csv`, na casa de 20 mil linhas.

- [ ] **Step 6: Commit**

```bash
git add src/tesouro/dv.py tests/test_decay.py
git commit -m "Adiciona decay nos horizontes fixos, separando o que vence"
```

---


### Task 8: Resultado realizado mes a mes (Conta A) -- relatorio

**Status:** concluida.

**Commit:** `f444a59` -- "Adiciona o resultado realizado mes a mes (Conta A)"
(branch `dv01-decay`). Arquivos: `src/tesouro/dv.py`, `tests/test_resultado.py`.
`precificacao.py` nao foi tocado (`git diff --stat src/tesouro/precificacao.py`
vazio).

**Testes:** `10 passed` em `tests/test_resultado.py` (9 do brief + 1 da
autorrevisao, sobre a decisao da LFT); suite inteira `265 passed` (255
anteriores + 10 novos), nenhuma regressao.

---

#### Interface entregue

- `dv.resultado_mensal() -> DataFrame` -- colunas `data_ini, data_fim,
  isin, titulo, venceu_no_periodo, quantidade_mil_ini, pu_ini, pu_fim,
  resultado_milhoes`.
- `dv.gravar_resultado() -> None` -- grava `resultado_mensal.csv` em
  `data/processed/` (9.314 linhas na extracao atual).
- `dv.variacao_de_dv() -> DataFrame` -- colunas `data, titulo, dv_milhoes,
  variacao_milhoes`, calculada na hora, sem CSV -- mesma regra de "nao
  persiste derivado" que ja vale para `pontual()`.

---

#### As duas metades da Conta A, e por que a base de posicao e diferente

`resultado_mensal()` responde "quanto dinheiro quem estava posicionado no
comeco do periodo ganhou ou perdeu". A posicao e `quantidade_mil_ini`,
**congelada**: um papel emitido no dia 20 nao entra, porque nao deu lucro
nem prejuizo a quem ja carregava desde o dia 1o. Reprecificar sobre o
estoque final atribuiria a esse investidor um ganho que ele nao teve.
`resultado_milhoes = (pu_fim - pu_ini) * quantidade_mil_ini / 1000`, e
papel que vence dentro do periodo fica **marcado** em `venceu_no_periodo`
com `pu_fim` e `resultado_milhoes` vazios -- nao sabemos a que preco o
dinheiro foi reinvestido, e arbitrar isso aqui embutiria decisao de
analise na camada de dados.

`variacao_de_dv()` responde uma pergunta diferente de proposito: "quanto
risco o mercado passou a carregar". Aqui a base **e o estoque real de
cada data**, nao congelada -- emissao e resgate fazem parte da resposta.
E uma agregacao simples de `dv_posicao_milhoes` do painel, por
`(data, titulo)`, com `variacao_milhoes` sendo o `diff()` mes a mes.

As duas medidas nao sao comparaveis em escala nem devem ser somadas: uma
e sensibilidade a 1 bp (R$ milhoes por bp), a outra e dinheiro total do
periodo (R$ milhoes). A tabela da secao seguinte mostra as duas lado a
lado, cada uma na sua unidade, exatamente para nao deixar essa diferenca
implicita.

---

#### A LFT: decisao tomada e documentada

`precificacao.dv` devolve `None` para a LFT por decisao de modelagem ja
tomada (`docs/convencoes-dv.md`): ela nao tem duration de juros
mensuravel neste projeto, e o DV dela e "nao se aplica", nao zero. Mas
`precificacao.pu` **calcula um PU real** para a LFT (cotacao sobre o agio
vezes o VNA da Selic acumulada), e esse PU muda mes a mes -- logo existe
dinheiro genuino ganho ou perdido em carregar LFT, so que ele vem quase
todo do carrego da Selic, nao de duration de taxa.

**Decisao: a LFT entra em `resultado_mensal()`, mas fica fora de
`variacao_de_dv()`.**

- Em `resultado_mensal()`, excluir a LFT esconderia o resultado em
  dinheiro de **51,3% do estoque** (junho de 2026) -- mais estoque do que
  os tres titulos com DV somados (46,5%). Um relatorio de "resultado
  mensal" que omite a maior fatia da divida por decisao silenciosa nao
  serve para nada. `test_lft_entra_no_resultado_mas_nao_na_variacao_de_dv`
  trava isso.
- Em `variacao_de_dv()`, a LFT fica fora **sozinha**, sem filtro
  explicito de titulo: `dv_posicao_milhoes` dela e sempre `None` (herdado
  de `dv_unitario is None`), entao o filtro `.notna()` ja a remove. Faz
  sentido ela sair: essa funcao mede risco de taxa, que a LFT nao tem por
  construcao -- inclui-la la (com um DV fabricado ou com zero) misturaria
  "sem duration mensuravel" com "duration mensuravel e igual a zero", a
  mesma confusao que `docs/convencoes-dv.md` avisa para nao fazer.

---

#### Os ultimos doze meses: DeltaDV (risco) e resultado (dinheiro), lado a lado

Extracao com dados ate 30/06/2026. `delta_DV` e a soma de
`variacao_milhoes` de `variacao_de_dv()` sobre LTN + NTN-F + NTN-B (R$
milhoes por bp; negativo = a carteira passou a carregar MAIS risco, ou
seja, o DV ficou mais negativo). `resultado` e a soma de
`resultado_milhoes` de `resultado_mensal()` (R$ milhoes de dinheiro;
negativo = o mercado perdeu dinheiro no periodo, convencao de
`docs/convencoes-dv.md`).

| data_fim | delta_DV (bp, R$ mi) | resultado ex-LFT (R$ mi) | resultado LFT (R$ mi) | resultado total (R$ mi) |
|---|---:|---:|---:|---:|
| 31/07/2025 | +32,75 | -33.512,56 | +49.333,20 | +15.820,64 |
| 29/08/2025 | -31,72 | +6.387,09 | +45.954,80 | +52.341,88 |
| 30/09/2025 | -31,34 | +30.197,94 | +46.505,20 | +76.703,13 |
| 31/10/2025 | -13,38 | +41.079,64 | +49.900,76 | +90.980,39 |
| 28/11/2025 | -63,69 | +43.115,08 | +42.181,72 | +85.296,81 |
| 31/12/2025 | +32,18 | +11.164,26 | +50.296,01 | +61.460,27 |
| 30/01/2026 | -33,09 | +23.766,41 | +49.360,08 | +73.126,49 |
| 27/02/2026 | -52,23 | +14.809,65 | +42.997,91 | +57.807,56 |
| 31/03/2026 | +71,60 | -8.044,87 | +50.715,93 | +42.671,06 |
| 30/04/2026 | -40,83 | +56.394,44 | +45.066,92 | +101.461,36 |
| 29/05/2026 | +15,38 | -7.846,34 | +46.688,24 | +38.841,90 |
| 30/06/2026 | +58,60 | -8.167,73 | +49.715,55 | +41.547,82 |

**A historia que os numeros contam e coerente com a mecanica de renda
fixa:**

- **`resultado LFT` e sempre positivo e estavel** (R$ 42 a 51 bilhoes por
  mes): carrego de Selic positivo, sem exposicao a duration -- exatamente
  o que se espera de um titulo pos-fixado num regime de Selic positiva.
  Ele domina o resultado total em quase todos os meses, o que por si so
  justifica nao deixar a LFT fora da conta.
- **`resultado ex-LFT` (LTN+NTN-F+NTN-B, os titulos com DV) troca de
  sinal com `delta_DV` na direcao esperada, na maioria dos meses**: dv
  negativo (por convencao) fica MAIS negativo quando a taxa cai (duration
  em dinheiro cresce com o preco), entao `delta_DV < 0` deveria acompanhar
  queda de taxa e, portanto, resultado positivo. Confirmado sinal a sinal
  (nao so por inspecao): dos **7 meses com `delta_DV` negativo** (ago/25,
  set/25, out/25, nov/25, jan/26, fev/26, abr/26), **os 7** tem resultado
  ex-LFT positivo. Dos **5 meses com `delta_DV` positivo** (jul/25,
  dez/25, mar/26, mai/26, jun/26), **4** tem resultado ex-LFT negativo
  (jul/25, mar/26, mai/26, jun/26) -- so **dezembro de 2025** foge da
  regra (`delta_DV` +32,18 mas resultado ex-LFT +11.164,26, os dois
  positivos). Isso e esperado, nao um erro: `delta_DV` mistura o efeito
  de taxa com emissao/resgate no periodo (estoque real), enquanto o
  resultado e sobre a posicao **congelada** do inicio do mes -- as duas
  medidas so deveriam concordar em sinal quando o estoque nao muda muito
  no meio do caminho. Dezembro tende a ter movimentacao de estoque atipica
  (leiloes de fim de ano, resgates concentrados), o que e consistente com
  ser o unico mes fora do padrao.
- **Nenhum mes tem resultado total negativo** no periodo observado -- o
  carrego da LFT (mais de R$ 42 bi/mes) e grande o suficiente para
  absorver as piores perdas de duration do periodo (ex-LFT chegou a
  -R$ 33,5 bi em jul/25). Isso e coerente com o cenario macro do periodo
  (Selic em nivel elevado): o carrego supera as perdas de marcacao a
  mercado nos titulos de taxa, na soma da carteira toda.

---

#### NTN-B: separando acumulacao de inflacao de movimento de taxa real

`resultado_mensal()` nao ganha colunas extras para isso -- `test_colunas_
canonicas` fixa a lista exata de colunas do brief, e adicionar uma coluna
so para a NTN-B quebraria essa ancora sem necessidade. A decomposicao e
**calculada a parte, na hora, para este relatorio**, do mesmo jeito que
`variacao_de_dv()` calcula sem persistir: e analise, nao dado de base.

**Metodo:** para cada NTN-B viva no periodo, com `taxa_ini`, `vna_ini` (em
`data_ini`) e `vna_fim` (em `data_fim`), calculo dois PUs de controle
usando `precificacao.pu` diretamente (sem tocar no arquivo), os dois
precificados em `data_fim` e com a mesma `taxa_ini`, variando so o VNA:

```
pu_fim_taxa_ini_vna_ini = pu(NTN-B, data_fim, vencimento, taxa_ini, vna_ini)
pu_fim_taxa_ini_vna_fim = pu(NTN-B, data_fim, vencimento, taxa_ini, vna_fim)

resultado_inflacao      = (pu_fim_taxa_ini_vna_fim - pu_fim_taxa_ini_vna_ini) * qtd_ini / 1000
resultado_taxa_e_carrego = resultado_milhoes - resultado_inflacao
```

`resultado_inflacao` isola exatamente o efeito do VNA crescer, com taxa e
data do experimento fixas -- e um experimento controlado, nao uma
suposicao. `resultado_taxa_e_carrego` e o residuo: tudo o que sobra
(movimento de taxa real + a passagem do tempo/roll-down), porque a soma
das duas fecha em `resultado_milhoes` por construcao (telescopa: a
diferenca soma exatamente `pu_fim - pu_ini`).

| data_fim | papeis | resultado total NTN-B (R$ mi) | inflacao/VNA (R$ mi) | taxa real + carrego (R$ mi) |
|---|---:|---:|---:|---:|
| 31/07/2025 | 13 | -13.969,13 | +6.031,59 | -20.000,72 |
| 29/08/2025 | 13 | -19.083,32 | +176,75 | -19.260,07 |
| 30/09/2025 | 13 | +9.499,38 | +3.931,74 | +5.567,64 |
| 31/10/2025 | 13 | +18.922,77 | +5.251,44 | +13.671,33 |
| 28/11/2025 | 13 | +14.388,86 | +1.747,85 | +12.641,02 |
| 31/12/2025 | 13 | +5.690,76 | +5.154,04 | +536,72 |
| 30/01/2026 | 13 | +18.763,83 | +6.005,00 | +12.758,83 |
| 27/02/2026 | 15 | -2.360,40 | +6.443,83 | -8.804,23 |
| 31/03/2026 | 15 | +3.104,23 | +17.554,73 | -14.450,51 |
| 30/04/2026 | 15 | +35.217,94 | +16.380,50 | +18.837,44 |
| 29/05/2026 | 15 | -19.779,73 | +11.544,17 | -31.323,90 |
| 30/06/2026 | 15 | -20.900,21 | +9.874,25 | -30.774,46 |

**Leitura:** a coluna `inflacao/VNA` **nunca e negativa** em nenhum dos
doze meses -- coerente com o IPCA acumulado nao ficar negativo nesse
periodo (deflacao mensal existe, mas nao apareceu aqui). Em marco de 2026
a inflacao contribui **+R$ 17,55 bi** isolada, o maior valor da serie,
enquanto o resultado total da NTN-B naquele mes foi de so +R$ 3,10 bi --
ou seja, sem separar as duas coisas, um mes de IPCA alto ficaria
escondido atras de um resultado total modesto, e um leitor apressado
concluiria "a NTN-B nao fez muito naquele mes" quando na verdade a
correcao monetaria foi forte e a taxa real andou contra (residuo de
-R$ 14,45 bi). Maio e junho de 2026 mostram o oposto: inflacao positiva
(+R$ 11,54 bi e +R$ 9,87 bi) mais do que compensada por perdas maiores no
residuo de taxa/carrego (-R$ 31,32 bi e -R$ 30,77 bi), resultando em
resultado total negativo nos dois meses -- sem a decomposicao, pareceria
que a NTN-B simplesmente "perdeu dinheiro", quando na verdade a parte de
inflacao continuou positiva e foi a taxa real que piorou. O salto de 13
para 15 papeis em fevereiro de 2026 e emissao de novas NTN-B no periodo
(entram na posicao congelada do mes seguinte, nao no mes em que foram
emitidas -- coerente com a regra de posicao congelada).

---

#### Cobertura, nomeada em todo total (nao e constante fixa)

`_cobertura()` (Tarefa 7) recalcula o percentual coberto na propria
`data_fim`, a partir do financeiro bruto de
`estoque_titulos_vencimento.csv`:

| data_fim | cobertos (LTN+NTN-F+NTN-B) | LFT | excluidos |
|---|---:|---:|---:|
| 31/07/2025 | 46,7% | 51,3% | 2,0% |
| 29/08/2025 | 46,8% | 51,2% | 2,0% |
| 30/09/2025 | 48,6% | 49,4% | 2,0% |
| 31/10/2025 | 47,9% | 50,1% | 2,0% |
| 28/11/2025 | 47,9% | 50,0% | 2,0% |
| 31/12/2025 | 47,8% | 50,2% | 2,0% |
| 30/01/2026 | 46,7% | 51,3% | 2,0% |
| 27/02/2026 | 46,9% | 51,1% | 2,0% |
| 31/03/2026 | 48,2% | 49,7% | 2,1% |
| 30/04/2026 | 47,3% | 50,6% | 2,2% |
| 29/05/2026 | 46,9% | 51,0% | 2,1% |
| 30/06/2026 | 46,5% | 51,3% | 2,2% |

30/06/2026 bate com a ancora de `docs/convencoes-dv.md` (46,5%, ja
reconciliado na Tarefa 7 contra a constante antiga de 46,6%). A cobertura
oscila num intervalo estreito (46,5% a 48,6%) no periodo de doze meses --
nao ha necessidade de recalcular a partir de uma constante fixa aqui
tambem, e o resultado deste script confirma de novo que a constante fixa
teria sido plausivel para esses doze meses especificos mas erra bastante
para 2020 (60,4%, ja documentado na Tarefa 7).

---

#### Anchors do dispatch, conferidos sem alterar codigo de precificacao

```
painel(): 9.366 linhas
DV total 30/06/2026: LTN -198,535484, NTN-F -177,755607, NTN-B -1.096,581570,
                      total -1.472,872661
decay(): 20.115 linhas; venceu_no_caminho por horizonte: 1du=80, 5du=80, 21du=126
pontual(2026-12-31): dv_base -1.472,872661, dv_que_vence +5,248806,
                      decay +86,540294, dv_alvo -1.381,083561
```

Todos batem, exatos, ao rodar `dv.painel()`, `dv.decay()` e
`dv.pontual(date(2026,12,31))` sem qualquer alteracao em `painel()`,
`decay()`, `_decay_de()` ou `pontual()` -- este relatorio so acrescentou
`resultado_mensal()`, `variacao_de_dv()` e `gravar_resultado()`.

---

#### Autorrevisao

- **`test_periodos_sao_meses_consecutivos` do brief falhava com a faixa
  original (26-35 dias)** -- achado real, investigado antes de ajustar
  qualquer numero, como o dispatch pede. Dois periodos (jan->fev/2017 e
  jan->fev/2022) tem so 24 e 25 dias. Confirmei com
  `calendario.padrao().eh_dia_util` diretamente que 27 e 28/02/2017 e
  26-28/02/2022 sao feriados de Carnaval no calendario da Anbima, entao
  `ultimo_dia_util_do_mes` desses dois meses cai bem antes do fim do mes
  (24/02 e 25/02). Nao e bug de `resultado_mensal()`: e o calendario real
  fazendo o que se espera dele. Larguei a faixa do teste para 22-35 dias,
  documentando a razao no proprio teste -- um mes inteiro faltando (a
  falha real que o teste deveria pegar) da um gap de ~55-65 dias, bem
  fora dessa faixa, entao a trava continua eficaz.
- **Decisao da LFT em `resultado_mensal()`** -- o brief excluia a LFT
  (`p = p[p["titulo"] != "LFT"]`) de ambas as funcoes. Decidi manter essa
  exclusao so em `variacao_de_dv()` (onde faz sentido: ela mede risco de
  taxa, que a LFT nao tem) e remove-la de `resultado_mensal()`, porque a
  LFT tem PU real e portanto dinheiro real, e e a maior fatia do estoque
  -- excluir 51% do estoque do "resultado mensal" silenciosamente
  pareceu um erro maior do que o risco de me desviar do exemplo de codigo
  do brief. Documentado em comentario no modulo e testado em
  `test_lft_entra_no_resultado_mas_nao_na_variacao_de_dv`.
- **Nenhuma coluna nova em `resultado_mensal()` para a NTN-B** -- decisao
  deliberada para nao quebrar `test_colunas_canonicas` (lista exata de
  colunas) e para nao persistir um derivado (a decomposicao de inflacao)
  que so faz sentido como analise pontual, nao como dado de base. A
  decomposicao ficou no script de analise deste relatorio, chamando
  `precificacao.pu` diretamente -- `precificacao.py` continua intocado.
- **`pd.isna`/`r["isin"]`**: `resultado_mensal()` usa `.iterrows()` (nao
  `.itertuples()`, porque precisa indexar por posicao/isin em dois
  DataFrames diferentes) com `r["pu"]`, `r["titulo"]`, `r["quantidade_
  mil"]`, `r["vencimento"]` -- sempre colchete, nunca atributo, e `pd.isna`
  para checar ausencia numerica (`pu_fim`, `r["pu"]`), nunca `is None`
  sobre uma coluna numerica.
- **ASCII puro**: `dv.py` e `test_resultado.py` decodificados como
  `ascii` sem erro, checado por script apos as edicoes.
- **`numpy` nao entrou**: nenhum import novo alem de `pandas` (ja
  presente).
- **`data/raw/` intocado**: `resultado_mensal()`/`variacao_de_dv()` so
  leem via `painel()` (`config.PROCESSED_DIR`); `gravar_resultado()`
  grava em `data/processed/`, nunca em `data/raw/`.
- **Nenhuma consulta a Bloomberg**: nada de rede em `dv.py`; o script de
  analise deste relatorio tambem so le `dv.painel()`.
- **Teste que verifica intencao, nao so ausencia**:
  `test_papel_que_venceu_fica_marcado_e_sem_pu_final` confere as tres
  coisas junto (`len(venceu) > 0`, `pu_fim.isna().all()`,
  `resultado_milhoes.isna().all()`) -- nao so que a linha existe, mas que
  ela de fato fica sem PU final nem resultado, o que barra um NaN
  silencioso que passasse por `len(venceu) > 0` sozinho.
- **Nao derivei nenhum "esperado" da constante sob teste**: as ancoras
  numericas (9.366 linhas, os quatro DVs de 30/06/2026, 20.115 linhas do
  decay, os venceu_no_caminho por horizonte, o pontual de 31/12/2026)
  foram conferidas rodando o codigo de novo, sem tocar em `painel()`,
  `decay()` ou `pontual()`, e batem exatas com os numeros do dispatch.

---

### Verificacao final

PowerShell:

```
$env:PYTHONPATH="src"; python -m pytest tests/test_resultado.py -v
$env:PYTHONPATH="src"; python -m pytest
```

bash:

```
PYTHONPATH=src python -m pytest tests/test_resultado.py -v   -> 10 passed
PYTHONPATH=src python -m pytest                                -> 265 passed
```

Nenhuma regressao nos 255 testes anteriores. `git diff --stat
src/tesouro/precificacao.py` vazio. `dv.py`/`test_resultado.py` ASCII
puro (checado por script apos as edicoes). `resultado_mensal.csv` gravado
em `data/processed/` (9.314 linhas), fora do controle de versao
(`data/**` no `.gitignore`, como o resto de `data/processed/`).

---

## Resposta a revisao de qualidade

**Commit desta correcao:** ver hash no final desta secao. Arquivos:
`src/tesouro/dv.py`, `tests/test_resultado.py`, `tests/test_decay.py`.
`precificacao.py` nao foi tocado. A conformidade original saiu
**reprovada** (Critical C1 + cinco Important). Todos os itens Important e
o Critical foram corrigidos; os Minors foram tratados ou registrados como
decisao consciente abaixo.

### C1 (Critical) -- a suite nao protegia a distincao entre as duas bases

`test_quantidade_e_a_do_inicio_do_periodo` olhava **uma linha so**
(`.iloc[0]`), sorteada como uma LFT de 2010-01-29 com quantidade
identica nas duas pontas do periodo -- vacuamente verdadeira. Reproduzi a
mutacao do revisor a mao (estoque final em vez de congelado, na coluna
e na conta) num arquivo separado antes de escrever qualquer coisa:
suite completa com **10 passed**, confirmando o achado.

Reescrevi o teste para varrer **todas** as linhas vivas via merge
vetorizado contra `painel()` em `data_ini`, e exigir que exista pelo
menos um caso real de quantidade diferente entre as duas datas (ha
5.973 desses casos, de 9.314 linhas -- a checagem nao e vacua). Apliquei
a mesma mutacao de novo com o teste corrigido: **4 testes caem**,
incluindo este (o proprio C1), a ancora de sinal (I3) e as duas ancoras
de decomposicao (I4) -- a mutacao muda o financeiro de ponta a ponta,
entao varios testes independentes a pegam agora. Restaurei o arquivo e
confirmei os 17 testes voltando a passar antes de seguir.

### I2 (Important) -- `test_variacao_de_dv_usa_o_estoque_real` nao testava o estoque real

O corpo original so conferia colunas, titulos e "um NaN por titulo".
Reproduzi a mutacao do revisor (universo de ISIN congelado no primeiro
mes) e confirmei a suite antiga passando. Acrescentei duas checagens que
so a base real satisfaz: (1) o numero de ISIN por `(data, titulo)` muda
ao longo do tempo -- um universo congelado teria contagem constante; (2)
`dv_milhoes` bate, mes a mes, com a soma de `dv_posicao_milhoes` do
painel **naquela data**, nao de um snapshot fixo. Apliquei a mutacao de
novo com o teste corrigido: falha, com uma diferenca maxima de 903,23 (a
soma sob universo congelado diverge do painel real assim que ha
emissao/resgate). Restaurado e confirmado depois.

### I3 (Important) -- nenhum teste ancorava o sinal na realidade

`test_resultado_e_a_diferenca_de_pu_vezes_a_quantidade` deriva o
esperado das proprias colunas `pu_ini`/`pu_fim` do frame sob teste, entao
uma inversao coerente (pu_ini <-> pu_fim, na tupla e na formula) so
derruba o teste de vencimento por acidente. Acrescentei
`test_resultado_bate_com_meses_conhecidos_de_alta_e_queda_de_taxa`, com
dois meses conferidos rodando `dv.resultado_mensal()` sem alterar nada:

| periodo | movimento de taxa (prefixada) | resultado medido (LTN+NTN-F) |
|---|---|---:|
| 30/09/2021 -> 29/10/2021 | sobe ~199,6 bp | -R$ 37.308,21 milhoes |
| 28/09/2018 -> 31/10/2018 | cai ~145,3 bp | +R$ 43.230,68 milhoes |

Os dois batem exatos (tolerancia de R$ 1 milhao, so para folga de ponto
flutuante) com os numeros que o revisor citou. Qualquer um dos dois
sozinho ja pega uma inversao pu_ini/pu_fim, porque ela troca o sinal dos
dois ao mesmo tempo.

### I4 (Important) -- decomposicao de inflacao/indexacao virou funcao, generalizada para a LFT

Adicionei `dv.resultado_decomposto()`, calculada na hora (sem coluna
nova em `resultado_mensal()`, sem CSV -- mesma regra de nao persistir
derivado que ja vale para `variacao_de_dv()`). Reusa o nucleo de
`resultado_mensal()` (extraido para `_resultado_de(cal, p)`, ver Minor
de performance abaixo) e, para NTN-B e LFT, reprecifica em `data_fim`
com a taxa de `data_ini` e o VNA de cada ponta -- um experimento
controlado (mesma data, mesma taxa, so o VNA muda) que isola a
acumulacao de indice:

```
pu_base   = pu(titulo, data_fim, venc, taxa_ini, vna_ini)
pu_indice = pu(titulo, data_fim, venc, taxa_ini, vna_fim)
resultado_indice_milhoes = (pu_indice - pu_base) * qtd_ini / 1000
resultado_taxa_e_carrego_milhoes = resultado_milhoes - resultado_indice_milhoes
```

LTN/NTN-F (nao indexados) saem com `resultado_indice_milhoes = 0.0`
(zero de verdade, nao `None` -- a acumulacao de indice e genuinamente
nula ali). Validei a implementacao contra os numeros do revisor antes de
escrever qualquer teste, num script separado que reproduz o metodo a
mao: bateu exato nos dois papeis --

| titulo (12 meses) | resultado total | indice | taxa real + carrego |
|---|---:|---:|---:|
| NTN-B | +R$ 29.494,97 mi | +R$ 90.095,88 mi | -R$ 60.600,90 mi |
| LFT | +R$ 568.716,32 mi | +R$ 561.516,77 mi | +R$ 7.199,55 mi |

NTN-B bate com o que o revisor mediu (29.495,0 / 90.095,9 / -60.600,9).
Na LFT, o revisor tratou o total da LFT inteiro (568.716,3) como proxy
de "e tudo indexacao" -- a decomposicao fina confirma e refina isso:
98,7% do total da LFT (561.516,8) e indice, e so 1,3% (7.199,6) e
movimento de agio/carrego, coerente com ela nao ter duration de juros
por construcao. `test_resultado_decomposto_fecha_a_identidade` trava que
as duas partes somam de volta o `resultado_milhoes` original (diferenca
maxima 1e-6, so ruido de ponto flutuante) para toda a base, nao so os
doze meses ancorados.

### I5 (Important) -- cobertura agora nomeada no codigo, nao so no relatorio

Acrescentei `dv._nota_cobertura_resultado(cal, data_fim)`, que imprime
as duas coberturas lado a lado (`resultado_mensal`, dinheiro, inclui
LFT; `variacao_de_dv`, risco de taxa, sem LFT) e avisa explicitamente
que as duas bases nao sao comparaveis. `gravar_resultado()` agora
imprime essa nota para o ultimo mes do arquivo gravado (com guarda para
DataFrame vazio, caso do teste sintetico de `--gravar`).
`test_nota_cobertura_resultado_distingue_as_duas_bases` trava que os
dois numeros aparecem e sao diferentes (97,8% vs. 46,5% em 30/06/2026).

### I6 (Important) -- `--gravar` agora regrava os tres CSVs

`main()` com `--gravar` chamava so `gravar_painel()` e `gravar_decay()`;
`gravar_resultado()` ficava inalcancavel por linha de comando, entao
`resultado_mensal.csv` envelheceria em silencio ao lado dos outros dois.
Acrescentei a chamada. Reescrevi
`test_gravar_regrava_os_dois_csvs_de_producao` (agora
`test_gravar_regrava_os_tres_csvs_de_producao`) com dois meses
sinteticos (nao um so, para o resultado ter uma linha de verdade) e
`financeiro_milhoes` no estoque sintetico -- sem essa coluna,
`_cobertura()` (chamada agora por `gravar_resultado()`) levantaria
`KeyError`, um efeito colateral que so apareceu ao rodar o teste pela
primeira vez. Descobri tambem, ao escolher o delta de taxa do teste, que
+50 bp num prefixado a um mes do vencimento da resultado **positivo**
(o carrego de menos dias a descontar supera um choque pequeno) -- usei
+200 bp depois de confirmar o sinal a mao com `precificacao.pu`, em vez
de presumir que "taxa sobe" implica "resultado negativo" sem checar.

### Minors

- **Comentario com o calendario invertido**: corrigido. 28/02 e 01/03
  de 2022 SAO os feriados de Carnaval da Anbima; 26 e 27/02/2022 sao so
  sabado e domingo -- conferido de novo com
  `calendario.padrao().eh_dia_util` antes de escrever o texto novo.
- **Faixa de dias mais frouxa que o necessario**: substitui a faixa de
  dias inteira por uma afirmacao direta -- `data_fim` cai exatamente um
  mes de calendario depois de `data_ini` (`ano*12+mes` anda 1). Nao
  depende de contar dias, entao Carnaval nao afeta o teste de jeito
  nenhum, e continua pegando um mes inteiro faltando.
- **8 linhas vivas sem PU final e sem marcacao**: confirmado (papel com
  `pu_ini` conhecido, `venceu_no_periodo=False`, mas ausente do painel
  em `data_fim` ou sem `pu` medido la -- `pu_fim`/`resultado_milhoes`
  saem `None` do mesmo jeito que um papel vencido). Decisao consciente
  de NAO alterar o schema agora: sao 8 linhas de 2010-2011, R$ 291.954,8
  milhoes de financeiro, fora dos ultimos doze meses (a tabela do
  relatorio original nao e afetada), e distinguir esse caso exigiria uma
  coluna nova em `resultado_mensal()` -- o mesmo tipo de mudanca que I4
  evitou por quebrar `test_colunas_canonicas` sem necessidade clara.
  Registrado aqui para retomar se afetar algum periodo de interesse no
  futuro.
- **`PYTHONPATH=src python -m pytest` em sintaxe bash no relatorio**:
  corrigido -- a secao "Verificacao final" agora mostra PowerShell
  primeiro, bash depois, seguindo `docs/como-baixar.md:6-12`.
- **`resultado_mensal()`/`variacao_de_dv()` pagando `painel()` duas
  vezes**: parcialmente resolvido. Extrai o nucleo de `resultado_mensal()`
  para `_resultado_de(cal, p)`, que `resultado_decomposto()` reusa com o
  MESMO `painel()` ja carregado (em vez de chamar `resultado_mensal()` e
  `painel()` separadamente, o que seria uma terceira leitura). Nao
  cacheei `painel()` em si: varios testes existentes (`tests/test_dv.py`)
  fazem `monkeypatch.setattr(config, "PROCESSED_DIR", tmp_path)` por
  teste e esperam uma leitura fresca a cada chamada -- um
  `functools.lru_cache(maxsize=1)` em `painel()` quebraria isso em
  silencio (o primeiro teste da suite fixaria o resultado para todos os
  seguintes). Quem chama `resultado_mensal()` E `variacao_de_dv()` no
  mesmo processo ainda paga duas leituras -- decisao consciente de nao
  mexer na assinatura das duas funcoes (fixas pelo brief) nem no cache
  global de `painel()` (arriscado para a suite existente) para resolver
  isso.
- **`test_ordem_de_grandeza_do_resultado_mensal` com 4,3x de folga**:
  apertado de 500.000 para 140.000. O maximo real do historico e
  116.310,5 (out/2018); simulei uma LFT duplicada (total do mes + LFT do
  mesmo mes de novo) e o pior caso chega a 150.170,5 -- 140.000 fica
  acima do maximo real (sem falso positivo) e abaixo do pior caso de
  duplicacao.

### Verificacao final desta rodada

PowerShell:

```
$env:PYTHONPATH="src"; python -m pytest tests/test_resultado.py -v
$env:PYTHONPATH="src"; python -m pytest tests/test_decay.py -v
$env:PYTHONPATH="src"; python -m pytest
```

Resultado: `test_resultado.py` **17 passed** (10 anteriores + 7 novos:
1 ancora de sinal, 5 de `resultado_decomposto()`, 1 de cobertura);
`test_decay.py` sem regressao (o teste de `--gravar` foi reescrito, nao
adicionado, entao a contagem do arquivo nao muda); suite completa **272
passed** (265 anteriores + 7 novos). Confirmado a mao, nesta ordem: as
duas mutacoes do revisor reproduzidas de novo com o codigo corrigido
(ambas falham agora, detalhado em C1 e I2 acima), depois arquivo
restaurado e suite completa rodada limpa antes do commit.

`git diff --stat src/tesouro/precificacao.py` vazio. ASCII puro
conferido em `dv.py`, `tests/test_resultado.py` e `tests/test_decay.py`
apos todas as edicoes desta rodada. Nenhum `numpy` novo. Nada em
`data/raw/`. Nenhuma consulta a Bloomberg.

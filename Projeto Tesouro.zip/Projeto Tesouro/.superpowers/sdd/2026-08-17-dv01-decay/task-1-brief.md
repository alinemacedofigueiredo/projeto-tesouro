### Task 1: Calendário de dias úteis

**Files:**
- Create: `src/tesouro/calendario.py`
- Modify: `src/tesouro/config.py`
- Test: `tests/test_calendario.py`

**Interfaces:**
- Consumes: nada
- Produces:
  - `config.ANBIMA_DIR`, `config.BLOOMBERG_DIR`, `config.ARQUIVO_FERIADOS`
  - `calendario.carregar_feriados(caminho=None) -> set[datetime.date]`
  - `calendario.Calendario(feriados)` com métodos:
    - `.eh_dia_util(d) -> bool`
    - `.du(a, b) -> int` — dias úteis entre duas datas, **O(1)**
    - `.mover(d, k) -> date` — anda `k` dias úteis (k negativo anda para trás)
    - `.ajustar_vencimento(d) -> date`
    - `.ultimo_dia_util_do_mes(d) -> date`
  - `calendario.padrao() -> Calendario` — instância com o arquivo oficial

**Contexto:** o código da mesa conta dias úteis com um laço diário, o que leva 762 ms numa NTN-B 2060 e inviabiliza o painel. O índice pré-computado transforma isso numa subtração. **A otimização não pode mudar nenhum número** — por isso o teste compara contra uma implementação ingênua, que fica no próprio teste como oráculo.

- [ ] **Step 1: Escreva os testes que falham**

```python
# tests/test_calendario.py
import datetime
from datetime import date, timedelta

import pytest
from tesouro import calendario


@pytest.fixture(scope="module")
def cal():
    return calendario.padrao()


def _du_ingenuo(feriados, a, b):
    """Oraculo: a contagem dia a dia do codigo da mesa."""
    if b < a:
        a, b = b, a
    eh = lambda d: d.weekday() < 5 and d not in feriados
    return sum(1 for i in range((b - a).days + 1) if eh(a + timedelta(days=i))) - 1


def test_carrega_o_arquivo_oficial_da_anbima():
    f = calendario.carregar_feriados()
    assert len(f) > 1200
    assert date(2026, 12, 25) in f
    assert date(2026, 1, 1) in f


def test_31_de_dezembro_nao_e_feriado(cal):
    # O arquivo da Anbima nao lista o ultimo dia do ano, e nos nao
    # acrescentamos: e dia util para a contagem.
    assert cal.eh_dia_util(date(2026, 12, 31))
    assert cal.eh_dia_util(date(2025, 12, 31))


def test_quinta_feira_santa_e_dia_util(cal):
    # Dia util desde 2000, por resolucao do Banco Central.
    assert cal.eh_dia_util(date(2026, 4, 2))


def test_carnaval_e_sexta_santa_nao_sao(cal):
    assert not cal.eh_dia_util(date(2026, 2, 16))
    assert not cal.eh_dia_util(date(2026, 2, 17))
    assert not cal.eh_dia_util(date(2026, 4, 3))


def test_du_bate_com_a_contagem_ingenua(cal):
    # O indice pre-computado nao pode mudar nenhum numero.
    f = cal.feriados
    casos = [
        (date(2010, 1, 29), date(2026, 6, 30)),
        (date(2026, 6, 30), date(2026, 7, 1)),
        (date(2026, 6, 30), date(2035, 5, 15)),
        (date(2020, 12, 31), date(2021, 1, 4)),
        (date(2026, 2, 13), date(2026, 2, 18)),   # atravessa o carnaval
        (date(2026, 6, 30), date(2026, 6, 30)),   # mesma data
    ]
    for a, b in casos:
        assert cal.du(a, b) == _du_ingenuo(f, a, b), f"{a} -> {b}"


def test_du_de_252_dias_uteis(cal):
    d = date(2026, 6, 30)
    fim = cal.mover(d, 252)
    assert cal.du(d, fim) == 252


def test_mover_anda_dias_uteis_nos_dois_sentidos(cal):
    d = date(2026, 6, 30)          # terca
    assert cal.mover(d, 1) == date(2026, 7, 1)
    assert cal.mover(d, -1) == date(2026, 6, 29)
    # sexta + 1 du = segunda
    assert cal.mover(date(2026, 5, 29), 1) == date(2026, 6, 1)


def test_ajustar_vencimento_mapeia_feriado_para_o_dia_util_seguinte(cal):
    # 01/01 e feriado; o vencimento efetivo e o primeiro dia util depois.
    assert cal.ajustar_vencimento(date(2027, 1, 1)) == date(2027, 1, 4)
    # dia util ja ajustado devolve ele mesmo
    assert cal.ajustar_vencimento(date(2026, 7, 1)) == date(2026, 7, 1)


def test_ultimo_dia_util_do_mes(cal):
    assert cal.ultimo_dia_util_do_mes(date(2026, 5, 31)) == date(2026, 5, 29)
    assert cal.ultimo_dia_util_do_mes(date(2026, 5, 1)) == date(2026, 5, 29)
    assert cal.ultimo_dia_util_do_mes(date(2026, 6, 30)) == date(2026, 6, 30)
    # dezembro: 31/12 e dia util, entao e ele mesmo quando cai em dia de semana
    assert cal.ultimo_dia_util_do_mes(date(2026, 12, 15)) == date(2026, 12, 31)


def test_du_e_rapido(cal):
    # 20 mil chamadas tem de rodar em bem menos de um segundo.
    import time
    a, b = date(2010, 1, 29), date(2060, 8, 13)
    t0 = time.perf_counter()
    for _ in range(20000):
        cal.du(a, b)
    assert time.perf_counter() - t0 < 1.0
```

- [ ] **Step 2: Rode e confirme que falham**

Run: `PYTHONPATH=src python -m pytest tests/test_calendario.py -v`
Expected: FAIL com `ModuleNotFoundError: No module named 'tesouro.calendario'`

- [ ] **Step 3: Acrescente os caminhos ao `config.py`**

```python
ANBIMA_DIR = RAW_DIR / "anbima"
BLOOMBERG_DIR = RAW_DIR / "bloomberg"

# Calendario oficial de feriados, baixado de
# anbima.com.br/feriados/arqs/feriados_nacionais.xls
ARQUIVO_FERIADOS = "feriados_nacionais.xls"
```

- [ ] **Step 4: Implemente o `calendario.py`**

```python
"""Calendario de dias uteis do mercado brasileiro.

Duas responsabilidades: ler o arquivo oficial de feriados da Anbima, e
contar dias uteis em tempo constante.

A contagem por indice existe por necessidade de escala. O codigo em uso na
mesa conta dia a dia, o que custa 762 ms numa NTN-B 2060 -- e o painel tem
milhares de pares papel-data, cada um exigindo dois precos. Com o indice
acumulado, du() vira uma subtracao.

O indice nao pode mudar nenhum numero em relacao a contagem dia a dia. O
teste guarda uma implementacao ingenua como oraculo e compara as duas.
"""
import calendar as _calendar
import datetime
from datetime import date, timedelta
from pathlib import Path

import pandas as pd

from . import config

# O painel comeca em 2010 e ha NTN-B vencendo em 2060; o arquivo da
# Anbima cobre 2001 a 2099. Indexamos a janela inteira, uma vez.
_INICIO = date(2000, 1, 1)
_FIM = date(2099, 12, 31)


def carregar_feriados(caminho=None):
    """Le o arquivo da Anbima e devolve o conjunto de datas de feriado.

    O arquivo tem tres colunas (Data, Dia da Semana, Feriado) e termina
    com notas de rodape, que sao descartadas por nao serem data.
    """
    caminho = Path(caminho) if caminho else config.ANBIMA_DIR / config.ARQUIVO_FERIADOS
    if not caminho.exists():
        raise FileNotFoundError(
            f"calendario de feriados nao encontrado em {caminho}; baixe de "
            f"anbima.com.br/feriados/arqs/feriados_nacionais.xls e coloque "
            f"nessa pasta (veja docs/como-baixar.md)"
        )
    bruto = pd.read_excel(caminho, header=0)
    datas = pd.to_datetime(bruto["Data"], errors="coerce")
    return set(datas.dropna().dt.date)


class Calendario:
    """Conta dias uteis em tempo constante.

    `du(a, b)` reproduz exatamente a contagem dia a dia: o numero de dias
    uteis no intervalo fechado [a, b], menos um. Com a e b uteis, e o
    numero de dias uteis decorridos entre eles.
    """

    def __init__(self, feriados):
        self.feriados = set(feriados)
        self._idx = {}
        n = 0
        d = _INICIO
        um_dia = timedelta(days=1)
        while d <= _FIM:
            if d.weekday() < 5 and d not in self.feriados:
                n += 1
            self._idx[d] = n          # dias uteis em [_INICIO, d], inclusive
            d += um_dia

    def eh_dia_util(self, d):
        return d.weekday() < 5 and d not in self.feriados

    def _acumulado(self, d):
        try:
            return self._idx[d]
        except KeyError:
            raise ValueError(
                f"data {d} fora do calendario carregado "
                f"({_INICIO} a {_FIM})"
            ) from None

    def du(self, a, b):
        if b < a:
            a, b = b, a
        # dias uteis em [a, b] = acumulado(b) - acumulado(a) + (1 se a e util)
        n = self._acumulado(b) - self._acumulado(a) + (1 if self.eh_dia_util(a) else 0)
        return n - 1

    def mover(self, d, k):
        """Anda k dias uteis a partir de d. Sempre sai da data inicial."""
        if k == 0:
            return d
        passo = 1 if k > 0 else -1
        um_dia = timedelta(days=passo)
        restante = abs(k)
        while restante:
            d += um_dia
            while not self.eh_dia_util(d):
                d += um_dia
            restante -= 1
        return d

    def ajustar_vencimento(self, d):
        """Leva a data para o dia util efetivo de pagamento.

        Reproduz o comportamento do codigo da mesa: recua um dia util e
        avanca um. Um dia util devolve ele mesmo; um feriado ou fim de
        semana devolve o primeiro dia util seguinte.
        """
        return self.mover(self.mover(d, -1), 1)

    def ultimo_dia_util_do_mes(self, d):
        ultimo = date(d.year, d.month, _calendar.monthrange(d.year, d.month)[1])
        while not self.eh_dia_util(ultimo):
            ultimo -= timedelta(days=1)
        return ultimo


_PADRAO = None


def padrao():
    """Instancia unica sobre o arquivo oficial; o indice custa a montar."""
    global _PADRAO
    if _PADRAO is None:
        _PADRAO = Calendario(carregar_feriados())
    return _PADRAO
```

- [ ] **Step 5: Rode os testes e confirme que passam**

Run: `PYTHONPATH=src python -m pytest tests/test_calendario.py -v`
Expected: PASS, 10 testes

- [ ] **Step 6: Commit**

```bash
git add src/tesouro/calendario.py src/tesouro/config.py tests/test_calendario.py
git commit -m "Adiciona calendario de dias uteis com indice pre-computado"
```

---


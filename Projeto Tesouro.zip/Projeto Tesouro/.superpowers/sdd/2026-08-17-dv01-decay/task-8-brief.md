### Task 8: Resultado realizado mês a mês (Conta A)

**Files:**
- Modify: `src/tesouro/dv.py`
- Test: `tests/test_resultado.py`

**Interfaces:**
- Consumes: `dv.painel()`, `calendario`, `precificacao`
- Produces:
  - `dv.resultado_mensal() -> DataFrame` — colunas `data_ini, data_fim, isin, titulo, venceu_no_periodo, quantidade_mil_ini, pu_ini, pu_fim, resultado_milhoes`
  - `dv.gravar_resultado() -> None` — escreve `resultado_mensal.csv`
  - `dv.variacao_de_dv() -> DataFrame` — colunas `data, titulo, dv_milhoes, variacao_milhoes`

**Contexto:** esta é a **Conta A** da spec, e ela tem duas metades com convenções de posição diferentes. Ler a §4 da spec antes de começar.

**O resultado em dinheiro é sobre a posição congelada no início do período.** O papel emitido no dia 20 não deu lucro nem prejuízo a quem estava posicionado no dia 1º. Então: pega a quantidade de `data_ini`, e reprecifica com o PU de `data_fim`.

`resultado_milhoes = (pu_fim − pu_ini) × quantidade_mil_ini / 1000`

**Papel que vence dentro do período é marcado, não somado junto** — mesma razão do decay. Para ele, `pu_fim` fica **vazio**: não sabemos a que preço o dinheiro foi reinvestido, e inventar uma hipótese de reinvestimento aqui seria embutir uma decisão de análise dentro da camada de dados. Quem analisar decide.

**A variação do DV é sobre o estoque real de cada data**, não sobre a posição congelada — ela responde "quanto risco o mercado passou a carregar", e emissão e resgate fazem parte da resposta. Como isso é uma agregação simples do painel, **não vira tabela**: é a função `variacao_de_dv()`, calculada na hora, coerente com a regra de não persistir derivado.

- [ ] **Step 1: Escreva os testes que falham**

```python
# tests/test_resultado.py
import pandas as pd
import pytest
from tesouro import dv


@pytest.fixture(scope="module")
def r():
    return dv.resultado_mensal()


@pytest.fixture(scope="module")
def v():
    return dv.variacao_de_dv()


def test_colunas_canonicas(r):
    assert list(r.columns) == [
        "data_ini", "data_fim", "isin", "titulo", "venceu_no_periodo",
        "quantidade_mil_ini", "pu_ini", "pu_fim", "resultado_milhoes",
    ]


def test_periodos_sao_meses_consecutivos(r):
    pares = r[["data_ini", "data_fim"]].drop_duplicates()
    assert (pd.to_datetime(pares["data_fim"]) > pd.to_datetime(pares["data_ini"])).all()
    dias = (pd.to_datetime(pares["data_fim"]) - pd.to_datetime(pares["data_ini"])).dt.days
    assert dias.between(26, 35).all()


def test_quantidade_e_a_do_inicio_do_periodo(r):
    # A posicao e congelada: papel emitido no meio do mes nao entra.
    p = dv.painel()
    uma = r[r["quantidade_mil_ini"].notna()].iloc[0]
    no_painel = p[(p["data"] == uma["data_ini"]) & (p["isin"] == uma["isin"])]
    assert no_painel["quantidade_mil"].iloc[0] == pytest.approx(uma["quantidade_mil_ini"])


def test_papel_que_venceu_fica_marcado_e_sem_pu_final(r):
    venceu = r[r["venceu_no_periodo"]]
    assert len(venceu) > 0
    assert venceu["pu_fim"].isna().all()
    assert venceu["resultado_milhoes"].isna().all()


def test_resultado_e_a_diferenca_de_pu_vezes_a_quantidade(r):
    x = r[r["resultado_milhoes"].notna()].head(300)
    esperado = (x["pu_fim"] - x["pu_ini"]) * x["quantidade_mil_ini"] / 1000
    assert (esperado - x["resultado_milhoes"]).abs().max() < 1e-9


def test_resultado_tem_os_dois_sinais(r):
    # Ha meses de alta e de queda de taxa; se so houver um sinal, algo
    # esta errado na convencao.
    s = r["resultado_milhoes"].dropna()
    assert (s > 0).any() and (s < 0).any()


def test_ordem_de_grandeza_do_resultado_mensal(r):
    # O resultado de um mes da carteira inteira fica na casa de dezenas de
    # bilhoes de reais no maximo -- ou seja, dezenas de milhares de milhoes.
    por_mes = r.groupby("data_fim")["resultado_milhoes"].sum().abs()
    assert por_mes.max() < 500000


def test_variacao_de_dv_usa_o_estoque_real(v):
    assert list(v.columns) == ["data", "titulo", "dv_milhoes", "variacao_milhoes"]
    assert set(v["titulo"].unique()) <= {"LTN", "NTN-F", "NTN-B"}
    # A primeira data de cada titulo nao tem variacao.
    assert v.groupby("titulo")["variacao_milhoes"].apply(lambda s: s.isna().sum()).eq(1).all()


def test_variacao_e_a_diferenca_do_dv_entre_meses(v):
    for _, g in v.groupby("titulo"):
        g = g.sort_values("data")
        esperado = g["dv_milhoes"].diff()
        assert (esperado - g["variacao_milhoes"]).abs().max() < 1e-9
```

- [ ] **Step 2: Rode e confirme que falham**

Run: `PYTHONPATH=src python -m pytest tests/test_resultado.py -v`
Expected: FAIL com `AttributeError: module 'tesouro.dv' has no attribute 'resultado_mensal'`

- [ ] **Step 3: Acrescente as duas funções ao `dv.py`**

```python
_COLUNAS_RESULTADO = [
    "data_ini", "data_fim", "isin", "titulo", "venceu_no_periodo",
    "quantidade_mil_ini", "pu_ini", "pu_fim", "resultado_milhoes",
]


def resultado_mensal():
    """Conta A: resultado em dinheiro sobre a posicao congelada.

    A posicao e a do inicio do periodo, reprecificada com o PU do fim: o
    papel emitido no dia 20 nao deu lucro nem prejuizo a quem estava
    posicionado no dia 1o.

    Papel que vence dentro do periodo fica marcado e com pu_fim vazio. Nao
    sabemos a que preco o dinheiro foi reinvestido, e arbitrar uma hipotese
    de reinvestimento aqui embutiria decisao de analise na camada de dados.
    """
    cal = calendario.padrao()
    p = painel()
    p = p[p["titulo"] != "LFT"]

    datas = sorted(p["data"].unique())
    por_data = {d: g.set_index("isin") for d, g in p.groupby("data")}

    linhas = []
    for ini, fim in zip(datas, datas[1:]):
        antes, depois = por_data[ini], por_data[fim]
        for isin, r in antes.iterrows():
            venceu = cal.ajustar_vencimento(r["vencimento"]) <= fim
            pu_fim = None
            if not venceu and isin in depois.index:
                pu_fim = depois.loc[isin, "pu"]
                if pd.isna(pu_fim):
                    pu_fim = None
            resultado = None
            if pu_fim is not None and not pd.isna(r["pu"]):
                resultado = (pu_fim - r["pu"]) * r["quantidade_mil"] / 1000
            linhas.append((ini, fim, isin, r["titulo"], venceu,
                           r["quantidade_mil"], r["pu"], pu_fim, resultado))

    return pd.DataFrame(linhas, columns=_COLUNAS_RESULTADO).sort_values(
        ["data_fim", "titulo", "isin"]
    ).reset_index(drop=True)


def variacao_de_dv():
    """Conta A, outra metade: variacao do DV sobre o estoque REAL.

    Diferente do resultado, aqui a posicao nao e congelada -- emissao e
    resgate fazem parte da resposta a pergunta "quanto risco o mercado
    passou a carregar".

    Nao vira tabela: e agregacao simples do painel, e o projeto nao
    persiste derivado.
    """
    p = painel()
    p = p[(p["titulo"] != "LFT") & p["dv_posicao_milhoes"].notna()]
    por = (p.groupby(["data", "titulo"])["dv_posicao_milhoes"].sum()
             .reset_index().rename(columns={"dv_posicao_milhoes": "dv_milhoes"}))
    por = por.sort_values(["titulo", "data"])
    por["variacao_milhoes"] = por.groupby("titulo")["dv_milhoes"].diff()
    return por.reset_index(drop=True)


def gravar_resultado():
    config.PROCESSED_DIR.mkdir(parents=True, exist_ok=True)
    df = resultado_mensal()
    saida = config.PROCESSED_DIR / "resultado_mensal.csv"
    df.to_csv(saida, index=False, encoding="utf-8")
    print(f"gravado: {saida} ({len(df)} linhas)")
```

- [ ] **Step 4: Rode os testes e confirme que passam**

Run: `PYTHONPATH=src python -m pytest tests/test_resultado.py -v`
Expected: PASS, 9 testes

- [ ] **Step 5: Grave e olhe os números**

Run: `PYTHONPATH=src python -c "import sys; sys.path.insert(0,'src'); from tesouro import dv; dv.gravar_resultado(); r=dv.resultado_mensal(); print(r.groupby('data_fim')['resultado_milhoes'].sum().tail(6))"`

Expected: grava `resultado_mensal.csv` e imprime o resultado dos últimos seis meses. Confira que os valores têm ordem de grandeza plausível e que há meses positivos e negativos.

- [ ] **Step 6: Commit**

```bash
git add src/tesouro/dv.py tests/test_resultado.py
git commit -m "Adiciona o resultado realizado mes a mes (Conta A)"
```

---


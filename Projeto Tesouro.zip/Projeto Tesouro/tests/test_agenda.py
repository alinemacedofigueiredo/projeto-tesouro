"""A agenda de leiloes: o que o Tesouro planeja ofertar, e a pagina que a mostra.

O RISCO DESTA PAGINA E ESPECIFICO, e nao e calcular errado. E o leitor tomar por
previsao uma coisa que nao e. O calendario diz QUAIS benchmarks vao a mercado; a
quantidade so sai no edital das 10h30 do proprio dia.

Entao os testes cobrem, alem dos numeros, as MARCAS que impedem essa leitura: a
hachura da barra suposta, o aviso da taxa velha, e o texto que diz de onde vem cada
coisa.

Nao tocam a rede: rodam contra a amostra congelada em tests/fixtures/api_leiloes/.
"""
import json
import pathlib

import matplotlib
matplotlib.use("Agg")
import re

import pandas as pd
import pytest

from tesouro import agenda, config
from tesouro.graficos import cronograma, painel_agenda

FIXTURES = pathlib.Path(__file__).parent / "fixtures" / "api_leiloes"

# O calendario congelado vai de 20/08 a 29/09/2026; um "hoje" fixo mantem o teste
# igual amanha. Data movel em teste e teste que quebra sozinho num dia qualquer.
HOJE = "2026-08-21"


@pytest.fixture(scope="module")
def registros():
    return json.loads((FIXTURES / "calendario.json").read_text(
        encoding="utf-8"))["registros"]


@pytest.fixture(scope="module")
def base_ate_hoje():
    """O historico de taxas COMO ELE ERA EM 21/08, e nao como esta hoje.

    ESTE E O CONSERTO DE UM LOOK-AHEAD, achado em 09/09/2026 quando os leiloes
    de 27/08 a 08/09 entraram no projeto. O calendario ja era congelado e o
    "hoje" ja era fixo -- mas o historico de taxas nao: agenda.proximos() le
    leiloes_recentes.completo() do disco. Enquanto o dado vivo parava perto de
    21/08 ninguem via; assim que passou, o teste comparava um dia de leilao de
    21/08 com a taxa do leilao de 08/09.

    Quatro testes ficaram vermelhos de uma vez, e um deles era justamente o que
    diz "a invariante de verdade e que a taxa nao venha do FUTURO" -- ele
    pegou. Os outros tres reclamavam de nao existir taxa velha, que e o mesmo
    defeito visto de outro angulo: com taxa de 08/09 nada tem 45 dias.

    NAO E DEFEITO DE PRODUCAO. La o "hoje" e hoje e a taxa vem sempre do
    passado. Era a mistura de data congelada com dado vivo, dentro do teste.
    """
    from tesouro import leiloes_recentes

    base = leiloes_recentes.completo("aceito")
    return base[base["data_leilao"] <= pd.Timestamp(HOJE)]


@pytest.fixture(scope="module")
def dados(registros, base_ate_hoje):
    return agenda.proximos(registros=registros, hoje=HOJE,
                           base=base_ate_hoje)


# --------------------------------------------------------------------------
# Os dados
# --------------------------------------------------------------------------

def test_a_BASE_DO_TESTE_nao_conhece_o_futuro(base_ate_hoje):
    """A guarda do proprio teste, e nao do codigo.

    O defeito de 09/09/2026 nao estava na producao: estava aqui, em congelar a
    DATA e deixar o HISTORICO vivo. Ficou latente por semanas e so apareceu
    quando o dado passou de 21/08 -- e apareceu como quatro testes vermelhos
    que pareciam falar de outra coisa.

    Esta linha faz a mistura ficar impossivel de repetir em silencio.
    """
    assert len(base_ate_hoje) > 0, "a base congelada ficou vazia"
    assert (base_ate_hoje["data_leilao"] <= pd.Timestamp(HOJE)).all(), (
        "o historico do teste tem leilao depois do 'hoje' congelado")


def test_a_agenda_olha_so_para_a_frente(dados):
    # Leilao que ja aconteceu nao e agenda: ele esta na pagina de emissoes, com
    # numero de verdade. Mistura-los daria duas versoes do mesmo dia.
    assert len(dados) > 0
    assert (dados["data_leilao"] >= pd.Timestamp(HOJE)).all()


def test_cada_linha_da_agenda_sabe_de_que_leilao_veio_a_taxa(dados):
    # A taxa e sempre a do ULTIMO leilao daquele papel. Sem a data ao lado, nao ha
    # como julgar se ela ainda vale.
    assert dados["taxa_pct"].notna().all()
    assert dados["taxa_de_quando"].notna().all()
    # MENOR OU IGUAL, e nao menor. O papel pode ir a leilao HOJE e estar na
    # agenda de hoje: assim que o resultado sai, a taxa dele passa a ser a do
    # proprio dia. A invariante de verdade e que a taxa nao venha do FUTURO.
    # Quebrou em 25/08/2026, quando o resultado do dia entrou antes de a agenda
    # do dia sair de cena.
    assert (dados["taxa_de_quando"] <= dados["data_leilao"]).all()


def test_a_taxa_velha_e_sinalizada(dados):
    # Os 11 bp de erro foram medidos com o leilao anterior em ate 45 dias. Alem
    # disso o mercado ja e outro, e o erro deixa de ser o que esta medido.
    esperado = dados["taxa_dias_de_idade"] > agenda.DIAS_ATE_A_TAXA_ENVELHECER
    assert list(dados["taxa_velha"]) == list(esperado)
    # E o calendario vai longe o bastante para haver ao menos uma.
    assert dados["taxa_velha"].any()


def test_o_dv_unitario_encurta_conforme_o_leilao_se_afasta(dados):
    # O DV01 unitario NAO e constante por papel ao longo da agenda, e nao deveria
    # ser: cada dia de leilao liquida um dia depois, entao o prazo restante encurta
    # e o DV cai em modulo. A primeira versao deste teste exigia constancia e
    # acusou o codigo por um erro que era meu.
    #
    # O que se trava aqui e o SENTIDO: leilao mais tarde, DV menor em modulo. Se
    # crescesse, a precificacao estaria errada de um jeito grosseiro.
    com_dv = dados[dados["dv_unitario"].notna()]
    assert len(com_dv) > 0
    repetidos = 0
    for benchmark, g in com_dv.groupby("benchmark"):
        if len(g) < 2:
            continue
        repetidos += 1
        valores = list(g.sort_values("data_leilao")["dv_unitario"])
        assert valores == sorted(valores, reverse=True), benchmark
    assert repetidos > 0, "a agenda precisa repetir algum benchmark"


def test_a_quantidade_nao_entra_no_dv_unitario(dados):
    # O numero mais firme da pagina e o que nao depende de quantidade. Duas linhas
    # do mesmo papel, com ofertas anteriores diferentes, no MESMO dia, teriam de dar
    # o mesmo DV -- e como o calendario nao repete papel no mesmo dia, a checagem e
    # pela formula: o DV nao muda quando a oferta muda.
    from tesouro import agenda as mod

    uma = dados[dados["dv_unitario"].notna()].iloc[[0]].copy()
    esperado = float(uma.iloc[0]["dv_unitario"])
    uma["oferta_anterior_qtd"] = uma["oferta_anterior_qtd"] * 1000
    assert mod._dv_unitario(uma)[0] == pytest.approx(esperado)


def test_o_dv_unitario_e_POSITIVO_e_cresce_com_o_vertice(dados):
    # Convencao de RISCO EMITIDO (docs/convencoes-dv.md): positivo e o Tesouro
    # emitindo. A mesma do dv_emitido_por_leilao.csv -- se as duas divergissem, o
    # numero da agenda e o do historico teriam sinais diferentes na mesma tela.
    com_dv = dados[dados["dv_unitario"].notna()].drop_duplicates("benchmark")
    assert (com_dv["dv_unitario"] > 0).all()

    # E cresce com o prazo. Se nao crescesse, a precificacao estaria errada de um
    # jeito grosseiro.
    ntnb = com_dv[com_dv["titulo"] == "NTN-B"].sort_values("vertice_anos")
    valores = list(ntnb["dv_unitario"])
    assert valores == sorted(valores)


def test_a_lft_entra_na_agenda_mas_sem_dv(dados):
    # Sem DV por DECISAO DE MODELAGEM (premissa de duration zero, entrega 2), e nao
    # por falha de calculo: ela aparece no cronograma, que e sobre o que vai a
    # mercado, e nao na conta de risco.
    from tesouro import leiloes_dv

    lft = dados[dados["titulo"] == "LFT"]
    assert len(lft) > 0
    assert lft["dv_unitario"].isna().all()

    # A DECISAO ESTA DECLARADA em SEM_DV, e e o que este teste trava. Quebrar a
    # guarda em agenda._dv_unitario NAO faz o teste falhar, e isso e um fato sobre o
    # projeto e nao um descuido: precificacao.dv ja devolve None para LFT sozinha.
    # A guarda daqui e cinto e suspensorio -- dizer isso e melhor que fingir que ela
    # protege alguma coisa.
    assert "LFT" in leiloes_dv.SEM_DV


def test_o_dv_se_repetir_e_o_produto_declarado(dados):
    # Nao e previsao, e uma multiplicacao -- e o teste diz por qual numero.
    com = dados[dados["dv_unitario"].notna()
                & dados["oferta_anterior_qtd"].notna()]
    assert len(com) > 0
    esperado = com["dv_unitario"] * com["oferta_anterior_qtd"] / 1e6
    assert com["dv_se_repetir"].round(9).equals(esperado.round(9))


def test_a_familia_da_ntnb_usa_o_vertice_do_benchmark(dados):
    # A mesma regra dos graficos de emissao, e vinda da mesma fonte: o rotulo do
    # Tesouro. Se as duas paginas classificassem diferente, a mesma NTN-B apareceria
    # como curta numa e longa na outra.
    ntnb = dados[dados["titulo"] == "NTN-B"]
    curta = ntnb[ntnb["familia"] == "NTN-B at\u00e9 10 anos"]
    longa = ntnb[ntnb["familia"] == "NTN-B acima de 10 anos"]
    assert len(curta) > 0 and len(longa) > 0
    # LE A CONSTANTE. O 5 estava escrito na mao aqui, e em 25/09/2026 o corte
    # foi para 10: o teste ficou vermelho sem ter nada a ver com o assunto dele,
    # que e as duas paginas classificarem IGUAL, pelo vertice.
    from tesouro.leiloes_dv import CORTE_NTNB_ANOS

    assert (curta["vertice_anos"] <= CORTE_NTNB_ANOS).all()
    assert (longa["vertice_anos"] > CORTE_NTNB_ANOS).all()


def test_a_liquidacao_suposta_e_o_proximo_dia_util(dados):
    # D+1 pelo calendario de feriados do projeto, e nao pela data do leilao
    # anterior: o DV varia com o prazo restante, e uma data velha o mediria no dia
    # errado.
    from tesouro import calendario

    cal = calendario.padrao()
    dia = pd.Timestamp("2026-09-03")
    assert agenda._proximo_util(cal, dia) == cal.mover(dia.date(), 1)


def test_por_dia_soma_o_dia_e_marca_a_taxa_velha(dados):
    por_dia = agenda.por_dia(dados)
    assert len(por_dia) == dados["data_leilao"].nunique()
    assert por_dia["papeis"].sum() == len(dados)
    assert por_dia["alguma_taxa_velha"].any()


# --------------------------------------------------------------------------
# O desenho
#
# Os TRES graficos anteriores -- cronograma de pontos, DV por titulo, e "DV se
# repetir a ultima oferta" -- foram recusados na revisao de 20/08/2026 e sairam
# junto com os testes deles. O que entrou responde uma pergunta que nenhuma
# outra pagina responde: ele nao conseguiu colocar, ou nao quis?
#
# E os "ultimos seis" sao seis PREGOES, e nao seis de cada papel. A versao por
# familia cobria periodos diferentes em cada bloco e nao permitia somar o dia --
# que e justamente a leitura que interessa.
# --------------------------------------------------------------------------

@pytest.fixture(scope="module")
def por_dia():
    return agenda.ultimos_dias()


@pytest.fixture(scope="module")
def lft():
    return agenda.ultimos_de("LFT")


def test_os_ultimos_leiloes_sao_PREGOES_e_nao_seis_de_cada_papel(por_dia):
    # O DEFEITO QUE ISTO CONSERTA: contando por familia, o grafico mostrava vinte e
    # quatro linhas cobrindo periodos diferentes em cada bloco -- de 14/07 a 20/08 no
    # prefixado e de 14/07 a 18/08 na NTN-B -- e nao dava para somar o dia.
    assert not por_dia.empty
    assert por_dia["data_leilao"].nunique() == agenda.LEILOES_NA_COMPARACAO
    # Varias familias por leilao, e nem toda familia em todo leilao: LFT e NTN-B vao
    # a mercado num dia e o prefixado no outro.
    por_leilao = por_dia.groupby("data_leilao")["familia"].nunique()
    assert por_leilao.min() >= 2
    assert por_dia.groupby("familia")["data_leilao"].nunique().min() < len(por_leilao)


def test_quantos_atras_numera_os_leiloes_do_mais_recente(por_dia):
    ordem = por_dia.drop_duplicates("data_leilao").sort_values("quantos_atras")
    assert list(ordem["quantos_atras"]) == list(range(len(ordem)))
    # 0 e o mais recente.
    assert ordem.iloc[0]["data_leilao"] == por_dia["data_leilao"].max()


def test_o_total_do_dia_e_a_soma_das_familias(por_dia):
    # E o numero que ela pediu: quanto risco entrou no mercado naquele leilao. Com a
    # barra empilhada, nenhuma fatia sozinha o mostra.
    total = agenda.total_por_dia(por_dia)
    assert len(total) == por_dia["data_leilao"].nunique()
    for _, r in total.iterrows():
        do_dia = por_dia[por_dia["data_leilao"] == r["data_leilao"]]
        assert r["dv_aceito"] == pytest.approx(do_dia["dv_aceito"].sum())
        assert r["dv_ofertado"] == pytest.approx(do_dia["dv_ofertado"].sum())
        assert r["papeis"] == do_dia["papeis"].sum()


def test_o_aceito_nunca_passa_do_ofertado(por_dia):
    com_dv = por_dia[por_dia["dv_ofertado"] > 0]
    assert len(com_dv) > 0
    assert (com_dv["dv_aceito"] <= com_dv["dv_ofertado"] * 1.001).all()


def test_o_grafico_desenha_uma_linha_por_LEILAO(por_dia):
    import matplotlib.pyplot as plt
    from tesouro.graficos import cronograma

    fig, ax = plt.subplots()
    cronograma.desenha_ofertado_e_aceito(por_dia, ax)
    rotulos = [r.get_text() for r in ax.get_yticklabels()]
    assert len(rotulos) == por_dia["data_leilao"].nunique()
    assert len(set(rotulos)) == len(rotulos), "datas repetidas no eixo"
    plt.close(fig)


def test_a_barra_do_leilao_vem_EMPILHADA_por_papel(por_dia):
    # Sem empilhar, a soma do dia apagaria a composicao: num dia de prefixado a LTN
    # e a NTN-F somam, e saber qual das duas pesou e metade da leitura.
    import matplotlib.pyplot as plt
    from tesouro.graficos import cronograma

    fig, ax = plt.subplots()
    cronograma.desenha_ofertado_e_aceito(por_dia, ax)
    familias = [f for f in cronograma.FAMILIAS_COM_DV
                if f in set(por_dia["familia"])]
    dias = por_dia["data_leilao"].nunique()
    # Duas barras (ofertado e aceito) por familia por dia -- as vazias tambem sao
    # desenhadas, com comprimento zero, e e isso que mantem a pilha alinhada.
    assert len(ax.patches) == 2 * dias * len(familias)
    plt.close(fig)


def test_a_LFT_fica_de_fora_do_grafico_de_DV(por_dia):
    # Sem DV por decisao de modelagem: uma fatia de espessura zero dentro da pilha
    # nao se distingue de ausencia.
    from tesouro.graficos import cronograma

    assert "LFT" in set(por_dia["familia"])
    assert "LFT" not in cronograma.FAMILIAS_COM_DV


def test_o_grafico_da_LFT_usa_quantidade_e_escreve_o_financeiro(lft):
    # Ela nao tem DV, entao a comparacao e em titulos -- e o financeiro entra como
    # rotulo porque e a grandeza que se compara com o resto do projeto.
    import matplotlib.pyplot as plt
    from tesouro.graficos import cronograma

    assert len(lft) == agenda.LEILOES_DA_LFT
    fig, ax = plt.subplots()
    cronograma.desenha_quantidade_lft(lft, ax)
    assert len(ax.patches) == 2 * agenda.LEILOES_DA_LFT
    assert "t\u00edtulos" in ax.get_xlabel()
    textos = " ".join(a.get_text() for a in ax.texts)
    assert "R$" in textos and "bi" in textos
    plt.close(fig)


# --------------------------------------------------------------------------
# A pagina
# --------------------------------------------------------------------------

@pytest.fixture(scope="module")
def pagina(tmp_path_factory, registros, monkeypatch_module, base_ate_hoje):
    """A pagina montada a partir da AMOSTRA CONGELADA, e nao da API.

    O monkeypatch estava sendo pedido e nao usado: a fixture recebia 'registros' e
    'monkeypatch_module' e nao amarrava um no outro. painel_agenda.grava chama
    agenda.proximos() SEM registros, e proximos() sem registros vai a rede.

    Passou despercebido porque a API respondia. Em 21/08/2026 ela nao respondeu, e
    dezessete testes deste arquivo quebraram com ConnectionError -- num commit que
    nao tocava em nada disso. Teste que depende da rede e teste que um dia acusa
    quem nao tem culpa, e o docstring deste arquivo ja prometia o contrario.
    """
    from tesouro import api_leiloes

    # O ALARME DE REDE FICA, e nao deve disparar nunca: desde 20/10/2026 o
    # calendario e lido do DISCO (api_leiloes.calendario_publicado), e quem
    # desenha pagina nao toca a rede -- e o que o README do projeto promete.
    # Se este stub disparar, alguem pos rede de volta no caminho de desenho.
    def nao_va_a_rede(nome, timeout=None):
        raise AssertionError(
            "a pagina foi a rede pedir '%s'; o calendario vem do disco" % nome)

    monkeypatch_module.setattr(api_leiloes, "buscar", nao_va_a_rede)

    # E A AMOSTRA CONGELADA ENTRA PELO LUGAR NOVO. Ela chegava por dentro do
    # 'buscar'; agora chega por onde o calendario de fato entra.
    def do_disco_congelado(registros_pedidos=None, destino=None):
        if registros_pedidos is not None:
            return registros_pedidos, "injetado", None
        return registros, "disco", None

    monkeypatch_module.setattr(api_leiloes, "calendario_publicado",
                               do_disco_congelado)

    # E O HISTORICO DE TAXAS TAMBEM CONGELADO, pelo mesmo motivo que a fixture
    # 'dados' congela: painel_agenda.grava chama agenda.proximos(hoje=HOJE) sem
    # base, e proximos() sem base le o disco -- que hoje vai muito alem de
    # 21/08. Sem isto a PAGINA e os DADOS deste arquivo passavam a discordar, e
    # o teste que compara os dois quebrava com "1 >= 2" sem que nada estivesse
    # errado no codigo. Achado em 09/09/2026.
    from tesouro import leiloes_recentes

    monkeypatch_module.setattr(leiloes_recentes, "completo",
                               lambda *a, **k: base_ate_hoje)
    destino = tmp_path_factory.mktemp("agenda") / painel_agenda.ARQUIVO
    return painel_agenda.grava(destino, hoje=HOJE).read_text(encoding="utf-8")


@pytest.fixture(scope="module")
def monkeypatch_module():
    from _pytest.monkeypatch import MonkeyPatch

    mp = MonkeyPatch()
    yield mp
    mp.undo()


def test_a_pagina_traz_os_dois_graficos_e_as_duas_tabelas(pagina):
    for g in painel_agenda.REGISTRO:
        assert f'id="{g.id}"' in pagina, g.id
    assert pagina.count("<section") == 2
    assert 'id="tabela-ultimos"' in pagina
    assert 'id="tabela-calendario"' in pagina


def test_a_pagina_tem_TRES_SECOES_recolhiveis(pagina):
    # Sem elas a pagina tem quase dois metros de rolagem. <details>/<summary> e HTML
    # puro: a setinha nao custa uma linha de JavaScript, e o conteudo continua no
    # arquivo -- quem procurar com Ctrl+F acha, e quem imprimir leva tudo.
    import re

    corpo = pagina[pagina.index("<main>"):pagina.index("</main>")]
    achadas = re.findall(r'secao-(\w+)"( open)?><summary>', corpo)
    assert [a[0] for a in achadas] == [chave for chave, _, _ in
                                       painel_agenda.SECOES]

    # A PRIMEIRA ABERTA e as outras fechadas: quem abre a pagina ve os graficos.
    abertas = [bool(a[1]) for a in achadas]
    assert abertas == [aberta for _, _, aberta in painel_agenda.SECOES]
    assert abertas[0] is True


def test_os_graficos_ficam_DENTRO_da_primeira_secao(pagina):
    corpo = pagina[pagina.index("<main>"):pagina.index("</main>")]
    i = corpo.index('secao-graficos')
    j = corpo.index('secao-ultimos')
    assert corpo[i:j].count("<section") == len(painel_agenda.REGISTRO)


def test_o_historico_e_o_calendario_tem_CORES_diferentes(pagina):
    # As duas tabelas tem o mesmo formato de proposito, e a cor e o que diz num
    # relance qual delas se esta lendo -- o que ja aconteceu ou o que ainda vai.
    assert ".secao-ultimos > summary { border-left-color:" in pagina
    assert ".secao-calendario > summary { border-left-color:" in pagina
    # E as duas cores sao diferentes.
    import re

    cores = re.findall(r"\.secao-(?:ultimos|calendario) > summary "
                       r"\{ border-left-color: (#[0-9a-f]{6}); \}", pagina)
    assert len(cores) == 2 and cores[0] != cores[1], cores


def test_a_palavra_agenda_nao_aparece_mais_na_tela(pagina):
    # Ela chama de calendario. Duas palavras para a mesma coisa fazem quem le
    # procurar a diferenca.
    import re

    visiveis = re.findall(r">[^<]*[Aa]genda[^<]*<", pagina)
    assert visiveis == [], visiveis[:2]


def test_o_historico_vem_antes_do_calendario(pagina):
    # A ordem das secoes: graficos, historico, calendario. O que aconteceu explica o
    # que vem, e nao o contrario.
    assert (pagina.index('id="tabela-ultimos"')
            < pagina.index('id="tabela-calendario"'))


def test_a_linha_do_LEILAO_sai_marcada_e_traz_o_total(pagina, por_dia):
    # As duas tabelas tem o mesmo formato; sem a marca elas se parecem demais, e
    # nao fica claro qual e leilao que ja aconteceu. E a linha marcada traz o TOTAL
    # do dia, que e o numero que a abertura por papel sozinha nao da.
    assert pagina.count('class="passado"') == por_dia["data_leilao"].nunique()
    assert "o leil\u00e3o todo" in pagina


def test_a_pagina_diz_que_a_quantidade_nao_esta_no_calendario(pagina):
    # O texto que impede a leitura errada da TABELA da agenda: ela e o que vem pela
    # frente, e o calendario nao traz quantidade.
    assert "n\u00e3o est\u00e1 no calend\u00e1rio" in pagina
    assert "10h30" in pagina


def test_a_tabela_dos_ultimos_separa_ofertado_de_aceito(pagina):
    # A pergunta da pagina inteira. Sem as duas colunas, so da para ver o que ele
    # colocou -- e nao o que tentou colocar.
    assert "DV01 ofertado" in pagina
    assert "DV01 aceito" in pagina
    assert "colocou" in pagina
    # E o DV por TITULO saiu da tabela da agenda: o unitario e propriedade do papel
    # e nao diz nada sobre o tamanho do leilao.
    assert "DV01 por t\u00edtulo" not in pagina


def test_a_tabela_dos_ultimos_desce_ao_nivel_de_PAPEL_E_VENCIMENTO(pagina):
    # MESMO FORMATO da tabela da agenda, de proposito: as duas respondem a mesma
    # pergunta em tempos diferentes -- o que vem e o que veio -- e ler as duas exige
    # que as colunas estejam no mesmo lugar. A versao anterior parava na familia, e
    # ai nao dava para ver que dentro de "NTN-B acima de 10 anos" o corte foi num vencimento so.
    detalhe = agenda.ultimos_leiloes()
    i = pagina.index('id="tabela-ultimos"')
    j = pagina.index('id="tabela-calendario"')
    so_ultimos = pagina[i:j]

    leiloes = detalhe["data_leilao"].nunique()
    # Uma linha de soma por leilao, mais uma por papel-vencimento, mais o cabecalho.
    assert so_ultimos.count("<tr") == leiloes + len(detalhe) + 1
    # E as colunas sao as mesmas da agenda, na mesma ordem.
    for coluna in ("papel", "vencimento", "taxa m\u00e9dia", "ofertou", "aceitou",
                   "DV01 ofertado", "DV01 aceito", "financeiro"):
        assert f">{coluna}<" in so_ultimos, coluna


def test_a_LFT_aparece_na_tabela_sem_DV_mas_com_financeiro(pagina):
    # Ela e mais da metade da emissao: deixa-la de fora esconderia o maior numero
    # do dia. Sem DV01 por decisao de modelagem, com quantidade e financeiro.
    detalhe = agenda.ultimos_leiloes()
    lft = detalhe[detalhe["titulo"] == "LFT"]
    assert len(lft) > 0
    assert lft["dv_aceito"].fillna(0).eq(0).all()
    assert (lft["financeiro_milhoes"] > 0).all()
    assert (lft["qtd_ofertada"] > 0).all()

    i = pagina.index('id="tabela-ultimos"')
    j = pagina.index('id="tabela-calendario"')
    assert "LFT" in pagina[i:j]


def test_a_soma_do_leilao_inclui_a_LFT_no_financeiro(pagina):
    # O DV do dia soma so quem tem DV; o financeiro soma TODOS. Se a LFT ficasse de
    # fora do financeiro, o total do dia sairia ate tres vezes menor -- em 18/08 ela
    # e 29,3 dos 34,5 bilhoes.
    detalhe = agenda.ultimos_leiloes()
    total = agenda.total_dos_leiloes(detalhe)
    for _, r in total.iterrows():
        do_dia = detalhe[detalhe["data_leilao"] == r["data_leilao"]]
        assert r["financeiro_milhoes"] == pytest.approx(
            do_dia["financeiro_milhoes"].sum())
        assert r["dv_aceito"] == pytest.approx(do_dia["dv_aceito"].sum())


def test_a_taxa_da_tabela_e_ponderada_pelo_financeiro(pagina):
    # A media simples trataria um lote de 100 milhoes e um de 10 bilhoes como
    # iguais, o que nao descreve leilao nenhum.
    detalhe = agenda.ultimos_leiloes()
    com_taxa = detalhe[detalhe["taxa_media_pct"].notna()]
    assert len(com_taxa) > 0
    # Faixa de percentual, nunca de fracao: 0,0702 no lugar de 7,02 nao levanta
    # nada, so precifica errado.
    prefixados = com_taxa[com_taxa["titulo"] != "LFT"]
    assert (prefixados["taxa_media_pct"] > 1).all()


def test_a_tabela_do_calendario_tem_uma_linha_por_papel_e_um_cabecalho_por_dia(
        pagina, dados):
    # A pagina tem TRES tabelas desde 25/08/2026, entao a contagem e so do
    # calendario: uma linha por papel, mais um cabecalho por dia, mais o do
    # <thead>.
    #
    # O RECORTE FECHA NA PROPRIA TABELA. Antes ia de "tabela-calendario" ate o
    # FIM DO ARQUIVO, o que so funcionava enquanto esta era a ultima coisa da
    # pagina. Quando a secao da Expectativa entrou depois dela, as linhas da
    # nova foram contadas junto -- 105 onde se esperava 66. O teste estava
    # certo no que media e errado no que recortava.
    i = pagina.index('id="tabela-calendario"')
    so_calendario = pagina[i:pagina.index("</table>", i)]
    assert so_calendario.count('<tr class="dia"') == dados["data_leilao"].nunique()
    assert (so_calendario.count("<tr")
            == len(dados) + dados["data_leilao"].nunique() + 1)


def test_a_tabela_marca_a_taxa_velha(pagina, dados):
    assert pagina.count("\u26a0") >= int(dados["taxa_velha"].sum())
    assert 'class="velha"' in pagina


def test_a_pagina_nao_tem_referencia_externa(pagina):
    import re

    externos = [m.group(1) for m in
                re.finditer(r'(?:src|href|xlink:href)\s*=\s*"([^"]*)"', pagina)
                if "://" in m.group(1)]
    assert externos == [], externos[:3]
    assert "<link" not in pagina


def test_a_barra_liga_as_paginas_irmas(pagina):
    from tesouro.graficos import dashboard

    assert 'id="paginas"' in pagina
    # Uma marca de pagina atual, e nenhuma a mais: duas confundiriam quem le.
    assert pagina.count('class="atual"') == 1
    # E o arquivo desta pagina esta na lista das irmas -- se o nome mudar num lugar
    # e nao no outro, os links das outras paginas quebram em silencio.
    assert painel_agenda.ARQUIVO in [a for a, _ in dashboard.PAGINAS]
    for arquivo, _ in dashboard.PAGINAS:
        if arquivo != painel_agenda.ARQUIVO:
            assert f'href="{arquivo}"' in pagina


def test_a_pagina_tem_a_secao_da_EXPECTATIVA_de_calendario():
    """A quarta secao, pedida por ela em 25/08/2026.

    A pagina tinha tres blocos e mostrava so o que o Tesouro publicou. Faltava o
    lado nosso: quantos dias de leilao ainda estamos contando ate 31/12, para dar
    para bater um contra o outro assim que ele publicar o calendario novo.
    """
    from tesouro.graficos import painel_agenda

    html = painel_agenda.tabela_da_expectativa(
        hoje=pd.Timestamp("2026-08-26"), registros=[])

    assert 'id="tabela-expectativa"' in html
    # As tres situacoes tem de aparecer nomeadas, e nao por cor sozinha.
    assert "estimado" in html
    assert "n\u00e3o consideramos" in html or "nao consideramos" in html


def test_a_expectativa_MOSTRA_os_dias_que_a_regra_descarta():
    """O ponto da secao: a ausencia tem de estar escrita.

    Mostrar so os dias que a gente conta responderia "o que esperamos". Ela
    pediu para ver o que NAO esperamos -- se o Tesouro publicar leilao em 29/12,
    tem de dar para bater o olho e ver que aquela linha estava marcada como fora.
    """
    from tesouro import calendario_leiloes
    from tesouro.graficos import painel_agenda

    hoje = pd.Timestamp("2026-08-26")
    ate = pd.Timestamp("2026-12-31")
    html = painel_agenda.tabela_da_expectativa(hoje=hoje, registros=[])

    contados = set(calendario_leiloes.dias_estimados(hoje, ate))
    possiveis = calendario_leiloes.dias_possiveis(hoje, ate)
    descartados = [d for d in possiveis if d not in contados]
    assert descartados, "a janela do teste tem de conter dia descartado"

    for d in descartados:
        assert f"{d:%d/%m/%Y}" in html, (
            f"{d:%d/%m/%Y} foi descartado pela regra e nao aparece na pagina; "
            f"a ausencia tem de ser visivel")


def test_a_expectativa_separa_o_PUBLICADO_do_ESTIMADO():
    """Palpite e transcricao nao podem ter a mesma cara.

    Onde o Tesouro ja disse, a linha e transcricao e os papeis saem do que ele
    listou. Depois da fronteira e inferencia nossa, pela regra de terca e quinta.
    """
    from tesouro.graficos import painel_agenda

    import json
    import pathlib as _pathlib

    fixtures = _pathlib.Path(__file__).parent / "fixtures" / "api_leiloes"
    registros = json.loads(
        (fixtures / "calendario.json").read_text(encoding="utf-8"))["registros"]

    com = painel_agenda.tabela_da_expectativa(
        hoje=pd.Timestamp("2026-08-26"), registros=registros)
    sem = painel_agenda.tabela_da_expectativa(
        hoje=pd.Timestamp("2026-08-26"), registros=[])

    # NAS LINHAS, e nao na pagina inteira: o rodape resume com "0 dia(s)
    # publicado(s)", e procurar a palavra solta casava com esse resumo. Foi a
    # primeira versao deste teste, e ela reprovava codigo correto.
    def linhas_publicadas(html):
        return len(re.findall(r'<tr class="publicado">', html))

    assert linhas_publicadas(com) > 0, (
        "com o calendario da amostra tem de haver linha transcrita")
    assert linhas_publicadas(sem) == 0, (
        "sem calendario publicado nenhuma linha pode se dizer publicada")
    # E o total de dias contados nao muda: o publicado SUBSTITUI o estimado
    # naquele dia, nao se soma a ele.
    assert com.count("<tr class=") >= linhas_publicadas(com)


def test_o_dia_publicado_depois_da_fronteira_nao_vira_estimado():
    # Em 24/09/2026 a fronteira passou a ser POR PAPEL, e a devolvida por
    # dias_ate virou a do papel MENOS publicado -- 29/09, no calendario real do
    # 4T-2026. Rotular linha por "dia <= fronteira" passou a chamar de estimado
    # as quintas de outubro a dezembro que o Tesouro JA PUBLICOU.
    #
    # A procedencia de uma linha nao e uma data de corte: e se aquele dia esta
    # na lista que o Tesouro publicou. Vai a publicada direto.
    from tesouro.graficos import painel_agenda

    registros = []
    for d in pd.date_range("2026-10-01", "2026-12-17", freq="W-THU"):
        for titulo in ("LTN", "NTN-F"):
            registros.append({"DATA_LEILAO": d.strftime("%Y-%m-%d"),
                              "TITULO": titulo,
                              "VENCIMENTO": "2028-01-01",
                              "TIPO_LEILAO": "Venda",
                              "BENCHMARK": titulo})
    for titulo in ("LFT", "NTN-B"):
        registros.append({"DATA_LEILAO": "2026-09-29",
                          "TITULO": titulo,
                          "VENCIMENTO": "2032-12-01",
                          "TIPO_LEILAO": "Venda",
                          "BENCHMARK": titulo})

    html = painel_agenda.tabela_da_expectativa(
        hoje=pd.Timestamp("2026-09-23"), ate=pd.Timestamp("2026-12-31"),
        registros=registros)

    # 05/11/2026 e uma quinta publicada, bem depois da fronteira de 29/09.
    linha = [x for x in html.split("<tr") if "05/11/2026" in x]
    assert len(linha) == 1, "esperava uma linha para 05/11/2026"
    assert "publicado" in linha[0], (
        "a quinta de 05/11 esta no calendario que o Tesouro publicou, mas a "
        f"tabela nao a marcou como publicada: {linha[0]}")
    # E os papeis tem de vir da lista DELE, nao da nossa regra de dia da semana.
    assert "LTN" in linha[0] and "NTN-F" in linha[0]


def test_os_papeis_do_dia_publicado_vem_da_lista_do_TESOURO():
    # DEFEITO ANTIGO, descoberto em 24/09/2026: _papeis_por_dia usava
    # parse_api_leiloes sem que o modulo jamais o importasse. O NameError caia
    # no `except Exception` e virava {} -- silencioso. A coluna "papeis" das
    # linhas publicadas mostrava travessao desde sempre, e nenhum teste via,
    # porque a rotulagem vinha da data da fronteira e nao desse mapa.
    #
    # A prova tem de DISTINGUIR a lista dele da nossa regra: publica um dia so
    # com LTN. Nossa regra de quinta diria "LTN + NTN-F"; a lista dele diz LTN.
    from tesouro.graficos import painel_agenda

    registros = [{"DATA_LEILAO": "2026-11-05",
                  "TITULO": "LTN",
                  "VENCIMENTO": "2028-01-01",
                  "TIPO_LEILAO": "Venda",
                  "BENCHMARK": "LTN 12 meses"}]

    html = painel_agenda.tabela_da_expectativa(
        hoje=pd.Timestamp("2026-09-23"), ate=pd.Timestamp("2026-12-31"),
        registros=registros)

    linha = [x for x in html.split("<tr") if "05/11/2026" in x]
    assert len(linha) == 1
    assert "LTN" in linha[0]
    assert "NTN-F" not in linha[0], (
        "o Tesouro listou so LTN nesse dia; a tabela acrescentou NTN-F pela "
        f"nossa regra de quinta-feira: {linha[0]}")


def test_papeis_por_dia_nao_engole_erro_de_programacao():
    # O `except Exception` amplo foi o que escondeu o NameError por meses. Um
    # calendario valido tem de devolver os dias -- se voltar {} de novo, e
    # porque alguma excecao esta sendo engolida outra vez.
    from tesouro.graficos import painel_agenda

    registros = [{"DATA_LEILAO": "2026-11-05",
                  "TITULO": "LTN",
                  "VENCIMENTO": "2028-01-01",
                  "TIPO_LEILAO": "Venda",
                  "BENCHMARK": "LTN 12 meses"}]
    mapa = painel_agenda._papeis_por_dia(registros)
    assert mapa, "calendario valido nao pode devolver mapa vazio"
    assert mapa[pd.Timestamp("2026-11-05")] == "LTN"


def test_papel_que_nunca_foi_a_leilao_mostra_travessao_em_vez_de_quebrar():
    # ACHADO EM 24/09/2026, quando o calendario do 4o trimestre trouxe um
    # vertice de LFT novo -- 01/12/2032 -- que nunca tinha ido a leilao. Sem
    # leilao anterior nao ha taxa nem data da taxa, e _celula_taxa formatava a
    # data ANTES da guarda que ja tratava esse caso. Resultado: a agenda inteira
    # parava de ser gravada, com "NaTType does not support strftime", e o
    # pipeline seguia avisando que a pagina ficou com o calendario velho.
    #
    # A guarda ja existia e ja devolvia travessao. So nunca era alcancada.
    from tesouro.graficos import painel_agenda

    sem_leilao_anterior = pd.Series({
        "taxa_pct": float("nan"),
        "taxa_de_quando": pd.NaT,
        "taxa_dias_de_idade": float("nan"),
        "taxa_velha": False,
    })
    assert painel_agenda._celula_taxa(sem_leilao_anterior) == "\u2014"


def test_a_celula_da_taxa_NAO_depende_da_rede_para_ser_testada():
    # A PRIMEIRA VERSAO DESTE TESTE LIA A API AO VIVO e usava pytest.skip
    # quando nao achava vertice estreante. Numa rodada em que a API devolveu
    # "Server Error" ele pulou calado -- um teste que some justamente quando o
    # ambiente esta ruim nao protege nada, e ainda passa a impressao de ter
    # rodado.
    #
    # O vertice estreante e uma FORMA de linha, nao um fato do calendario de
    # hoje: da para construi-la aqui e cobrar o comportamento sempre.
    from tesouro.graficos import painel_agenda

    linhas = pd.DataFrame([
        {"taxa_pct": 14.2, "taxa_de_quando": pd.Timestamp("2026-09-17"),
         "taxa_dias_de_idade": 7.0, "taxa_velha": False},
        {"taxa_pct": float("nan"), "taxa_de_quando": pd.NaT,
         "taxa_dias_de_idade": float("nan"), "taxa_velha": False},
    ])
    celulas = [painel_agenda._celula_taxa(r) for _, r in linhas.iterrows()]
    assert "17/09" in celulas[0], celulas[0]
    assert celulas[1] == "\u2014", (
        "o vertice sem leilao anterior tem de virar travessao, e nao derrubar "
        "a pagina inteira")

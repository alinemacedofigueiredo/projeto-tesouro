# Projeto Tesouro — camada de dados, DV01 e decay

Baixa os dados públicos do Tesouro Nacional (e, para o DV01, também da
Bloomberg) e os converte em CSVs limpos para análise da Dívida Pública
Federal: estoque, funding, custo médio e prazo médio a partir do RMD e dos
leilões; e, a partir da entrega 2, o preço unitário (PU) e o resultado
mensal de LTN, NTN-F, NTN-B e LFT, além do DV01 e do decay de LTN, NTN-F e
NTN-B (a LFT não tem duration de juros por construção — ver
`docs/convencoes-dv.md`).

## Uso rápido

O projeto não instala pacote (decisão deliberada — ver
`docs/superpowers/specs/2026-08-14-camada-de-dados-design.md`, §3): toda
invocação precisa apontar `PYTHONPATH` para `src`.

    pip install -r requirements.txt

Para o modo `hoje` **mandar e-mail** (e só para isso), um pacote a mais:

    pip install -r requirements-envio.txt

Ele fica fora da lista principal de propósito: num ambiente com trava de
download, tê-lo ali faria a instalação inteira falhar, e o projeto não rodaria
nem para gravar as páginas. Sem ele, o modo `hoje` monta os e-mails, grava em
`data/processed` e diz onde ficaram — é só colar.

PowerShell:

    $env:PYTHONPATH="src"; python -m tesouro.pipeline --ano 2026 --mes 6

bash:

    PYTHONPATH=src python -m tesouro.pipeline --ano 2026 --mes 6

Sem acesso à internet (ver `docs/como-baixar.md`):

    $env:PYTHONPATH="src"; python -m tesouro.pipeline --sem-coleta   # PowerShell
    PYTHONPATH=src python -m tesouro.pipeline --sem-coleta           # bash

**Para o dia a dia, rode sem argumento nenhum:**

    $env:PYTHONPATH="src"; python -m tesouro.pipeline

Ele pergunta o que atualizar — o RMD do mês, os leilões do dia, a banda do PAF
que você acabou de editar, ou tudo — e faz só o que aquela fonte move. O passo
a passo de cada caso, o que conferir depois e o que fazer quando falha estão em
**`docs/como-atualizar.md`**, que é o documento de operação deste projeto.

O pipeline grava vinte e dois CSVs em `data/processed/` — dezessete da
camada de dados (RMD e leilões) e cinco do DV01/decay (taxa e VNA da
Bloomberg, painel de DV por papel, decay e resultado mensal). O dicionário
de cada um está em `docs/dicionario-de-dados.md`; as convenções de sinal e
as fórmulas de cálculo estão em `docs/convencoes-dv.md`.

### O dashboard

Os vinte e oito gráficos da dívida em arquivos HTML autocontidos, que abrem com
duplo clique e continuam funcionando copiados para outra máquina ou mandados
por e-mail.

PowerShell:

    $env:PYTHONPATH="src"; python -m tesouro.graficos

bash:

    PYTHONPATH=src python -m tesouro.graficos

Grava **duas** páginas, ligadas pela barra do topo:

| arquivo | tamanho | o que leva |
|---|---|---|
| `data/processed/dashboard.html` | 4,03 MB | o total, estoque, vencimentos, prazo e custo |
| `data/processed/dashboard-funding.html` | 5,60 MB | funding, detentores e reserva de liquidez |

Cada uma com quatro janelas — 12 meses, 3 anos, 5 anos e série completa — e os
botões no cabeçalho que alternam entre elas.

**Por que duas.** O limiar da spec é 10 MB por página, e um teste o guarda. Com
os 28 gráficos numa página só o arquivo chegou a 9,62 MB: sobravam 0,38, e o
próximo gráfico com quatro janelas não caberia. As alternativas eram cortar
janela ou cortar gráfico, e as duas custam informação; dividir custa um clique.
O corte é **por assunto** — a primeira responde de quanto é a dívida, quando ela
vence e quanto custa; a segunda, o que o Tesouro emitiu, que colchão tem e quem
carrega o papel. Os tamanhos são consequência, não critério.

Para um recorte específico, com os botões suprimidos porque só existe uma
janela:

    $env:PYTHONPATH="src"; python -m tesouro.graficos --de 2021-01-01 --ate 2026-06-30
    PYTHONPATH=src python -m tesouro.graficos --de 2021-01-01 --ate 2026-06-30

Com `--de`/`--ate` sai **uma** página só, com todos os gráficos, no caminho de
`--saida` se ele for dado. Serve para inspecionar; não é o formato publicado, e
pode estourar o limiar.

### As outras cinco páginas

O `pipeline` grava mais cinco, que não saem de `python -m tesouro.graficos`
porque não são do RMD — elas mudam em ritmos próprios:

| arquivo | tamanho | o que leva | muda quando |
|---|---|---|---|
| `data/processed/paf.html` | 0,02 MB | onde a dívida está hoje contra a banda do PAF, onde o ano fecha no ritmo atual, e o que fazer para chegar lá | a cada leilão liquidado |
| `data/processed/calendario.html` | 0,19 MB | a agenda do que o Tesouro planeja ofertar | a cada publicação do calendário |
| `data/processed/emissoes.html` | 6,78 MB | o que já foi emitido (só venda, com 2ª volta) | a cada leilão |
| `data/processed/emissoes-1a-volta.html` | 6,79 MB | idem, só 1ª volta | a cada leilão |
| `data/processed/emissoes-com-compra.html` | 6,83 MB | idem, venda e compra | a cada leilão |

**Por que separadas do dashboard.** O corte não é só de assunto, é de **cadência**:
as duas páginas do RMD mudam uma vez por mês, e a do PAF muda toda semana.
Enterrar uma tabela semanal num arquivo de 4 MB obriga a reescrever 4 MB para
mudar uma linha. A do PAF é minúscula porque não tem gráfico nenhum — são duas
tabelas.

A página do PAF é a única que precisa do calendário da API. Com `--sem-coleta`
ela é gravada assim mesmo, estimando o calendário, e o rodapé dela passa a dizer
"calendário inteiramente estimado" em vez de "publicado até DD/MM". A diferença
não é decorativa: são 34 dias de leilão até 31/12 pelo publicado contra 36
estimando tudo.

O `pipeline` já gera o dashboard no fim, depois de reescrever os CSVs; o
comando acima serve para regerar sem rodar o pipeline inteiro.

### A suíte precisa que o pipeline tenha rodado

**Boa parte dos testes lê CSVs de `data/processed/`**, que é gerado e fica fora do
git. Num clone novo eles falham até você rodar o pipeline uma vez:

    $env:PYTHONPATH="src"; python -m pytest -q          # muitas falhas num clone novo
    $env:PYTHONPATH="src"; python -m tesouro.pipeline --sem-coleta
    $env:PYTHONPATH="src"; python -m pytest -q          # 773 passed, 1 skipped

A última contagem exata de quantos dependem do pipeline é de 21/08/2026: **155 de
451**. A proporção não foi remedida desde então — a suíte cresceu para 774 — e
está aqui como ordem de grandeza, não como número atual.

Não é defeito: são as âncoras de valor, que existem justamente para conferir número
real contra as páginas do RMD — um teste que não lê o dado não pegaria erro de
parser. O pipeline, por sua vez, precisa do anexo do RMD em `data/raw/rmd/`
(ver `docs/como-baixar.md`).

O teste pulado é o do PU contra o `PX_DIRTY_MID` da Bloomberg, que aguarda
autorização para puxar os arquivos de preço.

### Cálculo pontual: quanto do DV01 desaparece até uma data escolhida

Além do pipeline, há um comando específico para uma pergunta do dia a dia —
"da posição de hoje, quanto do meu DV01 some até tal data, e quanto disso é
vencimento em vez de queda de risco de mercado" — sem precisar regravar
nenhum CSV:

PowerShell:

    $env:PYTHONPATH="src"; python -m tesouro.dv --alvo 31/12/2027

bash:

    PYTHONPATH=src python -m tesouro.dv --alvo 31/12/2027

O comando usa o painel já gravado em `data/processed/dv_por_papel.csv` (rode
o pipeline pelo menos uma vez antes) e imprime a decomposição — DV na
data-base, o que vence no caminho, o decay dos sobreviventes, DV na
data-alvo — junto com a cobertura do DV01 sobre o estoque naquela data
específica. `--base DD/MM/AAAA` escolhe outra data de partida (o padrão é o
último fim de mês do painel); `--gravar` regrava os três CSVs de DV01/decay/
resultado em vez de calcular o pontual. Detalhe completo do que cada número
significa, e por que a cobertura do DV01 muda de mês a mês, em
`docs/convencoes-dv.md`.

## Como o projeto está organizado

O fluxo é sempre `fetch → data/raw/ → parse → data/processed/`. Os
coletores (`fetch_*`) baixam arquivos; os parsers (`parse_*`) leem apenas
de `data/raw/` e nunca acessam a rede. É isso que permite rodar o projeto
em ambiente fechado: basta colocar os arquivos na pasta manualmente. O
mesmo desenho vale para a Bloomberg: `fetch_bloomberg.py` fala com o
terminal (se ele existir na máquina); `parse_bloomberg.py` só lê
`data/raw/bloomberg/`. Num ambiente de banco sem `blpapi`, a exportação sai
por `BDH` para Excel e cai na mesma pasta, sem mudar nenhum código — ver
`docs/como-baixar.md`.

Arquivos em `data/raw/` nunca são modificados. Se o Tesouro republicar um
mês, entra um arquivo novo e o antigo permanece; o mesmo vale para a
Bloomberg, cuja coleta é incremental (nunca sobrescreve, só acrescenta
arquivos novos — ver `docs/convencoes-dv.md`, seção "Recuperando um
arquivo apagado à mão").

## Documentação

- `docs/fontes-de-dados.md` — de onde vem cada dado
- `docs/dicionario-de-dados.md` — o que há em cada CSV
- `docs/como-baixar.md` — download manual, para ambiente sem rede
- `docs/convencoes-dv.md` — convenções de sinal, fórmulas de PU e DV01, e as
  armadilhas medidas na Bloomberg e no RMD — confira aqui antes de qualquer
  conta que envolva sinal, taxa ou cobertura do DV01
- `docs/superpowers/specs/` — decisões de design e por quê

## Testes

    python -m pytest tests/ -v

(`tests/conftest.py` já ensina o Python a achar o código em `src/` sozinho,
então os testes não precisam de `PYTHONPATH` — ao contrário dos outros
comandos deste documento.)

Os testes em `tests/test_coerencia.py` e `tests/test_coerencia_dv.py`
cruzam tabelas independentes entre si. São os mais importantes: um parser
errado raramente quebra, ele produz números plausíveis e falsos.

A suíte roda com **1 teste pulado** (`skipped`), não uma falha: o teste que
compara o PU calculado com o preço da Bloomberg
(`test_pu_reproduz_o_preco_da_bloomberg_com_deslocamento_de_d1`) exige o
arquivo `data/raw/bloomberg/bbg_precos_*.csv`, que depende de uma consulta à
Bloomberg ainda não autorizada. Ver `docs/convencoes-dv.md`, seção
"Verificação pendente de autorização", para o comando que gera esse
arquivo.
